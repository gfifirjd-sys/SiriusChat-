package com.sirius.chat.ai.provider

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.AiContentPart
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.streaming.SseParser
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.ProviderConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.job
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Speaks the `/chat/completions` protocol, which covers OpenAI itself plus
 * OpenRouter, Groq, Together, vLLM, LM Studio, Ollama and most self-hosted
 * gateways.
 */
class OpenAiCompatibleProvider(
    private val config: ProviderConfig,
    private val apiKey: String?,
    private val client: OkHttpClient = HttpClientProvider.client
) : AiProvider {

    override val id: String = config.id
    override val label: String = config.label
    override val models: List<AiModel> = config.models

    private val json = Json { ignoreUnknownKeys = true }

    override fun chat(request: ChatRequest): Flow<ChatStreamEvent> = flow {
        emit(ChatStreamEvent.Started)

        val payload = buildJsonObject {
            put("model", request.model)
            put("temperature", request.params.temperature)
            put("max_tokens", request.params.maxTokens)
            put("stream", request.stream)
            putJsonArray("messages") {
                request.systemPrompt?.takeIf { it.isNotBlank() }?.let { system ->
                    add(buildJsonObject {
                        put("role", "system")
                        put("content", system)
                    })
                }
                request.messages.forEach { message ->
                    add(buildJsonObject {
                        put("role", message.role.wireName())
                        if (message.parts.isEmpty()) {
                            // String content, exactly as before: some
                            // OpenAI-compatible servers reject the array form
                            // outright, so it is only used when there is something
                            // that needs it.
                            put("content", message.content)
                        } else {
                            putJsonArray("content") {
                                message.parts.forEach { part -> add(contentBlock(part)) }
                            }
                        }
                    })
                }
            }
        }

        val httpRequest = Request.Builder()
            .url(config.baseUrl.trimEnd('/') + "/chat/completions")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .apply {
                header("Content-Type", "application/json")
                if (!apiKey.isNullOrBlank()) header("Authorization", "Bearer $apiKey")
                if (request.stream) header("Accept", "text/event-stream")
            }
            .build()

        val call = client.newCall(httpRequest)
        // OkHttp reads block; cancelling the coroutine must abort the socket.
        currentCoroutineContext().job.invokeOnCompletion { if (!call.isCanceled()) call.cancel() }

        val response = runCatching { call.execute() }.getOrElse { error ->
            emit(ChatStreamEvent.Failure(error.toAiError()))
            return@flow
        }

        response.use { httpResponse ->
            if (!httpResponse.isSuccessful) {
                val body = runCatching { httpResponse.body?.string() }.getOrNull().orEmpty()
                emit(ChatStreamEvent.Failure(httpError(httpResponse.code, body)))
                return@flow
            }
            val source = httpResponse.body?.source()
            if (source == null) {
                emit(
                    ChatStreamEvent.Failure(
                        AiError(
                            AiError.Kind.Server,
                            AppStrings.get(R.string.error_empty_body, fallback = "Empty response body")
                        )
                    )
                )
                return@flow
            }

            val builder = StringBuilder()
            var finishReason: String? = null

            if (!request.stream) {
                val text = source.readUtf8()
                val root = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
                val choice = root?.get("choices")?.jsonArray?.firstOrNull()?.jsonObject
                val content = choice?.get("message")?.jsonObject?.get("content")?.jsonPrimitive?.contentOrNull
                finishReason = choice?.get("finish_reason")?.jsonPrimitive?.contentOrNull
                if (content != null) {
                    builder.append(content)
                    emit(ChatStreamEvent.Delta(content))
                }
            } else {
                // SseParser.read is inline, so tokens are emitted downstream the
                // moment they arrive instead of being buffered.
                SseParser.read(source) { event ->
                    if (event.data == SseParser.DONE) return@read false
                    val (chunk, finish) = extractDelta(event.data)
                    if (finish != null) finishReason = finish
                    if (!chunk.isNullOrEmpty()) {
                        builder.append(chunk)
                        emit(ChatStreamEvent.Delta(chunk))
                    }
                    true
                }
            }

            emit(ChatStreamEvent.Completed(finishReason, builder.toString()))
        }
    }.flowOn(Dispatchers.IO)

    /** Returns content delta and finish reason for one SSE payload. */
    private fun extractDelta(data: String): Pair<String?, String?> {
        val root = runCatching { json.parseToJsonElement(data).jsonObject }.getOrNull() ?: return null to null
        val choice = (root["choices"] as? JsonArray)?.firstOrNull()?.jsonObject ?: return null to null
        val delta = (choice["delta"] as? JsonObject)
        val content = delta?.get("content")?.jsonPrimitive?.contentOrNull
        val finish = choice["finish_reason"]?.jsonPrimitive?.contentOrNull
        return content to finish
    }

    private fun AiRole.wireName(): String = when (this) {
        AiRole.System -> "system"
        AiRole.User -> "user"
        AiRole.Assistant -> "assistant"
    }

    private companion object {
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    /**
     * One content block in the OpenAI chat-completions format.
     *
     * Images travel as `image_url` with a data uri. PDFs have no equivalent here,
     * so instead of sending something the endpoint would reject, the model is told
     * the document exists and cannot be read — which is recoverable, unlike a
     * failed request.
     */
    private fun contentBlock(part: AiContentPart): JsonObject = when (part) {
        is AiContentPart.Text -> buildJsonObject {
            put("type", "text")
            put("text", part.text)
        }
        is AiContentPart.Image -> buildJsonObject {
            put("type", "image_url")
            putJsonObject("image_url") {
                put("url", "data:${part.mediaType};base64,${part.base64}")
            }
        }
        is AiContentPart.Document -> buildJsonObject {
            put("type", "text")
            put(
                "text",
                "[Attached document \"${part.name}\" — this provider cannot receive PDF " +
                    "documents. Ask the user for the relevant text, or to switch to a provider " +
                    "that supports documents.]"
            )
        }
    }

}
