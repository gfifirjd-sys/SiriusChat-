package com.sirius.chat.domain.usecase

import com.sirius.chat.domain.model.ChangeKind
import com.sirius.chat.domain.model.ChangeStatus
import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.repository.WorkspaceRepository

data class ApplyResult(
    val applied: Int,
    val failed: List<PendingChange>
) {
    val success: Boolean get() = failed.isEmpty()
}

/**
 * Writes approved proposals to the workspace. Each change is applied
 * independently so one failure never leaves the batch half-reported.
 */
class ApplyChangesUseCase(private val workspace: WorkspaceRepository) {

    suspend operator fun invoke(treeUri: String, changes: List<PendingChange>): ApplyResult {
        var applied = 0
        val failures = ArrayList<PendingChange>()

        for (change in changes) {
            val result = runCatching { applyOne(treeUri, change) }.getOrElse { false }
            if (result) applied++ else failures += change.copy(status = ChangeStatus.Failed)
        }
        return ApplyResult(applied, failures)
    }

    private suspend fun applyOne(treeUri: String, change: PendingChange): Boolean {
        return when (change.kind) {
            ChangeKind.Create -> {
                val parentId = change.parentDocumentId ?: workspace.rootNode(treeUri)?.documentId
                if (parentId == null) false else {
                    val name = change.path.trim('/').substringAfterLast('/')
                    val created = workspace.createFile(treeUri, parentId, name)
                    created != null && workspace.writeText(treeUri, created.documentId, change.newContent.orEmpty())
                }
            }

            ChangeKind.Modify -> {
                val documentId = change.documentId ?: return false
                workspace.writeText(treeUri, documentId, change.newContent.orEmpty())
            }

            ChangeKind.Move -> {
                // Recreate under the new parent, then drop the original. The source
                // is only deleted once the copy is fully written, so a failure
                // halfway through never loses the file.
                val parentId = change.parentDocumentId ?: return false
                val name = change.newName ?: change.path.trim('/').substringAfterLast('/')
                val created = workspace.createFile(treeUri, parentId, name) ?: return false
                val written = workspace.writeText(treeUri, created.documentId, change.newContent.orEmpty())
                if (!written) return false
                val sourceId = change.documentId
                if (sourceId == null) true else workspace.delete(treeUri, sourceId)
            }

            ChangeKind.Delete -> {
                val documentId = change.documentId ?: return false
                workspace.delete(treeUri, documentId)
            }

            ChangeKind.Rename -> {
                val documentId = change.documentId ?: return false
                val newName = change.newName ?: return false
                workspace.rename(treeUri, documentId, newName) != null
            }
        }
    }
}
