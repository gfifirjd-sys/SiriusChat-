package com.sirius.chat.domain.model

enum class DiffLineType { Context, Added, Removed }

data class DiffLine(
    val type: DiffLineType,
    val oldLineNumber: Int?,
    val newLineNumber: Int?,
    val text: String
)

/** A contiguous group of changes plus surrounding context lines. */
data class DiffHunk(
    val id: Int,
    val oldStart: Int,
    val newStart: Int,
    val lines: List<DiffLine>
) {
    val added: Int get() = lines.count { it.type == DiffLineType.Added }
    val removed: Int get() = lines.count { it.type == DiffLineType.Removed }
}

data class FileDiff(
    val path: String,
    val hunks: List<DiffHunk>,
    val added: Int,
    val removed: Int,
    val binary: Boolean = false
) {
    val isEmpty: Boolean get() = hunks.isEmpty()
}

enum class ChangeKind { Create, Modify, Delete, Rename, Move }

enum class ChangeStatus { Pending, Applied, Rejected, Failed }

/**
 * A file mutation proposed by the agent. Nothing is written to the workspace
 * until the user approves it, which is what makes agent mode safe to use.
 */
data class PendingChange(
    val id: String,
    val sessionId: String,
    val kind: ChangeKind,
    val path: String,
    val documentId: String?,
    val parentDocumentId: String?,
    val oldContent: String?,
    val newContent: String?,
    val newName: String? = null,
    val status: ChangeStatus = ChangeStatus.Pending,
    val error: String? = null
)

/** A batch of proposals produced by one agent turn. */
data class ChangeSet(
    val sessionId: String,
    val changes: List<PendingChange>
) {
    val isEmpty: Boolean get() = changes.isEmpty()
    val fileCount: Int get() = changes.size
}
