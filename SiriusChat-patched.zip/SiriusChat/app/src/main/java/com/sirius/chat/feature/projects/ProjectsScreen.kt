package com.sirius.chat.feature.projects

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.ProjectAccentInk
import com.sirius.chat.core.designsystem.ProjectAccents
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.AccentSwatchRow
import com.sirius.chat.core.designsystem.components.EmptyState
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.ListSkeleton
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusConfirmSheet
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.ToastTone
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.components.labelled
import com.sirius.chat.core.ui.rememberWorkspacePicker
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.relativeTimeText
import com.sirius.chat.domain.model.Project

@Composable
fun ProjectsScreen(
    onBack: () -> Unit,
    onOpenProject: (String) -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: ProjectsViewModel = siriusViewModel { ProjectsViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()

    val picker = rememberWorkspacePicker { viewModel.onFolderPicked(it) }
    val listState = rememberLazyListState()
    // The bar only earns its seam once there is content hidden behind it.
    val scrolled by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 4 }
    }

    var pendingDelete by remember { mutableStateOf<Project?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }
    var toastTone by remember { mutableStateOf(ToastTone.Success) }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.projects_title),
            subtitle = pluralStringResource(
                R.plurals.projects_count,
                state.projects.size,
                state.projects.size
            ),
            scrolled = scrolled,
            onBack = onBack,
            actions = {
                GlassIconButton(
                    icon = Icons.Rounded.CreateNewFolder,
                    contentDescription = stringResource(R.string.projects_new),
                    highlighted = true,
                    onClick = { picker.launch(null) }
                )
            }
        )

        when {
            state.loading -> ListSkeleton(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = SiriusSpacing.sm),
                rows = 6
            )

            state.projects.isEmpty() -> Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center
            ) {
                EmptyState(
                    icon = Icons.Rounded.FolderOpen,
                    title = stringResource(R.string.projects_empty_title),
                    message = stringResource(R.string.projects_empty_message),
                    actionLabel = stringResource(R.string.projects_choose_folder),
                    onAction = { picker.launch(null) }
                )
            }

            else -> LazyColumn(
                modifier = Modifier.weight(1f),
                state = listState,
                contentPadding = PaddingValues(
                    start = SiriusSpacing.sm,
                    end = SiriusSpacing.sm,
                    top = SiriusSpacing.xs,
                    bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
                ),
                verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
            ) {
                items(state.projects, key = { it.id }) { project ->
                    val favorited = stringResource(R.string.projects_favorited, project.name)
                    val unfavorited = stringResource(R.string.projects_unfavorited, project.name)
                    ProjectRow(
                        project = project,
                        active = project.id == state.activeProjectId,
                        // Reordering after a favourite toggle should look like the
                        // row moved, not like the list was rebuilt underneath.
                        modifier = Modifier.animateItem(),
                        onOpen = {
                            viewModel.activate(project)
                            onOpenProject(project.id)
                        },
                        onToggleFavorite = {
                            viewModel.toggleFavorite(project)
                            toastTone = ToastTone.Success
                            toast = if (project.favorite) unfavorited else favorited
                        },
                        onDelete = { pendingDelete = project }
                    )
                }
            }
        }
    }

    pendingDelete?.let { project ->
        val deleted = stringResource(R.string.projects_deleted, project.name)
        SiriusConfirmSheet(
            title = stringResource(R.string.projects_delete_title, project.name),
            message = stringResource(R.string.projects_delete_message),
            confirmLabel = stringResource(R.string.action_delete),
            icon = Icons.Rounded.DeleteOutline,
            onConfirm = {
                pendingDelete = null
                viewModel.delete(project)
                toastTone = ToastTone.Success
                toast = deleted
            },
            onDismiss = { pendingDelete = null }
        )
    }

    state.pendingTreeUri?.let { treeUri ->
        CreateProjectSheet(
            treeUri = treeUri,
            onDismiss = viewModel::cancelCreation,
            onCreate = { name, accent -> viewModel.confirmCreation(name, accent, onOpenProject) }
        )
    }

    MessageToast(
        message = toast,
        tone = toastTone,
        bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.sm
    )
}

/**
 * A project as a physical plate: accent monogram, name, folder, state chips.
 *
 * The two trailing controls are the only interactive children of a card that is
 * itself a button, so they carry explicit labels — a screen reader user needs to
 * know which of the three targets in this row does what.
 */
@Composable
private fun ProjectRow(
    project: Project,
    active: Boolean,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = SiriusTheme.colors
    val accent = ProjectAccents[project.accentIndex % ProjectAccents.size]
    // take(1) split an emoji or a flag in half and rendered a tofu box, so the
    // monogram is cut on a code point and falls back to the app glyph.
    val monogram = remember(project.name) { monogramOf(project.name) }

    GlassCard(
        modifier = modifier,
        onClick = onOpen,
        onClickLabel = stringResource(R.string.projects_open_project, project.name),
        // Tint alone marks the active workspace; the travelling beam stays
        // reserved for rows that are genuinely working.
        tint = if (active) accent.copy(alpha = 0.15f) else null
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(SiriusRadius.sm))
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.45f))))
                    // The monogram repeats the name that is right beside it.
                    .labelled(""),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = monogram,
                    style = MaterialTheme.typography.titleMedium,
                    color = ProjectAccentInk
                )
            }
            Spacer(Modifier.width(SiriusSpacing.sm))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = project.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (project.hasWorkspace) {
                        project.workspaceLabel.ifBlank {
                            stringResource(R.string.projects_workspace_attached)
                        }
                    } else {
                        stringResource(R.string.projects_no_folder_attached)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (project.hasWorkspace) colors.textTertiary else colors.warning,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(SiriusSpacing.xxs))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (active) {
                        SiriusChip(text = stringResource(R.string.label_active), selected = true)
                    }
                    SiriusChip(text = relativeTimeText(project.lastOpenedAt))
                }
            }
            GlassIconButton(
                icon = if (project.favorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                contentDescription = if (project.favorite) {
                    stringResource(R.string.projects_unfavorite)
                } else {
                    stringResource(R.string.projects_favorite)
                },
                size = 34.dp,
                iconSize = 16.dp,
                tint = if (project.favorite) colors.warning else null,
                onClick = onToggleFavorite
            )
            GlassIconButton(
                icon = Icons.Rounded.DeleteOutline,
                contentDescription = stringResource(R.string.projects_delete),
                size = 34.dp,
                iconSize = 16.dp,
                onClick = onDelete
            )
        }
    }
}

/**
 * First code point of a project name, uppercased for display.
 *
 * Names arrive from the folder picker, so they can start with an emoji, a
 * combining mark or nothing at all; each of those has to end up as one legible
 * glyph on the accent plate.
 */
private fun monogramOf(name: String): String {
    val trimmed = name.trim()
    if (trimmed.isEmpty()) return "\u00B7"
    val end = trimmed.offsetByCodePoints(0, 1)
    return trimmed.substring(0, end).uppercase()
}

@Composable
private fun CreateProjectSheet(
    treeUri: String,
    onDismiss: () -> Unit,
    onCreate: (String, Int) -> Unit
) {
    val defaultName = stringResource(R.string.projects_new)
    // The folder the user just granted is almost always the name they want. The
    // tree uri is percent-encoded, so it is decoded first — otherwise a folder
    // called "My Code" was proposed as "My%20Code".
    var name by remember(treeUri, defaultName) {
        mutableStateOf(
            Uri.decode(treeUri)
                .substringAfterLast('/')
                .substringAfterLast(':')
                .ifBlank { defaultName }
        )
    }
    var accent by remember(treeUri) { mutableIntStateOf(0) }
    val trimmed = name.trim()

    SiriusBottomSheet(
        title = stringResource(R.string.projects_new),
        subtitle = stringResource(R.string.projects_new_subtitle),
        onDismiss = onDismiss
    ) {
        SiriusTextField(
            value = name,
            onValueChange = { name = it },
            placeholder = stringResource(R.string.projects_name_placeholder),
            modifier = Modifier.fillMaxWidth(),
            onImeAction = { if (trimmed.isNotBlank()) onCreate(trimmed, accent) }
        )
        VSpace(SiriusSpacing.md)
        AccentSwatchRow(selectedIndex = accent, onSelect = { accent = it })
        VSpace(SiriusSpacing.md)
        SiriusPrimaryButton(
            text = stringResource(R.string.projects_create),
            onClick = { onCreate(trimmed, accent) },
            enabled = trimmed.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
