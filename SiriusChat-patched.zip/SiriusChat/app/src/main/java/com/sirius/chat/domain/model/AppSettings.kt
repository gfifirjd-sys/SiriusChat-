package com.sirius.chat.domain.model

enum class ThemeMode { System, Light, Dark }

/** How aggressive the liquid-glass layer is; lowest tier is the fastest. */
enum class GlassLevel { Off, Subtle, Full }

/**
 * UI language. [System] follows the device locale, the rest force one language
 * regardless of system settings. [tag] is a BCP-47 tag matching a `values-*`
 * resource folder; it is empty for [System].
 */
enum class AppLanguage(val tag: String) {
    System(""),
    English("en"),
    Russian("ru");

    companion object {
        fun ofTag(tag: String): AppLanguage =
            entries.firstOrNull { it.tag == tag } ?: System
    }
}

/**
 * Which engine the terminal runs commands with.
 *
 * [DeviceShell] always works but is confined to the app sandbox; [Termux] gives
 * up streaming output and process control in exchange for a real toolchain.
 */
enum class TerminalEngine { DeviceShell, Termux }

data class AppSettings(
    val language: AppLanguage = AppLanguage.System,
    val themeMode: ThemeMode = ThemeMode.System,
    /**
     * Interface accent as an ARGB int, or 0 for the monochrome default.
     *
     * This replaced the Material You switch. A wallpaper scheme could only ever
     * reach four palette slots, and which four was unpredictable; an explicit
     * colour lands on the same four, visibly and reproducibly.
     */
    val accentColor: Int = 0,
    val glassLevel: GlassLevel = GlassLevel.Full,
    val reduceMotion: Boolean = false,
    val hapticsEnabled: Boolean = true,
    val streamingEnabled: Boolean = true,
    val activeProviderId: String = "",
    val activeModel: String = "",
    val temperature: Float = 0.3f,
    val maxTokens: Int = 4096,
    val agentAutoApproveReads: Boolean = true,
    val agentMaxSteps: Int = 6,
    val editorFontSize: Int = 14,
    val editorTabSize: Int = 4,
    val editorWordWrap: Boolean = false,
    val editorLineNumbers: Boolean = true,
    val editorAutoSave: Boolean = false,
    val terminalFontSize: Int = 13,
    val terminalEngine: TerminalEngine = TerminalEngine.DeviceShell,
    /**
     * Whether the one-off Termux background-mode explanation has been read.
     *
     * Termux is a separate app: once Android stops it, RUN_COMMAND silently
     * stops producing results and the terminal looks broken rather than
     * throttled. The explanation is therefore shown once, the first time the
     * user picks the Termux engine, and never again.
     */
    val termuxBackgroundNoticeShown: Boolean = false,
    val activeProjectId: String = "",
    /** `owner/name` of the repository the GitHub screen is pointed at. */
    val githubRepo: String = "",
    val onboardingDone: Boolean = false
)
