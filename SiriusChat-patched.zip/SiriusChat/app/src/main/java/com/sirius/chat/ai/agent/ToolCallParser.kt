package com.sirius.chat.ai.agent

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

data class ParsedToolCall(val tool: String, val args: JsonObject, val rawBlock: String)

/**
 * Extracts tool calls from an assistant message.
 *
 * A fenced ```sirius-tool block is used instead of vendor specific function
 * calling so that *every* OpenAI or Anthropic compatible endpoint, including
 * small local models, can drive the agent.
 */
object ToolCallParser {

    private const val FENCE = "```"
    private const val TAG = "sirius-tool"
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun parse(text: String): List<ParsedToolCall> {
        val calls = ArrayList<ParsedToolCall>()
        var index = 0
        while (true) {
            val start = text.indexOf("$FENCE$TAG", index)
            if (start < 0) break
            val bodyStart = text.indexOf('\n', start)
            if (bodyStart < 0) break
            val end = text.indexOf(FENCE, bodyStart)
            if (end < 0) break

            val body = text.substring(bodyStart + 1, end).trim()
            calls += decode(body)
            index = end + FENCE.length
        }
        return calls
    }

    /** Strips tool blocks so the transcript shows only the prose. */
    fun stripToolBlocks(text: String): String {
        val builder = StringBuilder(text.length)
        var index = 0
        while (true) {
            val start = text.indexOf("$FENCE$TAG", index)
            if (start < 0) {
                builder.append(text, index, text.length)
                break
            }
            builder.append(text, index, start)
            val bodyStart = text.indexOf('\n', start)
            val end = if (bodyStart < 0) -1 else text.indexOf(FENCE, bodyStart)
            index = if (end < 0) text.length else end + FENCE.length
        }
        return builder.toString().trim()
    }

    private fun decode(body: String): List<ParsedToolCall> = runCatching {
        when (val element = json.parseToJsonElement(body)) {
            is JsonArray -> element.mapNotNull { it.toCall(body) }
            is JsonObject -> listOfNotNull(element.toCall(body))
            else -> emptyList()
        }
    }.getOrDefault(emptyList())

    private fun kotlinx.serialization.json.JsonElement.toCall(raw: String): ParsedToolCall? {
        val obj = runCatching { jsonObject }.getOrNull() ?: return null
        val name = obj["tool"]?.jsonPrimitive?.content
            ?: obj["name"]?.jsonPrimitive?.content
            ?: return null
        val args = (obj["args"] ?: obj["arguments"] ?: obj["parameters"])
            ?.let { runCatching { it.jsonObject }.getOrNull() }
            ?: JsonObject(emptyMap())
        return ParsedToolCall(name, args, raw)
    }
}
