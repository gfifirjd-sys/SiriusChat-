package com.sirius.chat.ai.model

import com.sirius.chat.domain.model.GenerationParams

/**
 * Provider-neutral message.
 *
 * [content] is the whole message as plain text and stays authoritative for
 * everything that reasons about text: the agent loop, history trimming, and any
 * provider that only speaks strings.
 *
 * [parts] is the same message as an ordered list of blocks, and is only set when
 * the message carries attachments. Keeping both means multimodal support did not
 * have to be threaded through every caller: a provider that understands blocks
 * uses [parts] when it is there, and every other path keeps working off
 * [content] exactly as before.
 */
data class AiMessage(
    val role: AiRole,
    val content: String,
    val parts: List<AiContentPart> = emptyList()
)

/**
 * One block of a message, in the order the user assembled it.
 *
 * Order is the point. The provider array must read "text, image, text,
 * document" if that is how it was typed, because that adjacency is the only
 * thing telling the model which sentence refers to which file.
 */
sealed interface AiContentPart {
    data class Text(val text: String) : AiContentPart

    /** Base64 image. [mediaType] must be one the provider accepts. */
    data class Image(val base64: String, val mediaType: String) : AiContentPart

    /** Base64 document (PDF), sent natively where supported. */
    data class Document(val base64: String, val mediaType: String, val name: String) :
        AiContentPart
}

enum class AiRole { System, User, Assistant }

data class ChatRequest(
    val model: String,
    val messages: List<AiMessage>,
    val systemPrompt: String? = null,
    val params: GenerationParams = GenerationParams(),
    val stream: Boolean = true
)

/** Everything a provider can emit while answering. */
sealed interface ChatStreamEvent {
    data object Started : ChatStreamEvent
    data class Delta(val text: String) : ChatStreamEvent
    data class Completed(val finishReason: String?, val fullText: String) : ChatStreamEvent
    data class Failure(val error: AiError) : ChatStreamEvent
}

/** Normalised error so the UI can react without knowing the provider. */
data class AiError(
    val kind: Kind,
    val message: String,
    val statusCode: Int? = null
) {
    enum class Kind { Network, Unauthorized, RateLimited, BadRequest, Server, Cancelled, Unknown }

    val isRetryable: Boolean
        get() = kind == Kind.Network || kind == Kind.RateLimited || kind == Kind.Server
}
