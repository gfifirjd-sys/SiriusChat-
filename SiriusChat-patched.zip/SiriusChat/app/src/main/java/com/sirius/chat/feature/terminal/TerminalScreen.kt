package com.sirius.chat.feature.terminal

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.HelpOutline
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.BatteryAlert
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SheetOptionRow
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.siriusFadeThrough
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.data.repository.TerminalLineType
import com.sirius.chat.data.terminal.TermuxShellBackend
import com.sirius.chat.domain.model.TerminalEngine
import kotlinx.coroutines.launch

@Composable
fun TerminalScreen(contentPadding: PaddingValues) {
    val viewModel: TerminalViewModel = siriusViewModel { TerminalViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val colors = SiriusTheme.colors
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    var showEngines by remember { mutableStateOf(false) }
    var showGuide by remember { mutableStateOf(false) }

    // Termux can be installed, uninstalled or have its permission revoked while
    // this screen sits in the background, so availability is re-read on return
    // rather than trusted from when the screen was first composed.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refreshAvailability() }

    // Starting an external screen is the one thing here that can fail outright:
    // a device with a stripped Settings app or no browser throws instead of
    // opening anything, and the log is where the user finds out.
    val start: (Intent?) -> Unit = { intent ->
        val opened = intent != null &&
            runCatching { context.startActivity(intent) }.isSuccess
        if (!opened) viewModel.noteSetupActionUnavailable()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshAvailability()
        // RUN_COMMAND is declared by Termux, not the platform, and the system
        // routinely returns "denied" for another app's permission without ever
        // showing a dialog. Without this fallback the button reads as broken, so
        // a denial hands the user the App Info screen where it can be toggled.
        if (!granted) start(viewModel.permissionSettingsIntent())
    }

    // Shared by the inline setup step and the guide, so both go through the same
    // "ask the system, fall back to App Info" path rather than diverging.
    val requestPermission: () -> Unit = {
        permissionLauncher.launch(TermuxShellBackend.RUN_COMMAND_PERMISSION)
    }

    // App Info for Termux, which is where its battery restriction is lifted. Null
    // when Termux is absent, because that screen opens empty for a package that
    // is not installed. Remembered: it queries the package manager, and both the
    // banner and the explanation sheet need the same answer.
    val openTermuxSettings: (() -> Unit)? = remember(state.termuxInstalled) {
        viewModel.termuxAppDetailsIntent()?.let { intent -> { start(intent) } }
    }

    // Following the output is only helpful while the user is already at the end.
    // Scrolling up to read an earlier error must not be yanked away by new output.
    val pinnedToEnd by remember {
        derivedStateOf { !listState.canScrollForward }
    }
    val scrolledBack by remember {
        derivedStateOf { listState.canScrollForward && listState.firstVisibleItemIndex > 0 }
    }

    LaunchedEffect(state.lines.size) {
        if (state.lines.isNotEmpty() && pinnedToEnd) {
            listState.animateScrollToItem(state.lines.lastIndex)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.terminal_title),
            subtitle = state.workingDirectory,
            // The output sits directly under the bar, so the seam is always earned.
            scrolled = true,
            actions = {
                if (state.running) {
                    GlassIconButton(
                        icon = Icons.Rounded.Stop,
                        contentDescription = stringResource(R.string.action_stop),
                        tint = colors.error,
                        onClick = viewModel::stop
                    )
                }
                GlassIconButton(
                    icon = Icons.Rounded.Memory,
                    contentDescription = stringResource(R.string.terminal_engine_open),
                    onClick = { showEngines = true }
                )
                GlassIconButton(
                    icon = Icons.Rounded.DeleteSweep,
                    contentDescription = stringResource(R.string.terminal_clear),
                    enabled = state.lines.isNotEmpty(),
                    onClick = viewModel::clear
                )
            }
        )

        Row(
            modifier = Modifier.padding(horizontal = SiriusSpacing.sm),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SiriusChip(
                text = if (state.backendAvailable) {
                    state.backendName
                } else {
                    stringResource(R.string.terminal_backend_unavailable)
                },
                color = if (state.backendAvailable) colors.success else colors.error,
                // The engine is the one setting that changes what a command can
                // do, so the badge that names it is also the way to change it.
                onClick = { showEngines = true }
            )
            state.lastExitCode?.let { code ->
                SiriusChip(
                    text = stringResource(R.string.terminal_exit_code, code),
                    color = if (code == 0) colors.success else colors.error
                )
            }
            if (state.running) {
                SiriusChip(
                    text = stringResource(R.string.terminal_running),
                    color = colors.warning,
                    // A run that starts while the user is elsewhere on the screen
                    // should still be announced once.
                    modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }
                )
            }
        }

        // Both Termux states are fixable, but by opposite actions, so each one
        // offers the step that actually applies instead of a generic button.
        if (state.termuxMissing) {
            TermuxSetupAction(
                label = stringResource(R.string.terminal_termux_install),
                hint = stringResource(R.string.terminal_termux_install_hint),
                onClick = { start(viewModel.termuxInstallIntent()) },
                // Installing is only the first of four steps, and the remaining
                // three are done inside Termux where this app cannot follow.
                onOpenGuide = { showGuide = true }
            )
        } else if (state.permissionRequired) {
            TermuxSetupAction(
                label = stringResource(R.string.terminal_termux_grant),
                hint = stringResource(R.string.terminal_termux_grant_hint),
                // Ask the system first: when it does show the dialog this is one
                // tap, and the launcher result re-reads availability either way.
                // The fallback to App Info lives in the result callback, because
                // only there is it known that the dialog never appeared.
                onClick = requestPermission,
                onOpenGuide = { showGuide = true }
            )
        }

        // Setup is complete but Termux is not answering: a different problem with
        // a different fix, so it gets its own banner rather than reusing the
        // setup steps above. Only ever shown for the Termux engine, and only
        // after a probe has actually failed.
        if (state.termuxUnresponsive) {
            TermuxBackgroundBanner(
                probing = state.termuxProbing,
                onOpenTermuxSettings = openTermuxSettings,
                onRecheck = { viewModel.checkTermuxHealth(force = true) },
                onExplain = viewModel::showBackgroundNotice
            )
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .padding(SiriusSpacing.sm)
                .clip(RoundedCornerShape(SiriusRadius.md))
                .background(colors.codeBackground)
        ) {
            // Output is worth nothing if it cannot leave the app, so the whole log
            // is selectable rather than a wall of read-only text.
            SelectionContainer {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(10.dp),
                    verticalArrangement = Arrangement.spacedBy(1.dp)
                ) {
                    items(state.lines, key = { it.id }) { line ->
                        Text(
                            text = line.text,
                            style = codeTextStyle(13),
                            color = when (line.type) {
                                TerminalLineType.Command -> colors.primary
                                TerminalLineType.Stdout -> colors.codePlain
                                TerminalLineType.Stderr -> colors.error
                                TerminalLineType.System -> colors.codeComment
                            }
                        )
                    }
                }
            }

            // Reading back through a long build should not cost the user their way
            // back to the live end of the log.
            JumpToLatestButton(
                visible = scrolledBack,
                onClick = {
                    if (state.lines.isNotEmpty()) {
                        scope.launch { listState.animateScrollToItem(state.lines.lastIndex) }
                    }
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(SiriusSpacing.xs)
            )
        }

        if (state.history.isNotEmpty()) {
            LazyRow(
                modifier = Modifier.padding(horizontal = SiriusSpacing.sm),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(state.history.reversed().take(12)) { command ->
                    val label = stringResource(R.string.terminal_recall, command)
                    SiriusChip(
                        text = command,
                        onClick = { viewModel.recall(command) },
                        modifier = Modifier.semantics { contentDescription = label }
                    )
                }
            }
        }

        val canRun = state.input.isNotBlank() && state.backendAvailable

        // The floating tab bar's reserved space is only real while the bar is
        // visible. Once the keyboard covers it, keeping those 92dp leaves the
        // composer stranded in the middle of the screen, so the reservation is
        // spent down by exactly as much of the keyboard as has already risen.
        val imeBottom = with(LocalDensity.current) {
            WindowInsets.ime.getBottom(this).toDp()
        }
        val barInset = (contentPadding.calculateBottomPadding() - imeBottom)
            .coerceAtLeast(0.dp)

        TerminalComposer(
            value = state.input,
            onValueChange = viewModel::onInputChange,
            placeholder = stringResource(R.string.terminal_input_hint),
            enabled = state.backendAvailable,
            running = state.running,
            canRun = canRun,
            onRun = viewModel::run,
            onStop = viewModel::stop,
            bottomInset = barInset
        )
    }

    if (showEngines) {
        EngineSheet(
            selected = state.engine,
            onSelect = { engine ->
                viewModel.setEngine(engine)
                showEngines = false
            },
            // Only offered when Termux is there to open: allow-external-apps can
            // only be written from inside a Termux session, and the requirement
            // is read here, next to the engine that needs it.
            onOpenTermux = if (!state.termuxInstalled) {
                null
            } else {
                {
                    showEngines = false
                    start(viewModel.termuxLaunchIntent())
                }
            },
            // Reachable even when Termux already works: the requirements line
            // above raises the question, and this is where it is answered.
            onOpenGuide = {
                showEngines = false
                showGuide = true
            },
            onDismiss = { showEngines = false }
        )
    }

    // Not a `remember`ed flag like the sheets above: whether this has been read
    // is persisted, so the ViewModel owns it and the screen only renders it.
    if (state.showBackgroundNotice) {
        TermuxBackgroundSheet(
            siriusUnrestricted = state.siriusUnrestricted,
            onOpenTermuxSettings = openTermuxSettings,
            onOpenSiriusSettings = { start(viewModel.siriusAppDetailsIntent()) },
            onUnderstood = viewModel::acknowledgeBackgroundNotice,
            // Swiping the sheet away is not an acknowledgement: the flag stays
            // unset, so the explanation returns the next time Termux is picked.
            onDismiss = viewModel::dismissBackgroundNotice
        )
    }

    if (showGuide) {
        TermuxGuideSheet(
            onInstall = { start(viewModel.termuxInstallIntent()) },
            // Null while Termux is absent: step 1 is what produces the app this
            // button would open, so offering it early can only fail.
            onOpenTermux = if (!state.termuxInstalled) {
                null
            } else {
                { start(viewModel.termuxLaunchIntent()) }
            },
            onGrantPermission = requestPermission,
            // The four setup steps produce a working bridge; keeping it working
            // is the background switch, so the guide links to it.
            onOpenBackgroundNotice = {
                showGuide = false
                viewModel.showBackgroundNotice()
            },
            onDismiss = { showGuide = false }
        )
    }
}

/**
 * Termux is set up but silent.
 *
 * Separate from [TermuxSetupAction] because the cause is the opposite of a
 * missing step: everything is installed and permitted, and Android stopped the
 * app anyway. The banner therefore leads with the battery setting, offers a
 * re-check so the user can confirm the fix without typing a command, and keeps
 * the full explanation one tap away.
 */
@Composable
private fun TermuxBackgroundBanner(
    probing: Boolean,
    onOpenTermuxSettings: (() -> Unit)?,
    onRecheck: () -> Unit,
    onExplain: () -> Unit
) {
    val colors = SiriusTheme.colors
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SiriusSpacing.sm, vertical = 6.dp)
            .clip(RoundedCornerShape(SiriusRadius.md))
            .background(colors.warning.copy(alpha = 0.10f))
            .padding(SiriusSpacing.xs)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Rounded.BatteryAlert,
                contentDescription = null,
                tint = colors.warning,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(SiriusSpacing.xs))
            Text(
                text = stringResource(R.string.terminal_termux_background_warning),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
                // Announced once when it appears: the user may well be looking
                // at the composer rather than the top of the screen.
                modifier = Modifier
                    .weight(1f)
                    .semantics { liveRegion = LiveRegionMode.Polite }
            )
        }
        VSpace(6.dp)
        // The one action that fixes it, when Termux is there to be opened.
        onOpenTermuxSettings?.let { open ->
            SiriusPrimaryButton(
                text = stringResource(R.string.terminal_background_open_termux_settings),
                onClick = open,
                modifier = Modifier.fillMaxWidth()
            )
            VSpace(4.dp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SiriusGhostButton(
                text = if (probing) {
                    stringResource(R.string.terminal_termux_checking)
                } else {
                    stringResource(R.string.terminal_termux_recheck)
                },
                onClick = onRecheck,
                icon = Icons.Rounded.Refresh,
                enabled = !probing,
                modifier = Modifier.weight(1f)
            )
            SiriusGhostButton(
                text = stringResource(R.string.terminal_background_why_button),
                onClick = onExplain,
                icon = Icons.AutoMirrored.Rounded.HelpOutline,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

/**
 * Command composer.
 *
 * One flat panel, exactly like the chat composer: the command line sits directly
 * on the panel instead of inside a second plate of its own. The nested version
 * stacked a field surface and a travelling beam border inside an already-bordered
 * panel, and the beam's bloom read as a stray arc floating off the field edge.
 * Focus is worth one hairline getting brighter — nothing else moves.
 */
@Composable
private fun TerminalComposer(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    enabled: Boolean,
    running: Boolean,
    canRun: Boolean,
    onRun: () -> Unit,
    onStop: () -> Unit,
    bottomInset: Dp
) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.lg)
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val edgeAlpha by animateFloatAsState(
        targetValue = if (focused) 1f else 0.55f,
        animationSpec = siriusSpring(),
        label = "terminalComposerEdge"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
            .padding(
                start = SiriusSpacing.sm,
                end = SiriusSpacing.sm,
                top = 6.dp,
                bottom = bottomInset + 6.dp
            )
            .glassSurface(shape = shape, elevation = 0.dp, borderAlpha = edgeAlpha)
            .padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(
                    text = placeholder,
                    style = codeTextStyle(14),
                    color = colors.textTertiary,
                    maxLines = 1
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                enabled = enabled,
                singleLine = true,
                interactionSource = interaction,
                // A command is code, so it is set in the same face as the log it
                // will appear in rather than in body text.
                textStyle = codeTextStyle(14).copy(
                    color = if (enabled) colors.textPrimary else colors.textPrimary.copy(alpha = 0.5f)
                ),
                cursorBrush = SolidColor(colors.primary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = { if (canRun) onRun() },
                    onDone = { if (canRun) onRun() }
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.width(8.dp))
        GlassIconButton(
            icon = if (running) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
            contentDescription = if (running) {
                stringResource(R.string.action_stop)
            } else {
                stringResource(R.string.terminal_run)
            },
            tint = if (running) colors.error else null,
            highlighted = true,
            // Running is the one destructive-adjacent action here: an empty
            // command should not look like it will do something.
            enabled = running || canRun,
            onClick = { if (running) onStop() else onRun() }
        )
    }
}

/**
 * A Termux setup step the user can take right now.
 *
 * The hint is not decoration: both steps end somewhere outside this app — a
 * system permission list, an F-Droid page — and a button that silently throws
 * the user into Settings is indistinguishable from one that does nothing.
 */
@Composable
private fun TermuxSetupAction(
    label: String,
    hint: String,
    onClick: () -> Unit,
    onOpenGuide: () -> Unit
) {
    val colors = SiriusTheme.colors
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SiriusSpacing.sm, vertical = 6.dp)
    ) {
        SiriusPrimaryButton(
            text = label,
            onClick = onClick,
            modifier = Modifier.fillMaxWidth()
        )
        VSpace(4.dp)
        Text(
            text = hint,
            style = MaterialTheme.typography.bodySmall,
            color = colors.textTertiary
        )
        VSpace(4.dp)
        // The button above fixes one step; the whole sequence — F-Droid build,
        // allow-external-apps, permission, engine — lives in the walkthrough,
        // and a user who lands here has not finished it.
        SiriusGhostButton(
            text = stringResource(R.string.terminal_guide_open),
            onClick = onOpenGuide,
            icon = Icons.AutoMirrored.Rounded.HelpOutline,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * Engine picker.
 *
 * Each engine is described by what it can actually do rather than by its name,
 * because the choice between "device shell" and "Termux" is meaningless until
 * the user knows one has a package manager and the other does not. Termux also
 * carries its setup requirement here, where it is read before the command fails.
 */
@Composable
private fun EngineSheet(
    selected: TerminalEngine,
    onSelect: (TerminalEngine) -> Unit,
    onOpenTermux: (() -> Unit)?,
    onOpenGuide: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors
    SiriusBottomSheet(
        title = stringResource(R.string.terminal_engine_title),
        subtitle = stringResource(R.string.terminal_engine_subtitle),
        onDismiss = onDismiss
    ) {
        SheetOptionRow(
            label = stringResource(R.string.terminal_backend_local_name),
            supporting = stringResource(R.string.terminal_backend_local_description),
            supportingMaxLines = 3,
            selected = selected == TerminalEngine.DeviceShell,
            onClick = { onSelect(TerminalEngine.DeviceShell) }
        )
        SheetOptionRow(
            label = stringResource(R.string.terminal_backend_termux_name),
            supporting = stringResource(R.string.terminal_backend_termux_description),
            supportingMaxLines = 3,
            selected = selected == TerminalEngine.Termux,
            onClick = { onSelect(TerminalEngine.Termux) }
        )
        VSpace(SiriusSpacing.xs)
        Text(
            text = stringResource(R.string.terminal_termux_requirements),
            style = MaterialTheme.typography.bodySmall,
            color = colors.textTertiary,
            modifier = Modifier.padding(horizontal = SiriusSpacing.sm)
        )
        // The requirement line above names two things the user has to have done
        // but not how; this is where the how lives. Ghost, not primary: choosing
        // an engine is what this sheet is for, and a second filled plate would
        // compete with the choice above it.
        VSpace(SiriusSpacing.xs)
        SiriusGhostButton(
            text = stringResource(R.string.terminal_guide_open),
            onClick = onOpenGuide,
            icon = Icons.AutoMirrored.Rounded.HelpOutline,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SiriusSpacing.sm)
        )
        // The properties file can only be written from a Termux session, so the
        // requirement above is followed by the one step that can act on it.
        onOpenTermux?.let { open ->
            VSpace(6.dp)
            SiriusGhostButton(
                text = stringResource(R.string.terminal_termux_open),
                onClick = open,
                icon = Icons.AutoMirrored.Rounded.OpenInNew,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = SiriusSpacing.sm)
            )
        }
    }
}

/**
 * Returns the reader to the live end of the log. Extracted from the log Box so
 * the call sits outside the screen's Column receiver, which would otherwise bind
 * [AnimatedVisibility] to its ColumnScope overload.
 */
@Composable
private fun JumpToLatestButton(
    visible: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (enter, exit) = siriusFadeThrough()
    AnimatedVisibility(
        visible = visible,
        enter = enter,
        exit = exit,
        modifier = modifier
    ) {
        GlassIconButton(
            icon = Icons.Rounded.ArrowDownward,
            contentDescription = stringResource(R.string.terminal_jump_to_latest),
            size = 36.dp,
            iconSize = 16.dp,
            onClick = onClick
        )
    }
}
