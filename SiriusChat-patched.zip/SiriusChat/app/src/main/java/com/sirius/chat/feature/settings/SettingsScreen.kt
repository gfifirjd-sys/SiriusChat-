package com.sirius.chat.feature.settings

import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.ProviderAvatar
import com.sirius.chat.core.designsystem.components.SectionHeader
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusConfirmSheet
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.ToastTone
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.locale.displayLabel
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.domain.model.AppLanguage
import com.sirius.chat.domain.model.GlassLevel
import com.sirius.chat.domain.model.ThemeMode

@Composable
fun SettingsScreen(
    onOpenProviders: () -> Unit,
    onOpenGitHub: () -> Unit,
    onOpenEditorSettings: () -> Unit,
    onOpenAbout: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: SettingsViewModel = siriusViewModel { SettingsViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val settings = state.settings
    val colors = SiriusTheme.colors

    val listState = rememberLazyListState()
    // The bar only earns its seam once content has slid under it.
    val scrolled by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 4
        }
    }
    var confirmClearKeys by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.settings_title),
            subtitle = stringResource(R.string.settings_version_subtitle),
            scrolled = scrolled
        )

        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(
                start = SiriusSpacing.sm,
                end = SiriusSpacing.sm,
                bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
            ),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.sm)
        ) {
            item(key = "appearance") {
                SectionHeader(title = stringResource(R.string.settings_section_appearance))
                VSpace(SiriusSpacing.xs)
                GlassCard {
                    OptionChipGroup(
                        label = stringResource(R.string.settings_theme),
                        options = ThemeMode.entries,
                        selected = settings.themeMode,
                        labelOf = { stringResource(it.labelRes()) },
                        iconOf = { if (it == ThemeMode.Dark) Icons.Rounded.DarkMode else null },
                        onSelect = viewModel::setThemeMode
                    )
                    VSpace(SiriusSpacing.sm)
                    OptionChipGroup(
                        label = stringResource(R.string.settings_glass),
                        options = GlassLevel.entries,
                        selected = settings.glassLevel,
                        labelOf = { stringResource(it.labelRes()) },
                        onSelect = viewModel::setGlassLevel
                    )
                    VSpace(SiriusSpacing.xs)
                    Text(
                        text = stringResource(R.string.settings_glass_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textTertiary
                    )
                    VSpace(SiriusSpacing.sm)
                    AccentColorPicker(
                        selected = settings.accentColor,
                        onSelect = viewModel::setAccentColor
                    )
                    VSpace(SiriusSpacing.xs)
                    SettingToggle(
                        icon = Icons.Rounded.AutoAwesome,
                        title = stringResource(R.string.settings_reduce_motion),
                        subtitle = stringResource(R.string.settings_reduce_motion_subtitle),
                        checked = settings.reduceMotion,
                        onCheckedChange = viewModel::setReduceMotion
                    )
                    SettingToggle(
                        icon = Icons.Rounded.Vibration,
                        title = stringResource(R.string.settings_haptics),
                        subtitle = stringResource(R.string.settings_haptics_subtitle),
                        checked = settings.hapticsEnabled,
                        onCheckedChange = viewModel::setHaptics
                    )
                }
            }

            item(key = "language") {
                SectionHeader(title = stringResource(R.string.settings_section_language))
                VSpace(SiriusSpacing.xs)
                GlassCard {
                    OptionChipGroup(
                        label = stringResource(R.string.settings_language),
                        options = AppLanguage.entries,
                        selected = settings.language,
                        labelOf = { stringResource(it.labelRes()) },
                        iconOf = { if (it == AppLanguage.System) Icons.Rounded.Language else null },
                        onSelect = viewModel::setLanguage
                    )
                    VSpace(SiriusSpacing.xs)
                    Text(
                        text = stringResource(R.string.settings_language_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textTertiary
                    )
                }
            }

            item(key = "ai") {
                SectionHeader(title = stringResource(R.string.settings_section_ai))
                VSpace(SiriusSpacing.xs)
                GlassCard {
                    val activeProvider = state.activeProvider
                    NavigationRow(
                        icon = Icons.Rounded.Key,
                        // With a provider selected the row is about that endpoint,
                        // so it wears the mark the user picked for it instead of
                        // the generic key.
                        leading = if (activeProvider != null) {
                            { ProviderAvatar(provider = activeProvider, size = 26.dp) }
                        } else {
                            null
                        },
                        title = stringResource(R.string.settings_providers_title),
                        subtitle = activeProvider?.let {
                            "${it.displayLabel()} \u00B7 ${settings.activeModel.ifBlank { it.defaultModel }}"
                        } ?: stringResource(R.string.settings_no_provider),
                        onClick = onOpenProviders
                    )
                    SettingToggle(
                        icon = Icons.Rounded.AutoAwesome,
                        title = stringResource(R.string.settings_streaming),
                        subtitle = stringResource(R.string.settings_streaming_subtitle),
                        checked = settings.streamingEnabled,
                        onCheckedChange = viewModel::setStreaming
                    )
                    VSpace(SiriusSpacing.xs)
                    SliderRow(
                        label = stringResource(R.string.settings_temperature),
                        value = settings.temperature,
                        valueLabel = String.format(java.util.Locale.US, "%.2f", settings.temperature),
                        range = 0f..1.5f,
                        // 0.05 apart: fine enough to tune, coarse enough to hit again.
                        steps = 29,
                        onChange = viewModel::setTemperature
                    )
                    SliderRow(
                        label = stringResource(R.string.settings_max_tokens),
                        value = settings.maxTokens.toFloat(),
                        valueLabel = settings.maxTokens.toString(),
                        range = 512f..16_000f,
                        steps = 30,
                        onChange = { viewModel.setMaxTokens(it.toInt()) }
                    )
                    SliderRow(
                        label = stringResource(R.string.settings_agent_steps),
                        value = settings.agentMaxSteps.toFloat(),
                        valueLabel = settings.agentMaxSteps.toString(),
                        range = 1f..12f,
                        steps = 10,
                        onChange = { viewModel.setAgentMaxSteps(it.toInt()) }
                    )
                }
            }

            item(key = "github") {
                SectionHeader(title = stringResource(R.string.settings_section_github))
                VSpace(SiriusSpacing.xs)
                GlassCard {
                    NavigationRow(
                        icon = Icons.Rounded.Cloud,
                        title = stringResource(R.string.github_title),
                        // The subtitle answers the only question the row raises:
                        // is anything connected, and to what repository.
                        subtitle = settings.githubRepo.ifBlank {
                            stringResource(R.string.github_not_connected)
                        },
                        onClick = onOpenGitHub
                    )
                }
            }

            item(key = "workspace") {
                SectionHeader(title = stringResource(R.string.settings_section_workspace))
                VSpace(SiriusSpacing.xs)
                GlassCard {
                    NavigationRow(
                        icon = Icons.Rounded.Code,
                        title = stringResource(R.string.editor_title),
                        subtitle = stringResource(
                            R.string.settings_editor_summary,
                            settings.editorFontSize,
                            settings.editorTabSize,
                            stringResource(
                                if (settings.editorWordWrap) R.string.label_on else R.string.label_off
                            )
                        ),
                        onClick = onOpenEditorSettings
                    )
                    // The terminal has nothing to configure, so this row states a fact
                    // instead of pretending to lead somewhere.
                    NavigationRow(
                        icon = Icons.Rounded.Terminal,
                        title = stringResource(R.string.terminal_title),
                        subtitle = stringResource(R.string.settings_terminal_subtitle),
                        onClick = null
                    )
                }
            }

            item(key = "privacy") {
                SectionHeader(title = stringResource(R.string.settings_section_privacy))
                VSpace(SiriusSpacing.xs)
                GlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.Security,
                            contentDescription = null,
                            tint = colors.success,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(SiriusSpacing.xs))
                        Text(
                            text = stringResource(R.string.settings_privacy_title),
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary
                        )
                    }
                    VSpace(SiriusSpacing.xs)
                    Text(
                        text = stringResource(R.string.settings_privacy_body),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    val withKeys = state.providers.count { it.hasKey }
                    VSpace(SiriusSpacing.sm)
                    Text(
                        text = stringResource(
                            R.string.settings_keys_stored,
                            withKeys,
                            state.providers.size
                        ),
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.textTertiary
                    )
                    VSpace(SiriusSpacing.xs)
                    // Wiping every key is irreversible for anyone who did not save them
                    // elsewhere, so it is a real button with a real confirmation — and it
                    // goes quiet when there is nothing to wipe.
                    SiriusGhostButton(
                        text = stringResource(R.string.settings_clear_keys),
                        icon = Icons.Rounded.DeleteOutline,
                        tint = colors.error,
                        enabled = withKeys > 0,
                        onClick = { confirmClearKeys = true },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            item(key = "about") {
                GlassCard(
                    onClick = onOpenAbout,
                    onClickLabel = stringResource(
                        R.string.settings_open,
                        stringResource(R.string.settings_about)
                    )
                ) {
                    NavigationRow(
                        icon = Icons.Rounded.Info,
                        title = stringResource(R.string.settings_about),
                        subtitle = stringResource(R.string.settings_about_subtitle),
                        // The card is already the touch target; a nested one would
                        // give screen readers two ways to do the same thing.
                        onClick = null
                    )
                }
            }
        }
    }

    if (confirmClearKeys) {
        val done = stringResource(R.string.settings_clear_keys_done)
        SiriusConfirmSheet(
            title = stringResource(R.string.settings_clear_keys_title),
            message = stringResource(R.string.settings_clear_keys_message),
            confirmLabel = stringResource(R.string.settings_clear_keys_confirm),
            icon = Icons.Rounded.Key,
            onConfirm = {
                confirmClearKeys = false
                viewModel.clearCredentials()
                toast = done
            },
            onDismiss = { confirmClearKeys = false }
        )
    }

    MessageToast(
        message = toast,
        tone = ToastTone.Success,
        bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.sm
    )
}

/**
 * One decision, rendered as a wrapping row of chips.
 *
 * FlowRow rather than Row because translated labels ("Приглушённый", "Русский")
 * outgrow a phone line and must not be clipped, and [selectableGroup] plus a
 * group label is what turns three tinted chips into one announced choice.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> OptionChipGroup(
    label: String,
    options: List<T>,
    selected: T,
    labelOf: @Composable (T) -> String,
    onSelect: (T) -> Unit,
    iconOf: (T) -> ImageVector? = { null }
) {
    val colors = SiriusTheme.colors
    Column(modifier = Modifier.semantics { contentDescription = label }) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleSmall,
            color = colors.textPrimary
        )
        VSpace(SiriusSpacing.xs)
        FlowRow(
            modifier = Modifier.selectableGroup(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            options.forEach { option ->
                SiriusChip(
                    text = labelOf(option),
                    icon = iconOf(option),
                    selected = option == selected,
                    onClick = { onSelect(option) }
                )
            }
        }
    }
}

/**
 * Label, supporting line and a switch.
 *
 * The whole row toggles — a 20dp thumb is not a touch target — and the switch
 * itself stops being independently clickable so the row is announced once, with
 * its on/off state, instead of twice.
 */
@Composable
fun SettingToggle(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true
) {
    val colors = SiriusTheme.colors
    val stateLabel = stringResource(
        if (checked) R.string.a11y_state_on else R.string.a11y_state_off
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .toggleable(
                value = checked,
                enabled = enabled,
                role = Role.Switch,
                onValueChange = onCheckedChange
            )
            .semantics {
                contentDescription = "$title. $subtitle"
                stateDescription = stateLabel
            }
            .heightIn(min = 48.dp)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = colors.textSecondary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(SiriusSpacing.sm))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = colors.textTertiary)
        }
        Switch(
            checked = checked,
            onCheckedChange = null,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = colors.onPrimary,
                checkedTrackColor = colors.primary,
                uncheckedTrackColor = colors.surfaceMuted
            )
        )
    }
}

/**
 * Navigation or informational row.
 *
 * A null [onClick] is the informational form: no chevron, no click target, no
 * promise it cannot keep.
 *
 * [leading] replaces the stock [icon] when the row stands for something that
 * carries its own mark, such as a provider the user gave an icon to.
 */
@Composable
fun NavigationRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: (() -> Unit)?,
    leading: (@Composable () -> Unit)? = null
) {
    val colors = SiriusTheme.colors
    val openLabel = stringResource(R.string.settings_open, title)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (onClick != null) {
                    Modifier
                        .clickable(role = Role.Button, onClickLabel = openLabel, onClick = onClick)
                        .heightIn(min = 48.dp)
                } else {
                    Modifier
                }
            )
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) {
            leading()
        } else {
            Icon(
                icon,
                contentDescription = null,
                tint = colors.primary,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(Modifier.width(SiriusSpacing.sm))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary,
                maxLines = 2
            )
        }
        if (onClick != null) {
            Icon(
                Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = colors.textTertiary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * Slider with its value shown as text.
 *
 * [steps] keeps a dragged value reachable again — a continuous 512..16000 range
 * cannot be returned to on purpose — and the value is announced as the row's
 * state rather than being visible only in the label beside it.
 */
@Composable
fun SliderRow(
    label: String,
    value: Float,
    valueLabel: String,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    steps: Int = 0
) {
    val colors = SiriusTheme.colors
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = valueLabel,
                style = MaterialTheme.typography.labelMedium,
                color = colors.primary,
                // The slider already announces the value; reading it twice is noise.
                modifier = Modifier.clearAndSetSemantics { }
            )
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = colors.primary,
                activeTrackColor = colors.primary,
                inactiveTrackColor = colors.surfaceMuted
            ),
            modifier = Modifier.semantics {
                contentDescription = label
                stateDescription = valueLabel
            }
        )
    }
}

/** Localized label for each theme mode, so chips never show enum names. */
@StringRes
private fun ThemeMode.labelRes(): Int = when (this) {
    ThemeMode.System -> R.string.theme_system
    ThemeMode.Light -> R.string.theme_light
    ThemeMode.Dark -> R.string.theme_dark
}

/** Localized label for each glass level. */
@StringRes
private fun GlassLevel.labelRes(): Int = when (this) {
    GlassLevel.Off -> R.string.glass_off
    GlassLevel.Subtle -> R.string.glass_subtle
    GlassLevel.Full -> R.string.glass_full
}

/**
 * Localized label for each UI language. Language names stay in their own
 * language so they are recognizable regardless of the active locale.
 */
@StringRes
private fun AppLanguage.labelRes(): Int = when (this) {
    AppLanguage.System -> R.string.language_system
    AppLanguage.English -> R.string.language_english
    AppLanguage.Russian -> R.string.language_russian
}
