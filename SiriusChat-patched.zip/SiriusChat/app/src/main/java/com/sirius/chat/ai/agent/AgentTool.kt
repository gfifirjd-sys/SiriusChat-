package com.sirius.chat.ai.agent

import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.repository.WorkspaceRepository
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

/** Everything a tool needs to touch the workspace. */
data class AgentContext(
    val sessionId: String,
    val projectId: String?,
    val treeUri: String?,
    val workspace: WorkspaceRepository
)

data class AgentToolResult(
    val output: String,
    val success: Boolean = true,
    /** Set by mutating tools: the change waits for user approval. */
    val proposal: PendingChange? = null
)

/**
 * A capability the model can invoke.
 *
 * Tools are split into read-only and mutating. Read-only tools run
 * immediately; mutating tools never touch storage themselves, they only
 * produce a [PendingChange] that the user reviews in the diff viewer.
 */
interface AgentTool {
    val name: String
    val description: String
    /** Human readable argument list injected into the system prompt. */
    val usage: String
    val mutating: Boolean get() = false

    suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult
}

internal fun JsonObject.string(key: String): String? =
    this[key]?.let { runCatching { it.jsonPrimitive.content }.getOrNull() }?.takeIf { it.isNotBlank() }

internal fun JsonObject.stringOrEmpty(key: String): String =
    this[key]?.let { runCatching { it.jsonPrimitive.content }.getOrNull() }.orEmpty()

internal fun JsonObject.int(key: String, fallback: Int): Int =
    this[key]?.let { runCatching { it.jsonPrimitive.content.toInt() }.getOrNull() } ?: fallback
