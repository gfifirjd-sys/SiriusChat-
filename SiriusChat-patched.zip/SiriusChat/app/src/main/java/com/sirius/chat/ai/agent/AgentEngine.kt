package com.sirius.chat.ai.agent

import com.sirius.chat.ai.agent.tools.AnalyzeProjectTool
import com.sirius.chat.ai.agent.tools.CreateFileTool
import com.sirius.chat.ai.agent.tools.DeleteFileTool
import com.sirius.chat.ai.agent.tools.ListDirectoryTool
import com.sirius.chat.ai.agent.tools.MoveFileTool
import com.sirius.chat.ai.agent.tools.ReadFileTool
import com.sirius.chat.ai.agent.tools.RenameFileTool
import com.sirius.chat.ai.agent.tools.SearchFilesTool
import com.sirius.chat.ai.agent.tools.SearchTextTool
import com.sirius.chat.ai.agent.tools.WriteFileTool
import com.sirius.chat.ai.context.SystemPrompts
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.provider.AiProvider
import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.model.ToolRun
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import java.util.UUID

/** Events the chat layer renders while the agent works. */
sealed interface AgentEvent {
    data class StepStarted(val step: Int) : AgentEvent
    data class Delta(val text: String) : AgentEvent
    data class ToolStarted(val toolName: String, val preview: String) : AgentEvent
    data class ToolFinished(val run: ToolRun) : AgentEvent
    data class Proposals(val changes: List<PendingChange>) : AgentEvent
    data class Completed(val text: String) : AgentEvent
    data class Failure(val error: AiError) : AgentEvent
}

/**
 * The agent loop: ask the model, run the tools it requested, feed the results
 * back, repeat until it stops asking for tools or the step budget runs out.
 *
 * Mutating tools do not write anything; their proposals are collected and
 * emitted so the UI can show a diff and ask for approval.
 */
class AgentEngine(
    private val tools: List<AgentTool> = defaultTools()
) {

    fun toolList(): List<AgentTool> = tools

    fun run(
        provider: AiProvider,
        model: String,
        history: List<AiMessage>,
        context: AgentContext,
        projectContext: String?,
        params: com.sirius.chat.domain.model.GenerationParams,
        maxSteps: Int
    ): Flow<AgentEvent> = channelFlow {
        val systemPrompt = SystemPrompts.agent(tools, projectContext)
        val conversation = history.toMutableList()
        val proposals = ArrayList<PendingChange>()
        // Prose from *every* step, in order. The chat bubble shows the whole run
        // as it streams, so the stored message has to be the whole run too --
        // keeping only the last step silently dropped everything the model said
        // before its first tool call.
        val transcript = StringBuilder()

        for (step in 1..maxSteps) {
            send(AgentEvent.StepStarted(step))

            val builder = StringBuilder()
            var failed: AiError? = null

            provider.chat(
                ChatRequest(
                    model = model,
                    messages = conversation.toList(),
                    systemPrompt = systemPrompt,
                    params = params,
                    stream = true
                )
            ).collect { event ->
                when (event) {
                    is ChatStreamEvent.Delta -> {
                        builder.append(event.text)
                        send(AgentEvent.Delta(event.text))
                    }
                    is ChatStreamEvent.Failure -> failed = event.error
                    else -> Unit
                }
            }

            val error = failed
            if (error != null) {
                send(AgentEvent.Failure(error))
                return@channelFlow
            }

            val answer = builder.toString()
            val calls = ToolCallParser.parse(answer)

            // Append this step's prose instead of replacing the total. A step whose
            // entire output was a tool call contributes nothing and must not erase
            // what came before it.
            val prose = ToolCallParser.stripToolBlocks(answer)
            if (prose.isNotBlank()) {
                if (transcript.isNotEmpty()) transcript.append("\n\n")
                transcript.append(prose)
            }

            if (calls.isEmpty()) break

            conversation += AiMessage(AiRole.Assistant, answer)
            val results = StringBuilder("Tool results:\n")

            for (call in calls) {
                val tool = tools.firstOrNull { it.name == call.tool }
                val preview = call.args.toString().take(160)
                send(AgentEvent.ToolStarted(call.tool, preview))

                val startedAt = System.currentTimeMillis()
                val result = if (tool == null) {
                    AgentToolResult("Unknown tool '${call.tool}'.", success = false)
                } else {
                    // `runCatching` also catches CancellationException, which
                    // turned pressing Stop mid-tool into a fake tool failure and
                    // let the loop start another step. Cancellation has to win.
                    try {
                        tool.execute(call.args, context)
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (t: Throwable) {
                        AgentToolResult("Tool failed: ${t.message}", success = false)
                    }
                }
                val duration = System.currentTimeMillis() - startedAt

                result.proposal?.let { proposals += it }

                val run = ToolRun(
                    id = UUID.randomUUID().toString(),
                    toolName = call.tool,
                    argumentsPreview = preview,
                    // What the user can expand under the tool row. Larger than it
                    // was: a 4000-char cap hid the tail of exactly the reads that
                    // needed checking, and the transcript is where a user
                    // verifies what the model actually saw.
                    output = result.output.take(MAX_STORED_OUTPUT_CHARS),
                    success = result.success,
                    durationMs = duration
                )
                send(AgentEvent.ToolFinished(run))

                results.appendLine("[${call.tool}] ${if (result.success) "ok" else "error"}")
                results.appendLine(clipForModel(result.output))
                results.appendLine()
            }

            conversation += AiMessage(AiRole.User, results.toString())

            if (step == maxSteps && transcript.isBlank()) {
                transcript.append(
                    "Reached the step limit ($maxSteps). Ask me to continue if more work is needed."
                )
            }
        }

        if (proposals.isNotEmpty()) send(AgentEvent.Proposals(proposals))
        send(AgentEvent.Completed(transcript.toString().trim()))
    }

    /**
     * Bounds one tool result before it is handed back to the model.
     *
     * The cut itself is unavoidable — a tool can return more than a context
     * window holds — but a *silent* cut is a correctness bug, not a limit: this
     * is what made `read_file` stop at line 277 of a longer file while looking
     * like a complete read, after which the model rewrote the file from the part
     * it had. So the clip now ends on a line boundary and says, in the output the
     * model reads, that data is missing and how to ask for the rest.
     *
     * Tools that page their own output (read_file, github_read_file) stay well
     * under this cap and are never touched here.
     */
    private fun clipForModel(output: String): String {
        if (output.length <= MAX_TOOL_OUTPUT_CHARS) return output
        val head = output.take(MAX_TOOL_OUTPUT_CHARS)
        // Prefer the last newline so a truncated line never reads as a real one.
        val boundary = head.lastIndexOf('\n').takeIf { it > MAX_TOOL_OUTPUT_CHARS / 2 }
            ?: head.length
        val kept = head.substring(0, boundary)
        val dropped = output.length - kept.length
        return buildString {
            append(kept)
            appendLine()
            append(
                "\u2026 [Sirius cut this tool result after ${kept.length} characters; " +
                    "$dropped characters were NOT shown. The data above is incomplete. " +
                    "Re-run the tool with a narrower request, or with pagination arguments " +
                    "(read_file and github_read_file accept \"offset\" and \"limit\") " +
                    "until you have read everything. Do not rewrite a file you have only " +
                    "partially read.]"
            )
        }
    }

    companion object {
        /**
         * Characters of one tool result that reach the model.
         *
         * Raised from 8000, which was under a single page of a real source file:
         * a 300-line HTML file with line numbers already exceeded it. Kept finite
         * because several results accumulate in one conversation turn.
         */
        private const val MAX_TOOL_OUTPUT_CHARS = 24_000

        /** Characters of one tool result kept in the transcript for the user. */
        private const val MAX_STORED_OUTPUT_CHARS = 16_000

        fun defaultTools(): List<AgentTool> = listOf(
            ReadFileTool(),
            ListDirectoryTool(),
            SearchFilesTool(),
            SearchTextTool(),
            AnalyzeProjectTool(),
            CreateFileTool(),
            WriteFileTool(),
            DeleteFileTool(),
            RenameFileTool(),
            MoveFileTool()
        )
    }
}
