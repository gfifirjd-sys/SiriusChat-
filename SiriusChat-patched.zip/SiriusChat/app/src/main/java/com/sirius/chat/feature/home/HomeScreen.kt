package com.sirius.chat.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountTree
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.ProjectAccents
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.ProviderAvatar
import com.sirius.chat.core.designsystem.components.SectionHeader
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusOrb
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.labelled
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.locale.displayLabel
import com.sirius.chat.core.ui.rememberWorkspacePicker
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.relativeTimeText
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.ProviderConfig

@Composable
fun HomeScreen(
    onOpenChat: (String) -> Unit,
    onOpenProjects: () -> Unit,
    onOpenProject: (String) -> Unit,
    onOpenFiles: () -> Unit,
    onOpenTerminal: () -> Unit,
    onOpenGit: () -> Unit,
    onOpenGitHub: () -> Unit,
    onOpenProviders: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: HomeViewModel = siriusViewModel { HomeViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors

    val picker = rememberWorkspacePicker { treeUri ->
        viewModel.createProjectFromTree(treeUri) { onOpenProject(it) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(
            start = SiriusSpacing.md,
            end = SiriusSpacing.md,
            top = SiriusSpacing.xs,
            bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
        ),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.md)
    ) {
        item(key = "header") {
            Column(modifier = Modifier.statusBarsPadding()) {
                Spacer(Modifier.height(SiriusSpacing.sm))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // The orb is the brand mark: it is the assistant, so it
                    // stands in for a logo here rather than a generic sparkle.
                    // The wordmark next to it already names the app, so the orb
                    // stays silent instead of announcing "Sirius" twice.
                    SiriusOrb(size = 34.dp)
                    Spacer(Modifier.width(SiriusSpacing.xs))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.home_brand),
                            style = MaterialTheme.typography.headlineSmall,
                            color = colors.textPrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.semantics { heading() }
                        )
                        Text(
                            text = state.activeProject?.let {
                                stringResource(R.string.home_workspace_named, it.name)
                            } ?: stringResource(R.string.home_no_workspace),
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textTertiary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        item(key = "hero") {
            HeroCard(
                needsSetup = state.needsProviderSetup,
                provider = state.readyProvider,
                modelLabel = state.readyProvider?.let { provider ->
                    "${provider.displayLabel()} \u00B7 ${state.settings.activeModel.ifBlank { provider.defaultModel }}"
                } ?: stringResource(R.string.home_no_provider),
                onStart = { viewModel.startChat { onOpenChat(it) } },
                onSetup = onOpenProviders
            )
        }

        // Five tiles do not fit a 360dp phone without truncating the labels, and a
        // truncated label on an icon-only tile is a guessing game. Two rows of
        // equal tiles instead, GitHub next to Git because that is where a user
        // looking for "the repository thing" starts.
        item(key = "quick") {
            Column(verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                    QuickAction(
                        icon = Icons.Rounded.CreateNewFolder,
                        label = stringResource(R.string.home_open_folder),
                        modifier = Modifier.weight(1f)
                    ) { picker.launch(null) }
                    QuickAction(
                        icon = Icons.Rounded.FolderOpen,
                        label = stringResource(R.string.nav_files),
                        modifier = Modifier.weight(1f),
                        onClick = onOpenFiles
                    )
                    QuickAction(
                        icon = Icons.Rounded.Terminal,
                        label = stringResource(R.string.nav_terminal),
                        modifier = Modifier.weight(1f),
                        onClick = onOpenTerminal
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                    QuickAction(
                        icon = Icons.Rounded.AccountTree,
                        label = stringResource(R.string.git_title),
                        modifier = Modifier.weight(1f),
                        onClick = onOpenGit
                    )
                    QuickAction(
                        icon = Icons.Rounded.Cloud,
                        label = stringResource(R.string.github_title),
                        modifier = Modifier.weight(1f),
                        onClick = onOpenGitHub
                    )
                    QuickAction(
                        icon = Icons.Rounded.Tune,
                        label = stringResource(R.string.providers_title),
                        modifier = Modifier.weight(1f),
                        onClick = onOpenProviders
                    )
                }
            }
        }

        if (state.projects.isNotEmpty()) {
            item(key = "projects-header") {
                SectionHeader(
                    title = stringResource(R.string.projects_title),
                    subtitle = pluralStringResource(
                        R.plurals.home_projects_count,
                        state.projects.size,
                        state.projects.size
                    ),
                    actionLabel = stringResource(R.string.action_see_all),
                    onAction = onOpenProjects
                )
            }
            item(key = "projects-row") {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs),
                    contentPadding = PaddingValues(vertical = SiriusSpacing.xxs)
                ) {
                    items(state.projects.take(8), key = { it.id }) { project ->
                        ProjectCard(
                            project = project,
                            active = project.id == state.settings.activeProjectId,
                            // Selecting reorders nothing here, but favouriting on
                            // the Projects screen does, so the cards animate.
                            modifier = Modifier.animateItem(),
                            onClick = {
                                viewModel.selectProject(project.id)
                                onOpenProject(project.id)
                            }
                        )
                    }
                }
            }
        }

        item(key = "chats-header") {
            SectionHeader(
                title = stringResource(R.string.home_recent_chats),
                subtitle = if (state.sessions.isEmpty()) {
                    stringResource(R.string.home_nothing_yet)
                } else {
                    pluralStringResource(
                        R.plurals.chats_count,
                        state.sessions.size,
                        state.sessions.size
                    )
                }
            )
        }

        if (state.sessions.isEmpty()) {
            item(key = "chats-empty") {
                GlassCard {
                    Text(
                        text = stringResource(R.string.home_chats_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary
                    )
                }
            }
        } else {
            items(state.sessions.take(6), key = { it.id }) { session ->
                SessionRow(session = session, onClick = { onOpenChat(session.id) })
            }
        }
    }
}

/**
 * The one hero on the one screen that gets a hero.
 *
 * There is exactly one filled button here: two adjacent primaries cancel each
 * other out and leave the user with no default. "New chat" is the default, so
 * the agent option is a ghost sitting next to it.
 */
@Composable
private fun HeroCard(
    needsSetup: Boolean,
    provider: ProviderConfig?,
    modelLabel: String,
    onStart: () -> Unit,
    onSetup: () -> Unit
) {
    val colors = SiriusTheme.colors
    GlassCard(contentPadding = SiriusSpacing.lg) {
        Text(
            text = stringResource(R.string.home_hero_title),
            style = MaterialTheme.typography.headlineMedium,
            color = colors.textPrimary,
            modifier = Modifier.semantics { heading() }
        )
        Spacer(Modifier.height(SiriusSpacing.xxs))
        Text(
            text = stringResource(R.string.home_hero_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary
        )
        Spacer(Modifier.height(SiriusSpacing.md))
        Row(verticalAlignment = Alignment.CenterVertically) {
            // The endpoint's own mark next to its name, so the icon picked on the
            // providers screen is what greets you here too.
            if (provider != null) {
                ProviderAvatar(provider = provider, size = 28.dp)
                Spacer(Modifier.width(SiriusSpacing.xs))
            }
            SiriusChip(
                text = modelLabel,
                icon = if (needsSetup) Icons.Rounded.Key else Icons.Rounded.Bolt,
                color = if (needsSetup) colors.warning else colors.accent
            )
        }
        Spacer(Modifier.height(SiriusSpacing.md))
        if (needsSetup) {
            SiriusPrimaryButton(
                text = stringResource(R.string.home_connect_provider),
                onClick = onSetup,
                icon = Icons.Rounded.Key,
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            Row(
                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Still one filled button: the second control is an icon, so the
                // default path forward stays unambiguous.
                SiriusPrimaryButton(
                    text = stringResource(R.string.chats_new_agent),
                    onClick = onStart,
                    icon = Icons.Rounded.AutoAwesome,
                    modifier = Modifier.weight(1f)
                )
                // Switching endpoint or model was three taps away (Settings ->
                // Providers) even though the chip above already names the model.
                GlassIconButton(
                    icon = Icons.Rounded.Tune,
                    contentDescription = stringResource(R.string.providers_title),
                    size = 46.dp,
                    iconSize = 20.dp,
                    onClick = onSetup
                )
            }
        }
    }
}

@Composable
private fun QuickAction(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = SiriusTheme.colors
    GlassCard(
        modifier = modifier,
        onClick = onClick,
        onClickLabel = label,
        contentPadding = SiriusSpacing.sm,
        shape = RoundedCornerShape(SiriusRadius.md)
    ) {
        Icon(icon, contentDescription = null, tint = colors.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = colors.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ProjectCard(
    project: Project,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = SiriusTheme.colors
    val accent = ProjectAccents[project.accentIndex % ProjectAccents.size]
    val favouriteLabel = stringResource(R.string.projects_favorite)

    GlassCard(
        modifier = modifier.width(180.dp),
        onClick = onClick,
        onClickLabel = stringResource(R.string.projects_open_project, project.name),
        tint = if (active) accent.copy(alpha = 0.18f) else null
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(SiriusRadius.xs))
                    .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.4f))))
                    // The monogram is decoration; the card already says the name.
                    .labelled(""),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = project.name.take(1).uppercase(),
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White
                )
            }
            Spacer(Modifier.weight(1f))
            if (project.favorite) {
                Icon(
                    Icons.Rounded.Star,
                    contentDescription = favouriteLabel,
                    tint = colors.warning,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
        Spacer(Modifier.height(SiriusSpacing.xs))
        // The tint alone carried "this is the active workspace", which is
        // invisible to a screen reader and to anyone who cannot separate the
        // two plate colours. The chip states it outright.
        if (active) {
            SiriusChip(
                text = stringResource(R.string.label_active),
                icon = Icons.Rounded.Bolt,
                color = accent
            )
            Spacer(Modifier.height(SiriusSpacing.xs))
        }
        Text(
            text = project.name,
            style = MaterialTheme.typography.titleSmall,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = if (project.hasWorkspace) {
                project.workspaceLabel.ifBlank { stringResource(R.string.label_workspace) }
            } else {
                stringResource(R.string.home_no_folder)
            },
            style = MaterialTheme.typography.bodySmall,
            color = colors.textTertiary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(SiriusSpacing.xxs))
        Text(
            text = relativeTimeText(project.lastOpenedAt),
            style = MaterialTheme.typography.labelSmall,
            color = colors.textTertiary
        )
    }
}

@Composable
private fun SessionRow(session: ChatSession, onClick: () -> Unit) {
    val colors = SiriusTheme.colors
    val agentLabel = stringResource(R.string.chats_agent)

    GlassCard(
        onClick = onClick,
        onClickLabel = stringResource(R.string.chats_open_chat, session.title),
        contentPadding = SiriusSpacing.sm
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .softSurface(CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = agentLabel,
                    tint = colors.accent,
                    modifier = Modifier.size(17.dp)
                )
            }
            Spacer(Modifier.width(SiriusSpacing.sm))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = session.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = session.lastMessagePreview.ifBlank {
                        stringResource(R.string.chats_no_messages)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(SiriusSpacing.xs))
            Text(
                text = relativeTimeText(session.updatedAt),
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary
            )
        }
    }
}
