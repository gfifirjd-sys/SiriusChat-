# Tool calling

How a model's request to use a tool becomes a tool run, and what goes wrong on
the way.

## Channels, in the order they are trusted

1. **Vendor function calling.** Sent only when a real probe request proved the
   endpoint accepts a `tools` array. Arguments arrive as structured JSON, so
   nothing can be mangled by a missing fence.
2. **A fenced block** the system prompt documents:
   ````sirius-tool` with `{"tool": ..., "args": {...}}`. This is the
   fallback every model can drive, including small local ones.
3. **XML-shaped calls.** `invoke name="tool">{...}</invoke>`, with or without
   `<|...|>` harness sentinels around it. Some hosted models emit this on a
   plain completions endpoint, where nothing strips it for them.
4. **An unfenced object**, as a last resort, and only when it names a tool that
   actually exists.

## What the parser normalises

- **Names.** `functions.read_file`, `tools:read_file`, `Read-File` and
  `read file` all resolve to `read_file`. Only the spelling is normalised; an
  invented name still fails, with the list of real tools in the answer so the
  model can correct itself on the next step.
- **Drafts.** `<think>`/`<reasoning>` blocks are removed before parsing and
  before display. A reasoning model narrates the call it is about to make, and
  running the narration meant acting on arguments it had already discarded.
- **Half-arrived calls.** While an answer streams, an unclosed tool fence, an
  unclosed `invoke`, and a partial sentinel are hidden rather than shown and
  then retracted.
- **Duplicates.** Identical calls in one turn run once.

## What the argument readers accept

| Sent | Read as |
| --- | --- |
| `"path": "a.kt"` | `a.kt` |
| `"content": ["line", "line"]` | the lines, joined with newlines |
| `"offset": "12"` or `12.0` | `12` |
| `"arguments"` as an object instead of a string | the object, re-serialised |
| a required argument present but blank | reported as missing, with the usage line |

Each row is a call that used to fail as "missing argument", or -- worse for
`write_file` -- succeed with nothing in it.
