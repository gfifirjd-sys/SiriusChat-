# Touch targets and sheet gestures

Two bugs with the same shape: a control that moves or resizes while a finger is
on it stops being the control the finger landed on.

## Press-scale must sit below the click node

Every tappable surface springs inwards on press (chip 0.94, icon button 0.88,
primary 0.965, ghost 0.97, card 0.978, sheet row 0.985). Compose hit-tests
through layer transforms, so a `scale` applied *above* a `clickable` shrinks the
hit box while the press is held. A finger near an edge is then outside the node
and `clickable` cancels the press instead of firing it -- the control appears to
need a second tap. Order is therefore always:

```kotlin
Modifier
    .clickable(...)   // hit box: the laid-out size, stable
    .scale(scale)     // visual only
    .softSurface(shape)
    .padding(...)
```

Applies to `GlassCard`, `SiriusChip`, `SiriusPrimaryButton`, `SiriusGhostButton`,
`SheetActionRow` and `Modifier.pressable`. `GlassIconButton` was already ordered
this way.

## Text fields: the plate is the target

`SiriusTextField` draws a plate with 10dp of vertical padding around a single
line of text. Only the text box itself could take focus, so a tap on the padding
did nothing and the field looked like it needed two taps. The plate now carries a
no-indication `clickable` that forwards focus to the field through a
`FocusRequester`.

## Sheet bodies

- **No entrance animation on the body.** A translating node slides out from
  under a stationary finger (press cancelled) and injects phantom delta into
  drag-slop detection (first flick eaten). The sheet window already animates; the
  header keeps its reveal because nothing there is tappable.
- **`imePadding()`.** The app is edge-to-edge, so the keyboard arrives as an
  inset and does not resize anything. Without it the focused field and the
  buttons under it sit behind the keyboard.
- **`lockBodyDrag = true` for list sheets.** Drags the list did not claim are
  swallowed instead of being handed to the sheet's dismiss drag, so a swipe can
  never move the sheet a few pixels in place of moving the list. Set on the
  provider catalog, the local-server sweep and the provider editor.
