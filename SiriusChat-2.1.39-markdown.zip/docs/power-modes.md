# Answer power

Five modes -- LOW, MEDIUM, HIGH, MAX, CUSTOM -- resolved per endpoint.

## Why not max_tokens

`max_tokens` is a length cap. On a reasoning model it buys no extra thinking and
on the o-series it is not even called `max_tokens`. Power is therefore an intent
translated per endpoint.

## The chain

1. **Effort tier** when the API has one (`reasoning_effort`, `reasoning.effort`,
   `thinking.type`). Tiers come from the endpoint's own list, so MAX means the
   strongest word *that* provider accepts, and a two-tier API (xAI mini) maps
   MEDIUM to `low` rather than inventing `medium`.
2. **Thinking budget** when the API takes a token count: 1k / 4k / 16k / model
   maximum, clamped to the real range, with the flag the API requires
   (`thinking.type`, `enable_thinking`) attached automatically.
3. **Length** only when neither exists: 1k / 4k / 16k / real ceiling.
4. **Nothing.** `PowerConfig.NoOp`, the request goes out untouched, and the sheet
   says the endpoint has no power settings. Silence here is a bug, not a default.

A budget always raises `max_tokens` above itself, because on Anthropic thinking
and the reply share one cap.

## Guarantees

- No field is written unless `EndpointCapabilities` has a wire path for it and
  this endpoint has not refused it. The path can come from the table, from the
  dialect, or from the model family; the value is set either by the resolver
  (presets) or by the user (manual).
- A learned rejection (`ModelQuirks`) removes the capability, so the second
  attempt is honest and the UI degrades to "not adjustable".
- The model is never changed by a power change.
- `temperature` is untouched by all of this.

## Storage

Per `(endpointId, modelId)` pair, in the existing settings DataStore:
`power_modes` holds `endpoint|model=MODE`, `power_custom` holds the CUSTOM fields
as `endpoint|model=tokens;effort;budget`. New pairs start at MEDIUM.

## Endpoints nobody listed

The table only knows the endpoints somebody typed into it, so a hand-added
gateway used to get length as its only knob even while it served a thinking
model. `EndpointCapabilityTable.upgrade` closes that in two steps, and it only
ever widens -- a listed endpoint outranks a guess about a name.

1. **Dialect.** An Anthropic-compatible endpoint gets `thinking.budget_tokens`
   whatever the model is called, because that path belongs to the protocol.
   Presets stay off, manual mode can reach it.
2. **Model family.** An id that reads as a thinking model gets the knob its
   dialect uses: `deepseek-r1`, `qwq`, `qwen3`, `gpt-oss`, `magistral`,
   `glm-4.5`/`4.6`, `minimax-m*`, `nemotron`, `ernie-x1`, `hunyuan-t1`, anything
   containing `thinking`/`reasoner`/`reasoning`, plus the o-series, gpt-5,
   Gemini 2.5+, Grok 3 mini and Claude 3.7+. These are marked `inferred`, the
   sheet says so out loud, and one refusal removes them for good.

Manual mode is wider still: `reasoning_effort` may go to any endpoint that has
not refused it, because on a private gateway the user is the only one who knows.
`refusedReasoningEffort` / `refusedThinkingBudget` are what keep "never
declared" apart from "tried and rejected" -- the first still allows a hand-set
value, the second is final.

The cost of a wrong guess is bounded and paid once: the 400 names the field,
`ModelQuirks` records it, `AgentEngine` retries the same step without it, and
every later request is clean.

## What each family actually gets

Read off the providers' own 2026 docs, newest first. "Wire path" is what a preset
writes into the request; "ladder" is the set of words that endpoint accepts.

| Family | Wire path | Ladder |
| --- | --- | --- |
| Claude 4.7+, Opus 5, Sonnet 5 | `output_config.effort` + `thinking.type: adaptive` | low, medium, high, xhigh, max |
| Claude 4.6 | `output_config.effort` + `thinking.type: adaptive` | low, medium, high, max (`xhigh` is a 400) |
| Claude 3.7 - 4.5 | `thinking.budget_tokens` + `thinking.type: enabled` | 1k / 4k / 16k / ceiling |
| gpt-5.6 line | `reasoning_effort` | none, low, medium, high, xhigh, max |
| gpt-5.2 - 5.5, codex-max | `reasoning_effort` | none, low, medium, high, xhigh |
| gpt-5, gpt-5.1 | `reasoning_effort` | none, low, medium, high |
| o1, o3, o4-mini | `reasoning_effort` | low, medium, high |
| o1-preview, o1-mini, any `*-chat` | length only | -- |
| gpt-6, o5, anything newer than this table | `reasoning_effort` | low, medium, high (deliberately conservative) |
| Gemini 3+ Flash / Lite | `extra_body.google.thinking_config.thinking_level` | minimal, low, medium, high |
| Gemini 3+ Pro | `extra_body.google.thinking_config.thinking_level` | low, high (`medium` is a 400) |
| Gemini 2.5 | `extra_body.google.thinking_config.thinking_budget` | 0/128 - 32k |
| Gemini image / tts / embedding | length only | -- |
| Grok 4.6+ | `reasoning_effort` | low, medium, high, xhigh |
| Grok 4.5 | `reasoning_effort` | low, medium, high |
| Grok 4.3 | `reasoning_effort` | none, low, medium, high |
| Grok 3 mini | `reasoning_effort` | low, high |
| Grok 4, 4.1-fast, code models | length only | -- |
| DeepSeek V4, reasoner | `reasoning_effort` + `thinking.type: enabled` | low, high, max |
| GLM 5.3+ | `reasoning_effort` + `thinking.type: enabled` | low, high, max |
| GLM 5.0 - 5.2 | `reasoning_effort` + `thinking.type: enabled` | minimal, low, medium, high, xhigh, max |
| GLM 4.x | `thinking.type` | disabled, enabled |
| Kimi K3 | `reasoning_effort` | low, high, max |
| Kimi K2.x | length only (its own `thinking` block rejects the word) | -- |
| Qwen3+ | `reasoning_effort` *or* `thinking_budget` + `enable_thinking` | low, medium, xhigh / 0 - 8k |
| OpenRouter | `reasoning.effort` *or* `reasoning.max_tokens` | minimal, low, medium, high, xhigh |
| Groq / Cerebras gpt-oss | `reasoning_effort` | low, medium, high |
| Perplexity sonar-reasoning | `reasoning_effort` | low, medium, high |
| Anything unlisted | inferred from the model name and the dialect, then length | -- |

Three rules keep this table from turning into a special case per model.

- A tier and a budget are never sent together. They are two spellings of one
  decision, and every gateway that exposes both rejects the pair.
- A switch (`thinking.type`, `enable_thinking`) is only ever sent next to the
  control it enables, and now travels with a *tier* as well as with a budget --
  that is what Claude's adaptive mode, GLM and DashScope all require.
- A mode picks its tier by meaning, not by position in the list. Counting slots
  sent `none` for LOW on a six-word ladder and `medium` for MAX on a three-word
  one; each mode now names the words it accepts and takes the first one this
  endpoint lists.
- Rows are version rules, not name lists. `gpt-5.6-sol`, `-terra`, `-luna`,
  `-mini`, `-codex`, dated snapshots, `claude-opus-4-7`, `grok-4.7`, `glm-6`,
  `kimi-k4`, `gemini-4-flash` all land on the right ladder without a new branch,
  because only the version and the dialect are read. A future major nobody has
  documented yet gets the conservative ladder rather than the newest one: an
  unknown *word* is refused exactly like an unknown *field*, and that would cost
  the endpoint the whole knob instead of one step.

MAX asks for at most 32k of output even where the model publishes 128k or more.
That number is also what the context trimmer reserves before dropping turns, so
asking for the literal ceiling would spend the window on room the answer never
uses.

## Adding an endpoint

Add one branch to `EndpointCapabilityTable`. The resolver, the wire converter and
the UI need no changes.
