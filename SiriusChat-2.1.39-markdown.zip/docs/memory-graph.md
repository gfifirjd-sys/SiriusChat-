# The memory scene

Two renderers draw the same graph. Which one runs is decided once, when the
screen opens, by whether the library is in `app/src/main/assets/graph`.

| | WebView scene | Canvas scene |
| --- | --- | --- |
| Renderer | `3d-force-graph` (WebGL, three.js) | Compose `Canvas` |
| Lives in | `app/src/main/assets/graph`, `MemoryWebScene.kt` | `MemoryGraphScreen.kt` |
| Needs vendoring | yes | no |
| Layout | the library's `d3-force-3d` | the same d3-force defaults, ported |

The app never downloads the library at runtime. `MemoryWebScene` blocks network
loads on the WebView, and the page loads three local files.

## Vendoring the library

```sh
sh tools/fetch_graph_lib.sh
```

That writes two files:

- `app/src/main/assets/graph/3d-force-graph.min.js` — required. Its presence is
  what switches the screen to the WebView scene.
- `app/src/main/assets/graph/three.min.js` — optional. Only the glow sprites use
  it; without it the nodes are plain lit spheres.

CI does the same in the `Vendor the graph library` step, so a cloud build ships
the WebGL scene even though the files are not committed. The step is
`continue-on-error`: if unpkg is down, the build still produces an APK, with the
Canvas scene inside it.

## The bridge

Kotlin owns the data; the page owns the pixels.

| Direction | Call | Payload |
| --- | --- | --- |
| app → page | `window.siriusRender(json)` | `{ nodes: [{ id, text, file, color, size }], links: [{ source, target, group, color }] }` |
| app → page | `window.siriusApply(json)` | `{ selected, labels, spin }` |
| page → app | `Sirius.onNodeTap(id)` | the tapped fact |
| page → app | `Sirius.onBackgroundTap()` | empty space was tapped |

`siriusRender` reseeds the simulation, so it is only called when the facts
themselves change. Everything that changes more often — the open fact, the
label switch, auto-rotate — goes through `siriusApply`.

## The look, in both renderers

- Almost black with an indigo glow behind the middle of the cloud, black at the
  edges.
- Node colour is the category — profile violet, projects turquoise, habits pink,
  topics amber, people coral, preferences sky — shaded per memory file, so two
  files in the same category are still two visibly different clusters.
- Node size grows with the number of links, capped at six.
- Nodes are lit from inside: a halo, a body, and a hot core, rather than a flat
  fill.
- Labels are small captions beside the nodes, capped at eighteen so the scene
  stays a picture rather than a page of text.
- A tap opens the fact in a bottom sheet and flies the camera to it.

## How the renderer is found (updated)

1. `assets/graph/3d-force-graph.min.js`, when it was vendored by
   `tools/fetch_graph_lib.sh` or by the release build.
2. The published copy, fetched once by `index.html`. This is the only request
   the page is allowed to make; file and content access stay off, and the
   memory itself never leaves the phone.
3. Neither: after a few seconds the page calls `onSceneFailed`, and the screen
   draws the same graph with the Compose `Canvas` renderer.

## Spheres

Both renderers aim at the same picture. The WebGL side gets lit spheres from
the library plus an additive glow sprite behind each one, and a single particle
travelling along every stated link. The Canvas side shades each node with a
radial gradient offset up and to the left, with a highlight where the light
lands and a dark rim on the far side -- an offset gradient reads as a ball, a
centred one reads as a disc.

## While the scene loads

The Canvas scene is the failure path and nothing else. Until the page reports a
scene, the screen shows its gradient and one line of text -- the flat graph is
never drawn first. Two different designs inside one second read as a broken
screen rather than as a fallback doing its job.
