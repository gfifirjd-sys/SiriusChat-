# Transcript scrolling and images

## Why the chat used to jump while it was being scrolled

Two separate movements were read as one bug.

1. **The follow ran mid-gesture.** While an answer streams, a delta lands every
   few frames and the transcript re-anchors itself to the end. `atBottom` alone
   decided whether to do that, and during a fling the content passes the end for
   a frame or two, so a delta arriving right then cancelled the gesture and threw
   the list to the bottom. The follow now also requires
   `listState.isScrollInProgress` to be false: a list somebody is touching is
   never taken over. `atBottom` also answers `false` when nothing is measured
   yet, instead of `true`.
2. **The jump to the end was two jumps.** `scrollToItem(index)` aligns an item's
   *top* with the top of the viewport. For a streaming answer several screens
   tall that meant showing its first line, then correcting downwards on the next
   frame. The instant path now passes an offset larger than any item can be
   (`END_ANCHOR_PX`) and lets the list clamp itself at the bottom of its content
   in one pass.

Items also used to change height under the finger: a picture was drawn as a
loading card first and as the real bitmap a frame later, which moved every
message below it. `GeneratedImageStore.dimensions` reads the file header without
decoding the pixels, and the placeholder reserves that aspect ratio.

## Pictures that point at nothing

`sirius-image:` references are file names in `filesDir/generated-images`. A model
that retypes one instead of copying the line it was given produces a name that
resolves to no file, and the transcript used to show a full-width grey square
saying the image was no longer stored on the device -- a data-loss message for
data that never existed.

- `resolve` is lenient: it trims prose punctuation and falls back to a
  case-insensitive and extension-insensitive match.
- `repair` runs once, before the answer is stored. A dead reference is replaced
  by the picture this turn's tools actually produced when there is exactly one,
  and otherwise the link degrades to its alt text.
- If a file really is gone (pruned at the 256 MB budget), the renderer shows a
  single line rather than a picture-shaped hole.
