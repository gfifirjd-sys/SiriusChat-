# Markdown

What the chat renderer reads, and what it deliberately refuses to read.

The vocabulary here is the contract between three places: `MarkdownParser`
splits the text into blocks, `MarkdownText` draws them, `InlineMarkdown` draws
the runs inside them, and `SystemPrompts.RENDERING` tells the model which of it
exists. A block the prompt never mentions is dead code, so anything added below
is added there too.

## Blocks

| Written as | Drawn as |
| --- | --- |
| `# H1` … `###### H6` | headings, 20/18/16sp then body weight |
| `Title` over `=====` | H1. The `-----` form stays a divider on purpose |
| `## Title ##` | heading; the closing run is dropped, but `## C#` keeps its hash |
| `- item`, `* item`, `+ item` | bullets, two spaces per nesting level, four deep |
| `1. item`, `1) item` | numbered list, keeping the numbers the author wrote |
| `- [ ]`, `- [x]` | task list with a drawn mark, not a live checkbox |
| `> text` | quote with an accent bar |
| `> [!NOTE]` and `[!TIP]` `[!IMPORTANT]` `[!WARNING]` `[!CAUTION]` | coloured callout with an icon and a translated label |
| ```` ```lang ```` and `~~~lang` | code block, highlighted, copyable |
| ```` ```lang File.kt ```` | file card that can be opened, saved or shared |
| ```` ```diff ```` | patch colouring: `+` green, `-` red, `@@` accented |
| ```` ```progress ```` / ```` ```tree ```` | progress bars / a file tree |
| `$$ \\frac{a}{b} $$` | display maths, also mid-paragraph |
| `| a | b |` with `|:---|---:|` | table, honouring alignment and `\\|` inside a cell |
| `![alt](uri)` alone on a line | image, including a generated one |
| `<details><summary>T</summary>…</details>` | folded section; the body is full markdown, three deep |
| `[^1]: note` | collected and printed once under a rule at the end |
| `---`, `***`, `___` | divider |
| `<!-- note -->` | nothing. It is a note to the author |

## Inline

| Written as | Drawn as |
| --- | --- |
| `**bold**`, `*it*`, `_it_`, `~~struck~~` | the obvious |
| `` `code` `` and ``` ``code with a ` in it`` ``` | monospace on a tinted ground |
| `==marked==` | highlighted ground |
| `[label](url)` | tappable link |
| `<https://sirius.dev>` | tappable link labelled with the address |
| `https://sirius.dev` bare | tappable link. Trailing `.,;:!?)]}` stay in the sentence |
| `[^1]` | superscript marker in link colour |
| `<br>` | line break, the only way to break a line inside a table cell |
| `\\*` `\\_` `\\|` `\\#` … | the character itself, unstyled |
| `#ff8800`, `rgb(…)`, `hsl(…)` | the value plus a colour chip |

## Not supported, on purpose

- **Four-space indented code.** Chat text is full of accidentally indented
  lines; treating them as code turned ordinary paragraphs into grey boxes far
  more often than it caught a real block. Use a fence.
- **`Title` over `-----` as a heading.** After a sentence that underline is far
  more often a divider, and guessing wrong silently retitles the paragraph above
  it while the reader watches.
- **HTML beyond `<br>`, `<details>` and `<summary>`.** Not a browser. Tags
  arrive as text.
- **Reference links, definition lists, `~sub~`, `^sup^`, `<kbd>`, mermaid.**
  No renderer, so they would print as their own syntax.

## Adding one

1. A branch in `MarkdownParser.parse`, plus the block in `MarkdownBlock`.
2. A branch in `MarkdownText`'s `when (block)` — it is exhaustive, so the
   compiler will insist anyway.
3. A line in `SystemPrompts.RENDERING`, or the model will never emit it.
4. A row in the tables above.
