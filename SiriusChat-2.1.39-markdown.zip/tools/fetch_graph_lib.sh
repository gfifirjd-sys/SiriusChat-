#!/bin/sh
# Vendors the memory scene's renderer into app/src/main/assets/graph.
#
# The app draws the memory graph with 3d-force-graph when these files are
# present and with its own Canvas renderer when they are not, so this script is
# optional -- it upgrades the scene, it does not make the app work.
#
# CI runs the same two downloads before a build (.github/workflows/sirius-apk.yml).
# Run it by hand when you want the WebGL scene in a local build:
#
#   sh tools/fetch_graph_lib.sh

set -e

GRAPH_VERSION="${GRAPH_VERSION:-1.73.4}"
THREE_VERSION="${THREE_VERSION:-0.149.0}"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIR="$ROOT/app/src/main/assets/graph"
mkdir -p "$DIR"

echo "3d-force-graph $GRAPH_VERSION -> $DIR"
curl -fsSL --retry 3 \
  -o "$DIR/3d-force-graph.min.js" \
  "https://unpkg.com/3d-force-graph@$GRAPH_VERSION/dist/3d-force-graph.min.js"

# Optional. The force-graph bundle carries its own three.js and does not export
# it; this copy is only what the glue uses for the glow sprites, and the scene
# draws without it.
echo "three $THREE_VERSION -> $DIR (optional)"
curl -fsSL --retry 3 \
  -o "$DIR/three.min.js" \
  "https://unpkg.com/three@$THREE_VERSION/build/three.min.js" || \
  echo "three.min.js was not fetched; nodes will draw without the glow sprite"

ls -l "$DIR"
