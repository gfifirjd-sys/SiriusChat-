#!/usr/bin/env python3
"""kselftest.py - proves kcheck.py catches real defects and stays quiet otherwise.

Two synthetic projects are generated from scratch:
  clean/  - valid Kotlin/Compose code. Expected result: zero findings.
  broken/ - one deliberate defect per class, each in its own file, mirroring the
            defects that actually broke this project's builds.

A checker nobody has tested against known-bad input is just a source of noise,
so this is the gate that makes kcheck's "0 findings" mean something.

Usage: python3 /data/tools/kselftest.py
"""

import os
import shutil
import sys

sys.path.insert(0, "/data/tools")
import kcheck  # noqa: E402

ROOT = "/data/regress"

STRINGS = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="ok">OK</string>
</resources>
"""

CLEAN = """package com.x

import androidx.compose.runtime.Composable

/** Doc comment with an apostrophe: the tokenizer's old nemesis. */
interface Repo {
    val id: String
    suspend fun load(key: String): String
    fun close() {}
}

class RealRepo(private val tag: String) : Repo {
    override val id: String = tag
    override suspend fun load(key: String): String = "value of ${'$'}key + ' quote {"
}

sealed interface Event {
    val stamp: Long
        get() = 0L

    data class Delta(val text: String) : Event
    data class Done(val reason: String?, val total: Int = 0) : Event
}

@Composable
fun Card(title: String, subtitle: String = "", content: @Composable () -> Unit) {
    content()
}

@Composable
fun Screen() {
    Card(title = "a") { }
    Card("a", "b") { }
    val label = R.string.ok
}
"""

BAD_BALANCE = """package com.x

fun broken(): Int {
    if (true) {
        return 1
    return 0
}
"""

BAD_DUP = """package com.x

class Holder {
    private var probeJob: Int? = null
    private val other: Int = 1
    private var probeJob: Int? = null
}
"""

BAD_IMPL = """package com.x

interface Store {
    val id: String
    suspend fun searchMessages(query: String): List<String>
    fun close() {}
}

class StoreImpl : Store {
    override val id: String = "s"
}
"""

BAD_COMPOSE = """package com.x

import androidx.compose.runtime.Composable

@Composable
fun Panel(title: String, subtitle: String = "", content: @Composable () -> Unit) {
    content()
}

@Composable
fun Host() {
    Panel(subtitle = "b") { }
    Panel(title = "a", bogus = 1) { }
    Panel("a", "b", "c", "d") { }
}
"""

BAD_PKG = """package com.wrong

fun label(): Int = R.string.nope
"""


BAD_ICON = """package com.x

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.rounded.Image as ImageIcon

// Compiles nowhere: this file imports the outlined eye, not the rounded one.
val wrong = Icons.Rounded.Visibility

// Both fine, and neither may be reported.
val right = Icons.Outlined.Visibility
val aliased = Icons.Rounded.ImageIcon
"""


def write(path, body):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(body)


def build(name, files):
    root = os.path.join(ROOT, name)
    shutil.rmtree(root, ignore_errors=True)
    for rel, body in files.items():
        write(os.path.join(root, "app", "src", "main", "java", rel), body)
    write(os.path.join(root, "app", "src", "main", "res", "values", "strings.xml"), STRINGS)
    return root


def main():
    failures = 0

    clean_root = build("clean", {"com/x/Main.kt": CLEAN})
    report = kcheck.run(clean_root)
    findings = sum(len(report[k]) for k in ("balance", "package", "duplicates", "impls", "calls", "res"))
    ok = findings == 0
    failures += 0 if ok else 1
    print("[%s] negative control: clean project -> %d findings" % ("PASS" if ok else "FAIL", findings))
    if not ok:
        for key in ("balance", "package", "duplicates", "impls", "calls", "res"):
            for item in report[key]:
                print("        false positive (%s): %s" % (key, item))

    broken_root = build(
        "broken",
        {
            "com/x/BadBalance.kt": BAD_BALANCE,
            "com/x/BadDup.kt": BAD_DUP,
            "com/x/BadImpl.kt": BAD_IMPL,
            "com/x/BadCompose.kt": BAD_COMPOSE,
            "com/x/BadPkg.kt": BAD_PKG,
            "com/x/BadIcon.kt": BAD_ICON,
        },
    )
    report = kcheck.run(broken_root)
    blob = "\n".join(
        report["balance"] + report["package"] + report["duplicates"]
        + report["impls"] + report["calls"] + report["icons"] + report["res"]
    )

    expected = [
        ("unbalanced brace", "unclosed '{'"),
        ("duplicate declaration", "'probeJob' declared 2 times"),
        ("unimplemented member", "does not declare 'searchMessages'"),
        ("missing required arg", "missing required argument(s): title"),
        ("unknown named arg", "has no parameter 'bogus'"),
        ("too many args", "got 5 arguments, takes 3"),
        ("package mismatch", "package com.wrong does not match"),
        ("missing string res", "missing string resource: nope"),
        ("icon style without import", "Icons.Rounded.Visibility needs import"),
    ]
    for label, needle in expected:
        hit = needle in blob
        failures += 0 if hit else 1
        print("[%s] catches %s" % ("PASS" if hit else "FAIL", label))
        if not hit:
            print("        expected substring: %s" % needle)

    # The other half of a useful gate: what it must stay quiet about. An icon
    # check that flags correct code gets switched off within a week.
    for label, needle in (
        ("aliased icon import", "ImageIcon"),
        ("matching icon import", "Icons.Outlined.Visibility needs"),
    ):
        clean = needle not in blob
        failures += 0 if clean else 1
        print("[%s] allows %s" % ("PASS" if clean else "FAIL", label))
        if not clean:
            print("        unexpected substring: %s" % needle)

    print("\n--- broken project report ---")
    print(blob if blob else "(nothing reported)")
    print("\nFAILURES: %d" % failures)
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
