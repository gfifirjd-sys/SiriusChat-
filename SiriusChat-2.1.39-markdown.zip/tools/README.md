# tools

Offline checks for this project, in plain Python 3 with no dependencies.

This app is written on a phone and by agents that have no Android SDK, no Kotlin
compiler and often no network, so the compiler is not available at the moment
the code is written. These two scripts cover the gap between "the code looks
fine" and "the build ran".

## kcheck.py

    python3 tools/kcheck.py .
    python3 tools/kcheck.py . --json

Seven stages over `app/src/main/java`:

1. **tokenizer** - comments become spaces, string and char literals become `0`
   fillers. Offsets are preserved, so line numbers are exact, and an apostrophe
   in a KDoc comment or a brace inside a string can no longer desynchronise the
   scanner. A literal still counts as an argument.
2. **balance** - `()` `[]` `{}` with the line and column of the first mismatch.
3. **package** - the `package` declaration against the directory path.
4. **duplicates** - two declarations of the same name in the same block.
   Blocks are identified by their opening brace, and functions by their
   parameter types, so overloads and same-named locals in sibling scopes are
   not reported.
5. **interface members** - a concrete class that does not declare a member its
   interface requires. Abstract, sealed and enum classes are skipped, members
   with default bodies or getters are not required, and a nested data class
   inside a sealed interface is not confused with the interface's own members.
6. **Compose call sites** - arity, unknown named arguments and missing required
   arguments, restricted to uniquely named top-level `@Composable` functions,
   where an unqualified call cannot be resolving to something else's member.
7. **string resources** - every `R.string.*` reference against
   `values/strings.xml`.

Exits non-zero when anything is found, so CI can gate a build on it before
spending five minutes on Gradle.

## kselftest.py

    python3 tools/kselftest.py

Generates two synthetic projects and checks kcheck against both: a clean one
that must produce zero findings, and a broken one with one deliberate defect per
class, each of which must be caught. A checker nobody has run against known-bad
input is just a source of noise, and its first version really did report 318
findings of which about 315 were wrong.

## What these do not do

They are not a compiler. No type inference, no resolution of imports or
generics, no Compose compiler plugin rules. A green gate means the build has a
chance, not that it will pass. The compiler of record is the `Sirius APK`
workflow: run it with the `check` variant for `compileDebugKotlin` alone.
