#!/usr/bin/env python3
"""kcheck.py v2 - offline near-compiler checks for a Kotlin/Compose source tree.

This sandbox has a JRE but no javac, no kotlinc, no Gradle, no Android SDK and no
network, so the real compiler cannot run here. These stages reproduce the classes
of errors that actually broke builds in this project, with precision favoured
over recall: a check that cries wolf is worse than no check.

Stages
  1 blank     tokenizer: comments / strings / char literals -> spaces (offsets kept)
  2 balance   () [] {} with the exact line:col of the first mismatch
  3 package   package declaration must match directory path
  4 decls     duplicate declarations in the *same* block (block identity, not name)
  5 impls     concrete class implementing a project interface declares every member
  6 calls     PascalCase @Composable call sites: arity + named args + trailing lambda
  7 res       R.string.* references vs values/strings.xml

Usage: python3 /data/tools/kcheck.py [ROOT] [--json]
"""

import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict

# --------------------------------------------------------------- tokenizer


def _block_comment_end(s, i):
    n = len(s)
    depth = 1
    j = i + 2
    while j < n:
        if s.startswith("/*", j):
            depth += 1
            j += 2
            continue
        if s.startswith("*/", j):
            depth -= 1
            j += 2
            if depth == 0:
                return j
            continue
        j += 1
    return n


def _char_end(s, i):
    n = len(s)
    j = i + 1
    while j < n:
        if s[j] == "\\":
            j += 2
            continue
        if s[j] == "'":
            return j + 1
        if s[j] == "\n":
            return j
        j += 1
    return n


def _string_end(s, i):
    n = len(s)
    if s.startswith('"""', i):
        j = i + 3
        while j < n:
            if s.startswith('"""', j):
                k = j
                while k < n and s[k] == '"':
                    k += 1
                return k
            if s[j] == "$" and j + 1 < n and s[j + 1] == "{":
                j = _template_end(s, j)
                continue
            j += 1
        return n
    j = i + 1
    while j < n:
        c = s[j]
        if c == "\\":
            j += 2
            continue
        if c == '"':
            return j + 1
        if c == "\n":
            return j
        if c == "$" and j + 1 < n and s[j + 1] == "{":
            j = _template_end(s, j)
            continue
        j += 1
    return n


def _template_end(s, i):
    n = len(s)
    j = i + 1
    depth = 0
    while j < n:
        c = s[j]
        if c == "{":
            depth += 1
            j += 1
            continue
        if c == "}":
            depth -= 1
            j += 1
            if depth == 0:
                return j
            continue
        if c == '"':
            j = _string_end(s, j)
            continue
        if c == "'":
            j = _char_end(s, j)
            continue
        if s.startswith("//", j):
            k = s.find("\n", j)
            j = n if k < 0 else k
            continue
        if s.startswith("/*", j):
            j = _block_comment_end(s, j)
            continue
        j += 1
    return n


def blank(src):
    """Neutralise comments and literals while keeping every offset intact.

    Comments become spaces because a comment is not a token. String and char
    literals become '0' fillers instead, so a literal argument still counts as
    an argument while its brackets, quotes and apostrophes stay invisible.
    """
    out = list(src)
    n = len(src)
    i = 0

    def wipe(a, b, fill=" "):
        for k in range(a, min(b, n)):
            if src[k] != "\n":
                out[k] = fill

    while i < n:
        c = src[i]
        if src.startswith("//", i):
            k = src.find("\n", i)
            end = n if k < 0 else k
            wipe(i, end)
            i = end
            continue
        if src.startswith("/*", i):
            end = _block_comment_end(src, i)
            wipe(i, end)
            i = end
            continue
        if c == '"':
            end = _string_end(src, i)
            wipe(i, end, "0")
            i = end
            continue
        if c == "'":
            end = _char_end(src, i)
            wipe(i, end, "0")
            i = end
            continue
        i += 1
    return "".join(out)


# --------------------------------------------------------------- helpers

PAIRS = {"(": ")", "[": "]", "{": "}"}
CLOSERS = {")": "(", "]": "[", "}": "{"}

MODS = (
    "public|private|internal|protected|abstract|open|sealed|data|value|enum|"
    "annotation|inner|expect|actual|final|const|companion|override|lateinit|"
    "suspend|inline|operator|infix|tailrec|external"
)

TYPE_DECL = re.compile(
    r"(?m)^([ \t]*)((?:(?:%s)\s+)*)(class|interface|object)\s+(\w+)" % MODS
)
FUN_DECL = re.compile(
    r"\bfun\s+(?:<[^<>=]*>\s*)?(?:([\w.<>]+)\s*\.\s*)?(\w+)\s*\("
)
PROP_DECL = re.compile(r"(?m)^([ \t]*)((?:(?:%s)\s+)*)(val|var)\s+(\w+)\s*[:=]" % MODS)
CALL = re.compile(r"\b([A-Z]\w*)\s*\(")
NAMED_ARG = re.compile(r"^\s*(\w+)\s*=(?!=)")


def line_of(code, pos):
    return code.count("\n", 0, pos) + 1


def match_paren(code, i):
    depth = 0
    for j in range(i, len(code)):
        if code[j] == "(":
            depth += 1
        elif code[j] == ")":
            depth -= 1
            if depth == 0:
                return j
    return -1


def split_top(text):
    parts = []
    depth = 0
    cur = []
    for ch in text:
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append("".join(cur))
            cur = []
            continue
        cur.append(ch)
    tail = "".join(cur)
    if tail.strip():
        parts.append(tail)
    return [p for p in parts if p.strip()]


def has_default(part):
    depth = 0
    prev = ""
    for idx, ch in enumerate(part):
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        elif ch == "=" and depth == 0:
            nxt = part[idx + 1] if idx + 1 < len(part) else ""
            if prev not in "=!<>" and nxt != "=":
                return True
        prev = ch
    return False


PARAM_NAME = re.compile(
    r"^\s*(?:@\w+(?:\([^)]*\))?\s+)*"
    r"(?:vararg\s+|noinline\s+|crossinline\s+|val\s+|var\s+)*"
    r"(\w+)\s*:"
)


def split_params(inner):
    """Split a parameter or supertype list on top-level commas.

    Angle brackets count as nesting here: a type list is the one place where a
    comma inside `<...>` is guaranteed not to separate entries. `->` is excluded
    so function types do not close a bracket they never opened.
    """
    parts = []
    cur = []
    depth = 0
    angle = 0
    prev = ""
    for ch in inner:
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        elif ch == "<":
            angle += 1
        elif ch == ">" and prev != "-" and angle > 0:
            angle -= 1
        if ch == "," and depth == 0 and angle == 0:
            parts.append("".join(cur))
            cur = []
            prev = ch
            continue
        cur.append(ch)
        prev = ch
    tail = "".join(cur)
    if tail.strip():
        parts.append(tail)
    return [p for p in parts if p.strip()]


def arg_segments(inner):
    """Split call arguments at depth 0 and report whether a top-level `<` makes
    the segmentation ambiguous (generic call, or a comparison).
    """
    segs = []
    cur = []
    depth = 0
    angle = False
    for ch in inner:
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        elif ch == "<" and depth == 0:
            angle = True
        if ch == "," and depth == 0:
            segs.append("".join(cur))
            cur = []
            continue
        cur.append(ch)
    tail = "".join(cur)
    if tail.strip():
        segs.append(tail)
    return [s for s in segs if s.strip()], angle


def parse_params(code, open_idx):
    close = match_paren(code, open_idx)
    if close < 0:
        return None, open_idx
    params = []
    for part in split_params(code[open_idx + 1 : close]):
        m = PARAM_NAME.match(part)
        if not m:
            continue
        params.append(
            {
                "name": m.group(1),
                "default": has_default(part),
                "vararg": bool(re.search(r"\bvararg\b", part)),
            }
        )
    return params, close


def depths(code):
    """Return (paren_depth_before_pos, brace_blocks) for one file."""
    pdepth = bytearray(len(code) + 1)
    blocks = []
    stack = []
    p = 0
    for pos, ch in enumerate(code):
        pdepth[pos] = min(p, 255)
        if ch == "(":
            p += 1
        elif ch == ")":
            p = max(0, p - 1)
        elif ch == "{":
            stack.append(pos)
        elif ch == "}":
            if stack:
                blocks.append((stack.pop(), pos))
    pdepth[len(code)] = min(p, 255)
    return pdepth, sorted(blocks)


def enclosing(blocks, pos):
    """Innermost block containing pos, identified by its opening offset."""
    best = -1
    for open_pos, close_pos in blocks:
        if open_pos > pos:
            break
        if pos < close_pos and open_pos > best:
            best = open_pos
    return best


def preceded_by_composable(raw, pos):
    start = raw.rfind("\n", 0, pos)
    head = raw[max(0, start - 400) : pos]
    tail = head.split("\n")[-4:]
    return any("@Composable" in line for line in tail)


NEXT_DECL = re.compile(
    r"^(?:@|class\b|interface\b|object\b|fun\b|val\b|var\b|typealias\b|"
    r"private\b|internal\b|public\b|protected\b|data\b|sealed\b|abstract\b|"
    r"enum\b|open\b|annotation\b|companion\b)"
)


def class_header(text, start):
    """Bounds of a type declaration whose name ends at `start`.

    Returns (constructor_text, supertype_text, body_open_index). A body-less
    declaration yields body_open_index -1 instead of swallowing the next
    declaration's braces, which is what made this check unusable at first.
    """
    n = len(text)
    i = start
    while i < n and text[i] in " \t":
        i += 1
    if i < n and text[i] == "<":
        depth = 0
        while i < n:
            if text[i] == "<":
                depth += 1
            elif text[i] == ">":
                depth -= 1
                if depth == 0:
                    i += 1
                    break
            i += 1
    while i < n and text[i] in " \t\n":
        i += 1
    ctor = ""
    if i < n and text[i] == "(":
        close = match_paren(text, i)
        if close < 0:
            return "", None, -1
        ctor = text[i : close + 1]
        i = close + 1
    header_start = i
    depth = 0
    j = i
    while j < n:
        c = text[j]
        if c in "([":
            depth += 1
        elif c in ")]":
            depth = max(0, depth - 1)
        elif c == "{" and depth == 0:
            return ctor, text[header_start:j], j
        elif c == "\n" and depth == 0:
            k = j + 1
            while k < n and text[k] in " \t":
                k += 1
            end = text.find("\n", k)
            rest = text[k : end if end > 0 else n].strip()
            if not rest or NEXT_DECL.match(rest):
                header = text[header_start:j]
                return (ctor, header, -1) if ":" in header else (ctor, None, -1)
        j += 1
    return ctor, None, -1


def collect(root):
    files = []
    for base, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ("build", ".gradle", ".git", ".idea")]
        for name in names:
            if name.endswith(".kt"):
                files.append(os.path.join(base, name))
    return sorted(files)


# --------------------------------------------------------------- main pass


def run(root):
    src_root = os.path.join(root, "app", "src", "main", "java")
    if not os.path.isdir(src_root):
        src_root = root
    files = collect(src_root)

    raw, code, pdep, blks = {}, {}, {}, {}
    for path in files:
        with open(path, "r", encoding="utf-8") as handle:
            text = handle.read()
        raw[path] = text
        code[path] = blank(text)
        pdep[path], blks[path] = depths(code[path])

    report = {
        "survey": {
            "files": len(files),
            "lines": sum(t.count("\n") + 1 for t in raw.values()),
        },
        "balance": [],
        "package": [],
        "duplicates": [],
        "impls": [],
        "calls": [],
        "icons": [],
        "res": [],
        "stats": {},
    }

    def rel(path):
        return os.path.relpath(path, src_root)

    # ---- stage 2: bracket balance
    for path in files:
        text = code[path]
        stack = []
        line = col = 1
        for ch in text:
            if ch == "\n":
                line += 1
                col = 1
                continue
            if ch in PAIRS:
                stack.append((ch, line, col))
            elif ch in CLOSERS:
                if not stack:
                    report["balance"].append(
                        "%s:%d:%d unexpected '%s'" % (rel(path), line, col, ch)
                    )
                else:
                    opener, oline, ocol = stack.pop()
                    if PAIRS[opener] != ch:
                        report["balance"].append(
                            "%s:%d:%d '%s' closes '%s' opened at %d:%d"
                            % (rel(path), line, col, ch, opener, oline, ocol)
                        )
            col += 1
        for opener, oline, ocol in stack:
            report["balance"].append(
                "%s:%d:%d unclosed '%s'" % (rel(path), oline, ocol, opener)
            )

    # ---- stage 3: package vs directory
    for path in files:
        m = re.search(r"(?m)^package\s+([\w.]+)", code[path])
        if not m:
            report["package"].append("%s: no package declaration" % rel(path))
            continue
        expect = os.path.dirname(rel(path)).replace(os.sep, ".")
        if expect and m.group(1) != expect:
            report["package"].append(
                "%s: package %s does not match directory %s"
                % (rel(path), m.group(1), expect)
            )

    # ---- stage 4: declarations, duplicates
    types = {}
    funs = defaultdict(list)
    seen = defaultdict(list)

    for path in files:
        text = code[path]
        blocks = blks[path]
        for m in TYPE_DECL.finditer(text):
            mods, kind, name = m.group(2), m.group(3), m.group(4)
            types.setdefault(name, {"path": path, "kind": kind, "mods": mods, "pos": m.start()})
            seen[(path, enclosing(blocks, m.start()), "type", name, 0, "")].append(m.start())
        for m in FUN_DECL.finditer(text):
            recv, name = m.group(1) or "", m.group(2)
            open_idx = m.end() - 1
            params, close_idx = parse_params(text, open_idx)
            if params is None:
                continue
            line_start = text.rfind("\n", 0, m.start()) + 1
            indent = m.start() - line_start
            funs[name].append(
                {
                    "path": path,
                    "pos": m.start(),
                    "receiver": recv,
                    "params": params,
                    "toplevel": indent == 0,
                    "composable": preceded_by_composable(raw[path], m.start()),
                }
            )
            seen[
                (
                    path,
                    enclosing(blocks, m.start()),
                    "fun",
                    name,
                    re.sub(r"\s+", "", text[open_idx : close_idx + 1]),
                    recv,
                )
            ].append(m.start())
        for m in PROP_DECL.finditer(text):
            # skip constructor parameters: they live inside parentheses
            if pdep[path][m.start()] > 0:
                continue
            seen[
                (path, enclosing(blocks, m.start()), "prop", m.group(4), 0, "")
            ].append(m.start())

    for key, positions in sorted(seen.items(), key=lambda kv: (kv[0][0], kv[0][3])):
        if len(positions) > 1:
            path, block, kind, name, arity, recv = key
            lines = [line_of(code[path], p) for p in positions]
            report["duplicates"].append(
                "%s: %s '%s%s' declared %d times in the same block, lines %s"
                % (rel(path), kind, recv + "." if recv else "", name, len(positions), lines)
            )

    # ---- stage 5: interface members implemented
    interfaces = {}
    for path in files:
        text = code[path]
        blocks = blks[path]
        for m in TYPE_DECL.finditer(text):
            if m.group(3) != "interface":
                continue
            _, _, body_open = class_header(text, m.end())
            body = next((b for b in blocks if b[0] == body_open), None)
            if not body:
                continue
            members = []
            base = body[0] + 1
            rows = []
            cursor = base
            for line in text[base : body[1]].split("\n"):
                stripped = line.strip()
                rows.append((stripped, cursor + len(line) - len(line.lstrip())))
                cursor += len(line) + 1
            for idx, (s, offset) in enumerate(rows):
                if not s:
                    continue
                # Only declarations directly in this body. A nested data class
                # constructor parameter is not a member of the interface.
                if pdep[path][offset] != pdep[path][base]:
                    continue
                if enclosing(blocks, offset) != body[0]:
                    continue
                fm = re.match(r"^(?:suspend\s+)?fun\s+(?:<[^<>]*>\s*)?(\w+)\s*\(", s)
                if fm and "=" not in s and "{" not in s:
                    members.append(fm.group(1))
                    continue
                pm = re.match(r"^val\s+(\w+)\s*:", s)
                if pm and "=" not in s and "get(" not in s:
                    following = next((t for t, _ in rows[idx + 1 :] if t), "")
                    if not following.startswith("get("):
                        members.append(pm.group(1))
            interfaces[m.group(4)] = sorted(set(members))

    for path in files:
        text = code[path]
        blocks = blks[path]
        for m in TYPE_DECL.finditer(text):
            mods, kind, name = m.group(2), m.group(3), m.group(4)
            if kind != "class":
                continue
            if any(x in mods for x in ("abstract", "sealed", "expect", "enum")):
                continue
            ctor, header, body_open = class_header(text, m.end())
            if header is None or ":" not in header or " by " in header:
                continue
            supers = [
                s.strip().split("(")[0].split("<")[0]
                for s in split_params(header.split(":", 1)[1])
            ]
            if any(s in types and types[s]["kind"] == "class" for s in supers):
                continue
            declared = set(
                x.group(1) for x in re.finditer(r"(?:val|var)\s+(\w+)\s*:", ctor)
            )
            body = next((b for b in blocks if b[0] == body_open), None)
            if body:
                inner = text[body[0] : body[1]]
                declared |= set(x.group(2) for x in FUN_DECL.finditer(inner))
                declared |= set(x.group(4) for x in PROP_DECL.finditer(inner))
            for sup in supers:
                for member in interfaces.get(sup, []):
                    if member not in declared:
                        report["impls"].append(
                            "%s: class %s does not declare '%s' required by %s"
                            % (rel(path), name, member, sup)
                        )

    # ---- stage 6: Compose call sites
    composables = {
        name: sigs[0]
        for name, sigs in funs.items()
        if len(sigs) == 1
        and sigs[0]["composable"]
        and sigs[0]["toplevel"]
        and not sigs[0]["receiver"]
        and not any(p["vararg"] for p in sigs[0]["params"])
        and name not in types
        and name[:1].isupper()
    }
    checked = 0
    for path in files:
        text = code[path]
        for m in CALL.finditer(text):
            name = m.group(1)
            sig = composables.get(name)
            if not sig:
                continue
            before = text[: m.start()].rstrip()
            if before.endswith((".", "?", "::")):
                continue
            # The optional <...> matters: in `fun <S> SiriusSwap(` the type
            # parameters sit between the keyword and the name, so a bare
            # `fun\s*$` lookbehind misses it and reports the declaration as a
            # call site with one argument per parameter.
            if re.search(r"\b(fun|class|object|interface)\s*(?:<[^<>=]*>\s*)?$", before):
                continue
            if (path, m.start()) == (sig["path"], sig["pos"]):
                continue
            open_idx = m.end() - 1
            close = match_paren(text, open_idx)
            if close < 0:
                continue
            args, angle = arg_segments(text[open_idx + 1 : close])
            if any(a.strip().startswith("*") for a in args):
                continue
            trailing = re.match(r"\s*\{", text[close + 1 :]) is not None
            names = [p["name"] for p in sig["params"]]
            required = [p["name"] for p in sig["params"] if not p["default"]]
            supplied = set()
            bad_named = []
            named = 0
            positional = 0
            for arg in args:
                nm = NAMED_ARG.match(arg)
                if nm and nm.group(1) in names:
                    supplied.add(nm.group(1))
                    named += 1
                elif nm:
                    bad_named.append(nm.group(1))
                else:
                    positional += 1
            for idx in range(min(positional, len(names))):
                supplied.add(names[idx])
            total = positional + named
            if trailing and names:
                supplied.add(names[-1])
                total += 1
            where = "%s:%d" % (rel(path), line_of(text, m.start()))
            checked += 1
            for nm in bad_named:
                report["calls"].append(
                    "%s: %s(...) has no parameter '%s' (params: %s)"
                    % (where, name, nm, ", ".join(names))
                )
            if angle:
                continue
            if total > len(names):
                report["calls"].append(
                    "%s: %s(...) got %d arguments, takes %d (%s)"
                    % (where, name, total, len(names), ", ".join(names))
                )
                continue
            missing = [r for r in required if r not in supplied]
            if missing:
                report["calls"].append(
                    "%s: %s(...) missing required argument(s): %s"
                    % (where, name, ", ".join(missing))
                )

    report["stats"]["composables_indexed"] = len(composables)
    report["stats"]["compose_call_sites"] = checked
    report["stats"]["types"] = len(types)
    report["stats"]["interfaces"] = len(interfaces)
    report["stats"]["funs"] = sum(len(v) for v in funs.values())

    # ---- stage 7: material icon receivers
    # `Icons.Rounded.Visibility` compiles only in a file that imports the
    # extension from the matching package, and nothing about the expression
    # says which package that is. Changing one usage in a file to another
    # style, or moving an import with the usage that needed it, breaks the
    # build in a way every other stage here reads as a valid property access.
    styles = {
        "Default": "filled",
        "Filled": "filled",
        "Outlined": "outlined",
        "Rounded": "rounded",
        "Sharp": "sharp",
        "TwoTone": "twotone",
    }
    for path in files:
        # `import ...rounded.Image as ImageIcon` is used as
        # `Icons.Rounded.ImageIcon`, so the alias is what the receiver has to be
        # matched against -- reading only the imported name reports working code.
        imported = set()
        for imp in re.finditer(
            r"^import\s+androidx\.compose\.material\.icons\.([\w.*]+)(?:\s+as\s+(\w+))?",
            raw[path],
            re.M,
        ):
            entry, alias = imp.group(1), imp.group(2)
            imported.add(entry)
            if alias and "." in entry:
                imported.add(entry.rsplit(".", 1)[0] + "." + alias)
        seen = set()
        for m in re.finditer(r"\bIcons\.((?:AutoMirrored\.)?\w+)\.(\w+)\b", code[path]):
            style, icon = m.group(1), m.group(2)
            mirrored = style.startswith("AutoMirrored.")
            leaf = style.split(".")[-1]
            if leaf not in styles:
                continue
            package = ("automirrored." if mirrored else "") + styles[leaf]
            if "%s.%s" % (package, icon) in imported:
                continue
            if "%s.*" % package in imported:
                continue
            key = (style, icon)
            if key in seen:
                continue
            seen.add(key)
            report["icons"].append(
                "%s:%d: Icons.%s.%s needs import androidx.compose.material.icons.%s.%s"
                % (rel(path), line_of(code[path], m.start()), style, icon, package, icon)
            )

    # ---- stage 8: string resources
    values = os.path.join(root, "app", "src", "main", "res", "values", "strings.xml")
    if os.path.isfile(values):
        try:
            have = set(
                node.get("name") for node in ET.parse(values).getroot() if node.get("name")
            )
            used = set()
            for path in files:
                used |= set(re.findall(r"R\.string\.(\w+)", code[path]))
            for name in sorted(used - have):
                report["res"].append("missing string resource: %s" % name)
            report["stats"]["strings_defined"] = len(have)
            report["stats"]["strings_used"] = len(used)
        except ET.ParseError as exc:
            report["res"].append("strings.xml does not parse: %s" % exc)

    return report


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    root = args[0] if args else "/data/sirius/SiriusChat"
    report = run(root)
    if "--json" in sys.argv:
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return
    total = 0
    print("root : %s" % root)
    print("files: %d   lines: %d" % (report["survey"]["files"], report["survey"]["lines"]))
    for key, label in (
        ("balance", "BRACKET BALANCE"),
        ("package", "PACKAGE / PATH"),
        ("duplicates", "DUPLICATE DECLARATIONS"),
        ("impls", "UNIMPLEMENTED INTERFACE MEMBERS"),
        ("calls", "COMPOSE CALL SITES"),
        ("icons", "ICON IMPORTS"),
        ("res", "RESOURCES"),
    ):
        items = report[key]
        total += len(items)
        print("\n== %s: %d ==" % (label, len(items)))
        for item in items[:30]:
            print("  " + item)
        if len(items) > 30:
            print("  ... %d more" % (len(items) - 30))
    print("\nstats: %s" % json.dumps(report["stats"], sort_keys=True))
    print("TOTAL FINDINGS: %d" % total)
    if total:
        # Non-zero so this can gate a build before Gradle starts.
        sys.exit(1)


if __name__ == "__main__":
    main()
