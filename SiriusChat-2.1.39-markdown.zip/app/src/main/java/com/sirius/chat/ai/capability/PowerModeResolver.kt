package com.sirius.chat.ai.capability

import com.sirius.chat.domain.model.EndpointCapabilities
import com.sirius.chat.domain.model.PowerConfig
import com.sirius.chat.domain.model.PowerMode
import com.sirius.chat.domain.model.PowerSelection

/**
 * Turns "work harder" into fields one specific endpoint accepts.
 *
 * Deliberately knows nothing about providers: every difference between them is
 * already expressed in [EndpointCapabilities], so a new API is a new
 * capabilities object and never a new branch in here.
 */
interface PowerModeResolver {

    fun resolve(mode: PowerMode, capabilities: EndpointCapabilities): PowerConfig
}

/**
 * The fallback chain, in order: effort tier, then thinking budget, then length.
 *
 * ### Why the chain and not a single rule
 * The three knobs are not interchangeable. An effort tier is what the provider
 * itself uses to price thinking, a budget is an exact token count, and a length
 * cap is neither -- it only decides where an answer stops. Preferring them in
 * that order means HIGH buys more *thinking* wherever thinking is purchasable,
 * and only falls back to "write a longer answer" on endpoints where that is
 * genuinely the only variable.
 *
 * The end of the chain is empty on purpose. A fixed endpoint returns
 * [PowerConfig.NoOp], the request goes out unchanged, and the UI says so.
 */
object DefaultPowerModeResolver : PowerModeResolver {

    override fun resolve(mode: PowerMode, capabilities: EndpointCapabilities): PowerConfig {
        // CUSTOM is not derivable: its values are the user's, and inventing them
        // here would overwrite what they typed the moment a request is built.
        if (mode == PowerMode.CUSTOM) return PowerConfig.NoOp

        var config = PowerConfig.NoOp

        if (capabilities.supportsReasoningEffort) {
            tier(mode, capabilities.reasoningTiers)?.let { config = config.copy(reasoningEffort = it) }
        }
        // Only when no tier was set. The two are mutually exclusive wherever
        // both exist, so resolving both would make the sheet promise a request
        // that cannot be sent -- and the sheet reads its lines from right here.
        if (capabilities.supportsThinkingBudget && config.reasoningEffort == null) {
            config = config.copy(thinkingBudget = budget(mode, capabilities))
        }
        if (capabilities.supportsMaxTokens) {
            // Length is the scale only when it is the last knob standing. When a
            // budget was set it still has to be raised, because a budget larger
            // than the answer cap is rejected outright by Anthropic and wastes
            // the whole reply everywhere else.
            val asScale = if (config.reasoningEffort == null && config.thinkingBudget == null) {
                scale(mode, capabilities.maxTokensLimit)
            } else {
                null
            }
            val forBudget = config.thinkingBudget?.plus(MIN_VISIBLE_OUTPUT)
            // A tier needs the same room. Its thinking is invisible but it is
            // not free: on the o-series and gpt-5 it is spent from the very cap
            // this line sets, so `high` under the 4k default thought until the
            // cap and returned an empty message with `finish_reason: length`.
            val forEffort = config.reasoningEffort?.let {
                headroom(mode, capabilities.maxTokensLimit)
            }
            val wanted = listOfNotNull(asScale, forBudget, forEffort).maxOrNull()
            if (wanted != null) {
                config = config.copy(maxTokens = clamp(wanted, capabilities.maxTokensLimit))
            }
        }
        // A thinking control with its switch missing is a control the API
        // ignores -- or rejects. It is not only about budgets any more: GLM only
        // grades effort while `thinking.type` is enabled, DashScope wants
        // `enable_thinking` next to either field, DeepSeek V4 splits the switch
        // from the word, and Claude 4.7+ reads `output_config.effort` only in
        // adaptive mode. So the switch rides along with whichever control was set.
        val thinkingSet = config.thinkingBudget != null || config.reasoningEffort != null
        if (thinkingSet && capabilities.thinkingEnableFlags.isNotEmpty()) {
            config = config.copy(extra = config.extra + capabilities.thinkingEnableFlags)
        }
        return config
    }

    /**
     * The same question for a stored selection, CUSTOM included.
     *
     * A hand-made config is filtered rather than trusted: capabilities change
     * under a saved choice when the model is edited or when the endpoint refuses
     * a field, and sending a field that is no longer supported is exactly the
     * failure this whole layer exists to prevent.
     */
    fun resolve(selection: PowerSelection, capabilities: EndpointCapabilities): PowerConfig =
        if (selection.mode == PowerMode.CUSTOM) {
            sanitise(selection.custom, capabilities)
        } else {
            resolve(selection.mode, capabilities)
        }

    /** Drops unsupported fields and clamps the rest to the endpoint's real limits. */
    fun sanitise(custom: PowerConfig?, capabilities: EndpointCapabilities): PowerConfig {
        if (custom == null) return PowerConfig.NoOp
        var config = PowerConfig.NoOp

        // Manual mode is wider than the presets by design: on a private gateway
        // the user is the only one who knows what it accepts, so a hand-picked
        // tier goes through as long as this endpoint has not refused one.
        if (capabilities.manualEffortAllowed) {
            custom.reasoningEffort
                ?.takeIf { it in capabilities.manualTiers }
                ?.let { config = config.copy(reasoningEffort = it) }
        }
        // Same exclusivity, and here it also settles which hand-typed value
        // survives: a tier picked from a chip list beats a number left over from
        // an earlier endpoint.
        if (capabilities.manualBudgetAllowed && config.reasoningEffort == null) {
            custom.thinkingBudget?.let {
                val max = if (capabilities.thinkingBudgetMax > 0) capabilities.thinkingBudgetMax else it
                config = config.copy(thinkingBudget = it.coerceIn(capabilities.thinkingBudgetMin, max))
            }
        }
        if (capabilities.supportsMaxTokens) {
            val forBudget = config.thinkingBudget?.plus(MIN_VISIBLE_OUTPUT)
            val wanted = listOfNotNull(custom.maxTokens, forBudget).maxOrNull()
            if (wanted != null) {
                config = config.copy(maxTokens = clamp(wanted, capabilities.maxTokensLimit))
            }
        }
        val extra = custom.extra.filterKeys { it in capabilities.extraParams }
        if (extra.isNotEmpty()) config = config.copy(extra = config.extra + extra)
        val thinkingSet = config.thinkingBudget != null || config.reasoningEffort != null
        if (thinkingSet && capabilities.thinkingEnableFlags.isNotEmpty()) {
            config = config.copy(extra = config.extra + capabilities.thinkingEnableFlags)
        }
        return config
    }

    /**
     * Picks a tier off the endpoint's own list, by meaning first.
     *
     * ### Why not by position
     * The ladders stopped agreeing. DeepSeek V4 and Kimi K3 grade `low/high/max`,
     * gpt-5.6 accepts six words starting at `none`, Gemini 3 spells its lowest
     * step `minimal`, Opus 4.6 rejects `xhigh` while Opus 5 takes it. Counting
     * slots on those lists sends `none` for LOW on a six-word ladder -- thinking
     * switched off where the user asked for a little -- and `medium` for MAX on a
     * three-word one. So each mode names the words it accepts and takes the first
     * one this endpoint actually lists.
     *
     * The positional rule stays as the fallback for ladders that are not effort
     * words at all, like Z.ai's `disabled/enabled` or Groq's `none/default`.
     */
    private fun tier(mode: PowerMode, tiers: List<String>): String? {
        if (tiers.isEmpty()) return null
        val wanted = when (mode) {
            PowerMode.LOW -> LOW_WORDS
            PowerMode.MEDIUM -> MEDIUM_WORDS
            PowerMode.HIGH -> HIGH_WORDS
            else -> MAX_WORDS
        }
        wanted.firstOrNull { it in tiers }?.let { return it }
        val last = tiers.lastIndex
        val index = when (mode) {
            PowerMode.LOW -> 0
            PowerMode.MEDIUM -> if (last >= 2) 1 else 0
            PowerMode.HIGH -> if (last >= 2) 2 else last
            else -> last
        }
        return tiers[index.coerceIn(0, last)]
    }

    // Ordered by preference, not by strength: the first word a given endpoint
    // knows wins. Kept overlapping on purpose -- MEDIUM falling back to `low` on
    // a `low/high/max` ladder is weaker than HIGH, which is what keeps the four
    // modes monotone on ladders that have no middle word.
    private val LOW_WORDS = listOf("low", "minimal", "none", "medium")
    private val MEDIUM_WORDS = listOf("medium", "low", "high")
    private val HIGH_WORDS = listOf("high", "xhigh", "medium", "max")
    private val MAX_WORDS = listOf("max", "xhigh", "high", "medium")

    /** The budget scale, never above what the model really allows. */
    private fun budget(mode: PowerMode, capabilities: EndpointCapabilities): Int {
        val max = if (capabilities.thinkingBudgetMax > 0) capabilities.thinkingBudgetMax else BUDGET_HIGH
        val wanted = when (mode) {
            PowerMode.LOW -> BUDGET_LOW
            PowerMode.MEDIUM -> BUDGET_MEDIUM
            PowerMode.HIGH -> BUDGET_HIGH
            else -> max
        }
        return wanted.coerceIn(capabilities.thinkingBudgetMin.coerceAtLeast(0), max)
    }

    /** The length scale. MAX asks for the model's real ceiling, not a big number. */
    private fun scale(mode: PowerMode, limit: Int?): Int = when (mode) {
        PowerMode.LOW -> TOKENS_LOW
        PowerMode.MEDIUM -> TOKENS_MEDIUM
        PowerMode.HIGH -> TOKENS_HIGH
        else -> limit ?: TOKENS_HIGH
    }

    /**
     * Room for the thinking a tier just bought, plus an answer after it.
     *
     * The budget scale on purpose: a tier is the provider's own word for the
     * same amount of work, so HIGH gets the room a 16k budget would and MAX asks
     * for the model's real ceiling. [MIN_VISIBLE_OUTPUT] is added at every step,
     * so raising effort can never leave the reply with less space than before.
     */
    private fun headroom(mode: PowerMode, limit: Int?): Int = when (mode) {
        PowerMode.LOW -> BUDGET_LOW + MIN_VISIBLE_OUTPUT
        PowerMode.MEDIUM -> BUDGET_MEDIUM + MIN_VISIBLE_OUTPUT
        PowerMode.HIGH -> BUDGET_HIGH + MIN_VISIBLE_OUTPUT
        // Not the model's literal ceiling any more. The 2026 lines publish 128k
        // of output and more, and this same number is what the context trimmer
        // reserves before it starts dropping turns -- so MAX asks for a lot of
        // room rather than for all of it.
        else -> minOf(limit ?: MAX_HEADROOM, MAX_HEADROOM)
    }

    private fun clamp(wanted: Int, limit: Int?): Int =
        (if (limit != null) minOf(wanted, limit) else wanted).coerceAtLeast(MIN_TOKENS)

    /**
     * Room left for the answer itself once thinking has been paid for.
     *
     * Extended thinking spends from the same budget as the reply on Anthropic,
     * so a cap equal to the budget produces a request that thinks and then has
     * nothing left to say.
     */
    private const val MIN_VISIBLE_OUTPUT = 4_096

    private const val MIN_TOKENS = 256

    private const val TOKENS_LOW = 1_024
    private const val TOKENS_MEDIUM = 4_096
    private const val TOKENS_HIGH = 16_384

    private const val BUDGET_LOW = 1_024
    private const val BUDGET_MEDIUM = 4_096
    private const val BUDGET_HIGH = 16_384

    /** The most MAX will ask for as a length cap, whatever the model allows. */
    private const val MAX_HEADROOM = 32_768
}
