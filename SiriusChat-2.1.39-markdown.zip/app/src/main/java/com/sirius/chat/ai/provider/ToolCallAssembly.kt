package com.sirius.chat.ai.provider

import com.sirius.chat.ai.model.AiToolCall
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put

/**
 * Reassembly of tool calls that arrive in pieces.
 *
 * Both wire formats stream a call the same way in spirit: one event names it,
 * later events carry slices of its argument JSON, and nothing is parseable until
 * the last slice lands. Both also allow several calls in one turn, whose slices
 * interleave. So the pieces are collected per index and only turned into a call
 * at the end -- shared here because doing it twice, slightly differently, is how
 * one provider ends up dropping the second tool of every pair.
 */
internal class ToolCallBuilder {
    var id: String? = null
    var name: String? = null
    val arguments = StringBuilder()
}

/**
 * The finished calls, in the order the endpoint opened them.
 *
 * A slot with no name is dropped rather than guessed at: it means the naming
 * event never arrived, so there is nothing to run and no way to invent it. The
 * id is synthesised when missing, because it is only used for correlation.
 */
internal fun Map<Int, ToolCallBuilder>.reassemble(): List<AiToolCall> = entries
    .sortedBy { it.key }
    .mapNotNull { entry ->
        val slot = entry.value
        val name = slot.name?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
        AiToolCall(
            id = slot.id?.takeIf { it.isNotBlank() } ?: "call_${entry.key}",
            name = name,
            argumentsJson = slot.arguments.toString()
        )
    }

/** Accepts anything the tool's own description asked for. */
private val OPEN_OBJECT_SCHEMA = buildJsonObject { put("type", "object") }

/**
 * A tool's parameter schema, or an open object when the text will not parse.
 *
 * Falling back rather than throwing is the point: a malformed schema is a bug in
 * the caller, and taking the whole request down over it would turn that bug into
 * "the model stopped working".
 */
internal fun schemaOf(raw: String, json: Json): JsonObject =
    runCatching { json.parseToJsonElement(raw).jsonObject }.getOrNull() ?: OPEN_OBJECT_SCHEMA
