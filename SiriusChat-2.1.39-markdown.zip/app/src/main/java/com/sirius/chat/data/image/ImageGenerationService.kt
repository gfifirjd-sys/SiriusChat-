package com.sirius.chat.data.image

import android.util.Base64
import android.util.Log
import com.sirius.chat.ai.capability.ModelCapabilities
import com.sirius.chat.core.common.AppDispatchers
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.repository.ProviderRepository
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** What the caller asked for. Square by default; models are trained on squares. */
data class ImageRequest(
    val prompt: String,
    val width: Int = 1024,
    val height: Int = 1024,
    /** Passed through to whichever backend understands it; ignored otherwise. */
    val style: String = ""
)

/** A finished picture plus which engine actually produced it. */
data class ImageResult(
    val image: StoredImage,
    val engine: String,
    val prompt: String,
    /**
     * True when the native endpoint was tried and failed, so the keyless path
     * answered instead. Surfaced to the model, which should tell the user rather
     * than silently claiming their paid endpoint drew it.
     */
    val fellBack: Boolean = false,
    val fallbackReason: String = ""
)

/**
 * Text to picture, with the user's own endpoint preferred over ours.
 *
 * ### The two-tier design
 * The provider the session is already pointed at is asked first, whenever it
 * sells images and a key is stored. That is the right default for three separate
 * reasons: the user gets the quality they are paying for, the prompt never
 * leaves a vendor they have already chosen to trust, and there is no shared
 * service to rate-limit them behind everyone else.
 *
 * When that is not possible — a DeepSeek session, a local Ollama model, no key —
 * a keyless generator answers instead. This is what makes the switch in the chat
 * settings panel meaningful on every provider rather than on four of them.
 *
 * ### Why a native failure falls back instead of surfacing
 * An image endpoint refuses for reasons that are about billing and moderation
 * far more often than about the prompt: no credit on the account, the model not
 * enabled for the org, a region block. Turning each of those into "generation
 * failed" would strand the user with a switch that is on, a feature that is
 * advertised as working, and no picture. Falling back produces a picture and
 * says which engine drew it and why — [ImageResult.fellBack] is reported to the
 * model so the user is told, not deceived.
 *
 * A *moderation* refusal is the one case that does not fall back: retrying a
 * refused prompt against a second service is the app deciding to launder a
 * refusal, which it has no business doing.
 */
class ImageGenerationService(
    private val providers: ProviderRepository,
    private val dispatchers: AppDispatchers,
    private val store: GeneratedImageStore
) {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private val client = OkHttpClient.Builder()
        // Generation is slow and the user is looking at a progress card that says
        // so, which is exactly when a long timeout is correct. A 20s cap here
        // would fail every request to a queued Flux endpoint.
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Generate one image for the session's provider.
     *
     * @param providerId provider the conversation is using. Its key and base URL
     *   decide whether the native path is even attempted.
     * @throws ImageGenerationException when no engine produced a picture, or when
     *   the prompt was refused on moderation grounds.
     */
    suspend fun generate(providerId: String, request: ImageRequest): ImageResult =
        withContext(dispatchers.io) {
            val prompt = request.prompt.trim()
            if (prompt.isEmpty()) throw ImageGenerationException("The prompt is empty.")

            val provider = providers.get(providerId)
            var fallbackReason = ""

            if (provider != null && provider.hasKey) {
                val attempt = runCatching { native(provider, request) }
                attempt.getOrNull()?.let { return@withContext it }
                val error = attempt.exceptionOrNull()
                if (error is ImageModerationException) throw error
                fallbackReason = error?.message?.take(300).orEmpty()
                Log.w(TAG, "native image generation failed for ${provider.id}", error)
            }

            val stored = pollinations(request)
                ?: throw ImageGenerationException(
                    buildString {
                        append("No image engine produced a picture.")
                        if (fallbackReason.isNotEmpty()) {
                            append(" The provider endpoint said: ")
                            append(fallbackReason)
                        }
                    }
                )

            ImageResult(
                image = stored,
                engine = ModelCapabilities.BUILTIN_IMAGE,
                prompt = prompt,
                fellBack = fallbackReason.isNotEmpty(),
                fallbackReason = fallbackReason
            )
        }

    /**
     * Change an existing picture instead of drawing a new one.
     *
     * ### Why this is a separate call and not a flag on [generate]
     * They have different failure surfaces and, crucially, different fallbacks.
     * Generation always has one: if the user's endpoint sells no images, the
     * keyless engine draws it and the result is still a picture. Editing has
     * none. Handing "make the background blue" plus a photograph to a
     * text-to-image service produces a *different* photograph -- same words, new
     * composition, new subject, none of the thing the user wanted preserved. That
     * is not a degraded edit, it is a wrong answer that looks like a right one.
     *
     * So this throws [ImageEditUnsupportedException] where [generate] would fall
     * back, and the capability layer greys the switch out with a stated reason
     * before the user can ask for something that cannot happen.
     *
     * @param reference a `sirius-image:` uri from the transcript. Only images this
     *   app produced can be edited: an arbitrary URL would mean fetching whatever
     *   a model asked for and posting it to a paid endpoint.
     * @throws ImageEditUnsupportedException when this provider has no edit route,
     *   or no key to reach it with.
     * @throws ImageGenerationException when the edit was attempted and failed.
     */
    suspend fun edit(
        providerId: String,
        reference: String,
        instruction: String
    ): ImageResult = withContext(dispatchers.io) {
        val prompt = instruction.trim()
        if (prompt.isEmpty()) throw ImageGenerationException("The edit instruction is empty.")

        val source = store.resolve(reference)
            ?: throw ImageGenerationException(
                "That image is no longer in this conversation's storage."
            )
        val bytes = runCatching { source.readBytes() }.getOrNull()
            ?: throw ImageGenerationException("That image could not be read back.")

        val provider = providers.get(providerId)
            ?: throw ImageEditUnsupportedException("This conversation has no provider.")
        if (!provider.hasKey) {
            throw ImageEditUnsupportedException(
                "${provider.label} needs an API key before it can edit images."
            )
        }
        val key = providers.apiKey(provider.id)
            ?: throw ImageEditUnsupportedException("No API key stored for ${provider.label}.")

        when {
            ModelCapabilities.isGeminiImageProvider(provider) ->
                geminiEdit(provider, key, bytes, prompt)

            else -> {
                val model = ModelCapabilities.nativeImageEditModel(provider)
                    ?: throw ImageEditUnsupportedException(
                        "${provider.label} can generate images but cannot edit them."
                    )
                openAiEdit(provider, key, model, bytes, prompt)
            }
        }
    }

    /**
     * `POST /images/edits`, which is multipart rather than JSON because the
     * source picture goes in the body.
     *
     * No mask is sent. A mask would confine the change to a region, and the app
     * has no way to ask the user to paint one; without it `gpt-image-1` edits the
     * whole image against the instruction, which is exactly what "make the
     * background blue" means.
     *
     * `size` is omitted deliberately -- the endpoint keeps the source dimensions
     * when not told otherwise, and guessing a size here is how an edit silently
     * becomes a crop.
     */
    private fun openAiEdit(
        provider: ProviderConfig,
        key: String,
        model: String,
        source: ByteArray,
        instruction: String
    ): ImageResult {
        val body = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("model", model)
            .addFormDataPart("prompt", instruction)
            .addFormDataPart("n", "1")
            .addFormDataPart(
                "image",
                "source.png",
                source.toRequestBody(PNG_MEDIA)
            )
            .build()

        val http = Request.Builder()
            .url("${provider.baseUrl.trimEnd('/')}/images/edits")
            .header("Authorization", "Bearer $key")
            .post(body)
            .build()

        val payload = client.newCall(http).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = errorMessage(text) ?: "HTTP ${response.code}"
                if (looksLikeModeration(message)) throw ImageModerationException(message)
                // A 404 here means the gateway copied the generations route and not
                // the edits one. That is a capability answer, not a fault, and it
                // must not read as "editing is broken".
                if (response.code == 404 || response.code == 405) {
                    throw ImageEditUnsupportedException(
                        "${provider.label} does not serve an image editing endpoint."
                    )
                }
                throw ImageGenerationException(message)
            }
            text
        }

        val first = runCatching {
            json.parseToJsonElement(payload).jsonObject["data"]?.jsonArray?.firstOrNull()?.jsonObject
        }.getOrNull() ?: throw ImageGenerationException("The endpoint returned no image data.")

        val bytes = first["b64_json"]?.jsonPrimitive?.contentOrNullSafe()?.let(::decodeBase64)
            ?: first["url"]?.jsonPrimitive?.contentOrNullSafe()?.let(::download)
            ?: throw ImageGenerationException("The endpoint returned neither b64_json nor url.")

        val stored = saveBlocking(bytes)
            ?: throw ImageGenerationException("The endpoint returned data that is not an image.")
        return ImageResult(stored, model, instruction)
    }

    /**
     * Gemini edits through the same `generateContent` call it draws with: the
     * source picture is just another part alongside the instruction.
     *
     * That is why the model keeps the composition -- it is looking at the image
     * while it works, rather than re-reading a description of it.
     */
    private fun geminiEdit(
        provider: ProviderConfig,
        key: String,
        source: ByteArray,
        instruction: String
    ): ImageResult {
        val model = ModelCapabilities.GEMINI_IMAGE_MODEL
        val root = provider.baseUrl.trimEnd('/').removeSuffix("/openai")
        val encoded = Base64.encodeToString(source, Base64.NO_WRAP)
        val body = buildJsonObject {
            put(
                "contents",
                buildJsonArray {
                    add(
                        buildJsonObject {
                            put(
                                "parts",
                                buildJsonArray {
                                    // Instruction first: the picture is the subject
                                    // of the sentence that follows it.
                                    add(buildJsonObject { put("text", instruction) })
                                    add(
                                        buildJsonObject {
                                            put(
                                                "inlineData",
                                                buildJsonObject {
                                                    put("mimeType", "image/png")
                                                    put("data", encoded)
                                                }
                                            )
                                        }
                                    )
                                }
                            )
                        }
                    )
                }
            )
        }

        val http = Request.Builder()
            .url("$root/models/$model:generateContent")
            .header("x-goog-api-key", key)
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody(JSON_MEDIA))
            .build()

        val payload = client.newCall(http).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = errorMessage(text) ?: "HTTP ${response.code}"
                if (looksLikeModeration(message)) throw ImageModerationException(message)
                throw ImageGenerationException(message)
            }
            text
        }

        val inline = runCatching {
            json.parseToJsonElement(payload).jsonObject["candidates"]?.jsonArray
                ?.firstOrNull()?.jsonObject
                ?.get("content")?.jsonObject
                ?.get("parts")?.jsonArray
                ?.firstNotNullOfOrNull { part ->
                    (part.jsonObject["inlineData"] ?: part.jsonObject["inline_data"])
                        ?.jsonObject?.get("data")?.jsonPrimitive?.contentOrNullSafe()
                }
        }.getOrNull() ?: throw ImageGenerationException(
            "Gemini answered without a picture, so the edit produced nothing."
        )

        val stored = saveBlocking(decodeBase64(inline))
            ?: throw ImageGenerationException("Gemini returned data that is not an image.")
        return ImageResult(stored, model, instruction)
    }

    // --------------------------------------------------------------- native

    private suspend fun native(provider: ProviderConfig, request: ImageRequest): ImageResult {
        val key = providers.apiKey(provider.id)
            ?: throw ImageGenerationException("No API key stored for ${provider.label}.")

        return if (ModelCapabilities.isGeminiImageProvider(provider)) {
            gemini(provider, key, request)
        } else {
            val model = ModelCapabilities.nativeImageModel(provider)
                ?: throw ImageGenerationException("${provider.label} serves no image model.")
            openAiImages(provider, key, model, request)
        }
    }

    /**
     * `POST /images/generations`, the shape OpenAI defined and everyone copied.
     *
     * `response_format` is deliberately omitted rather than set to `b64_json`:
     * OpenAI's newer image models reject the field outright, while several
     * gateways ignore it and return a URL regardless. Since both a URL and inline
     * base64 have to be handled anyway, asking for neither is strictly more
     * compatible than asking for one and being refused.
     */
    private fun openAiImages(
        provider: ProviderConfig,
        key: String,
        model: String,
        request: ImageRequest
    ): ImageResult {
        val body = buildJsonObject {
            put("model", model)
            put("prompt", decoratePrompt(request))
            put("n", 1)
            put("size", "${request.width}x${request.height}")
        }

        val http = Request.Builder()
            .url("${provider.baseUrl.trimEnd('/')}/images/generations")
            .header("Authorization", "Bearer $key")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody(JSON_MEDIA))
            .build()

        val payload = client.newCall(http).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = errorMessage(text) ?: "HTTP ${response.code}"
                // 400 with a moderation reason is a decision, not a fault.
                if (looksLikeModeration(message)) throw ImageModerationException(message)
                throw ImageGenerationException(message)
            }
            text
        }

        val first = runCatching {
            json.parseToJsonElement(payload).jsonObject["data"]?.jsonArray?.firstOrNull()?.jsonObject
        }.getOrNull() ?: throw ImageGenerationException("The endpoint returned no image data.")

        val bytes = first["b64_json"]?.jsonPrimitive?.contentOrNullSafe()?.let(::decodeBase64)
            ?: first["url"]?.jsonPrimitive?.contentOrNullSafe()?.let(::download)
            ?: throw ImageGenerationException("The endpoint returned neither b64_json nor url.")

        val stored = saveBlocking(bytes)
            ?: throw ImageGenerationException("The endpoint returned data that is not an image.")
        return ImageResult(stored, model, request.prompt)
    }

    /**
     * Gemini draws through `generateContent`, not through an images route.
     *
     * The image comes back as an `inlineData` part alongside any text the model
     * felt like adding, so the parts are searched rather than indexed — the
     * picture is not reliably first.
     */
    private fun gemini(
        provider: ProviderConfig,
        key: String,
        request: ImageRequest
    ): ImageResult {
        val model = "gemini-2.5-flash-image"
        // The OpenAI-compat base URL is `.../v1beta/openai`; the native surface
        // is its parent. Trimming rather than hard-coding keeps a user-edited
        // base URL working.
        val root = provider.baseUrl.trimEnd('/').removeSuffix("/openai")
        val body = buildJsonObject {
            put(
                "contents",
                buildJsonArray {
                    add(
                        buildJsonObject {
                            put(
                                "parts",
                                buildJsonArray {
                                    add(buildJsonObject { put("text", decoratePrompt(request)) })
                                }
                            )
                        }
                    )
                }
            )
        }

        val http = Request.Builder()
            .url("$root/models/$model:generateContent")
            // Header rather than `?key=`, so the key never lands in a log line
            // that records the URL.
            .header("x-goog-api-key", key)
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody(JSON_MEDIA))
            .build()

        val payload = client.newCall(http).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = errorMessage(text) ?: "HTTP ${response.code}"
                if (looksLikeModeration(message)) throw ImageModerationException(message)
                throw ImageGenerationException(message)
            }
            text
        }

        val inline = runCatching {
            json.parseToJsonElement(payload).jsonObject["candidates"]?.jsonArray
                ?.firstOrNull()?.jsonObject
                ?.get("content")?.jsonObject
                ?.get("parts")?.jsonArray
                ?.firstNotNullOfOrNull { part ->
                    (part.jsonObject["inlineData"] ?: part.jsonObject["inline_data"])
                        ?.jsonObject?.get("data")?.jsonPrimitive?.contentOrNullSafe()
                }
        }.getOrNull() ?: throw ImageGenerationException("Gemini returned no inline image.")

        val stored = saveBlocking(decodeBase64(inline))
            ?: throw ImageGenerationException("Gemini returned data that is not an image.")
        return ImageResult(stored, model, request.prompt)
    }

    // ------------------------------------------------------------- fallback

    /**
     * The keyless generator.
     *
     * A plain GET whose path is the prompt; the response body is the PNG. There
     * is no account, no key and no JSON envelope, which is exactly why it is the
     * fallback — it is the only image service that can work on a fresh install
     * with nothing configured.
     *
     * `nologo` and an explicit seed are set so the same prompt does not return a
     * cached identical picture on a retry, which otherwise makes "generate
     * another one" look broken.
     */
    private fun pollinations(request: ImageRequest): StoredImage? = runCatching {
        val encoded = URLEncoder.encode(decoratePrompt(request), "UTF-8")
        val url = buildString {
            append("https://image.pollinations.ai/prompt/")
            append(encoded)
            append("?width=").append(request.width)
            append("&height=").append(request.height)
            append("&nologo=true")
            append("&seed=").append(System.currentTimeMillis() % 1_000_000)
        }
        val http = Request.Builder().url(url).header("Accept", "image/*").build()
        client.newCall(http).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            saveBlocking(response.body?.bytes() ?: ByteArray(0))
        }
    }.onFailure { Log.w(TAG, "keyless image generation failed", it) }.getOrNull()

    // -------------------------------------------------------------- plumbing

    /**
     * Appends the style hint as prose.
     *
     * Every backend here takes one free-text prompt and nothing else, so a style
     * has to be words. Kept out of [ImageRequest.prompt] itself so the transcript
     * shows what the user asked for rather than what was sent.
     */
    private fun decoratePrompt(request: ImageRequest): String =
        if (request.style.isBlank()) {
            request.prompt.trim()
        } else {
            "${request.prompt.trim()}. Style: ${request.style.trim()}"
        }

    private fun download(url: String): ByteArray {
        val http = Request.Builder().url(url).build()
        return client.newCall(http).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code} downloading image")
            response.body?.bytes() ?: ByteArray(0)
        }
    }

    private fun decodeBase64(raw: String): ByteArray {
        // Some gateways hand back a full data URI rather than bare base64.
        val payload = raw.substringAfterLast("base64,")
        return Base64.decode(payload, Base64.DEFAULT)
    }

    /**
     * [GeneratedImageStore.save] is suspending and every caller here is already
     * on the IO dispatcher inside a blocking OkHttp `use` block, so it is bridged
     * rather than restructured. `runBlocking` on a dispatcher thread is safe;
     * doing it on the main thread would not be, and nothing on this class's path
     * ever runs there.
     */
    private fun saveBlocking(bytes: ByteArray): StoredImage? =
        kotlinx.coroutines.runBlocking { store.save(bytes) }

    /** Pulls the human sentence out of whatever error envelope arrived. */
    private fun errorMessage(body: String): String? = runCatching {
        val root = json.parseToJsonElement(body).jsonObject
        val error = root["error"]
        when {
            error is JsonObject -> error["message"]?.jsonPrimitive?.contentOrNullSafe()
            error != null -> error.jsonPrimitive.contentOrNullSafe()
            else -> root["message"]?.jsonPrimitive?.contentOrNullSafe()
        }
    }.getOrNull()?.takeIf { it.isNotBlank() } ?: body.trim().take(300).takeIf { it.isNotEmpty() }

    /**
     * Whether a refusal was about the prompt's content.
     *
     * Substring matching on vendor phrasing, which is fragile — but the failure
     * mode is benign in both directions. A missed moderation refusal falls back
     * and the keyless service refuses too; a false positive surfaces the
     * endpoint's own sentence to the user, which is accurate regardless.
     */
    private fun looksLikeModeration(message: String): Boolean {
        val lower = message.lowercase()
        return MODERATION_MARKERS.any { lower.contains(it) }
    }

    private fun kotlinx.serialization.json.JsonPrimitive.contentOrNullSafe(): String? =
        runCatching { content }.getOrNull()?.takeIf { it.isNotBlank() && it != "null" }

    private companion object {
        const val TAG = "ImageGeneration"
        val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
        val PNG_MEDIA = "image/png".toMediaType()
        val MODERATION_MARKERS = listOf(
            "safety", "moderation", "content policy", "content_policy",
            "not allowed", "rejected by", "prohibited", "violates"
        )
    }
}

/** Any reason no picture was produced. */
open class ImageGenerationException(message: String) : IOException(message)

/** The prompt itself was refused. Never retried against another engine. */
class ImageModerationException(message: String) : ImageGenerationException(message)

/**
 * This provider cannot edit images at all.
 *
 * Distinct from a plain [ImageGenerationException] because the two need different
 * words: a failure is "that did not work, try again", this is "that cannot work
 * here, and here is what would". The tool turns it into an explanation for the
 * user instead of an error the model will retry.
 */
class ImageEditUnsupportedException(message: String) : ImageGenerationException(message)
