package com.sirius.chat.core.designsystem.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.ProjectAccentInk
import com.sirius.chat.core.designsystem.ProjectAccents
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.util.rememberHaptics

/**
 * One action inside a sheet: icon, label, whole-row target.
 *
 * Every sheet in the app used to hand-roll this row, which is how they drifted
 * apart on padding and on whether the destructive item was actually red. The
 * row is a real 52dp target rather than text with padding, and a [destructive]
 * item is the only one allowed to take the error colour.
 */
@Composable
fun SheetActionRow(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    supporting: String? = null,
    destructive: Boolean = false,
    enabled: Boolean = true,
    /**
     * Optional widget at the end of the row.
     *
     * State, never a second control: the row itself is the only click target, so
     * anything clickable in here would be a target a screen reader cannot reach.
     */
    trailing: (@Composable () -> Unit)? = null
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.985f else 1f,
        animationSpec = siriusSpring(),
        label = "sheetActionPress"
    )
    val tint = when {
        !enabled -> colors.textTertiary
        destructive -> colors.error
        else -> colors.textSecondary
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            // Click node above the press-scale; see SiriusPrimaryButton.
            .clickable(
                enabled = enabled,
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClickLabel = label
            ) {
                haptics.light()
                onClick()
            }
            .scale(scale)
            .clip(RoundedCornerShape(SiriusRadius.md))
            .heightIn(min = 52.dp)
            .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.sm)
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = if (destructive) colors.error else colors.textPrimary
            )
            if (supporting != null) {
                Text(
                    text = supporting,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (trailing != null) trailing()
    }
}

/**
 * One choice in a sheet full of mutually exclusive choices (sort order, theme).
 *
 * Selection is carried by a check mark as well as the colour, because a colour
 * shift alone fails both colour-blind users and a screen reader; the row also
 * reports [selected] so assistive tech reads the current pick without guessing.
 */
@Composable
fun SheetOptionRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    supporting: String? = null,
    /**
     * Lines allowed for [supporting]. One by default, because most pickers list
     * short hints; a choice that has to explain a trade-off before it can be
     * made (which shell runs your commands) needs the room to say it.
     */
    supportingMaxLines: Int = 1,
    /**
     * Position in the list, drawn as a numbered badge in front of the label.
     *
     * Set it where the options are a numbered choice the user may be counting --
     * "take the second one" -- and leave it null for plain pickers, where a
     * number in front of every row is noise.
     */
    index: Int? = null,
    /**
     * Draws the row as a checkbox instead of a single choice.
     *
     * The difference is not decoration. In a single-select list the tap is the
     * answer and the sheet closes; in a multi-select one the tap is a tick and
     * nothing happens until the user confirms. A row that looks identical in
     * both modes gives no warning of which one it is in, and a tick that only
     * appears *after* the first tap cannot tell anyone beforehand that a second
     * tap is allowed. This also switches the accessibility role, so TalkBack
     * announces a checkbox rather than a radio button.
     */
    multiSelect: Boolean = false,
    /** State shown before the check mark; same contract as in [SheetActionRow]. */
    trailing: (@Composable () -> Unit)? = null
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val tint by animateColorAsState(
        targetValue = if (selected) colors.primary else colors.textPrimary,
        animationSpec = siriusTween(SiriusMotion.Quick),
        label = "optionTint"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.md))
            .then(if (selected) Modifier.background(colors.primarySoft) else Modifier)
            .clickable(role = if (multiSelect) Role.Checkbox else Role.RadioButton) {
                haptics.light()
                onClick()
            }
            .semantics { this.selected = selected }
            .heightIn(min = 52.dp)
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.sm),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.sm)
    ) {
        if (index != null) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(if (selected) colors.primary else colors.surfaceMuted),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = index.toString(),
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected) colors.onPrimary else colors.textSecondary
                )
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(text = label, style = MaterialTheme.typography.bodyLarge, color = tint)
            if (supporting != null) {
                Text(
                    text = supporting,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary,
                    maxLines = supportingMaxLines,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (trailing != null) trailing()
        if (multiSelect) {
            // Always drawn, ticked or empty: the empty box is the only thing on
            // the row that says more than one answer is allowed.
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(RoundedCornerShape(SiriusRadius.xs))
                    .then(
                        if (selected) {
                            Modifier.background(colors.primary)
                        } else {
                            Modifier.border(
                                1.dp,
                                colors.outline,
                                RoundedCornerShape(SiriusRadius.xs)
                            )
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (selected) {
                    Icon(
                        Icons.Rounded.Check,
                        contentDescription = null,
                        tint = colors.onPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        } else if (selected) {
            Icon(
                Icons.Rounded.Check,
                contentDescription = null,
                tint = colors.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * The one gate in front of anything irreversible.
 *
 * Destructive work in this app happens against a real folder on the device, so
 * it gets a sheet that names the target and puts the safe choice first in
 * reading order. The confirm plate takes the danger tone so it cannot be
 * mistaken for the ordinary primary action it sits in the same slot as.
 */
@Composable
fun SiriusConfirmSheet(
    title: String,
    message: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    destructive: Boolean = true,
    icon: ImageVector? = null
) {
    val colors = SiriusTheme.colors
    SiriusBottomSheet(title = title, onDismiss = onDismiss) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary
        )
        VSpace(SiriusSpacing.md)
        SiriusPrimaryButton(
            text = confirmLabel,
            onClick = onConfirm,
            icon = icon,
            tone = if (destructive) SiriusButtonTone.Danger else SiriusButtonTone.Primary,
            modifier = Modifier.fillMaxWidth()
        )
        VSpace(SiriusSpacing.xs)
        SiriusGhostButton(
            text = stringResource(R.string.action_cancel),
            onClick = onDismiss,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * Accent picker for a project.
 *
 * Colour is the only thing that distinguishes these swatches, so each one is a
 * labelled, selectable target with a ring rather than a bare coloured square,
 * and the selected swatch grows on a spring instead of jumping a size.
 */
@Composable
fun AccentSwatchRow(
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val groupLabel = stringResource(R.string.projects_accent_label)

    Column(modifier = modifier) {
        Text(
            text = groupLabel,
            style = MaterialTheme.typography.labelMedium,
            color = colors.textTertiary,
            modifier = Modifier.clearAndSetSemantics { }
        )
        VSpace(SiriusSpacing.xs)
        Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
            ProjectAccents.forEachIndexed { index, color ->
                val chosen = index == selectedIndex
                val scale by animateFloatAsState(
                    targetValue = if (chosen) 1f else 0.84f,
                    animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
                    label = "swatch$index"
                )
                val label = stringResource(R.string.projects_accent_option, index + 1)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(SiriusRadius.sm))
                        .clickable(role = Role.RadioButton, onClickLabel = label) {
                            haptics.light()
                            onSelect(index)
                        }
                        .semantics {
                            selected = chosen
                            contentDescription = label
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .scale(scale)
                            .clip(RoundedCornerShape(SiriusRadius.sm))
                            .background(color)
                            .border(
                                width = if (chosen) 2.dp else 1.dp,
                                color = if (chosen) colors.textPrimary else Color.Transparent,
                                shape = RoundedCornerShape(SiriusRadius.sm)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (chosen) {
                            Icon(
                                Icons.Rounded.Check,
                                contentDescription = null,
                                tint = ProjectAccentInk,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Horizontally scrolling path, used as the only way back up the tree.
 *
 * Crumbs are real targets with a selected state rather than tinted text, and
 * the separators are hidden from screen readers so the path is read as names.
 */
@Composable
fun BreadcrumbSegment(
    label: String,
    isLast: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (isLast) colors.textPrimary else colors.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .clip(RoundedCornerShape(SiriusRadius.pill))
                .then(if (isLast) Modifier.softSurface(RoundedCornerShape(SiriusRadius.pill)) else Modifier)
                .clickable(enabled = !isLast, role = Role.Button, onClickLabel = label) {
                    haptics.light()
                    onClick()
                }
                .heightIn(min = 32.dp)
                .padding(horizontal = SiriusSpacing.xs, vertical = 6.dp)
                .semantics { selected = isLast }
        )
        if (!isLast) {
            Text(
                text = "/",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textTertiary,
                modifier = Modifier.clearAndSetSemantics { }
            )
        }
    }
}
