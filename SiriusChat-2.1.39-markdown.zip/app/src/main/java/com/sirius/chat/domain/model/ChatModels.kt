package com.sirius.chat.domain.model

/** Who produced a message inside a conversation. */
enum class MessageRole { User, Assistant, System, Tool }

/** Lifecycle of a single message. */
enum class MessageStatus { Pending, Streaming, Complete, Failed, Cancelled }

/**
 * A single chat message. [content] holds raw markdown as produced by the model,
 * rendering happens in the UI layer.
 */
data class ChatMessage(
    val id: String,
    val sessionId: String,
    val role: MessageRole,
    val content: String,
    val createdAt: Long,
    val model: String? = null,
    val providerId: String? = null,
    val status: MessageStatus = MessageStatus.Complete,
    val error: String? = null,
    val attachments: List<MessageAttachment> = emptyList(),
    val toolRuns: List<ToolRun> = emptyList(),
    /**
     * What this turn cost, when it can be known.
     *
     * `null` is not zero, and the difference is the whole point: zero means the
     * turn genuinely spent nothing, while null means nobody counted -- every
     * message written before this was recorded, and every endpoint that reports
     * no usage. Showing 0 for the second case would put a fabricated number
     * under half the archive.
     */
    val usage: TokenUsage? = null
) {
    val isFromUser: Boolean get() = role == MessageRole.User
}

/** A workspace file (or snippet) attached to a user message. */
data class MessageAttachment(
    val id: String,
    val name: String,
    /** Workspace document id, or a persisted `content://` uri for a picked file. */
    val uri: String,
    val sizeBytes: Long = 0L,
    val language: String? = null,
    val mimeType: String? = null,
    val kind: AttachmentKind = AttachmentKind.WorkspaceFile,
    /**
     * Caret offset in the message text where this attachment was inserted.
     *
     * This is what lets the prompt interleave text and files in the order the
     * user built them, instead of dumping every file after the message. Without
     * it, "look at this screenshot, and compare it with this log" arrives as two
     * files in an arbitrary order and the model cannot tell which sentence
     * belongs to which attachment.
     */
    val anchor: Int = 0
)

/**
 * How an attachment can be given to a model.
 *
 * Classified once, when the file is picked, because the answer decides both the
 * icon in the composer and the content block in the request — and because a
 * user who attaches a 40 MB archive should be told immediately, not after the
 * request fails.
 */
enum class AttachmentKind {
    /** A file inside the opened project, read through the workspace tree. */
    WorkspaceFile,

    /** PNG, JPEG, GIF or WebP: the four formats Anthropic accepts as images. */
    Image,

    /** PDF, sent as a native document block. */
    Document,

    /** Text or source code: inlined, labelled with its name. */
    TextFile,

    /** Archive, binary, executable: only its metadata can be described. */
    Opaque
}

/** Result of one agent tool invocation, surfaced inline in the transcript. */
data class ToolRun(
    val id: String,
    val toolName: String,
    val argumentsPreview: String,
    val output: String,
    val success: Boolean,
    val durationMs: Long = 0L
)

/** A conversation, optionally bound to a project workspace. */
data class ChatSession(
    val id: String,
    val title: String,
    val projectId: String? = null,
    val providerId: String,
    val model: String,
    // Legacy column. Sirius is agent-only: there is no plain-chat path left to
    // switch to, so this stays `true` for every session and is kept purely so
    // existing databases still map without a destructive migration.
    val agentMode: Boolean = true,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean = false,
    val messageCount: Int = 0,
    val lastMessagePreview: String = "",
    /**
     * The switches from this chat's settings panel.
     *
     * `null` means the session has never had them set and should follow the
     * user's defaults. Kept nullable rather than defaulted to `ChatFeatures()`
     * so the "inherit" state survives the round trip: a non-null value here is a
     * decision the user made *in this conversation*, and the settings panel needs
     * to know the difference in order not to freeze a session's switches at
     * whatever the global defaults happened to be the day it was created.
     *
     * The sessions list does not load this — it has no use for it and it would
     * cost a column in a query that already runs two correlated subqueries per
     * row — so it is always `null` there.
     */
    val features: ChatFeatures? = null,
    /**
     * Whether this chat shows the context meter above the composer.
     *
     * `null` means it has never been set here and follows the global default,
     * for the same reason [features] is nullable: a session that stored `true`
     * on the day the default happened to be on would freeze that choice for
     * the rest of its life.
     */
    val contextMeter: Boolean? = null,
    /**
     * Whether this chat is told what is known about the user.
     *
     * `null` inherits the global default, like [contextMeter]. Switching it off
     * does not stop new facts being learned here: the user asked for a chat that
     * answers as if it were meeting them for the first time, not for a chat that
     * throws away what they say in it.
     */
    val memory: Boolean? = null,
    /**
     * Whether the name is still the app's own guess.
     *
     * True while nothing but the instant heuristic has named this chat, which
     * is what lets the model try again on later turns: an opening message is
     * very often "привет" and the actual request lands after it, so naming has
     * to stay open instead of freezing on the first thing typed.
     *
     * Set to false the moment the model produces a real title or the user
     * renames the chat by hand -- a name a person chose is never overwritten.
     */
    val titleAuto: Boolean = false
)

/**
 * What one turn spent, in tokens.
 *
 * ### Why [estimated] is stored and not inferred
 * Most endpoints report usage; a good number of OpenAI-compatible servers do
 * not, and for those the count is derived from the characters actually sent and
 * received. Both are useful and only one is exact, so the flag travels with the
 * numbers and the UI marks the difference. Silently mixing the two would make
 * the cheaper-looking model the one with the worse tokenizer estimate.
 */
data class TokenUsage(
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    /** True when these are Sirius's own approximation, not the provider's count. */
    val estimated: Boolean = false
) {
    val total: Int get() = promptTokens + completionTokens

    val isEmpty: Boolean get() = promptTokens <= 0 && completionTokens <= 0
}

/**
 * A message that matched a search.
 *
 * [snippet] is already cut around the match by the repository, because the UI
 * must not have to hold a whole conversation in memory to show one line, and
 * because where the match sits inside the text is knowledge the query has and
 * the screen does not.
 */
data class MessageHit(
    val messageId: String,
    val sessionId: String,
    val sessionTitle: String,
    val snippet: String,
    val createdAt: Long
)
