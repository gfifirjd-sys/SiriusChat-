package com.sirius.chat.domain.model

/** Wire protocol implemented by a provider endpoint. */
enum class ProviderType { OpenAiCompatible, AnthropicCompatible, Custom }

/**
 * Whether a model can actually read an image, as opposed to whether its name
 * looks like it can.
 *
 * ### Why this is a tri-state and not a Boolean
 * [Unknown] is the honest answer for a model nobody has tested yet, and it has
 * to be distinguishable from [Unsupported]: the first means "fall back to the id
 * heuristic", the second means "the endpoint itself said no, stop guessing".
 * A Boolean would collapse those, and the collapse always lands the same way --
 * a brand-new vision model shipped after this build would be marked as blind
 * with no way to tell that from a real refusal.
 */
enum class VisionSupport { Unknown, Supported, Unsupported }

/**
 * What a real request proved about a capability that is not image input.
 *
 * Separate from [VisionSupport] on purpose: the two are read by different code
 * and mean different things at the end. A vision refusal is final, while a
 * refusal of a vendor `tools` array is not -- see
 * [com.sirius.chat.ai.capability.ModelCapabilities] for why a tool verdict can
 * only ever switch a feature on.
 */
enum class ProbeVerdict { Unknown, Supported, Unsupported }

data class AiModel(
    val id: String,
    val label: String = id,
    val contextWindow: Int = 0,
    val supportsStreaming: Boolean = true,
    val supportsTools: Boolean = true,
    /**
     * What a real request proved about image input.
     *
     * Filled in by [com.sirius.chat.ai.provider.ProviderProbe.probeVision] when a
     * provider is connected or refreshed, and persisted with the model, so the
     * answer survives a restart and is not re-bought on every chat.
     */
    val vision: VisionSupport = VisionSupport.Unknown,
    /**
     * What a real request proved about tool definitions being accepted.
     *
     * Recorded because it is cheap and true, but deliberately weak: this app
     * drives its agent with a fenced text block, so a gateway that rejects the
     * vendor `tools` field can still run every tool Sirius has. The verdict is
     * therefore only allowed to overrule a *negative* guess, never to create one.
     */
    val toolsProbe: ProbeVerdict = ProbeVerdict.Unknown,
    /**
     * What a real request proved about server-sent events.
     *
     * Unlike [toolsProbe] this one is decisive in both directions, because the
     * app genuinely consumes the SSE framing: if the endpoint will not produce
     * it, the switch has to go grey and say so.
     */
    val streamProbe: ProbeVerdict = ProbeVerdict.Unknown
)

/**
 * User-owned provider endpoint. The API key is never part of this object: it is
 * kept encrypted in the keystore-backed [com.sirius.chat.data.local.security.SecureCredentialStore]
 * and only resolved at request time.
 */
data class ProviderConfig(
    val id: String,
    val label: String,
    val type: ProviderType,
    val baseUrl: String,
    val models: List<AiModel> = emptyList(),
    val defaultModel: String = models.firstOrNull()?.id.orEmpty(),
    val enabled: Boolean = true,
    val builtIn: Boolean = false,
    val hasKey: Boolean = false,
    /**
     * Stable key a shipped template uses instead of a fixed English [label], so
     * the name can follow the in-app language. The UI layer maps it to a string
     * resource; `null` means [label] is user-authored and shown verbatim.
     *
     * Brand names (OpenAI, Anthropic) intentionally have no key.
     */
    val labelKey: String? = null,
    /**
     * Key of the built-in mark shown next to the name, from
     * `com.sirius.chat.core.designsystem.components.ProviderIcon`. `null` falls
     * back to a mark chosen from [type].
     */
    val iconKey: String? = null,
    /**
     * Absolute path to an image the user picked from the gallery. It is a copy
     * inside app storage, not the gallery Uri, because that permission dies with
     * the picker session. Takes precedence over [iconKey] when set.
     */
    val iconImagePath: String? = null
)

/**
 * True when the endpoint needs an API key. Loopback and LAN hosts (Ollama, LM
 * Studio) legitimately have none, so treating a missing key as "not ready"
 * would lock out a working local setup.
 */
val ProviderConfig.requiresApiKey: Boolean
    get() {
        val host = baseUrl.substringAfter("://").substringBefore('/')
        return !(
            host.startsWith("127.0.0.1") || host.startsWith("localhost") ||
                host.startsWith("10.") || host.startsWith("192.168.")
            )
    }

/** True when this provider can answer a request right now. */
val ProviderConfig.isUsable: Boolean
    get() = enabled && (hasKey || !requiresApiKey)

/**
 * Resolves which model to show and send for this provider.
 *
 * [preferred] is the app-wide remembered choice and may belong to a *different*
 * provider, so it is only honoured when this endpoint actually serves it.
 * Without this check, switching provider produced a request for a model the new
 * endpoint has never heard of.
 */
fun ProviderConfig.resolveModel(preferred: String): String =
    preferred.takeIf { candidate -> models.any { it.id == candidate } } ?: defaultModel

data class GenerationParams(
    val temperature: Float = 0.3f,
    val topP: Float = 1f,
    val maxTokens: Int = 4096,
    /**
     * The already-resolved power fields for this request, or null when this
     * endpoint has nothing to configure.
     *
     * Resolved rather than a bare mode, because a mode alone cannot build a
     * request: the same word is an effort tier on one endpoint and a token
     * budget on another, and only the resolver knows which. Null means "add
     * nothing" -- never "add a default".
     */
    val power: PowerConfig? = null,
    /**
     * The endpoint's real output ceiling, when it declares one.
     *
     * Carried next to the number it bounds because the wire converter clamps
     * silently: a retry that doubled the cap past this limit produced a
     * byte-for-byte identical request, so the engine paid for a second empty
     * answer and learned nothing from it.
     */
    val maxTokensLimit: Int? = null
)
