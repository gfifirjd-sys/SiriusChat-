package com.sirius.chat.data.local.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.GlassLevel
import com.sirius.chat.domain.model.MemoryCategory
import com.sirius.chat.domain.model.PowerConfig
import com.sirius.chat.domain.model.PowerMode
import com.sirius.chat.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "sirius_settings")

/** Single source of truth for user preferences. */
class SettingsDataStore(private val context: Context) {

    private object Keys {
        val language = stringPreferencesKey("app_language")
        val themeMode = stringPreferencesKey("theme_mode")
        val accentColor = intPreferencesKey("accent_color")
        val glassLevel = stringPreferencesKey("glass_level")
        val reduceMotion = booleanPreferencesKey("reduce_motion")
        val haptics = booleanPreferencesKey("haptics")
        val streaming = booleanPreferencesKey("streaming")
        val activeProviderId = stringPreferencesKey("active_provider")
        val activeModel = stringPreferencesKey("active_model")
        val temperature = floatPreferencesKey("temperature")
        val maxTokens = intPreferencesKey("max_tokens")
        val agentAutoApproveReads = booleanPreferencesKey("agent_auto_reads")
        val agentAutoApplyChanges = booleanPreferencesKey("agent_auto_apply")
        val agentMaxSteps = intPreferencesKey("agent_max_steps")
        val agentTerminalEnabled = booleanPreferencesKey("agent_terminal")
        val defaultWebSearch = booleanPreferencesKey("default_web_search")
        val defaultImageGeneration = booleanPreferencesKey("default_image_generation")
        val showContextMeter = booleanPreferencesKey("show_context_meter")
        val memoryEnabled = booleanPreferencesKey("memory_enabled")
        val memoryFilters = stringPreferencesKey("memory_filters")
        val memoryLabels = intPreferencesKey("memory_labels")
        val memorySpin = booleanPreferencesKey("memory_spin")
        val memoryLinks = booleanPreferencesKey("memory_links")
        val memoryTopics = booleanPreferencesKey("memory_topics")
        val notificationsEnabled = booleanPreferencesKey("notifications_enabled")
        val performanceMode = stringPreferencesKey("performance_mode")
        val powerModes = stringPreferencesKey("power_modes")
        val powerCustom = stringPreferencesKey("power_custom")
        val editorFontSize = intPreferencesKey("editor_font_size")
        val editorTabSize = intPreferencesKey("editor_tab_size")
        val editorWordWrap = booleanPreferencesKey("editor_word_wrap")
        val editorLineNumbers = booleanPreferencesKey("editor_line_numbers")
        val editorAutoSave = booleanPreferencesKey("editor_auto_save")
        val terminalFontSize = intPreferencesKey("terminal_font_size")
        val terminalEngine = stringPreferencesKey("terminal_engine")
        val termuxBackgroundNotice = booleanPreferencesKey("termux_background_notice_shown")
        val activeProjectId = stringPreferencesKey("active_project")
        val githubRepo = stringPreferencesKey("github_repo")
        val onboardingDone = booleanPreferencesKey("onboarding_done")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { it.toSettings() }

    suspend fun current(): AppSettings = settings.first()

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { prefs ->
            val updated = transform(prefs.toSettings())
            prefs[Keys.language] = updated.language.name
            prefs[Keys.themeMode] = updated.themeMode.name
            prefs[Keys.accentColor] = updated.accentColor
            prefs[Keys.glassLevel] = updated.glassLevel.name
            prefs[Keys.reduceMotion] = updated.reduceMotion
            prefs[Keys.haptics] = updated.hapticsEnabled
            prefs[Keys.streaming] = updated.streamingEnabled
            prefs[Keys.activeProviderId] = updated.activeProviderId
            prefs[Keys.activeModel] = updated.activeModel
            prefs[Keys.temperature] = updated.temperature
            prefs[Keys.maxTokens] = updated.maxTokens
            prefs[Keys.agentAutoApproveReads] = updated.agentAutoApproveReads
            prefs[Keys.agentAutoApplyChanges] = updated.agentAutoApplyChanges
            prefs[Keys.agentMaxSteps] = updated.agentMaxSteps
            prefs[Keys.agentTerminalEnabled] = updated.agentTerminalEnabled
            prefs[Keys.defaultWebSearch] = updated.defaultWebSearch
            prefs[Keys.defaultImageGeneration] = updated.defaultImageGeneration
            prefs[Keys.showContextMeter] = updated.showContextMeter
            prefs[Keys.memoryEnabled] = updated.memoryEnabled
            // Wire names, not ordinals: reordering the enum must not silently
            // turn a stored "people" filter into "habit".
            prefs[Keys.memoryFilters] = updated.memoryFilters.joinToString(",") { it.wireName }
            prefs[Keys.memoryLabels] = when (updated.memoryLabels) {
                true -> LABELS_ON
                false -> LABELS_OFF
                null -> LABELS_UNSET
            }
            prefs[Keys.memorySpin] = updated.memorySpin
            prefs[Keys.memoryLinks] = updated.memoryLinks
            prefs[Keys.memoryTopics] = updated.memoryTopics
            prefs[Keys.notificationsEnabled] = updated.notificationsEnabled
            prefs[Keys.performanceMode] = updated.performanceMode.name
            prefs[Keys.powerModes] = encodePowerModes(updated.powerModes)
            prefs[Keys.powerCustom] = encodePowerCustom(updated.powerCustom)
            prefs[Keys.editorFontSize] = updated.editorFontSize
            prefs[Keys.editorTabSize] = updated.editorTabSize
            prefs[Keys.editorWordWrap] = updated.editorWordWrap
            prefs[Keys.editorLineNumbers] = updated.editorLineNumbers
            prefs[Keys.editorAutoSave] = updated.editorAutoSave
            prefs[Keys.terminalFontSize] = updated.terminalFontSize
            prefs[Keys.terminalEngine] = updated.terminalEngine.name
            prefs[Keys.termuxBackgroundNotice] = updated.termuxBackgroundNoticeShown
            prefs[Keys.activeProjectId] = updated.activeProjectId
            prefs[Keys.githubRepo] = updated.githubRepo
            prefs[Keys.onboardingDone] = updated.onboardingDone
        }
    }

    private fun Preferences.toSettings(): AppSettings {
        val defaults = AppSettings()
        return AppSettings(
            language = enumOrDefault(this[Keys.language], defaults.language),
            themeMode = enumOrDefault(this[Keys.themeMode], defaults.themeMode),
            accentColor = this[Keys.accentColor] ?: defaults.accentColor,
            glassLevel = enumOrDefault(this[Keys.glassLevel], defaults.glassLevel),
            reduceMotion = this[Keys.reduceMotion] ?: defaults.reduceMotion,
            hapticsEnabled = this[Keys.haptics] ?: defaults.hapticsEnabled,
            streamingEnabled = this[Keys.streaming] ?: defaults.streamingEnabled,
            activeProviderId = this[Keys.activeProviderId] ?: defaults.activeProviderId,
            activeModel = this[Keys.activeModel] ?: defaults.activeModel,
            temperature = this[Keys.temperature] ?: defaults.temperature,
            maxTokens = this[Keys.maxTokens] ?: defaults.maxTokens,
            agentAutoApproveReads = this[Keys.agentAutoApproveReads] ?: defaults.agentAutoApproveReads,
            agentAutoApplyChanges = this[Keys.agentAutoApplyChanges] ?: defaults.agentAutoApplyChanges,
            agentMaxSteps = this[Keys.agentMaxSteps] ?: defaults.agentMaxSteps,
            // Absent for everyone who installed before this key existed, and the
            // fallback is the default `true` rather than `false`, so an update
            // does not quietly take the terminal away from a working setup.
            agentTerminalEnabled = this[Keys.agentTerminalEnabled] ?: defaults.agentTerminalEnabled,
            defaultWebSearch = this[Keys.defaultWebSearch] ?: defaults.defaultWebSearch,
            defaultImageGeneration =
                this[Keys.defaultImageGeneration] ?: defaults.defaultImageGeneration,
            showContextMeter = this[Keys.showContextMeter] ?: defaults.showContextMeter,
            memoryEnabled = this[Keys.memoryEnabled] ?: defaults.memoryEnabled,
            // An unknown wire name is dropped rather than mapped to a default
            // category: filtering by something the user never picked is worse
            // than filtering by one thing less.
            memoryFilters = this[Keys.memoryFilters]
                ?.split(',')
                ?.mapNotNullTo(LinkedHashSet()) { raw ->
                    val name = raw.trim()
                    MemoryCategory.entries.firstOrNull { it.wireName == name }
                }
                ?: defaults.memoryFilters,
            memoryLabels = when (this[Keys.memoryLabels]) {
                LABELS_ON -> true
                LABELS_OFF -> false
                else -> defaults.memoryLabels
            },
            memorySpin = this[Keys.memorySpin] ?: defaults.memorySpin,
            memoryLinks = this[Keys.memoryLinks] ?: defaults.memoryLinks,
            memoryTopics = this[Keys.memoryTopics] ?: defaults.memoryTopics,
            notificationsEnabled = this[Keys.notificationsEnabled]
                ?: defaults.notificationsEnabled,
            performanceMode = enumOrDefault(this[Keys.performanceMode], defaults.performanceMode),
            powerModes = decodePowerModes(this[Keys.powerModes]),
            powerCustom = decodePowerCustom(this[Keys.powerCustom]),
            editorFontSize = this[Keys.editorFontSize] ?: defaults.editorFontSize,
            editorTabSize = this[Keys.editorTabSize] ?: defaults.editorTabSize,
            editorWordWrap = this[Keys.editorWordWrap] ?: defaults.editorWordWrap,
            editorLineNumbers = this[Keys.editorLineNumbers] ?: defaults.editorLineNumbers,
            editorAutoSave = this[Keys.editorAutoSave] ?: defaults.editorAutoSave,
            terminalFontSize = this[Keys.terminalFontSize] ?: defaults.terminalFontSize,
            terminalEngine = enumOrDefault(this[Keys.terminalEngine], defaults.terminalEngine),
            termuxBackgroundNoticeShown = this[Keys.termuxBackgroundNotice]
                ?: defaults.termuxBackgroundNoticeShown,
            activeProjectId = this[Keys.activeProjectId] ?: defaults.activeProjectId,
            githubRepo = this[Keys.githubRepo] ?: defaults.githubRepo,
            onboardingDone = this[Keys.onboardingDone] ?: defaults.onboardingDone
        )
    }

    /**
     * `endpoint|model=MODE` per line.
     *
     * Plain text rather than a serialised map because the key is a pair, and a
     * pair has no natural JSON key. Enum *names* are stored, never ordinals, so
     * reordering [PowerMode] cannot turn a saved HIGH into MAX.
     */
    private fun encodePowerModes(modes: Map<Pair<String, String>, PowerMode>): String =
        modes.entries.joinToString(RECORD_SEPARATOR) { (pair, mode) ->
            pair.first + KEY_SEPARATOR + pair.second + FIELD_SEPARATOR + mode.name
        }

    private fun decodePowerModes(raw: String?): Map<Pair<String, String>, PowerMode> {
        if (raw.isNullOrBlank()) return emptyMap()
        val out = LinkedHashMap<Pair<String, String>, PowerMode>()
        raw.split(RECORD_SEPARATOR).forEach { line ->
            val pair = splitPairKey(line.substringBefore(FIELD_SEPARATOR)) ?: return@forEach
            // An unknown name is dropped rather than defaulted: a mode this build
            // does not have is not a mode it should guess at.
            val mode = PowerMode.entries
                .firstOrNull { it.name == line.substringAfter(FIELD_SEPARATOR) }
                ?: return@forEach
            out[pair] = mode
        }
        return out
    }

    /**
     * `endpoint|model=tokens;effort;budget`, empty fields meaning "unset".
     *
     * [PowerConfig.extra] is deliberately absent rather than forgotten: every
     * value it can hold is either an enabling flag the resolver re-adds from the
     * endpoint's own capabilities, or a wire path this endpoint does not declare,
     * which is dropped on the way to the request. Persisting it would store a
     * value that can only be ignored or overwritten.
     */
    private fun encodePowerCustom(configs: Map<Pair<String, String>, PowerConfig>): String =
        configs.entries.joinToString(RECORD_SEPARATOR) { (pair, config) ->
            pair.first + KEY_SEPARATOR + pair.second + FIELD_SEPARATOR +
                number(config.maxTokens) + VALUE_SEPARATOR +
                config.reasoningEffort.orEmpty() + VALUE_SEPARATOR +
                number(config.thinkingBudget)
        }

    private fun decodePowerCustom(raw: String?): Map<Pair<String, String>, PowerConfig> {
        if (raw.isNullOrBlank()) return emptyMap()
        val out = LinkedHashMap<Pair<String, String>, PowerConfig>()
        raw.split(RECORD_SEPARATOR).forEach { line ->
            val pair = splitPairKey(line.substringBefore(FIELD_SEPARATOR)) ?: return@forEach
            val fields = line.substringAfter(FIELD_SEPARATOR).split(VALUE_SEPARATOR)
            if (fields.size < 3) return@forEach
            val config = PowerConfig(
                maxTokens = fields[0].toIntOrNull(),
                reasoningEffort = fields[1].takeIf { it.isNotBlank() },
                thinkingBudget = fields[2].toIntOrNull()
            )
            // An all-empty record would make CUSTOM look configured while doing
            // nothing, which is the one state this whole feature exists to avoid.
            if (!config.isNoOp) out[pair] = config
        }
        return out
    }

    private fun number(value: Int?): String = value?.toString().orEmpty()

    /** `endpoint|model` back into a pair. A line without the separator is skipped. */
    private fun splitPairKey(raw: String): Pair<String, String>? {
        val index = raw.indexOf(KEY_SEPARATOR)
        if (index <= 0 || index == raw.lastIndex) return null
        return raw.substring(0, index) to raw.substring(index + 1)
    }

    private inline fun <reified T : Enum<T>> enumOrDefault(raw: String?, fallback: T): T =
        raw?.let { value -> enumValues<T>().firstOrNull { it.name == value } } ?: fallback

    companion object {
        // Tri-state for a nullable boolean. DataStore has no "absent or false or
        // true", and the difference matters here: "never chosen" is what lets a
        // default follow the device instead of freezing at first launch.
        // Records are newline separated and fields inside a record are not, so
        // a model id with a comma in it cannot swallow the next pair. Model ids
        // contain slashes and dots but never these three.
        private const val KEY_SEPARATOR = '|'
        private const val FIELD_SEPARATOR = '='
        private const val VALUE_SEPARATOR = ";"
        private const val RECORD_SEPARATOR = "\n"

        private const val LABELS_UNSET = -1
        private const val LABELS_OFF = 0
        private const val LABELS_ON = 1

        fun themeModeOf(name: String): ThemeMode =
            ThemeMode.entries.firstOrNull { it.name == name } ?: ThemeMode.System

        fun glassLevelOf(name: String): GlassLevel =
            GlassLevel.entries.firstOrNull { it.name == name } ?: GlassLevel.Full
    }
}
