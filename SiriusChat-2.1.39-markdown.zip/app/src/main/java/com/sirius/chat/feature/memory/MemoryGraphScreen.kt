package com.sirius.chat.feature.memory

import android.graphics.Color as AndroidColor
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.style.TextAlign
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.LoadingState
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusCheckToggle
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.DevicePerformance
import com.sirius.chat.domain.model.MemoryCategory
import com.sirius.chat.domain.model.MemoryEdge
import com.sirius.chat.domain.model.MemoryLinkKind
import com.sirius.chat.domain.model.MemoryNode
import com.sirius.chat.domain.model.memoryPath
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * The memory graph: every stored fact as a point in a force-directed cloud.
 *
 * ### Why this is drawn and not embedded
 * The reference for this view is a WebGL force graph in a browser. Putting a
 * WebView on this screen would mean shipping a renderer, a JavaScript engine and
 * a bridge to show at most a couple of hundred dots -- on the exact phones this
 * release is trying to make faster. The same picture is a few hundred lines of
 * `Canvas`: a layout that runs off the main thread, then nothing per frame but a
 * rotation, a projection and a circle each.
 *
 * ### What is kept from the reference
 * The parts that make that graph what it is, rather than the parts that happen
 * to be cheap: a dark scene, colour by group, node size by link count, links
 * that fade with depth, a layout that visibly settles instead of appearing
 * finished, labels next to the nodes facing you, orbit / pan / pinch on the
 * whole scene, and a camera that flies to whatever you tap.
 */
@Composable
fun MemoryGraphScreen(
    onBack: () -> Unit,
    onOpenFiles: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: MemoryViewModel = siriusViewModel { MemoryViewModel(it) }
    val state by viewModel.state.collectAsState()
    val colors = SiriusTheme.colors
    val context = LocalContext.current
    val reduceMotion = SiriusTheme.reduceMotion
    val economical = remember(context) { DevicePerformance.isWeak(context) }
    // The reference renderer is tried first and always, because it is what the
    // design asks for. If neither the vendored library nor its published copy
    // can be reached, the page says so and the Canvas scene below takes over
    // for the rest of the visit. See docs/memory-graph.md.
    var webScene by remember { mutableStateOf(true) }
    var webReady by remember { mutableStateOf(false) }

    val positions by rememberGraphLayout(state.nodes, state.edges, economical)
    val camera = remember { GraphCamera() }
    // Read through derivedStateOf so the screen recomposes once, when the view
    // stops being the default one -- not on every frame of a pinch.
    val adjusted by remember(camera) { derivedStateOf { camera.adjusted } }

    var searching by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    // Every switch below is read from settings rather than held here. They used
    // to be `remember` state, which gave them the lifetime of the screen: each
    // one was forgotten on the way out, so the panel looked like it did nothing
    // between visits.
    //
    // Captions are on: a sphere with the fact's own words beside it is the
    // design. Only a handful get one -- the nearest eighteen -- so the scene
    // stays a constellation rather than a page of text, and the switch in the
    // panel still turns them off for anyone who wants the shape alone.
    val labels = state.labels ?: true
    val spinning = state.spinning
    val showLinks = state.showLinks
    // The lines that hold a file together are a different thing from a stated
    // link between two facts, so they switch off separately: on, the cloud reads
    // as clusters by subject; off, only real relationships are drawn.
    val showTopics = state.showTopics

    val query = state.query
    val matches = remember(state.nodes, query) {
        val needle = query.trim()
        if (needle.isEmpty()) 0 else state.nodes.count { it.content.contains(needle, true) }
    }

    // System back closes what is open on top of the graph before it leaves the
    // screen. Without this the panel, the search field and the open fact all
    // swallow nothing and back drops the user out of memory entirely -- the same
    // complaint as any dialog that cannot be dismissed the usual way.
    BackHandler(enabled = menuOpen || searching || state.selectedId != null) {
        when {
            menuOpen -> menuOpen = false
            searching -> {
                searching = false
                viewModel.setQuery("")
            }
            else -> viewModel.select(null)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            SiriusTopBar(
                title = stringResource(R.string.memory_title),
                subtitle = if (query.isBlank()) {
                    stringResource(R.string.memory_count, state.nodes.size)
                } else {
                    stringResource(R.string.memory_search_results, matches)
                },
                scrolled = false,
                onBack = onBack,
                // A full-screen scene closes, it does not go back a step.
                backIcon = Icons.Rounded.Close,
                backDescription = stringResource(R.string.action_close),
                actions = {
                    GlassIconButton(
                        icon = Icons.Rounded.Description,
                        contentDescription = stringResource(R.string.memory_files_title),
                        onClick = onOpenFiles
                    )
                    GlassIconButton(
                        icon = Icons.Rounded.Search,
                        contentDescription = stringResource(R.string.memory_search),
                        highlighted = searching,
                        onClick = {
                            searching = !searching
                            // Closing the field clears the term: a hidden filter
                            // that keeps greying out half the graph is a bug
                            // report waiting to happen.
                            if (!searching) viewModel.setQuery("")
                        }
                    )
                    GlassIconButton(
                        icon = Icons.Rounded.Tune,
                        contentDescription = stringResource(R.string.memory_menu),
                        highlighted = state.filters.isNotEmpty(),
                        onClick = { menuOpen = true }
                    )
                }
            )

            AnimatedVisibility(visible = searching) {
                SiriusTextField(
                    value = query,
                    onValueChange = viewModel::setQuery,
                    placeholder = stringResource(R.string.memory_search_placeholder),
                    leadingIcon = Icons.Rounded.Search,
                    trailing = {
                        if (query.isNotEmpty()) {
                            GlassIconButton(
                                icon = Icons.Rounded.Close,
                                contentDescription = stringResource(R.string.action_close),
                                size = 30.dp,
                                iconSize = 16.dp,
                                onClick = { viewModel.setQuery("") }
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
                )
            }

            if (state.loaded && state.nodes.isEmpty()) {
                MemoryEmpty(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(SiriusSpacing.sm)
                )
            } else {
                // Edge to edge, and no rounded plate under it. The scene in
                // the reference is the window: an inset card with corners reads
                // as a preview of a graph rather than the graph itself.
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(SceneBackdrop)
                ) {
                    if (webScene) {
                        MemoryWebScene(
                            // Filtering happens here rather than in the page:
                            // the scene is told what to draw, it does not decide.
                            nodes = state.nodes.filter {
                                state.filters.isEmpty() || it.category in state.filters
                            },
                            edges = state.edges,
                            selectedId = state.selectedId,
                            labels = labels,
                            spinning = spinning,
                            showLinks = showLinks,
                            showTopics = showTopics,
                            onSelect = viewModel::select,
                            onReady = { webReady = true },
                            onUnavailable = { webScene = false },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    // What fills the wait instead: the gradient is already the
                    // scene's own background, so all it needs is a line saying
                    // the spheres are on their way. Nothing else is drawn, so
                    // there is no second design to replace.
                    if (webScene && !webReady) {
                        LoadingState(
                            label = stringResource(R.string.memory_scene_loading),
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    // Only when the page never managed a scene at all. It used
                    // to fill the wait as well, and that is the bug being fixed
                    // here: every visit drew the flat Canvas graph for a moment
                    // and then replaced it with the spheres. Two designs inside
                    // one second read as the new screen loading on top of the old
                    // one, which is exactly what it looked like.
                    if (!webScene && positions.size == state.nodes.size && state.nodes.isNotEmpty()) {
                        MemoryCanvas(
                            nodes = state.nodes,
                            edges = state.edges,
                            positions = positions,
                            selectedId = state.selectedId,
                            filters = state.filters,
                            query = query,
                            labels = labels,
                            showLinks = showLinks,
                            showTopics = showTopics,
                            spinning = spinning,
                            camera = camera,
                            reduceMotion = reduceMotion,
                            economical = economical,
                            onSelect = viewModel::select,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    if (query.isNotBlank() && matches == 0) {
                        Text(
                            text = stringResource(R.string.memory_search_none),
                            style = MaterialTheme.typography.bodySmall,
                            color = LabelColor,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(SiriusSpacing.md)
                        )
                    }
                    if (state.selected == null) {
                        // The reference keeps its controls on one dim line along
                        // the bottom edge of the scene instead of in a panel
                        // beside it, and so does this.
                        Text(
                            text = stringResource(R.string.memory_nav_hint),
                            style = MaterialTheme.typography.labelSmall,
                            color = HintColor,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = SiriusSpacing.xl)
                                .padding(
                                    bottom = contentPadding.calculateBottomPadding() +
                                        SiriusSpacing.sm
                                )
                        )
                    }
                    if (adjusted) {
                        GlassIconButton(
                            icon = Icons.Rounded.Refresh,
                            contentDescription = stringResource(R.string.memory_reset_view),
                            onClick = camera::reset,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(SiriusSpacing.sm)
                        )
                    }
                }
            }
        }

        // A tap on a sphere brings the fact up over the scene instead of
        // pushing the scene aside to make room for a card: the graph stays
        // whole behind it, which is the only reason to use a sheet here.
        val selected = state.selected
        if (selected != null) {
            SiriusBottomSheet(
                // The file it was filed under is the honest title: it says
                // where this fact lives, not just what kind of fact it is.
                title = selected.memoryPath(),
                onDismiss = { viewModel.select(null) }
            ) {
                Text(
                    text = stringResource(selected.category.labelRes()),
                    style = MaterialTheme.typography.labelMedium,
                    color = clusterTint(selected),
                    fontWeight = FontWeight.SemiBold
                )
                VSpace(SiriusSpacing.xs)
                Text(
                    text = selected.content,
                    style = MaterialTheme.typography.bodyLarge,
                    color = colors.textPrimary
                )
                if (selected.links.isNotEmpty()) {
                    VSpace(SiriusSpacing.xs)
                    Text(
                        text = stringResource(R.string.memory_links, selected.links.size),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textTertiary
                    )
                }
                VSpace(SiriusSpacing.sm)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { viewModel.forget(selected.id) }) {
                        Text(
                            text = stringResource(R.string.memory_forget),
                            color = colors.error
                        )
                    }
                }
            }
        }

        MemorySidePanel(
            visible = menuOpen,
            nodes = state.nodes,
            filters = state.filters,
            labels = labels,
            spinning = spinning,
            showLinks = showLinks,
            showTopics = showTopics,
            adjusted = adjusted,
            bottomPadding = contentPadding.calculateBottomPadding(),
            onToggleFilter = viewModel::toggleFilter,
            onLabels = viewModel::setLabels,
            onSpinning = { on ->
                viewModel.setSpinning(on)
                // Switching the spin back on also hands the scene back to it;
                // otherwise the toggle would look broken after the first drag.
                if (on) camera.resume()
            },
            onLinks = viewModel::setLinks,
            onTopics = viewModel::setTopics,
            onReset = camera::reset,
            onForgetAll = viewModel::forgetEverything,
            onDismiss = { menuOpen = false }
        )
    }
}

/**
 * The panel behind the top-right button: what is shown, how it is shown, and --
 * last, on its own, past everything else -- the button that erases all of it.
 *
 * It is a panel and not a bottom sheet because it holds a list that grows with
 * the number of categories, and because the graph stays visible beside it: you
 * can see the cloud grey out as you uncheck a category.
 */
@Composable
private fun MemorySidePanel(
    visible: Boolean,
    nodes: List<MemoryNode>,
    filters: Set<MemoryCategory>,
    labels: Boolean,
    spinning: Boolean,
    showLinks: Boolean,
    showTopics: Boolean,
    adjusted: Boolean,
    bottomPadding: Dp,
    onToggleFilter: (MemoryCategory) -> Unit,
    onLabels: (Boolean) -> Unit,
    onSpinning: (Boolean) -> Unit,
    onLinks: (Boolean) -> Unit,
    onTopics: (Boolean) -> Unit,
    onReset: () -> Unit,
    onForgetAll: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors
    // Only categories that actually hold a fact get a row: a filter that can
    // only ever grey out the whole screen is not worth the line it sits on.
    val counts = remember(nodes) {
        val tally = HashMap<MemoryCategory, Int>()
        for (node in nodes) tally[node.category] = (tally[node.category] ?: 0) + 1
        MemoryCategory.entries.mapNotNull { category ->
            val count = tally[category] ?: return@mapNotNull null
            category to count
        }
    }
    // The confirmation resets every time the panel opens, so a stray tap from
    // last time is never one tap away from erasing everything.
    var confirming by remember(visible) { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.matchParentSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ScrimColor)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onDismiss
                    )
            )
        }

        AnimatedVisibility(
            visible = visible,
            enter = slideInHorizontally { full -> full } + fadeIn(),
            exit = slideOutHorizontally { full -> full } + fadeOut(),
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .widthIn(max = 400.dp)
                    .fillMaxWidth(0.88f)
                    .background(colors.backgroundElevated)
                    .statusBarsPadding()
                    .padding(SiriusSpacing.md)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.memory_menu),
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.textPrimary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    GlassIconButton(
                        icon = Icons.Rounded.Close,
                        contentDescription = stringResource(R.string.action_close),
                        onClick = onDismiss
                    )
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    VSpace(SiriusSpacing.sm)
                    MemorySectionLabel(stringResource(R.string.memory_filters))
                    for (entry in counts) {
                        val category = entry.first
                        MemoryCategoryRow(
                            category = category,
                            count = entry.second,
                            // No filter at all reads as "every category shown",
                            // so every box is ticked -- unticking one is then
                            // the obvious way to grey it out.
                            checked = filters.isEmpty() || category in filters,
                            onToggle = { onToggleFilter(category) }
                        )
                    }

                    VSpace(SiriusSpacing.md)
                    MemorySectionLabel(stringResource(R.string.memory_view))
                    MemoryOptionRow(
                        icon = Icons.Rounded.TextFields,
                        title = stringResource(R.string.memory_labels),
                        checked = labels,
                        onToggle = onLabels
                    )
                    MemoryOptionRow(
                        icon = Icons.Rounded.Refresh,
                        title = stringResource(R.string.memory_spin),
                        checked = spinning,
                        onToggle = onSpinning
                    )
                    MemoryOptionRow(
                        icon = Icons.Rounded.Hub,
                        title = stringResource(R.string.memory_show_links),
                        checked = showLinks,
                        onToggle = onLinks
                    )
                    MemoryOptionRow(
                        icon = Icons.Rounded.Layers,
                        title = stringResource(R.string.memory_show_topics),
                        checked = showTopics,
                        onToggle = onTopics
                    )
                    VSpace(SiriusSpacing.sm)
                    SiriusGhostButton(
                        text = stringResource(R.string.memory_reset_view),
                        onClick = onReset,
                        enabled = adjusted,
                        modifier = Modifier.fillMaxWidth()
                    )

                    VSpace(SiriusSpacing.md)
                    Text(
                        text = stringResource(R.string.memory_nav_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textTertiary
                    )
                    VSpace(SiriusSpacing.sm)
                    Text(
                        text = stringResource(R.string.memory_about),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textTertiary
                    )
                    VSpace(SiriusSpacing.sm)
                }

                SiriusGhostButton(
                    text = stringResource(
                        if (confirming) {
                            R.string.memory_forget_all_confirm
                        } else {
                            R.string.memory_forget_all
                        }
                    ),
                    icon = Icons.Rounded.DeleteOutline,
                    tint = colors.error,
                    enabled = nodes.isNotEmpty(),
                    onClick = {
                        if (confirming) {
                            confirming = false
                            onForgetAll()
                            onDismiss()
                        } else {
                            confirming = true
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = bottomPadding)
                )
            }
        }
    }
}

@Composable
private fun MemorySectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        color = SiriusTheme.colors.textTertiary,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = SiriusSpacing.xs)
    )
}

/**
 * One category in the filter list.
 *
 * Unticking greys the category out in the scene instead of removing it. Hiding
 * would also hide every link that crosses a category, and "which project does
 * this habit belong to" is most of the reason to look at the graph at all.
 */
@Composable
private fun MemoryCategoryRow(
    category: MemoryCategory,
    count: Int,
    checked: Boolean,
    onToggle: () -> Unit
) {
    val colors = SiriusTheme.colors
    val tint = category.tint()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.sm))
            .clickable(onClick = onToggle)
            .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.sm)
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(if (checked) tint else colors.outline)
        )
        Text(
            text = stringResource(category.labelRes()),
            style = MaterialTheme.typography.bodyMedium,
            color = if (checked) colors.textPrimary else colors.textTertiary,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = count.toString(),
            style = MaterialTheme.typography.labelMedium,
            color = colors.textTertiary
        )
        SiriusCheckToggle(checked = checked, accent = tint)
    }
}

@Composable
private fun MemoryOptionRow(
    icon: ImageVector,
    title: String,
    checked: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.sm))
            .clickable { onToggle(!checked) }
            .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.sm)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = colors.textSecondary,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f)
        )
        SiriusCheckToggle(checked = checked)
    }
}

@Composable
private fun MemoryEmpty(modifier: Modifier) {
    val colors = SiriusTheme.colors
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        GlassCard(contentPadding = SiriusSpacing.lg) {
            Text(
                text = stringResource(R.string.memory_empty_title),
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
                fontWeight = FontWeight.SemiBold
            )
            VSpace(SiriusSpacing.xs)
            Text(
                text = stringResource(R.string.memory_empty_body),
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary
            )
            VSpace(SiriusSpacing.sm)
            Text(
                text = stringResource(R.string.memory_about),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary
            )
        }
    }
}

/**
 * The scene itself.
 *
 * Everything that changes per frame -- the angle, the projection, the circles --
 * is read or computed inside the draw lambda. Nothing here is state that
 * composition depends on, so a turning graph never recomposes.
 */
@Composable
private fun MemoryCanvas(
    nodes: List<MemoryNode>,
    edges: List<MemoryEdge>,
    positions: List<Vec3>,
    selectedId: String?,
    filters: Set<MemoryCategory>,
    query: String,
    labels: Boolean,
    showLinks: Boolean,
    showTopics: Boolean,
    spinning: Boolean,
    camera: GraphCamera,
    reduceMotion: Boolean,
    economical: Boolean,
    onSelect: (String?) -> Unit,
    modifier: Modifier
) {
    // Where each node landed on screen last frame, for hit testing. A plain list
    // on purpose: a snapshot list written to during drawing would invalidate the
    // draw that is writing it.
    val hits = remember { ArrayList<NodeHit>() }
    val measurer = rememberTextMeasurer()
    // Laid-out labels survive between frames; only the handful of nodes facing
    // the viewer are ever measured, and each of them only once.
    val labelCache = remember(nodes) { HashMap<String, TextLayoutResult>() }
    // Shading a sphere needs a gradient per colour and size. Building one per
    // node per frame would allocate thousands a second, so they are kept: sizes
    // are bucketed to the half pixel, which is finer than the eye and coarse
    // enough that the cache stops growing a moment after the camera does.
    val sphereCache = remember { HashMap<Long, Brush>() }
    val labelStyle = remember { TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium) }

    val index = remember(nodes) {
        HashMap<String, Int>(nodes.size).apply {
            nodes.forEachIndexed { position, node -> put(node.id, position) }
        }
    }
    // Two kinds of line share one list: the stated link between two facts, and
    // the grouping line that ties a file together. Both are resolved to indices
    // once, so the draw pass never looks anything up.
    val links = remember(edges, index) {
        val out = ArrayList<GraphLink>(edges.size)
        for (edge in edges) {
            val from = index[edge.from] ?: continue
            val to = index[edge.to] ?: continue
            if (from == to) continue
            out += GraphLink(from, to, edge.kind == MemoryLinkKind.Topic)
        }
        out
    }
    // A filtered-out or unmatched fact is greyed, never hidden: the cloud keeps
    // its shape and the links that cross categories stay readable.
    val muted = remember(nodes, filters, query) {
        val needle = query.trim()
        val filtered = filters.isNotEmpty()
        if (!filtered && needle.isEmpty()) {
            BooleanArray(nodes.size)
        } else {
            BooleanArray(nodes.size) { position ->
                val node = nodes[position]
                (filtered && node.category !in filters) ||
                    (needle.isNotEmpty() && !node.content.contains(needle, ignoreCase = true))
            }
        }
    }
    // Colour by file, not by category. Six category colours meant six colours
    // on screen no matter how many subjects were stored, so two unrelated
    // clusters sitting next to each other were the same yellow; the reference
    // gives every group its own, which is what makes the clusters readable as
    // separate things at a glance.
    val tints = remember(nodes, muted) {
        nodes.mapIndexed { position, node ->
            if (muted[position]) MutedNode else clusterTint(node)
        }
    }

    LaunchedEffect(spinning, reduceMotion, economical) {
        // "Reduce motion" means what it says: the scene still turns, but only
        // when the user turns it. The idle spin also stops the first time the
        // user takes hold of the graph -- a scene that drifts away from where you
        // just put it is worse than one that never moved.
        val speed = if (economical) SPIN_SLOW else SPIN_SPEED
        var last = 0L
        while (true) {
            val spin = spinning && !reduceMotion && !camera.userDriven
            val flying = camera.focusing
            if (!spin && !flying) {
                // Nothing is moving: stop asking for frames entirely rather than
                // waking the phone sixty times a second to add zero.
                last = 0L
                delay(IDLE_POLL_MS)
                continue
            }
            withFrameNanos { now ->
                val elapsed = if (last == 0L) 0f else (now - last) / 1_000_000_000f
                last = now
                if (spin) camera.yaw += elapsed * speed
                if (flying) camera.step(FOCUS_EASE)
            }
            // Half the frames on a slow phone. The elapsed time is still measured
            // from the real clock, so the graph turns at the same rate -- it just
            // gets there in fewer, cheaper steps.
            if (economical) delay(SLOW_FRAME_MS)
        }
    }

    Canvas(
        modifier = modifier
            .pointerInput(Unit) {
                // One finger orbits, two fingers pinch and pan -- the controls of
                // the WebGL graph this view is modelled on. Written out by hand
                // because the ready-made detectors report the gesture or the
                // pointer count, never both.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var previousCentroid: Offset? = null
                    var previousSpread = 0f
                    var previousCount = 0
                    while (true) {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.filter { it.pressed }
                        if (pressed.isEmpty()) break

                        var sumX = 0f
                        var sumY = 0f
                        for (change in pressed) {
                            sumX += change.position.x
                            sumY += change.position.y
                        }
                        val centroid = Offset(sumX / pressed.size, sumY / pressed.size)
                        var spread = 0f
                        if (pressed.size > 1) {
                            for (change in pressed) {
                                spread += (change.position - centroid).getDistance()
                            }
                            spread /= pressed.size
                        }

                        val previous = previousCentroid
                        val moved = pressed.any { it.positionChanged() }
                        // Act only when the same fingers moved. Putting a second
                        // finger down jumps the centroid, and following that jump
                        // is exactly what makes a graph flinch mid-pinch.
                        if (previous != null && moved && pressed.size == previousCount) {
                            val delta = centroid - previous
                            camera.take()
                            if (pressed.size > 1) {
                                camera.pan = Offset(
                                    (camera.pan.x + delta.x)
                                        .coerceIn(-size.width.toFloat(), size.width.toFloat()),
                                    (camera.pan.y + delta.y)
                                        .coerceIn(-size.height.toFloat(), size.height.toFloat())
                                )
                                if (previousSpread > MIN_SPREAD && spread > MIN_SPREAD) {
                                    camera.zoom = (camera.zoom * (spread / previousSpread))
                                        .coerceIn(MIN_ZOOM, MAX_ZOOM)
                                }
                            } else {
                                camera.yaw += delta.x * DRAG_TO_RADIANS
                                camera.pitch = (camera.pitch + delta.y * DRAG_TO_RADIANS)
                                    .coerceIn(-MAX_PITCH, MAX_PITCH)
                            }
                            // Consumed only after a real movement, so a tap still
                            // reaches the handler below and opens the fact.
                            pressed.forEach { it.consume() }
                        }

                        previousCentroid = centroid
                        previousSpread = spread
                        previousCount = pressed.size
                    }
                }
            }
            .pointerInput(nodes) {
                detectTapGestures { point ->
                    var best: NodeHit? = null
                    var bestScore = Float.MAX_VALUE
                    for (hit in hits) {
                        val distance = (hit.center - point).getDistance()
                        if (distance > hit.radius + hit.slop) continue
                        // A greyed-out fact stays tappable, but it never wins
                        // against one the filter is showing in colour.
                        val score = distance + if (hit.muted) hit.slop * 4f else 0f
                        if (score < bestScore) {
                            bestScore = score
                            best = hit
                        }
                    }
                    onSelect(best?.id)

                    val target = best ?: return@detectTapGestures
                    // Fly to the fact, the way clicking a node moves the camera in
                    // the reference. The pan is solved for the zoom it will end
                    // at, not the one it starts at, or the node drifts back off
                    // centre as the scene grows.
                    val centre = Offset(size.width / 2f, size.height / 2f)
                    val zoomNow = camera.zoom
                    val zoomNext = max(zoomNow, FOCUS_ZOOM).coerceAtMost(MAX_ZOOM)
                    val vector = target.center - centre - camera.pan
                    val ratio = zoomNext / zoomNow
                    val limitX = size.width.toFloat() * PAN_LIMIT
                    val limitY = size.height.toFloat() * PAN_LIMIT
                    camera.focus(
                        pan = Offset(
                            (-vector.x * ratio).coerceIn(-limitX, limitX),
                            (-vector.y * ratio).coerceIn(-limitY, limitY)
                        ),
                        zoom = zoomNext
                    )
                }
            }
    ) {
        val count = positions.size
        if (count == 0) return@Canvas

        // Almost black, with the indigo pooled behind the middle of the cloud
        // and gone by the corners. It is the one light in the scene, which is
        // what lets the nodes read as lit rather than painted.
        drawRect(brush = SceneBackdrop)

        hits.clear()
        val centreX = size.width / 2f + camera.pan.x
        val centreY = size.height / 2f + camera.pan.y
        val scale = min(size.width, size.height) * SCENE_FILL * camera.zoom
        val cosYaw = cos(camera.yaw)
        val sinYaw = sin(camera.yaw)
        val cosPitch = cos(camera.pitch)
        val sinPitch = sin(camera.pitch)

        val screenX = FloatArray(count)
        val screenY = FloatArray(count)
        val depth = FloatArray(count)

        for (i in 0 until count) {
            val point = positions[i]
            val x1 = point.x * cosYaw + point.z * sinYaw
            val z1 = point.z * cosYaw - point.x * sinYaw
            val y2 = point.y * cosPitch - z1 * sinPitch
            val z2 = point.y * sinPitch + z1 * cosPitch
            // Perspective: near nodes grow, far ones shrink. This is the only
            // depth cue that survives on a small screen.
            val perspective = FOCAL / (FOCAL + z2)
            screenX[i] = centreX + x1 * scale * perspective
            screenY[i] = centreY + y2 * scale * perspective
            depth[i] = z2
        }

        val lineWidth = 1.dp.toPx()
        val selectedIndex = selectedId?.let { index[it] } ?: -1
        for (link in links) {
            if (if (link.grouping) !showTopics else !showLinks) continue
            val a = link.a
            val b = link.b
            val nearness = 1f - ((depth[a] + depth[b]) * 0.5f + 1f) * 0.5f
            val base = EDGE_MIN_ALPHA + nearness * EDGE_ALPHA_RANGE
            // The links of the open fact are lit, the way hovering a node in
            // the reference lights up what it is attached to.
            val linked = a == selectedIndex || b == selectedIndex
            val alpha = when {
                linked -> (base * LINK_FOCUS_GAIN).coerceAtMost(0.9f)
                muted[a] && muted[b] -> base * DIM_ALPHA
                else -> base
            } * (if (link.grouping) GROUP_EDGE_FADE else 1f)
            // A grouping line takes the colour of the file it holds together, so
            // a subject reads as one coloured constellation. A stated link stays
            // neutral: it joins two particular facts, not two of a kind.
            val colour = if (link.grouping) tints[b] else EdgeColor
            val width = when {
                linked -> lineWidth * 1.8f
                link.grouping -> lineWidth * GROUP_EDGE_WIDTH
                else -> lineWidth
            }
            drawLine(
                color = colour.copy(alpha = alpha),
                start = Offset(screenX[a], screenY[a]),
                end = Offset(screenX[b], screenY[b]),
                strokeWidth = width
            )
        }

        // Small on purpose, and bigger with every link: the size of a sphere
        // is the one thing in the scene that says how connected a fact is. The
        // bonus is capped, or one much-linked fact becomes a planet.
        val baseRadius = 4f.dp.toPx()
        val linkRadius = 1.4f.dp.toPx()
        val slop = 10.dp.toPx()
        val labelGap = 6.dp.toPx()
        val searchActive = query.isNotBlank()
        var labelBudget = if (labels) MAX_LABELS else 0
        // Two passes instead of a depth sort: the far half, then the near half.
        // Sorting 200 indices every frame allocates; this reads the same.
        for (pass in 0..1) {
            for (i in 0 until count) {
                val far = depth[i] > 0f
                if ((pass == 0) != far) continue
                val node = nodes[i]
                val perspective = FOCAL / (FOCAL + depth[i])
                val radius =
                    (baseRadius + min(node.links.size, MAX_LINK_BONUS) * linkRadius) * perspective
                val centre = Offset(screenX[i], screenY[i])
                val tint = tints[i]
                val alpha = (NODE_MIN_ALPHA + (1f - (depth[i] + 1f) * 0.5f) * NODE_ALPHA_RANGE)
                    .coerceIn(0.25f, 1f) * (if (muted[i]) DIM_ALPHA else 1f)
                // A lit ball rather than a dot: a wide faint halo for the
                // glow, the body as a shaded sphere, then a small highlight
                // where the light lands. Flat discs were cheaper and read as
                // confetti. The halo is the first thing dropped on a weak phone.
                if (!economical) {
                    drawCircle(
                        color = tint.copy(alpha = alpha * HALO_ALPHA),
                        radius = radius * HALO_SCALE,
                        center = centre
                    )
                }
                translate(left = centre.x, top = centre.y) {
                    drawCircle(
                        brush = sphereBrush(sphereCache, tint, radius),
                        radius = radius,
                        center = Offset.Zero,
                        alpha = alpha
                    )
                }
                drawCircle(
                    color = Color.White.copy(alpha = alpha * CORE_ALPHA),
                    radius = radius * CORE_SCALE,
                    center = Offset(
                        centre.x - radius * LIGHT_X,
                        centre.y - radius * LIGHT_Y
                    )
                )
                if (node.id == selectedId) {
                    drawCircle(
                        color = tint,
                        radius = radius + slop * 0.4f,
                        center = centre,
                        style = Stroke(width = lineWidth * 1.6f)
                    )
                } else if (searchActive && !muted[i]) {
                    // Every hit of the search wears a ring, so a match at the back
                    // of the cloud is still findable.
                    drawCircle(
                        color = tint.copy(alpha = 0.7f),
                        radius = radius + slop * 0.3f,
                        center = centre,
                        style = Stroke(width = lineWidth)
                    )
                }
                // Labels only for what faces the viewer, and only a handful:
                // the reference shows one label at a time on hover, and a phone
                // screen covered in text is not more informative, only slower.
                if (labelBudget > 0 && !muted[i] && depth[i] < LABEL_DEPTH) {
                    val layout = labelCache.getOrPut(node.id) {
                        measurer.measure(
                            text = node.content.take(LABEL_CHARS).trim(),
                            style = labelStyle,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                    drawText(
                        textLayoutResult = layout,
                        color = LabelColor.copy(alpha = alpha),
                        topLeft = Offset(
                            centre.x + radius + labelGap,
                            centre.y - layout.size.height / 2f
                        )
                    )
                    labelBudget--
                }
                hits += NodeHit(
                    id = node.id,
                    center = centre,
                    radius = radius,
                    slop = slop,
                    muted = muted[i]
                )
            }
        }
    }
}

/**
 * One line in the scene: the two nodes it joins, and whether it is a grouping
 * line for a file rather than a link the user actually stated.
 */
private data class GraphLink(val a: Int, val b: Int, val grouping: Boolean)

private data class NodeHit(
    val id: String,
    val center: Offset,
    val radius: Float,
    val slop: Float,
    val muted: Boolean
)

/**
 * Where the viewer is standing, and where they are being taken.
 *
 * Kept in one object rather than five separate `remember`s so the screen can
 * offer a way back to the default view without hoisting the angles into
 * composition. The canvas reads these fields inside its draw lambda, where a
 * change repaints without recomposing anything -- which is why a pinch on a slow
 * phone costs a frame of drawing and nothing else.
 */
@Stable
private class GraphCamera {
    var yaw by mutableStateOf(0f)
    var pitch by mutableStateOf(START_PITCH)
    var zoom by mutableStateOf(1f)
    var pan by mutableStateOf(Offset.Zero)

    /** True once the user has moved the scene themselves; stops the idle spin. */
    var userDriven by mutableStateOf(false)

    // The fly-to target. Deliberately not snapshot state: it is written and read
    // only from the frame loop, and making it observable would recompose the
    // screen on every step of an animation that repaints by itself.
    private var panTarget: Offset? = null
    private var zoomTarget = 1f

    val focusing: Boolean
        get() = panTarget != null

    /** Whether there is anything for "reset view" to undo. */
    val adjusted: Boolean
        get() = userDriven || zoom != 1f || pan != Offset.Zero

    /** The user grabbed the scene: cancel any flight and stop the idle spin. */
    fun take() {
        panTarget = null
        if (!userDriven) userDriven = true
    }

    fun focus(pan: Offset, zoom: Float) {
        if (!userDriven) userDriven = true
        panTarget = pan
        zoomTarget = zoom
    }

    /** One eased step towards the target; ends exactly on it rather than near it. */
    fun step(fraction: Float) {
        val target = panTarget ?: return
        val nextX = pan.x + (target.x - pan.x) * fraction
        val nextY = pan.y + (target.y - pan.y) * fraction
        val nextZoom = zoom + (zoomTarget - zoom) * fraction
        val arrived = abs(target.x - nextX) < 0.5f &&
            abs(target.y - nextY) < 0.5f &&
            abs(zoomTarget - nextZoom) < 0.005f
        if (arrived) {
            pan = target
            zoom = zoomTarget
            panTarget = null
        } else {
            pan = Offset(nextX, nextY)
            zoom = nextZoom
        }
    }

    /** Hands the scene back to the idle spin without moving the camera. */
    fun resume() {
        panTarget = null
        userDriven = false
    }

    fun reset() {
        yaw = 0f
        pitch = START_PITCH
        zoom = 1f
        pan = Offset.Zero
        panTarget = null
        userDriven = false
    }
}

/** A point in the cloud, in unit space; the canvas decides how big that is. */
data class Vec3(val x: Float, val y: Float, val z: Float)

/**
 * Positions for [nodes], relaxed on a background thread and handed over while
 * they are still settling.
 *
 * ### Why the simulation does not run per frame
 * A live force simulation is what the browser reference does and it is the
 * single most expensive thing it does. The layout of a set of facts does not
 * change until the facts do, so it is computed when they change and then reused
 * for every frame after that. What the reference's warm-up actually buys is the
 * sense that the graph arranged itself, so that part is kept: the first few
 * hundred milliseconds are streamed out in chunks, and after that the phone
 * spends nothing on it. Weak phones and large graphs skip straight to the end.
 */
@Composable
private fun rememberGraphLayout(
    nodes: List<MemoryNode>,
    edges: List<MemoryEdge>,
    economical: Boolean
): State<List<Vec3>> = produceState(initialValue = emptyList(), nodes, edges, economical) {
    if (nodes.isEmpty()) {
        value = emptyList()
        return@produceState
    }
    // A weak phone or a large graph settles in one pass on a faster cooling
    // schedule: the same simulation, fewer ticks, and no half-second of visible
    // jitter on a device that cannot afford to draw it.
    val quick = economical || nodes.size > LARGE_GRAPH
    val layout = ForceLayout(nodes, edges, quick)
    if (quick) {
        value = withContext(Dispatchers.Default) {
            repeat(layout.iterations) { layout.tick() }
            layout.snapshot()
        }
        return@produceState
    }
    var done = 0
    while (done < layout.iterations) {
        val frame = withContext(Dispatchers.Default) {
            repeat(SETTLE_CHUNK) {
                if (done < layout.iterations) {
                    layout.tick()
                    done++
                }
            }
            layout.snapshot()
        }
        value = frame
        delay(SETTLE_FRAME_MS)
    }
}

/**
 * d3's force simulation, ported to three dimensions, one tick at a time.
 *
 * This is the reference implementation rather than something that resembles it:
 * the velocity-Verlet integrator of `d3-force`, its three default forces
 * (`forceManyBody`, `forceLink`, `forceCenter`) with their published defaults,
 * the same alpha schedule, and the spherical phyllotaxis `d3-force-3d` uses to
 * seed the first positions. Every number lives in the constants at the bottom
 * of this file, so it can be read against the original.
 *
 * The one deliberate departure is in `manyBody`: d3 approximates distant clumps
 * with a Barnes-Hut tree because it is built for thousands of nodes. Memory
 * holds a couple of hundred at most, where building the tree costs more than
 * walking every pair -- and the exact sum is what the tree was approximating.
 */
private class ForceLayout(
    nodes: List<MemoryNode>,
    edges: List<MemoryEdge>,
    quick: Boolean
) {
    private val count = nodes.size
    private val x = FloatArray(count)
    private val y = FloatArray(count)
    private val z = FloatArray(count)
    private val vx = FloatArray(count)
    private val vy = FloatArray(count)
    private val vz = FloatArray(count)
    private val linkFrom: IntArray
    private val linkTo: IntArray
    private val linkStrength: FloatArray
    private val linkBias: FloatArray
    private val linkDistance: FloatArray
    private val alphaDecay: Float
    private var alpha = ALPHA_START

    /**
     * Ticks until the simulation is cold, counted the way d3 counts them: alpha
     * starts at 1 and falls until it drops below alphaMin, and the decay rate is
     * solved for exactly that many steps.
     */
    val iterations = if (quick) QUICK_TICKS else FULL_TICKS

    init {
        // d3-force-3d's own seeding: a spherical phyllotaxis, radius growing as
        // the cube root of the index so the density stays even, rolled by the
        // golden angle and yawed by an irrational one so no two nodes ever line
        // up. Deterministic, which is why the same facts always settle into the
        // same picture.
        val roll = (PI * (3.0 - sqrt(5.0))).toFloat()
        val yaw = (PI * 20.0 / (9.0 + sqrt(221.0))).toFloat()
        for (i in 0 until count) {
            val radius = INITIAL_RADIUS * Math.cbrt(0.5 + i).toFloat()
            val rollAngle = i * roll
            val yawAngle = i * yaw
            x[i] = radius * sin(rollAngle) * cos(yawAngle)
            y[i] = radius * cos(rollAngle)
            z[i] = radius * sin(rollAngle) * sin(yawAngle)
        }

        val index = HashMap<String, Int>(count)
        nodes.forEachIndexed { position, node -> index[node.id] = position }
        val from = ArrayList<Int>(edges.size)
        val to = ArrayList<Int>(edges.size)
        val grouping = ArrayList<Boolean>(edges.size)
        val degree = IntArray(count)
        for (edge in edges) {
            val a = index[edge.from] ?: continue
            val b = index[edge.to] ?: continue
            if (a == b) continue
            from += a
            to += b
            grouping += edge.kind == MemoryLinkKind.Topic
            degree[a]++
            degree[b]++
        }

        val total = from.size
        linkFrom = IntArray(total) { from[it] }
        linkTo = IntArray(total) { to[it] }
        // d3's defaults, unchanged: a link between two busy nodes pulls less than
        // one between two lonely ones, and the busier end of it moves less. That
        // is what stops a hub from being dragged around by its own crowd.
        linkStrength = FloatArray(total) {
            val base = 1f / min(degree[from[it]], degree[to[it]]).coerceAtLeast(1)
            if (grouping[it]) base * GROUP_LINK_STRENGTH else base
        }
        linkBias = FloatArray(total) {
            val a = degree[from[it]].toFloat()
            val b = degree[to[it]].toFloat()
            if (a + b <= 0f) 0.5f else a / (a + b)
        }
        linkDistance = FloatArray(total) {
            if (grouping[it]) GROUP_LINK_DISTANCE else LINK_DISTANCE
        }
        alphaDecay = 1f - Math.pow(ALPHA_MIN.toDouble(), 1.0 / iterations).toFloat()
    }

    /**
     * One step of `simulation.tick()`: cool the alpha, run every force, then
     * integrate velocities into positions -- in that order, because the forces
     * write velocities and the integrator is what turns them into movement.
     */
    fun tick() {
        alpha += (0f - alpha) * alphaDecay
        manyBody()
        springs()
        recentre()
        for (i in 0 until count) {
            vx[i] *= VELOCITY_DECAY
            vy[i] *= VELOCITY_DECAY
            vz[i] *= VELOCITY_DECAY
            x[i] += vx[i]
            y[i] += vy[i]
            z[i] += vz[i]
        }
    }

    /** `forceManyBody`: every node pushes every other away, by 1/distance^2. */
    private fun manyBody() {
        for (i in 0 until count) {
            for (j in i + 1 until count) {
                var dx = x[j] - x[i]
                var dy = y[j] - y[i]
                var dz = z[j] - z[i]
                var square = dx * dx + dy * dy + dz * dz
                if (square == 0f) {
                    // d3 jiggles coincident nodes apart with a random nudge; a
                    // fixed one does the same job and keeps the layout stable
                    // across runs.
                    dx = 0.01f + (i % 3) * 0.003f
                    dy = 0.01f + (j % 3) * 0.003f
                    dz = 0.01f
                    square = dx * dx + dy * dy + dz * dz
                }
                // d3's distanceMin: below it the force stops growing, so two
                // facts that end up on top of each other are not fired across
                // the scene.
                if (square < DISTANCE_MIN_SQUARE) {
                    square = sqrt(DISTANCE_MIN_SQUARE * square)
                }
                val push = CHARGE * alpha / square
                vx[i] += dx * push
                vy[i] += dy * push
                vz[i] += dz * push
                vx[j] -= dx * push
                vy[j] -= dy * push
                vz[j] -= dz * push
            }
        }
    }

    /**
     * `forceLink`: one relaxation pass along every line, reading the velocities
     * already accumulated this tick -- which is what makes d3's links behave
     * like a constraint being solved rather than a spring being plucked.
     */
    private fun springs() {
        for (k in linkFrom.indices) {
            val a = linkFrom[k]
            val b = linkTo[k]
            var dx = x[b] + vx[b] - x[a] - vx[a]
            var dy = y[b] + vy[b] - y[a] - vy[a]
            var dz = z[b] + vz[b] - z[a] - vz[a]
            if (dx == 0f && dy == 0f && dz == 0f) {
                dx = 0.01f
                dy = 0.01f
                dz = 0.01f
            }
            val length = sqrt(dx * dx + dy * dy + dz * dz)
            val pull = (length - linkDistance[k]) / length * alpha * linkStrength[k]
            val px = dx * pull
            val py = dy * pull
            val pz = dz * pull
            val bias = linkBias[k]
            vx[b] -= px * bias
            vy[b] -= py * bias
            vz[b] -= pz * bias
            val rest = 1f - bias
            vx[a] += px * rest
            vy[a] += py * rest
            vz[a] += pz * rest
        }
    }

    /** `forceCenter`: slide everything so the centroid sits back at the origin. */
    private fun recentre() {
        if (count == 0) return
        var sx = 0f
        var sy = 0f
        var sz = 0f
        for (i in 0 until count) {
            sx += x[i]
            sy += y[i]
            sz += z[i]
        }
        sx = sx / count * CENTRE_STRENGTH
        sy = sy / count * CENTRE_STRENGTH
        sz = sz / count * CENTRE_STRENGTH
        for (i in 0 until count) {
            x[i] -= sx
            y[i] -= sy
            z[i] -= sz
        }
    }

    /**
     * The current positions, normalised so the cloud always fills the same
     * amount of the screen -- whether it holds four facts or two hundred, and at
     * every step of the settling, so nothing jumps in scale as it arranges.
     */
    fun snapshot(): List<Vec3> {
        if (count == 0) return emptyList()
        var extent = 0.0001f
        for (i in 0 until count) {
            val radius = sqrt(x[i] * x[i] + y[i] * y[i] + z[i] * z[i])
            if (radius > extent) extent = radius
        }
        return List(count) { i -> Vec3(x[i] / extent, y[i] / extent, z[i] / extent) }
    }
}

/** Category colours: violet profile, turquoise projects, pink habits, and so on. */
fun MemoryCategory.tint(): Color = when (this) {
    MemoryCategory.Profile -> Color(0xFF7C5CFF)
    MemoryCategory.Project -> Color(0xFF3EC9A7)
    MemoryCategory.Topic -> Color(0xFFF2C14E)
    MemoryCategory.Habit -> Color(0xFFFF7AA8)
    MemoryCategory.People -> Color(0xFFFF8E72)
    MemoryCategory.Preference -> Color(0xFF5CC8FF)
}

/**
 * The gradient that turns a circle into a sphere.
 *
 * Light from up and to the left, the node's own colour through the middle, a
 * dark edge on the far side. The offset is the whole trick: a centred gradient
 * reads as a flat disc, an offset one reads as a ball.
 *
 * Cached by colour and by half-pixel radius. The key packs both into one long,
 * so a lookup allocates nothing at all.
 */
private fun sphereBrush(cache: HashMap<Long, Brush>, tint: Color, radius: Float): Brush {
    val bucket = (radius * 2f).toInt().coerceAtLeast(1)
    val key = ((tint.toArgb().toLong() and 0xFFFFFFFFL) shl 13) or bucket.toLong()
    // A pinch walks through a lot of radii; this keeps the map bounded without
    // bothering to work out which entry was the least useful.
    if (cache.size > SPHERE_CACHE_MAX) cache.clear()
    return cache.getOrPut(key) {
        val size = bucket / 2f
        Brush.radialGradient(
            0.0f to lerp(tint, Color.White, 0.62f),
            0.30f to lerp(tint, Color.White, 0.16f),
            0.66f to tint,
            1.0f to lerp(tint, Color.Black, 0.52f),
            center = Offset(-size * LIGHT_X, -size * LIGHT_Y),
            radius = size * SPHERE_SPREAD
        )
    }
}

/**
 * The colour one fact is drawn in: its category, in a shade of its own.
 *
 * ### Why not the category alone
 * Six categories give six colours however much is stored, so “food” and
 * “music” -- two separate constellations with nothing to do with each other --
 * come out the same yellow and read as one subject.
 *
 * ### Why not a free palette
 * Colouring purely by file makes every cluster distinct but throws the category
 * away, and the category is what the colour is supposed to mean: violet is the
 * profile, turquoise is a project.
 *
 * Shading keeps both. The hue stays the category's, and the step along it comes
 * from a hash of the file path -- so `/topics/food.md` is the same green
 * tomorrow, on another phone, after a reinstall, and never the same green as
 * `/topics/music.md`.
 */
fun clusterTint(node: MemoryNode): Color =
    node.category.tint().shaded(paletteSlot(node.memoryPath(), SHADE_STEPS), SHADE_STEPS)

/**
 * The same colour, a step lighter or darker, with a little hue drift so
 * neighbouring shades stay apart on a small dot.
 */
private fun Color.shaded(slot: Int, span: Int): Color {
    val hsv = FloatArray(3)
    AndroidColor.colorToHSV(toArgb(), hsv)
    val step = if (span <= 1) 0f else slot.toFloat() / (span - 1) - 0.5f
    hsv[0] = (hsv[0] + step * HUE_SPREAD + 360f) % 360f
    hsv[1] = (hsv[1] * (1f + step * 0.22f)).coerceIn(0.30f, 1f)
    hsv[2] = (hsv[2] * (1f - step * 0.24f)).coerceIn(0.45f, 1f)
    return Color(AndroidColor.HSVToColor(hsv))
}

/** FNV-1a over the path, folded onto [span]. Deterministic everywhere. */
private fun paletteSlot(path: String, span: Int): Int {
    var hash = FNV_OFFSET
    for (char in path) {
        hash = hash xor char.code
        hash *= FNV_PRIME
    }
    val slot = hash % span
    return if (slot < 0) slot + span else slot
}

fun MemoryCategory.labelRes(): Int = when (this) {
    MemoryCategory.Profile -> R.string.memory_category_profile
    MemoryCategory.Project -> R.string.memory_category_project
    MemoryCategory.Topic -> R.string.memory_category_topic
    MemoryCategory.Habit -> R.string.memory_category_habit
    MemoryCategory.People -> R.string.memory_category_people
    MemoryCategory.Preference -> R.string.memory_category_preference
}

/** The scene's own colours: fixed, because the palette is chosen for black. */
private val SpaceDeep = Color(0xFF05040C)
private val EdgeColor = Color(0xFFCFC9F5)
private val MutedNode = Color(0xFF4A4770)
private val LabelColor = Color(0xFFF1EEFB)
private val HintColor = Color(0xB37A76A0)
private val ScrimColor = Color(0x8C05040C)

/**
 * The sky: almost black, with indigo pooled behind the middle of the cloud.
 *
 * A radial brush with no centre and no radius given resolves against whatever
 * it is drawn into, so the same value works for the full-screen box and for the
 * canvas inside it.
 */
private val SceneBackdrop = Brush.radialGradient(
    0.00f to Color(0xFF1B1440),
    0.34f to Color(0xFF130E30),
    0.62f to Color(0xFF0A0819),
    0.88f to Color(0xFF05040C),
    1.00f to Color(0xFF030308)
)

/** FNV-1a's published constants, on 32 bits. */
private const val FNV_OFFSET = -0x7EE3623B
private const val FNV_PRIME = 0x01000193

/** Radians per second at full speed: slow enough to read, fast enough to feel alive. */
private const val SPIN_SPEED = 0.16f
private const val SPIN_SLOW = 0.09f
private const val SLOW_FRAME_MS = 16L

/** How long the frame loop sleeps while nothing in the scene is moving. */
private const val IDLE_POLL_MS = 120L

private const val DRAG_TO_RADIANS = 0.006f
private const val MAX_PITCH = 1.2f
private const val FOCAL = 2.6f
private const val SCENE_FILL = 0.33f
private const val EDGE_MIN_ALPHA = 0.05f
private const val EDGE_ALPHA_RANGE = 0.13f
private const val LINK_FOCUS_GAIN = 3.2f
private const val NODE_MIN_ALPHA = 0.55f
private const val NODE_ALPHA_RANGE = 0.45f
private const val MAX_LINK_BONUS = 6

private const val LARGE_GRAPH = 90

/**
 * d3-force's published defaults, kept as they are so the scene settles into the
 * same shapes as the reference simulation: charge -30, links 30 apart, velocity
 * decay 0.4 (0.6 of the speed survives a tick), alpha falling from 1 to 0.001
 * over 300 ticks.
 */
private const val FULL_TICKS = 300
private const val QUICK_TICKS = 120
private const val ALPHA_START = 1f
private const val ALPHA_MIN = 0.001f
private const val VELOCITY_DECAY = 0.6f
private const val CHARGE = -30f
private const val DISTANCE_MIN_SQUARE = 1f
private const val LINK_DISTANCE = 30f
private const val CENTRE_STRENGTH = 1f
private const val INITIAL_RADIUS = 10f

/**
 * A grouping line is weaker evidence than a stated one, and is drawn and pulled
 * like it: a longer, softer tie that gathers a file into a cluster without
 * collapsing it onto one point.
 */
private const val GROUP_LINK_DISTANCE = 44f
private const val GROUP_LINK_STRENGTH = 0.6f
private const val GROUP_EDGE_FADE = 0.60f
private const val GROUP_EDGE_WIDTH = 0.7f

/** Iterations handed to the screen at a time while the layout settles. */
private const val SETTLE_CHUNK = 6
private const val SETTLE_FRAME_MS = 16L

/** The camera's resting tilt, and the limits of what a pinch may do to the view. */
private const val START_PITCH = 0.22f
private const val MIN_ZOOM = 0.4f
private const val MAX_ZOOM = 5f
private const val PAN_LIMIT = 1.5f

/** How close a tap takes you, and how quickly the camera gets there. */
private const val FOCUS_ZOOM = 1.6f
private const val FOCUS_EASE = 0.18f

/** Below this the two fingers are close enough that the ratio is mostly noise. */
private const val MIN_SPREAD = 12f

/** How much of itself a filtered-out fact keeps. */
private const val DIM_ALPHA = 0.28f

/** Labels: how many at once, how long, and how far back they are still drawn. */
private const val MAX_LABELS = 18
private const val HALO_ALPHA = 0.14f
private const val HALO_SCALE = 2.3f
private const val CORE_ALPHA = 0.38f
private const val CORE_SCALE = 0.30f
/** Where the light sits on a sphere, as a fraction of its radius. */
private const val LIGHT_X = 0.34f
private const val LIGHT_Y = 0.38f
/** How far the light spreads past the sphere before the dark side starts. */
private const val SPHERE_SPREAD = 1.45f
private const val SPHERE_CACHE_MAX = 512
/** Shades per category, and how far the hue may drift between them. */
private const val SHADE_STEPS = 7
private const val HUE_SPREAD = 26f
private const val LABEL_CHARS = 28
private const val LABEL_DEPTH = -0.15f
