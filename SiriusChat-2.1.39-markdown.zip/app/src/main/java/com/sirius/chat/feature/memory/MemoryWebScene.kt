package com.sirius.chat.feature.memory

import android.annotation.SuppressLint
import android.graphics.Color as AndroidColor
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.viewinterop.AndroidView
import com.sirius.chat.domain.model.MemoryEdge
import com.sirius.chat.domain.model.MemoryNode
import com.sirius.chat.domain.model.memoryPath
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.min

/**
 * The memory scene drawn by the reference library, in a WebView.
 *
 * ### What is where
 * `assets/graph/index.html` is the page, `assets/graph/scene.js` is the glue,
 * and `3d-force-graph.min.js` next to them is the renderer. Kotlin owns the
 * data: it hands the whole graph over as JSON and receives taps back over a
 * small bridge. The renderer is loaded from assets when it was vendored there
 * and from its published copy when it was not -- that one script is the only
 * thing this page may fetch, and nothing about the user's memory ever leaves
 * the phone.
 *
 * ### When nothing can be loaded
 * A fresh clone has no vendored library, and a phone with no network cannot
 * reach the published one. The page waits a few seconds, gives up, and reports
 * [onUnavailable]; the screen then draws the same scene with its own `Canvas`
 * renderer. Same data, same colours, same gestures -- one is WebGL, the other
 * is Compose.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MemoryWebScene(
    nodes: List<MemoryNode>,
    edges: List<MemoryEdge>,
    selectedId: String?,
    labels: Boolean,
    spinning: Boolean,
    showLinks: Boolean,
    showTopics: Boolean,
    onSelect: (String?) -> Unit,
    /** There is a scene on screen now, so the Canvas fallback can stand down. */
    onReady: () -> Unit,
    /** No renderer could be reached; the Canvas scene has to take over. */
    onUnavailable: () -> Unit,
    modifier: Modifier = Modifier
) {
    val select by rememberUpdatedState(onSelect)
    val ready by rememberUpdatedState(onReady)
    val unavailable by rememberUpdatedState(onUnavailable)
    val payload = remember(nodes, edges, showLinks, showTopics) {
        scenePayload(nodes, edges, showLinks, showTopics)
    }
    val host = remember { SceneHost() }

    // A WebView outlives the composition unless it is told not to: destroying it
    // here is what stops the renderer process from staying alive behind the app.
    DisposableEffect(host) {
        onDispose {
            host.view?.destroy()
            host.view = null
            host.ready = false
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(AndroidColor.TRANSPARENT)
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                // The page may fetch its own renderer and nothing else. File
                // and content access stay off, so no local file and no content
                // provider is reachable from the page even so.
                settings.blockNetworkLoads = false
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        host.ready = true
                        host.flush(view)
                    }
                }
                val main = Handler(Looper.getMainLooper())
                addJavascriptInterface(
                    // Every hop goes through the main thread: JavaScript calls
                    // arrive on the WebView's own thread, and touching Compose
                    // state from there is a crash waiting for a slow phone.
                    SceneBridge(
                        onTap = { id -> main.post { select(id) } },
                        onReady = { main.post { ready() } },
                        onFailed = { main.post { unavailable() } }
                    ),
                    BRIDGE_NAME
                )
                loadUrl(PAGE_URL)
                host.view = this
            }
        },
        update = { view ->
            host.pending = ScenePush(
                payload = payload,
                selectedId = selectedId,
                labels = labels,
                spinning = spinning
            )
            if (host.ready) host.flush(view)
        }
    )
}

/**
 * What the page is waiting for.
 *
 * The graph itself is only pushed when it actually changed: re-seeding the
 * simulation on every recomposition would restart the layout under the user's
 * finger.
 */
private class ScenePush(
    val payload: String,
    val selectedId: String?,
    val labels: Boolean,
    val spinning: Boolean
) {
    fun options(): String = JSONObject()
        .put("selected", selectedId ?: JSONObject.NULL)
        .put("labels", labels)
        .put("spin", spinning)
        .toString()
}

private class SceneHost {
    var view: WebView? = null
    var ready = false
    var pending: ScenePush? = null
    private var rendered: String? = null

    fun flush(view: WebView) {
        val push = pending ?: return
        if (push.payload != rendered) {
            view.evaluateJavascript("window.siriusRender(${quote(push.payload)})", null)
            rendered = push.payload
        }
        view.evaluateJavascript("window.siriusApply(${quote(push.options())})", null)
    }

    /** JSON handed to JS as a string literal, so no quoting can break the call. */
    private fun quote(json: String): String = JSONObject.quote(json)
}

/**
 * Everything the page is allowed to say to the app: a fact was tapped, the
 * background was tapped, the scene is up, or no renderer could be found.
 */
private class SceneBridge(
    private val onTap: (String?) -> Unit,
    private val onReady: () -> Unit,
    private val onFailed: () -> Unit
) {

    @JavascriptInterface
    fun onNodeTap(id: String) {
        onTap(id)
    }

    @JavascriptInterface
    fun onBackgroundTap() {
        onTap(null)
    }

    @JavascriptInterface
    fun onSceneReady() {
        onReady()
    }

    @JavascriptInterface
    fun onSceneFailed() {
        onFailed()
    }
}

/**
 * The graph as the page wants it: nodes with a colour and a weight, links with
 * the two ends and whether they are a stated link or the tie that holds one
 * memory file together.
 */
private fun scenePayload(
    nodes: List<MemoryNode>,
    edges: List<MemoryEdge>,
    showLinks: Boolean,
    showTopics: Boolean
): String {
    val known = nodes.associateBy { it.id }
    val nodeArray = JSONArray()
    for (node in nodes) {
        nodeArray.put(
            JSONObject()
                .put("id", node.id)
                .put("text", node.content)
                .put("file", node.memoryPath())
                .put("color", hexOf(clusterTint(node)))
                // Bigger with more links, capped: one fact with thirty ties
                // should not become a planet the rest of the cloud orbits.
                .put("size", 1 + min(node.links.size, MAX_WEIGHT))
        )
    }

    val linkArray = JSONArray()
    if (showLinks) {
        for (edge in edges) {
            if (!known.containsKey(edge.from) || !known.containsKey(edge.to)) continue
            linkArray.put(
                JSONObject()
                    .put("source", edge.from)
                    .put("target", edge.to)
                    .put("group", false)
            )
        }
    }
    if (showTopics) {
        // One chain per file rather than every pair: a file with ten facts would
        // otherwise contribute forty-five lines and read as a solid blob.
        for ((_, group) in nodes.groupBy { it.memoryPath() }) {
            for (position in 1 until group.size) {
                linkArray.put(
                    JSONObject()
                        .put("source", group[position - 1].id)
                        .put("target", group[position].id)
                        .put("group", true)
                        .put("color", hexOf(clusterTint(group[position])))
                )
            }
        }
    }

    return JSONObject()
        .put("nodes", nodeArray)
        .put("links", linkArray)
        .toString()
}

private fun hexOf(color: Color): String =
    String.format(Locale.US, "#%06X", 0xFFFFFF and color.toArgb())

private const val PAGE_URL = "file:///android_asset/graph/index.html"
private const val BRIDGE_NAME = "Sirius"
private const val MAX_WEIGHT = 6
