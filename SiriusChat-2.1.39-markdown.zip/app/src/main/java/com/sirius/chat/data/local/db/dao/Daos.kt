package com.sirius.chat.data.local.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import androidx.room.Upsert
import com.sirius.chat.data.local.db.entity.ChatMessageEntity
import com.sirius.chat.data.local.db.entity.ChatSessionEntity
import com.sirius.chat.data.local.db.entity.MessageHitRow
import com.sirius.chat.data.local.db.entity.ProjectEntity
import com.sirius.chat.data.local.db.entity.RecentFileEntity
import com.sirius.chat.data.local.db.entity.SessionWithStats
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {

    @Query("SELECT * FROM projects ORDER BY favorite DESC, lastOpenedAt DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    fun observeById(id: String): Flow<ProjectEntity?>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getById(id: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun delete(id: String)

    @Query("UPDATE projects SET lastOpenedAt = :timestamp WHERE id = :id")
    suspend fun touch(id: String, timestamp: Long)

    @Query("UPDATE projects SET favorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: String, favorite: Boolean)

    @Query("SELECT * FROM recent_files WHERE projectId = :projectId ORDER BY openedAt DESC LIMIT :limit")
    fun observeRecentFiles(projectId: String, limit: Int): Flow<List<RecentFileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecentFile(file: RecentFileEntity)

    @Query("UPDATE recent_files SET caretOffset = :caret, scrollLine = :line WHERE documentId = :documentId")
    suspend fun updateFilePosition(documentId: String, caret: Int, line: Int)

    @Query("DELETE FROM recent_files WHERE projectId = :projectId")
    suspend fun clearRecentFiles(projectId: String)
}

@Dao
interface ChatDao {

    @Query(
        """
        SELECT s.id AS id, s.title AS title, s.projectId AS projectId, s.providerId AS providerId,
               s.model AS model, s.agentMode AS agentMode, s.createdAt AS createdAt,
               s.updatedAt AS updatedAt, s.pinned AS pinned,
               (SELECT COUNT(*) FROM chat_messages m WHERE m.sessionId = s.id) AS messageCount,
               (SELECT m2.content FROM chat_messages m2 WHERE m2.sessionId = s.id
                 ORDER BY m2.createdAt DESC LIMIT 1) AS lastMessagePreview
        FROM chat_sessions s
        ORDER BY s.pinned DESC, s.updatedAt DESC
        """
    )
    fun observeSessions(): Flow<List<SessionWithStats>>

    @Query(
        """
        SELECT s.id AS id, s.title AS title, s.projectId AS projectId, s.providerId AS providerId,
               s.model AS model, s.agentMode AS agentMode, s.createdAt AS createdAt,
               s.updatedAt AS updatedAt, s.pinned AS pinned,
               (SELECT COUNT(*) FROM chat_messages m WHERE m.sessionId = s.id) AS messageCount,
               (SELECT m2.content FROM chat_messages m2 WHERE m2.sessionId = s.id
                 ORDER BY m2.createdAt DESC LIMIT 1) AS lastMessagePreview
        FROM chat_sessions s
        WHERE s.projectId = :projectId
        ORDER BY s.pinned DESC, s.updatedAt DESC
        """
    )
    fun observeSessionsForProject(projectId: String): Flow<List<SessionWithStats>>

    @Query("SELECT * FROM chat_sessions WHERE id = :id")
    suspend fun getSession(id: String): ChatSessionEntity?

    /**
     * Insert-or-update, never insert-or-*replace*.
     *
     * `OnConflictStrategy.REPLACE` compiles to SQLite's `INSERT OR REPLACE`, which
     * resolves a primary-key conflict by **deleting** the existing row and inserting
     * a new one. `chat_messages` points at this table with `ON DELETE CASCADE`, so
     * every rewrite of a session row silently deleted the entire conversation: the
     * chat emptied itself the moment a title was derived or the answer landed and
     * bumped `updatedAt`. `@Upsert` performs an INSERT and falls back to an UPDATE,
     * so the parent row is never deleted and nothing cascades.
     */
    @Upsert
    suspend fun upsertSession(session: ChatSessionEntity)

    @Update
    suspend fun updateSession(session: ChatSessionEntity)

    /**
     * Bumps only the ordering timestamp.
     *
     * A targeted UPDATE instead of a read-modify-write of the whole row: it cannot
     * clobber a draft that was saved in between, and it cannot delete anything.
     */
    @Query("UPDATE chat_sessions SET updatedAt = :timestamp WHERE id = :id")
    suspend fun touchSessionTimestamp(id: String, timestamp: Long)

    /** Metadata-only update; `draft` is deliberately left alone. */
    @Query(
        """
        UPDATE chat_sessions
        SET title = :title,
            projectId = :projectId,
            providerId = :providerId,
            model = :model,
            agentMode = :agentMode,
            pinned = :pinned,
            featureFlags = :featureFlags,
            contextMeter = :contextMeter,
            updatedAt = :updatedAt
        WHERE id = :id
        """
    )
    suspend fun updateSessionMeta(
        id: String,
        title: String,
        projectId: String?,
        providerId: String,
        model: String,
        agentMode: Boolean,
        pinned: Boolean,
        featureFlags: Int,
        contextMeter: Int,
        updatedAt: Long
    )

    @Query("DELETE FROM chat_sessions WHERE id = :id")
    suspend fun deleteSession(id: String)

    @Query("UPDATE chat_sessions SET pinned = :pinned WHERE id = :id")
    suspend fun setPinned(id: String, pinned: Boolean)

    @Query("UPDATE chat_sessions SET draft = :draft WHERE id = :id")
    suspend fun setDraft(id: String, draft: String)

    @Query("SELECT draft FROM chat_sessions WHERE id = :id")
    suspend fun draft(id: String): String?

    @Query("UPDATE chat_sessions SET updatedAt = :timestamp, title = :title WHERE id = :id")
    suspend fun touchSession(id: String, timestamp: Long, title: String)

    // rowid is the tie-breaker, and it is not decoration: createdAt is
    // System.currentTimeMillis(), so a question and a fast answer routinely land in
    // the same millisecond. Ordering by createdAt alone let SQLite return them in
    // either order, and the chat visibly reshuffled itself on the next emission --
    // which is what "the chat looks like it restarted" turned out to be.
    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY createdAt ASC, rowid ASC")
    fun observeMessages(sessionId: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY createdAt ASC, rowid ASC")
    suspend fun messages(sessionId: String): List<ChatMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMessage(message: ChatMessageEntity)

    /**
     * Stores a message and bumps its session in one transaction.
     *
     * Two separate writes meant two invalidations, and the chat list could observe
     * the message before the session it belongs to had moved. One transaction, one
     * emission, and no window where the transcript is half-written.
     */
    @Transaction
    suspend fun insertMessageAndTouch(message: ChatMessageEntity, timestamp: Long) {
        upsertMessage(message)
        touchSessionTimestamp(message.sessionId, timestamp)
    }

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun deleteMessage(id: String)

    @Query("SELECT createdAt FROM chat_messages WHERE id = :id")
    suspend fun messageTimestamp(id: String): Long?

    /** Ids in display order, used to rewind by position instead of by clock. */
    @Query("SELECT id FROM chat_messages WHERE sessionId = :sessionId ORDER BY createdAt ASC, rowid ASC")
    suspend fun messageIdsOrdered(sessionId: String): List<String>

    /**
     * Full-text-ish search across every chat.
     *
     * ### Why two patterns instead of one
     * SQLite's `LIKE` folds case for ASCII only, and its `lower()` does the same,
     * so a Cyrillic query typed in lower case would miss the same word written
     * with a capital -- which is most sentences. Rather than ship an ICU build or
     * a normalised duplicate of every message, the caller passes the needle twice,
     * lower-cased and capitalised, and the two patterns cover how people actually
     * type. Latin text is already handled by `LIKE` itself.
     *
     * The join is on an indexed primary key and the projection is five columns, so
     * this stays cheap enough to run while someone is typing.
     */
    @Query(
        """
        SELECT m.id AS messageId, m.sessionId AS sessionId, s.title AS sessionTitle,
               m.content AS content, m.createdAt AS createdAt
        FROM chat_messages m
        JOIN chat_sessions s ON s.id = m.sessionId
        WHERE m.content LIKE :lowered OR m.content LIKE :capitalised
        ORDER BY m.createdAt DESC
        LIMIT :limit
        """
    )
    suspend fun searchMessages(
        lowered: String,
        capitalised: String,
        limit: Int
    ): List<MessageHitRow>

    @Query("DELETE FROM chat_messages WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<String>)
}

/**
 * Long-term memory.
 *
 * Everything is ordered by `updatedAt` because that is the one ranking the rest
 * of the feature agrees on: the prompt sends the most recently touched facts
 * first, and the cap drops the least recently touched. A fact corrected today is
 * a better description of the user than one recorded in March.
 */
@Dao
interface MemoryDao {

    @Query("SELECT * FROM memory_nodes ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<com.sirius.chat.data.local.db.entity.MemoryEntity>>

    @Query("SELECT * FROM memory_nodes ORDER BY updatedAt DESC LIMIT :limit")
    suspend fun recent(limit: Int): List<com.sirius.chat.data.local.db.entity.MemoryEntity>

    @Query("SELECT COUNT(*) FROM memory_nodes")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(nodes: List<com.sirius.chat.data.local.db.entity.MemoryEntity>)

    @Query("DELETE FROM memory_nodes WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM memory_nodes")
    suspend fun clear()

    /** Drops the [count] least recently touched facts, keeping the table bounded. */
    @Query(
        """
        DELETE FROM memory_nodes
        WHERE id IN (SELECT id FROM memory_nodes ORDER BY updatedAt ASC LIMIT :count)
        """
    )
    suspend fun trimOldest(count: Int)
}

/**
 * The files memory is kept in: their versions and their aliases.
 *
 * Tiny by construction -- one row per file, a handful of files per user -- so it
 * is always read whole and never paged.
 */
@Dao
interface MemoryFileDao {

    @Query("SELECT * FROM memory_files ORDER BY updatedAt DESC")
    suspend fun all(): List<com.sirius.chat.data.local.db.entity.MemoryFileEntity>

    /** The same rows, for the screen that lists them while they change. */
    @Query("SELECT * FROM memory_files ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<com.sirius.chat.data.local.db.entity.MemoryFileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(files: List<com.sirius.chat.data.local.db.entity.MemoryFileEntity>)

    /** Drops one file's row; its lines are deleted separately, by id. */
    @Query("DELETE FROM memory_files WHERE path = :path")
    suspend fun delete(path: String)

    @Query("DELETE FROM memory_files")
    suspend fun clear()
}
