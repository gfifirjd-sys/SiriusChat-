package com.sirius.chat.ai.memory

import com.sirius.chat.ai.context.isSmallTalk
import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.provider.AiProvider
import com.sirius.chat.ai.provider.ProviderFactory
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.GenerationParams
import com.sirius.chat.domain.model.MEMORY_PREFERENCES_PATH
import com.sirius.chat.domain.model.MEMORY_PROFILE_PATH
import com.sirius.chat.domain.model.MemoryCategory
import com.sirius.chat.domain.model.MemoryFile
import com.sirius.chat.domain.model.MemoryWrite
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.model.memoryTopicSlug
import com.sirius.chat.domain.repository.ChatRepository
import com.sirius.chat.domain.repository.MemoryRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Learns durable facts about the user from a finished turn.
 *
 * ### What belongs in memory
 * Facts that stay true between conversations: who the user is, what they are
 * building, how they work, what they have asked for repeatedly. Not what was
 * said -- the transcript already holds that, and it is already in the prompt.
 * Not inferences either: a guess stored as a fact is indistinguishable from
 * something the user actually said the moment it is read back, and it will be
 * read back for months.
 *
 * ### Why it runs after the answer and never blocks it
 * This is a second request to the same endpoint, so doing it inline would add
 * its latency to every reply and its failure to every turn. It runs on the app
 * scope after the answer is stored; every failure path returns quietly and the
 * chat is unaffected. The user never waits for memory.
 *
 * ### Why it writes lines and never files
 * The model is shown every file with its version and its lines, and answers
 * with edits: append one line, or replace one line whose fact has changed. It
 * is never asked to restate a file, because a model asked to restate a file
 * paraphrases it and quietly drops whatever it forgot to repeat. The version it
 * planned against is checked before anything lands, so a file that moved in
 * between is a clean refusal instead of a silent overwrite.
 */
class MemoryExtractor(
    private val chatRepository: ChatRepository,
    private val memoryRepository: MemoryRepository,
    private val providerFactory: ProviderFactory
) {

    /** Last message id already considered, per session. */
    private val processed = ConcurrentHashMap<String, String>()

    /** Applies the edits, and owns the version check they can be refused by. */
    private val writer = MemoryWriter(memoryRepository)

    /**
     * Reads the newest turns of [sessionId] and files whatever is durable.
     *
     * @return how many lines were written, which is zero for almost every turn.
     */
    suspend fun learn(sessionId: String): Int {
        val session = chatRepository.getSession(sessionId) ?: return 0
        val stored = runCatching { chatRepository.messages(sessionId) }.getOrNull().orEmpty()
        // Keyed on the newest *user* message rather than the newest message,
        // because a turn is now looked at twice on purpose: once the moment the
        // user sends it -- so a fact is filed before the answer even starts, as
        // it must be for someone who then closes the app -- and once after the
        // answer lands, in case that first attempt failed. Keying on the last
        // message made the second pass look like a new turn and paid for the
        // same extraction twice.
        val lastId = stored.lastOrNull { it.role == MessageRole.User }?.id ?: return 0
        // The same turn can be reported twice (a retry, a regenerate that lands
        // on identical text); paying for a second extraction of it is waste.
        if (processed[sessionId] == lastId) return 0

        val material = material(stored) ?: return 0

        val provider = providerFactory.create(session.providerId) ?: return 0
        val index = writer.index()

        val raw = withTimeoutOrNull(TIMEOUT_MS) {
            ask(provider, request(session.model, material, index, emptyList()))
        }
        if (raw == null) {
            // Timed out, offline, out of quota, refused by the provider: nothing
            // was decided about this turn, so it is deliberately NOT marked as
            // processed. The next turn's window still holds these messages and
            // gets to try again.
            //
            // Marking it up front, before the request, is what used to lose a
            // fact for good to one dropped reply -- the turn was already
            // "handled" and nothing ever looked at it again.
            val explicit = commanded(stored, index, sessionId)
            return if (explicit > 0) explicit else fallbackWrites(stored, sessionId)
        }
        processed[sessionId] = lastId

        val outcome = writer.apply(parseWrites(raw, index, lenient = false), sessionId)
        if (outcome.applied > 0) return outcome.applied
        if (outcome.conflicts.isEmpty()) {
            // Nothing written and nothing refused: the model read the turn and
            // decided it held no fact. On a turn that plainly did hold one --
            // "мне 16", "люблю мороженое", "мне да" in answer to a question --
            // that call is wrong far more often than it is right, and the user
            // sees memory that only works when they say "запомни". So it is
            // asked once more with the sentence quoted back at it. Only a turn
            // that stated something and still came back empty pays for this.
            val stated = statedLines(stored)
            if (stated.isNotEmpty()) {
                val written = insist(session.model, provider, material, stated, sessionId)
                if (written > 0) return written
            }
            // An explicit "запомни ..." may not end a turn with nothing written,
            // even when the model answered with an empty list.
            val explicit = commanded(stored, index, sessionId)
            if (explicit > 0) return explicit
            // And when even that found nothing: the plainest sentences a person
            // writes about themselves, filed without the model. It has now been
            // asked twice and shown the sentence; a third empty answer is not a
            // judgement about the fact, it is a small model failing at JSON.
            return fallbackWrites(stored, sessionId)
        }

        // Everything was refused, which always means a version that no longer
        // matches: the file moved between the listing being built and the answer
        // coming back, or none was sent. Both are fixed by showing the file as it
        // is now, and this costs a second request only on the rare turn that hit
        // it -- never on the turns that wrote nothing at all.
        return retry(session.model, provider, material, outcome.conflicts, sessionId)
    }

    /**
     * One more attempt, against a freshly read listing.
     *
     * Lenient about a missing version this time, but only for appends: adding a
     * line the user really did say is recoverable -- they can delete it -- while
     * losing the fact to a field the model keeps forgetting is not. A replace
     * still needs its version, because that is the operation that can overwrite
     * something that was already there.
     */
    private suspend fun retry(
        model: String,
        provider: AiProvider,
        material: String,
        conflicts: List<String>,
        sessionId: String
    ): Int {
        val fresh = writer.index()
        val raw = withTimeoutOrNull(TIMEOUT_MS) {
            ask(provider, request(model, material, fresh, conflicts))
        } ?: return 0
        return writer.apply(parseWrites(raw, fresh, lenient = true), sessionId).applied
    }

    /**
     * The recent user sentences that plainly state something durable.
     *
     * An answer is quoted with the question above it. "я да" on its own says
     * nothing and reads to the model like an acknowledgement; under "ты любишь
     * мороженое?" it is a fact about the user, which is exactly the shape
     * that was being dropped.
     */
    private fun statedLines(stored: List<ChatMessage>): List<String> {
        val out = ArrayList<String>()
        for ((position, message) in stored.withIndex()) {
            if (message.role != MessageRole.User) continue
            val quoted = quotable(message.content.trim(), askedBefore(stored, position)) ?: continue
            out += quoted.take(MAX_MESSAGE_CHARS)
        }
        return out.takeLast(STATED_TURNS)
    }

    /** One user message as the nudge should quote it, or null when it states nothing. */
    private fun quotable(text: String, asked: String?): String? {
        if (text.isEmpty()) return null
        if (statesFact(text) || selfAnswered(text)) return text
        if (!answers(text, asked)) return null
        return "you asked: \"" + question(asked).take(MAX_QUESTION_CHARS) +
            "\" -- they answered: \"" + text.take(MAX_ANSWER_QUOTE_CHARS) + "\""
    }

    /** The assistant line immediately before the user message at [index]. */
    private fun askedBefore(messages: List<ChatMessage>, index: Int): String? {
        for (position in index - 1 downTo 0) {
            val message = messages[position]
            if (message.role == MessageRole.Assistant) return message.content
            if (message.role == MessageRole.User) return null
        }
        return null
    }

    /** The last question in a turn, which is the one an answer answers. */
    private fun question(raw: String?): String {
        val flat = raw.orEmpty().replace(Regex("\\s+"), " ").trim()
        val end = flat.lastIndexOf('?')
        if (end < 0) return flat
        val start = flat.lastIndexOfAny(QUESTION_BOUNDARY, end - 1)
        return flat.substring(start + 1, end + 1).trim()
    }

    /** Whether [text] is a yes to a question that was actually asked. */
    private fun answers(text: String, asked: String?): Boolean {
        if (asked.isNullOrBlank() || !asked.contains('?')) return false
        return affirms(text)
    }

    /** "ты любишь мороженое? я да" -- asked and answered in one message. */
    private fun selfAnswered(text: String): Boolean {
        val tail = text.substringAfterLast('?', "")
        return tail.isNotBlank() && affirms(tail)
    }

    /** Whether this is a yes and nothing else. */
    private fun affirms(text: String): Boolean {
        val flat = text.lowercase().trim { !it.isLetterOrDigit() }
        if (flat.isEmpty() || flat.length > MAX_ANSWER_CHARS) return false
        return AFFIRMATIONS.any {
            flat == it || flat.startsWith(it + " ") || flat.startsWith(it + ",")
        }
    }

    /**
     * One more attempt, with the fact quoted back at the model.
     *
     * Deliberately not a heuristic write: the sentence is known, but the file
     * it belongs in, the wording, and whether it is on the never-write list are
     * all still the model's call. This only removes the option of ignoring it.
     */
    private suspend fun insist(
        model: String,
        provider: AiProvider,
        material: String,
        stated: List<String>,
        sessionId: String
    ): Int {
        val fresh = writer.index()
        val nudge = buildString {
            appendLine()
            appendLine("You returned no writes, but the user stated this:")
            stated.forEach { appendLine("- " + it) }
            appendLine(
                "File whatever in it is durable: pick the file by subject, use the " +
                    "versions from the listing, and answer [] only if every line is " +
                    "already stored or is something you must never write."
            )
        }
        val raw = withTimeoutOrNull(TIMEOUT_MS) {
            ask(provider, request(model, material + nudge, fresh, emptyList()))
        } ?: return 0
        return writer.apply(parseWrites(raw, fresh, lenient = true), sessionId).applied
    }

    /** The request this makes: deterministic, small, and never streamed. */
    private fun request(
        model: String,
        material: String,
        index: MemoryIndex,
        conflicts: List<String>
    ): ChatRequest = ChatRequest(
        model = model,
        messages = listOf(AiMessage(AiRole.User, userPrompt(material, index, conflicts))),
        systemPrompt = SYSTEM,
        // Bookkeeping, not a turn in the conversation, and nothing renders it.
        params = GenerationParams(temperature = 0f, topP = 1f, maxTokens = MAX_TOKENS),
        stream = false
    )

    /** Forgets the per-session bookkeeping; used when a chat is deleted. */
    fun forget(sessionId: String) {
        processed.remove(sessionId)
    }

    /**
     * The recent conversation, or null when there is plainly nothing to learn.
     *
     * A turn where the user wrote "ок" carries no fact, and asking the model
     * about it costs exactly as much as asking about a real one. The cheap test
     * runs first and skips the request entirely.
     */
    private fun material(stored: List<ChatMessage>): String? {
        val usable = stored
            .filter { it.role == MessageRole.User || it.role == MessageRole.Assistant }
            .filter { it.content.isNotBlank() }
            .filterNot { it.content.contains(COMPACTION_MARKER) }
            .takeLast(MAX_TURNS)

        if (usable.none { it.role == MessageRole.User }) return null

        val substance = usable.withIndex().any { (position, message) ->
            if (message.role != MessageRole.User) {
                false
            } else {
                val text = message.content.trim()
                (text.length >= MIN_USER_CHARS && !isSmallTalk(text)) ||
                    statesFact(text) ||
                    selfAnswered(text) ||
                    answers(text, askedBefore(usable, position))
            }
        }
        if (!substance) return null

        var budget = MAX_MATERIAL_CHARS
        val chosen = ArrayList<ChatMessage>(usable.size)
        for (message in usable.asReversed()) {
            val body = message.content.trim().take(MAX_MESSAGE_CHARS)
            if (chosen.isNotEmpty() && budget - body.length < 0) break
            budget -= body.length
            chosen += message
        }
        chosen.reverse()

        return chosen.joinToString("\n\n") { message ->
            val label = if (message.role == MessageRole.Assistant) "Assistant: " else "User: "
            label + message.content.trim().take(MAX_MESSAGE_CHARS)
        }.ifBlank { null }
    }

    /**
     * Whether the user is stating something about themselves.
     *
     * The length-and-not-small-talk test on its own silently dropped the facts
     * that matter most, because they are the shortest things anyone writes:
     * "мне 16", "люблю Anthropic", "привет, тебе нравится мороженое? мне да".
     * Each of those is under a dozen characters of actual content or starts
     * with a greeting, and each is exactly what memory is for.
     *
     * Matching here only buys the turn one extraction request. What is written,
     * or whether anything is, remains the model's decision.
     */
    private fun statesFact(text: String): Boolean {
        val lower = text.lowercase()
        if (REMEMBER.any { lower.contains(it) }) return true
        if (FACT_MARKERS.any { lower.contains(it) }) return true
        // "мне 16" -- an age is a fact, and it is three characters long.
        return AGE_PREFIXES.any { prefix ->
            val at = lower.indexOf(prefix)
            at >= 0 && lower.getOrNull(at + prefix.length)?.isDigit() == true
        }
    }

    /**
     * The one write this can make without the model.
     *
     * "Запомни, что ..." is the single case where writing nothing is always
     * wrong: the user gave an explicit instruction, and a side request that
     * timed out is not their problem. Everything else is left to the model --
     * heuristics guessing at what is durable would fill the graph with noise.
     *
     * It goes to the profile, the one file a fact about the user is never
     * misfiled in; the model moves it to a topic later if it belongs there.
     */
    private suspend fun commanded(
        stored: List<ChatMessage>,
        index: MemoryIndex,
        sessionId: String
    ): Int {
        val asked = stored.lastOrNull { it.role == MessageRole.User }?.content ?: return 0
        val line = commandedLine(asked) ?: return 0
        val write = MemoryWrite.Append(
            path = MEMORY_PROFILE_PATH,
            ifVersion = index.version(MEMORY_PROFILE_PATH),
            content = line,
            category = MemoryCategory.Profile
        )
        // The writer drops a line that is already there, so repeating the
        // instruction cannot stack the same fact twice.
        return runCatching { writer.apply(listOf(write), sessionId).applied }.getOrDefault(0)
    }

    /** What the user asked to be remembered, or null when they did not ask. */
    private fun commandedLine(text: String): String? {
        val flat = text.trim().replace(Regex("\\s+"), " ")
        val lower = flat.lowercase()
        val opener = REMEMBER.firstOrNull { lower.startsWith(it) } ?: return null
        val rest = flat.drop(opener.length).trim { !it.isLetterOrDigit() }
        if (rest.length < MIN_FACT_CHARS) return null
        return rest.take(MAX_FACT_CHARS)
    }

    /**
     * The plainest facts in the recent turns, filed without the model.
     *
     * ### Why a heuristic is allowed at all
     * Everywhere else the model decides what is durable, because patterns
     * guessing at it fill the graph with noise. This runs only after the model
     * has been asked, been asked again with the sentence quoted back at it, and
     * still written nothing -- the case that reads to the user as "I told it I
     * like ice cream and it forgot". At that point an empty answer is not a
     * judgement about the fact, it is a small model failing at JSON, and the
     * fact should not be the thing that pays for it.
     *
     * ### What keeps it safe
     * Only the shapes below are recognised, and every line still goes through
     * [MemoryWriter.apply], which drops anything on the never-store list before
     * it reaches the graph. One file per turn at most, so a misfire is one line
     * the user can delete rather than a page of guesses.
     */
    private suspend fun fallbackWrites(stored: List<ChatMessage>, sessionId: String): Int {
        val index = runCatching { writer.index() }.getOrNull() ?: return 0
        val writes = ArrayList<MemoryWrite>()
        val recent = stored.withIndex()
            .filter { it.value.role == MessageRole.User }
            .takeLast(STATED_TURNS)

        for ((position, message) in recent) {
            for (fact in plainFacts(message.content, askedBefore(stored, position))) {
                if (writes.size >= MAX_FALLBACK_FACTS) break
                val path = index.resolve(fact.path, fact.aliases)
                if (path.isEmpty()) continue
                // One write per file per turn: a second edit to the same file in
                // the same batch would be planned against a version the first
                // one has already moved, and be refused as a conflict.
                if (writes.any { it.path == path }) continue
                writes += MemoryWrite.Append(
                    path = path,
                    ifVersion = index.version(path),
                    content = fact.line,
                    category = fact.category,
                    aliases = fact.aliases
                )
            }
        }
        if (writes.isEmpty()) return 0
        return runCatching { writer.apply(writes, sessionId).applied }.getOrDefault(0)
    }

    /** A fact plain enough to recognise without the model, and where it goes. */
    private data class PlainFact(
        val path: String,
        val line: String,
        val category: MemoryCategory,
        val aliases: List<String> = emptyList()
    )

    /** Everything one message states plainly about the person writing it. */
    private fun plainFacts(raw: String, asked: String?): List<PlainFact> {
        val flat = raw.replace(Regex("\\s+"), " ").trim()
        if (flat.isEmpty()) return emptyList()
        val out = ArrayList<PlainFact>()

        named(NAME_RU.find(flat))?.let {
            out += PlainFact(MEMORY_PROFILE_PATH, "зовут " + it, MemoryCategory.Profile)
        }
        named(NAME_EN.find(flat))?.let {
            out += PlainFact(MEMORY_PROFILE_PATH, "name: " + it, MemoryCategory.Profile)
        }

        for (match in TASTE_RU.findAll(flat)) {
            val verb = TASTE_VERBS_RU[match.groupValues[1].lowercase()] ?: continue
            val about = phrase(match.groupValues[2]) ?: continue
            out += taste(verb + " " + about, about)
        }
        for (match in TASTE_EN.findAll(flat)) {
            val verb = TASTE_VERBS_EN[match.groupValues[1].lowercase()] ?: continue
            val about = phrase(match.groupValues[2]) ?: continue
            out += taste(verb + " " + about, about)
        }

        // A question the user asked and answered in the same breath -- "ты
        // любишь мороженое? я да" -- and a yes to a question that was put to
        // them. Both are facts about the user; neither says so in first person,
        // which is why every pattern before this one misses them.
        val source = when {
            selfAnswered(flat) -> flat
            answers(flat, asked) -> asked
            else -> null
        }
        askedAbout(source)?.let { out += it }

        return out.distinctBy { it.line.lowercase() }.take(MAX_FALLBACK_FACTS)
    }

    /** What a "do you like X?" question was about, as a line about the user. */
    private fun askedAbout(raw: String?): PlainFact? {
        if (raw == null) return null
        val match = ASKED_TASTE.find(question(raw)) ?: return null
        val about = phrase(match.groupValues[2]) ?: return null
        // The line follows the language the question was asked in.
        val english = match.groupValues[1].any { it in 'a'..'z' || it in 'A'..'Z' }
        return taste(if (english) "likes " + about else "любит " + about, about)
    }

    /** Where a taste belongs: the food file when it plainly is one. */
    private fun taste(line: String, subject: String): PlainFact {
        val lower = subject.lowercase()
        return if (FOOD_WORDS.any { lower.contains(it) }) {
            PlainFact(FOOD_PATH, line, MemoryCategory.Topic, listOf("food", "еда"))
        } else {
            PlainFact(TASTES_PATH, line, MemoryCategory.Topic, listOf("tastes", "вкусы"))
        }
    }

    /** A captured name, tidied, or null when it is not one. */
    private fun named(match: MatchResult?): String? {
        val name = match?.groupValues?.getOrNull(1)?.trim()?.trim(*TRAILING) ?: return null
        return name.takeIf { it.length in MIN_SUBJECT_CHARS..MAX_NAME_CHARS }
    }

    /** A captured subject, tidied, or null when there is not enough of it. */
    private fun phrase(raw: String): String? {
        val cleaned = raw.trim().trim(*TRAILING)
        return cleaned.takeIf { it.length in MIN_SUBJECT_CHARS..MAX_SUBJECT_CHARS }
    }

    /**
     * The listing the model files against, plus the conversation.
     *
     * ### Why the contents are in the listing
     * A real memory tool reads the file it is about to edit. This runs as a
     * single request, so the read happens up front: every file, its version, its
     * aliases and every line in it. That is what lets the model see that a fact
     * is already stored, or that a line it is about to duplicate should be
     * replaced instead -- and the version beside each file is what lets the write
     * be refused if the file moved underneath it.
     */
    private fun userPrompt(
        material: String,
        index: MemoryIndex,
        conflicts: List<String>
    ): String = buildString {
        appendLine("memory_listing -- every file, its version, its aliases and its lines.")
        appendLine("This is the read; plan your edits against it.")
        if (index.isEmpty) {
            appendLine("(empty; nothing has been filed yet)")
        } else {
            var budget = MAX_EXISTING_SHOWN
            val files = index.files.sortedByDescending { file ->
                file.lines.maxOfOrNull { it.updatedAt } ?: 0L
            }
            for (file in files) {
                if (budget <= 0) break
                append(file.path).append("  v").append(file.version)
                if (file.aliases.isNotEmpty()) {
                    append("  aliases: ").append(file.aliases.joinToString(", "))
                }
                appendLine()
                if (file.lines.isEmpty()) {
                    appendLine("  (empty)")
                    continue
                }
                for (node in file.lines) {
                    if (budget <= 0) break
                    budget--
                    appendLine(
                        "  " + node.id + " | " +
                            node.content.trim().take(MAX_FACT_CHARS) + " [stated]"
                    )
                }
            }
        }
        if (conflicts.isNotEmpty()) {
            appendLine()
            appendLine("Your previous answer was refused:")
            conflicts.take(MAX_CONFLICTS_SHOWN).forEach { appendLine("- " + it) }
            appendLine("Send the same edits again, with the versions exactly as listed above.")
        }
        appendLine()
        appendLine("Conversation:")
        appendLine(material)
        appendLine()
        appendLine("Return the JSON array of write operations now.")
    }

    /** Collects one non-streaming answer, or null for anything that went wrong. */
    private suspend fun ask(provider: AiProvider, request: ChatRequest): String? {
        val text = StringBuilder()
        var failed = false
        try {
            provider.chat(request).collect { event ->
                when (event) {
                    is ChatStreamEvent.Delta -> text.append(event.text)
                    is ChatStreamEvent.Completed ->
                        if (event.fullText.isNotBlank()) {
                            text.setLength(0)
                            text.append(event.fullText)
                        }
                    is ChatStreamEvent.Failure -> failed = true
                    // A start marker, thinking text and keep-alives carry no
                    // answer for this one-shot helper to collect.
                    ChatStreamEvent.Started,
                    ChatStreamEvent.Heartbeat,
                    is ChatStreamEvent.Reasoning -> Unit
                }
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            return null
        }
        return if (failed) null else text.toString().ifBlank { null }
    }

    /**
     * The write operations in a model answer, ignoring everything malformed.
     *
     * Deliberately forgiving about the envelope and strict about the edit: a
     * model wraps JSON in a fence, calls the field `path` instead of `file`, or
     * answers with one object instead of an array, and none of those are reasons
     * to lose a fact. A blank line, a name that cannot be a file name, or a
     * replace with nothing to match *is* a reason to drop that entry.
     *
     * Every path is resolved against the listing rather than trusted, so a file
     * named in the user's language today lands in the one opened for the same
     * subject yesterday instead of beside it.
     */
    private fun parseWrites(
        raw: String,
        index: MemoryIndex,
        lenient: Boolean
    ): List<MemoryWrite> {
        val body = envelope(raw) ?: return emptyList()
        val element = runCatching { json.parseToJsonElement(body) }.getOrNull() ?: return emptyList()
        val array: JsonArray = runCatching {
            when (element) {
                is JsonArray -> element
                is JsonObject ->
                    element["writes"]?.jsonArray
                        ?: element["memories"]?.jsonArray
                        ?: JsonArray(listOf(element))
                else -> return emptyList()
            }
        }.getOrNull() ?: return emptyList()

        val known = index.files.flatMap { it.lines }.mapTo(HashSet()) { it.id }
        val out = ArrayList<MemoryWrite>()

        for (entry in array) {
            if (out.size >= MAX_PER_TURN) break
            val obj = (entry as? JsonObject) ?: continue
            val category = MemoryCategory.ofWire(obj.text("category"))
            val aliases = obj.list("aliases")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .take(MAX_ALIASES_SENT)
            val path = index.resolve(
                obj.text("file") ?: obj.text("path") ?: implied(obj, category),
                aliases
            )
            if (path.isEmpty()) continue

            val declared = version(obj["if_version"] ?: obj["ifVersion"])
            val quoted = (obj.text("old") ?: obj.text("old_str"))?.trim().orEmpty()
            val operation = obj.text("op")?.trim()?.lowercase(Locale.ROOT).orEmpty()

            if (operation.startsWith("replace") || (operation.isEmpty() && quoted.isNotEmpty())) {
                val line = (obj.text("new") ?: obj.text("new_str") ?: obj.text("content"))
                    ?.trim()
                    .orEmpty()
                if (quoted.isEmpty() || !usable(line)) continue
                out += MemoryWrite.Replace(path, declared, quoted, line)
                continue
            }

            if (operation.startsWith("rewrite")) {
                val rows = obj.list("lines")
                    .ifEmpty { obj.text("content").orEmpty().split('\n') }
                    .map { it.trim().trimStart('-', '*', ' ') }
                    .filter { usable(it) }
                    .distinct()
                    .take(MAX_PER_TURN)
                if (rows.isEmpty()) continue
                out += MemoryWrite.Rewrite(path, declared, rows, category)
                continue
            }

            val line = (obj.text("content") ?: obj.text("line") ?: obj.text("new"))?.trim().orEmpty()
            if (!usable(line)) continue
            val links = obj.list("links")
                .map { it.trim() }
                .filter { it.isNotEmpty() && it in known }
                .distinct()
                .take(MAX_LINKS)
            val against = if (declared == MemoryWrite.UNVERSIONED && lenient) {
                index.version(path)
            } else {
                declared
            }
            val title = (obj.text("title") ?: obj.text("name"))?.trim().orEmpty()
            val summary = (obj.text("description") ?: obj.text("summary"))?.trim().orEmpty()
            out += MemoryWrite.Append(
                path, against, line, category, aliases, links, title, summary
            )
        }
        return out
    }

    /** Where a fact belongs when the model named a category but never a file. */
    private fun implied(obj: JsonObject, category: MemoryCategory): String {
        val slug = memoryTopicSlug(obj.text("topic"))
        return when {
            category == MemoryCategory.Profile -> MEMORY_PROFILE_PATH
            category == MemoryCategory.Preference -> MEMORY_PREFERENCES_PATH
            category == MemoryCategory.Project -> "/areas/" + slug.ifEmpty { "projects" } + ".md"
            category == MemoryCategory.People -> "/people/" + slug.ifEmpty { "people" } + ".md"
            slug.isNotEmpty() -> "/topics/" + slug + ".md"
            else -> "/topics/" + category.wireName + ".md"
        }
    }

    /** Long enough to mean something, short enough to still be one fact. */
    private fun usable(line: String): Boolean = line.length in MIN_FACT_CHARS..MAX_FACT_CHARS

    /** The JSON inside whatever the model wrapped it in, or null. */
    private fun envelope(raw: String): String? {
        val text = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        if (text.equals("NONE", ignoreCase = true) || text.isEmpty()) return null
        val start = text.indexOfFirst { it == '[' || it == '{' }
        val end = text.indexOfLast { it == ']' || it == '}' }
        if (start < 0 || end <= start) return null
        return text.substring(start, end + 1)
    }

    private fun JsonObject.text(key: String): String? =
        (this[key] as? JsonPrimitive)?.contentOrNullSafe()

    private fun JsonPrimitive.contentOrNullSafe(): String? =
        if (this.content.equals("null", ignoreCase = true)) null else this.content

    private fun JsonObject.list(key: String): List<String> =
        this[key]?.let { value ->
            runCatching {
                value.jsonArray.mapNotNull { (it as? JsonPrimitive)?.contentOrNullSafe() }
            }.getOrNull()
        }.orEmpty()

    /**
     * The version an edit was planned against.
     *
     * `"new"` is a real answer and means the file must not exist yet. A missing
     * field is not the same thing: it stays [MemoryWrite.UNVERSIONED], which no
     * file is ever at, so the edit is refused instead of applied blind.
     */
    private fun version(element: JsonElement?): Int {
        val text = (element as? JsonPrimitive)?.contentOrNullSafe()
            ?.trim()
            ?.lowercase(Locale.ROOT)
            .orEmpty()
        return when {
            text.isEmpty() -> MemoryWrite.UNVERSIONED
            text == "new" || text == "none" || text == "0" -> MemoryFile.NEW_FILE
            else -> text.toIntOrNull()?.takeIf { it >= 0 } ?: MemoryWrite.UNVERSIONED
        }
    }

    private companion object {
        private val json = Json { ignoreUnknownKeys = true; isLenient = true }

        private const val SYSTEM =
            "You maintain long-term memory about one user: a small set of files, each " +
                "holding a few short lines. You are given the end of a conversation and " +
                "memory_listing -- every file, its version, its aliases and every line " +
                "in it. That listing is the read; plan your edits against it.\n" +
                "Reply with a JSON array of write operations and nothing else. [] is a " +
                "normal answer.\n" +
                "Append a line: {\"op\": \"append\", \"file\": \"/topics/food.md\", " +
                "\"if_version\": 3, \"content\": \"likes ice cream\", \"category\": " +
                "\"topic\", \"aliases\": [\"food\"], \"links\": [\"id\"]}\n" +
                "Create a file: the same, with \"if_version\": \"new\", and name it -- " +
                "{\"op\": \"append\", \"file\": \"/topics/food.md\", \"if_version\": " +
                "\"new\", \"title\": \"Food preferences\", \"description\": \"what the " +
                "user likes to eat\", \"content\": \"likes ice cream\", \"category\": " +
                "\"topic\", \"aliases\": [\"food\"]}. title is the heading a person " +
                "reads above the lines and description is one short line under it; " +
                "both are set once, when the file is opened.\n" +
                "Fix a line that changed: {\"op\": \"replace\", \"file\": " +
                "\"/topics/drinks.md\", \"if_version\": 2, \"old\": \"likes coffee\", " +
                "\"new\": \"switched to tea (was: likes coffee)\"}\n" +
                "Rewrite a file whole, only when several lines change together or the " +
                "file has grown into the wrong shape: {\"op\": \"rewrite\", \"file\": " +
                "\"/areas/sirius.md\", \"if_version\": 5, \"lines\": [\"one\", " +
                "\"another\"]}. It replaces every line, so it has to carry everything " +
                "still worth keeping: dropping a line the user did not ask you to " +
                "forget is a deletion, and deletions are theirs to ask for.\n" +
                "For every fact you hear, in this order:\n" +
                "1. Domain first. Decide what the fact is about -- food, work, a project, " +
                "a person -- and that decides which file to open. Not the file you were " +
                "last looking at: a fact about food goes to /topics/food.md in the middle " +
                "of a conversation about a project.\n" +
                "2. Check the listing. Is there already a file for this subject, by path " +
                "or by one of its aliases? Yes -> use that exact path and the version " +
                "shown beside it. No -> open one with \"if_version\": \"new\" and give it " +
                "one to three aliases, including the user's own word for the subject.\n" +
                "3. Check the lines. The fact is already there -> write nothing. It is " +
                "new -> append one line. It is there but has changed (\"likes coffee\" " +
                "becoming \"switched to tea\") -> replace that exact line, quoting it in " +
                "\"old\", so it is corrected in place and never stored twice.\n" +
                "4. One fact, one line, one file. Never restate a file, never repeat a " +
                "line that is already in it, never write the same fact into two files, " +
                "and never move a fact from one file to another.\n" +
                "5. The version is mandatory. if_version is the v shown beside the file " +
                "in the listing, or \"new\" for a file that does not exist yet. A missing " +
                "or stale version is refused and the fact is not stored.\n" +
                "Where things live: /profile.md is who the user is -- name, city, job, " +
                "languages: what is still true in three months. /areas/<name>.md is a " +
                "project they are working on -- its status, decisions and deadlines. " +
                "/people/<name>.md is one person in their life -- who they are and how " +
                "they relate to a project. /preferences.md is how you should answer " +
                "them -- format, length, tone, what to skip -- and nothing else. " +
                "/topics/<name>.md is everything else: tastes, habits, hobbies, " +
                "schedules, subjects they keep returning to. A taste is never a " +
                "preference.\n" +
                "A fact is anything durable the user says about themselves: \"I love " +
                "ice cream\", \"I work in Kotlin\", \"call me Spy\", \"I am 16\", \"I " +
                "like Anthropic models\". It counts exactly the same when it answers " +
                "something you asked -- you: \"do you like ice cream?\", them: \"I do\" " +
                "-> append \"likes ice cream\" to /topics/food.md -- and when it arrives " +
                "inside a greeting, a joke or a task.\n" +
                "Never wait to be told. \"Remember this\" is one way a fact arrives, not " +
                "the condition for storing it: a turn where the user stated something " +
                "durable about themselves and you returned [] is a mistake, and so is " +
                "answering that you have no memory. A question, a request, a task for " +
                "you, or anything you said yourself is not a fact. Write it the moment " +
                "it is stated, once.\n" +
                "When the user settles something, file the decision and not the options " +
                "that were weighed. When they tell you how to answer -- shorter, this " +
                "language, stop explaining -- that goes to /preferences.md. One mention " +
                "is enough; never wait for it to be repeated. If you are about to ask " +
                "them something, write what they have already said first -- they may " +
                "not come back to answer.\n" +
                "Never write, however plainly the user says it: health, diagnoses, " +
                "mental state and therapy; race, religion, sexual orientation, gender " +
                "identity, immigration status; political views; exact sums of money, " +
                "document and card numbers; where they are at this moment (a home city " +
                "is fine, \"I am in a cafe on X street\" is not); their age if they are " +
                "under 18; violence, self-harm, criminal history; any psychological " +
                "label you or another model put on them. A mixed message keeps only its " +
                "allowed half -- the other half is dropped, never softened into a " +
                "neutral wording. Nor your own advice, code, summaries or search " +
                "results, nor drafts the user did not choose, nor what you plan to ask " +
                "next, nor anything that expires within weeks -- today's plan, the " +
                "weather, the bug being fixed right now.\n" +
                "A fact dropped in passing inside a question is still a fact: file it, " +
                "separately from whatever the question was about. Read before you " +
                "write: the listing above is the file, and an edit that ignores it " +
                "overwrites blind. When a stored line stops being true, replace it and " +
                "carry the old value in the new line -- \"drinks tea (was: coffee)\". " +
                "Deleting is the user's to ask for; never drop a line to tidy up.\n" +
                "If edits came back refused, re-read the listing and send them again " +
                "against the versions as they now are -- never widen an edit to force it " +
                "through. If one line was refused on content, keep the rest and never " +
                "try that line again in different words.\n" +
                "Line style: short, in the user's own words and language, and only what " +
                "was actually said -- \"likes ice cream\", never \"probably has a sweet " +
                "tooth\". category is profile|project|topic|habit|people|preference. Add " +
                "links only when one fact explains another or both concern the same " +
                "project or person; facts sharing a file are already tied together. Write " +
                "silently: the array is the entire answer, and nothing announces it."

        /** Enough turns to catch a fact stated before the last message. */
        private const val MAX_TURNS = 6

        private const val MAX_MATERIAL_CHARS = 3_000
        private const val MAX_MESSAGE_CHARS = 700

        /**
         * Shorter than this, a message is an acknowledgement, not a fact.
         *
         * It was 12, which quietly threw away the shortest and most durable
         * things anyone says. The length test is also no longer the only way
         * in: [statesFact] admits a short first-person statement whatever its
         * length.
         */
        private const val MIN_USER_CHARS = 6

        /**
         * Explicit instructions to store something.
         *
         * These always earn an extraction request, and if that request fails
         * they are the only thing written without the model.
         */
        private val REMEMBER = listOf(
            "запомни", "запиши", "не забудь", "remember that", "remember this",
            "remember", "note that", "keep in mind"
        )

        /**
         * First-person statements: short, casual, and exactly what memory is for.
         *
         * Plain substrings on the lowercased message on purpose. This decides
         * whether one request is worth making, not what gets stored, so a loose
         * match costs a request and a miss costs a fact.
         */
        private val FACT_MARKERS = listOf(
            // Answers to a question you asked: "тебе нравится мороженое?" --
            // "мне да". Short, indirect, and exactly the kind of fact that was
            // being dropped.
            "мне да", "мне тоже", "я тоже", "нравится", "обожаю", "ненавижу",
            "зови меня", "мой ник", "я пользуюсь", "i do", "me too",
            "my nickname",
            "меня зовут", "мне нравится", "мне нравятся", "я люблю",
            "люблю ", "я обожаю", "я ненавижу", "я не люблю", "я предпочитаю",
            "я работаю", "я учусь", "я живу", "я использую", "я пишу на",
            "мой любимый", "моя любимая", "мой день рождения", "я из ",
            "my name is", "call me", "i like", "i love", "i hate", "i prefer",
            "i work", "i study", "i live", "i use", "i'm from", "i am from"
        )

        /** Prefixes that make a bare number an age rather than a quantity. */
        private val AGE_PREFIXES = listOf("мне ", "мне уже ", "i am ", "i'm ")

        private const val MAX_TOKENS = 500
        // Raised from thirty seconds: the model that writes memories is whichever
        // one the user picked, and a reasoning model spends longer than that
        // thinking before its first character.
        private const val TIMEOUT_MS = 120_000L

        /** The graph is a profile, not a log; a turn adds a few facts at most. */
        private const val MAX_PER_TURN = 6

        /** How many recent user messages the second attempt quotes back. */
        private const val STATED_TURNS = 3

        /** Ways of saying yes, and nothing else. */
        private val AFFIRMATIONS = listOf(
            "да", "ага", "угу", "конечно", "верно", "точно", "именно",
            "я да", "мне да", "и я", "и мне", "я тоже", "мне тоже", "тоже",
            "yes", "yeah", "yep", "sure", "i do", "me too", "same", "definitely"
        )

        /** Longer than this is an answer with content, not a bare yes. */
        private const val MAX_ANSWER_CHARS = 24

        /** How much of the question and the answer the nudge quotes. */
        private const val MAX_QUESTION_CHARS = 160
        private const val MAX_ANSWER_QUOTE_CHARS = 120

        /** Where a question ends when looking backwards for its start. */
        private val QUESTION_BOUNDARY = charArrayOf('.', '!', '?', '\n')

        /** At most this many lines are written without the model in one turn. */
        private const val MAX_FALLBACK_FACTS = 2

        private const val MIN_SUBJECT_CHARS = 3
        private const val MAX_SUBJECT_CHARS = 60
        private const val MAX_NAME_CHARS = 40

        /** Punctuation and quoting left over on the end of a captured phrase. */
        private val TRAILING = charArrayOf(
            ' ', '.', ',', '!', '?', ';', ':', '-', '\u2014', '\u2013',
            '"', '\'', '\u00ab', '\u00bb', ')', '('
        )

        /** The two files the fallback is allowed to open. */
        private const val FOOD_PATH = "/topics/food.md"
        private const val TASTES_PATH = "/topics/tastes.md"

        /**
         * Enough of a lexicon to put "любит мороженое" in the food file.
         *
         * Deliberately small: this only chooses between two files when the model
         * is not answering, and the model files properly the rest of the time.
         * A subject that is not on the list goes to tastes, which is true of it
         * either way.
         */
        private val FOOD_WORDS = listOf(
            "морожен", "еда", "еду", "пицц", "суши", "борщ", "шоколад", "кофе",
            "чай", "мясо", "рыба", "суп", "салат", "фрукт", "овощ", "выпечк",
            "пельмен", "бургер", "паста", "сыр", "ice cream", "food", "pizza",
            "sushi", "coffee", "tea", "chocolate", "burger", "pasta", "cheese"
        )

        /** "меня зовут X", "my name is X". */
        private val NAME_RU = Regex(
            "(?:меня зовут|зови меня|моё имя|мое имя)\\s+([^.,!?;\\n]{2,40})",
            RegexOption.IGNORE_CASE
        )
        private val NAME_EN = Regex(
            "\\b(?:my name is|call me)\\s+([^.,!?;\\n]{2,40})",
            RegexOption.IGNORE_CASE
        )

        /** First-person tastes, which is most of what anyone states outright. */
        private val TASTE_RU = Regex(
            "(?:^|[\\s,;:(])(?:я\\s+)?(не люблю|люблю|обожаю|ненавижу|предпочитаю)" +
                "\\s+([^.,!?;\\n]{2,60})",
            RegexOption.IGNORE_CASE
        )
        private val TASTE_EN = Regex(
            "\\bi (?:really )?(love|like|hate|prefer)\\s+([^.,!?;\\n]{2,60})",
            RegexOption.IGNORE_CASE
        )

        /** The question a bare "yes" turns into a fact. */
        private val ASKED_TASTE = Regex(
            "(ты любишь|вы любите|тебе нравится|тебе нравятся|вам нравится|" +
                "do you like|do you love|do you prefer)\\s+([^.,!?;\\n]{2,60})",
            RegexOption.IGNORE_CASE
        )

        /** Said in the first person, written in the third. */
        private val TASTE_VERBS_RU = mapOf(
            "люблю" to "любит",
            "не люблю" to "не любит",
            "обожаю" to "обожает",
            "ненавижу" to "ненавидит",
            "предпочитаю" to "предпочитает"
        )
        private val TASTE_VERBS_EN = mapOf(
            "love" to "loves",
            "like" to "likes",
            "hate" to "hates",
            "prefer" to "prefers"
        )

        private const val MAX_EXISTING_SHOWN = 60
        private const val MAX_LINKS = 4
        private const val MIN_FACT_CHARS = 4
        private const val MAX_FACT_CHARS = 200

        /** Enough refusals to explain the problem without becoming the prompt. */
        private const val MAX_CONFLICTS_SHOWN = 4

        /** The subject in the user's language, in English, and one synonym. */
        private const val MAX_ALIASES_SENT = 3

        private const val COMPACTION_MARKER = "[sirius:context-compacted]"
    }
}
