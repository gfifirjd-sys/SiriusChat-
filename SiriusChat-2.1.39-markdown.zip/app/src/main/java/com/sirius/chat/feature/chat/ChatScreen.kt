package com.sirius.chat.feature.chat

import com.sirius.chat.domain.model.PowerMode
import com.sirius.chat.feature.chat.components.PowerModeSheet

import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.animation.AnimatedVisibility
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import com.sirius.chat.domain.model.ChatMessage
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.CompareArrows
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.ai.agent.AgentQuestion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.MorphMenuItem
import com.sirius.chat.core.designsystem.components.SiriusOrb
import com.sirius.chat.core.designsystem.components.SheetOptionRow
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.feature.chat.components.ChatSettingsPanel
import com.sirius.chat.core.designsystem.components.SiriusTypingDots
import com.sirius.chat.core.designsystem.components.labelled
import com.sirius.chat.core.designsystem.effects.beamBorder
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.designsystem.pressable
import com.sirius.chat.core.designsystem.siriusFadeThrough
import com.sirius.chat.core.designsystem.siriusRise
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.domain.model.ToolRun
import com.sirius.chat.feature.chat.components.AttachmentSheet
import com.sirius.chat.feature.chat.components.ChatInputBar
import com.sirius.chat.feature.chat.components.MarkdownText
import com.sirius.chat.feature.chat.components.MessageBubble
import com.sirius.chat.feature.chat.components.ModelPickerSheet
import com.sirius.chat.feature.chat.components.MessageSources
import com.sirius.chat.feature.chat.components.sourcesFrom
import com.sirius.chat.feature.chat.components.ToolRunList
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    sessionId: String,
    onBack: () -> Unit,
    onOpenReview: () -> Unit,
    onOpenProviders: () -> Unit,
    onOpenChat: (String) -> Unit,
    /** Opens the memory graph, from the eye beside this chat's memory switch. */
    onOpenMemory: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: ChatViewModel = siriusViewModel(key = "chat-$sessionId") {
        ChatViewModel(it, sessionId)
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val attachmentResults by viewModel.attachmentResults.collectAsStateWithLifecycle()
    val attachmentQuery by viewModel.attachmentQuery.collectAsStateWithLifecycle()
    val codeFontSize by viewModel.codeFontSize.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var showModelPicker by remember { mutableStateOf(false) }

    /** Whether the answer-power sheet is showing. */
    var showPowerPicker by remember { mutableStateOf(false) }

    /** The answer being branched, while its target model is being chosen. */
    var forkMessageId by remember { mutableStateOf<String?>(null) }
    var showAttachments by remember { mutableStateOf(false) }
    var showAttachMenu by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<ChatMessage?>(null) }

    // Multi-select lives in the screen, not the ViewModel: it is a property of
    // this transcript being on screen, it dies with it, and keeping it out of
    // the ui state means picking a message does not touch anything that streams.
    var selectedIds by remember { mutableStateOf(emptySet<String>()) }
    var pendingBulkDelete by remember { mutableStateOf(false) }
    val selectionActive = selectedIds.isNotEmpty()
    val clipboard = LocalClipboardManager.current
    // Back leaves the selection before it leaves the chat. Anything else loses
    // the picks to a gesture people make without looking.
    BackHandler(enabled = selectionActive) { selectedIds = emptySet() }
    // Ids that have already been on screen. A LazyColumn recycles its items, so
    // without this the arrival animation would replay every time an old message
    // scrolled back into view.
    val seenMessages = remember { mutableSetOf<String>() }
    val editingMessageId by viewModel.editingMessageId.collectAsStateWithLifecycle()

    // OpenMultipleDocuments rather than GetContent: it is the only picker whose
    // uris can be granted long-lived read access, which the app needs to still be
    // able to read an attachment when an older message is regenerated.
    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) viewModel.attachFiles(uris.map { it.toString() })
    }

    // The three sources used to live in a bottom sheet. They are now a menu that
    // morphs out of the attach button itself: same three choices, but the panel
    // appears where the finger already is instead of sliding up from the bottom
    // of the screen, and the composer stays visible behind it.
    val attachMenuItems = listOf(
        MorphMenuItem(
            icon = Icons.Rounded.Image,
            label = stringResource(R.string.chat_attach_source_image),
            onClick = { filePicker.launch(arrayOf("image/*")) }
        ),
        MorphMenuItem(
            icon = Icons.Rounded.Description,
            label = stringResource(R.string.chat_attach_source_file),
            // Any type: what can be done with a file is decided when it is read,
            // not by filtering it out of the picker.
            onClick = { filePicker.launch(arrayOf("*/*")) }
        ),
        MorphMenuItem(
            icon = Icons.Rounded.Folder,
            label = stringResource(R.string.chat_attach_source_project),
            onClick = {
                showAttachments = true
                viewModel.searchAttachments("")
            }
        )
    )

    // Hoisted so the transcript's item callbacks can capture this list instead of
    // the whole ui state. See the `onDelete` comment below for why that decides
    // whether message bubbles can skip recomposition.
    val messages = state.messages
    val itemCount = messages.size + if (state.streaming != null) 1 else 0

    // "At the end" has to be measured in pixels, not in item indices. The
    // streaming answer is a single item that can be several screens tall, so the
    // last item being visible says nothing about whether its end is on screen.
    // The old index test (`last >= totalItemsCount - 2`) was true the whole time
    // an answer streamed, which is why the transcript kept yanking itself back to
    // the top of that answer while the text was being written off screen below.
    val endSlopPx = with(LocalDensity.current) { 48.dp.roundToPx() }
    val atBottom by remember(endSlopPx) {
        derivedStateOf {
            val info = listState.layoutInfo
            // Nothing measured yet is not the same as being at the end. It used
            // to answer "true", so the single frame after a relayout was enough
            // for the follow below to take the transcript over.
            val last = info.visibleItemsInfo.lastOrNull() ?: return@derivedStateOf false
            val contentBottom = info.viewportEndOffset - info.afterContentPadding
            last.index >= info.totalItemsCount - 1 &&
                (last.offset + last.size - contentBottom) <= endSlopPx
        }
    }

    // Opening a conversation lands on its newest message: a transcript is read
    // from the bottom. It cannot be done at first composition because the history
    // arrives from Room a frame or two later, so it happens the first time there
    // are messages — and as a jump, not an animated tour of the whole history.
    var anchored by remember(sessionId) { mutableStateOf(false) }
    LaunchedEffect(sessionId, state.messages.size) {
        if (anchored || state.messages.isEmpty()) return@LaunchedEffect
        listState.scrollToTranscriptEnd(smooth = false)
        anchored = true
    }

    // Sending always goes to the end, wherever the user was reading: they just
    // acted, and the answer to that action is what they are waiting for.
    val lastSentId = state.messages.lastOrNull()?.takeIf { it.isFromUser }?.id
    LaunchedEffect(lastSentId) {
        if (!anchored || lastSentId == null) return@LaunchedEffect
        listState.scrollToTranscriptEnd(smooth = true)
    }

    // Follow the answer while it streams, but never fight the user's scroll: as
    // soon as they scroll up, `atBottom` is false and the transcript is theirs
    // again until they come back down. The follow is deliberately instant — an
    // animated scroll restarted on every delta cancels itself mid-flight, which
    // is the jitter this replaces.
    LaunchedEffect(itemCount, state.streaming?.text?.length) {
        // `isScrollInProgress` is the missing half of this test. A delta lands
        // every few frames while an answer streams, and one that arrived while
        // the finger was still moving cancelled the gesture and jumped to the
        // end of the answer -- a swipe that ended somewhere the reader never
        // chose. Only a list nobody is touching is followed.
        if (atBottom && !listState.isScrollInProgress && itemCount > 0) {
            listState.scrollToTranscriptEnd(smooth = false)
        }
    }

    DisposableEffect(Unit) {
        // The blank check moved into the ViewModel. Reading the draft here meant
        // subscribing this screen to the composer's text, which recomposed the
        // whole transcript on every keystroke -- the very thing the split into
        // `viewModel.input` exists to prevent.
        onDispose { viewModel.persistDraft() }
    }

    // A Box around the whole chat, purely so the settings panel can overlay it.
    // The panel is intentionally inside this hierarchy rather than in a Dialog:
    // sharing the transcript's animation clock is what keeps its slide and the
    // scrim's fade from drifting apart on a slow frame.
    Box(modifier = Modifier.fillMaxSize()) {
    Column(modifier = Modifier.fillMaxSize()) {
        if (selectionActive) {
            SelectionTopBar(
                count = selectedIds.size,
                onClear = { selectedIds = emptySet() },
                onCopy = {
                    // In transcript order, not the order they were picked: the
                    // point of copying several messages is to keep the exchange
                    // readable somewhere else.
                    val text = messages
                        .filter { it.id in selectedIds }
                        .joinToString("\n\n") { it.content }
                    if (text.isNotBlank()) clipboard.setText(AnnotatedString(text))
                    selectedIds = emptySet()
                },
                onDelete = { pendingBulkDelete = true }
            )
        } else {
        SiriusTopBar(
            title = state.session?.title ?: stringResource(R.string.chat_title_fallback),
            subtitle = state.project?.name?.let {
                stringResource(R.string.chat_project_prefix, it)
            } ?: state.session?.model,
            onBack = onBack,
            actions = {
                if (state.pendingChanges.isNotEmpty()) {
                    val pendingCount = state.pendingChanges.size
                    // On its own this reads as a naked "3" to a screen reader.
                    // The banner below says it in full, so the badge borrows that
                    // sentence instead of inventing a shorter, vaguer one.
                    val pendingLabel = pluralStringResource(
                        R.plurals.chat_review_banner_title,
                        pendingCount,
                        pendingCount
                    )
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(SiriusRadius.pill))
                            .softSurface(RoundedCornerShape(SiriusRadius.pill))
                            .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xxs)
                            .labelled(pendingLabel),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.AutoMirrored.Rounded.CompareArrows,
                            contentDescription = null,
                            tint = colors.warning,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(Modifier.width(SiriusSpacing.xxs))
                        Text(
                            text = pendingCount.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.warning
                        )
                    }
                    Spacer(Modifier.width(SiriusSpacing.xxs))
                }

                // Rightmost, and the anchor the panel slides out from. Kept as
                // the last action so the two read as one gesture: the button is
                // on the right edge and the panel arrives from it.
                GlassIconButton(
                    icon = Icons.Rounded.Tune,
                    contentDescription = stringResource(R.string.chat_settings_open),
                    onClick = viewModel::openSettings
                )
            }
        )
        }

        // The banner shows up mid-conversation and pushes the transcript down,
        // so it rises into that space rather than materialising in it.
        val (bannerEnter, bannerExit) = siriusRise()
        AnimatedVisibility(
            visible = state.pendingChanges.isNotEmpty(),
            enter = bannerEnter,
            exit = bannerExit
        ) {
            ReviewBanner(
                count = state.pendingChanges.size,
                onReview = onOpenReview,
                modifier = Modifier.padding(horizontal = SiriusSpacing.sm)
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = SiriusSpacing.sm,
                    end = SiriusSpacing.sm,
                    top = SiriusSpacing.xs,
                    bottom = SiriusSpacing.sm
                ),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                if (messages.isEmpty() && state.streaming == null) {
                    item(key = "empty") {
                        EmptyConversation()
                    }
                }

                items(
                    messages,
                    key = { it.id },
                    // A user bubble and an assistant answer are different enough
                    // that reusing one's nodes for the other costs more than it
                    // saves. Keyed by role, each kind is only ever reused for its
                    // own kind, which is what makes scrolling cheap on a slow
                    // phone.
                    contentType = { it.role }
                ) { message ->
                    // `add` is true only the first time this id is seen, which is
                    // exactly the condition for animating it in.
                    val fresh = remember(message.id) { seenMessages.add(message.id) }
                    MessageBubble(
                        message = message,
                        codeFontSize = codeFontSize,
                        animateEntry = fresh,
                        selectionActive = selectionActive,
                        selected = message.id in selectedIds,
                        onToggleSelect = {
                            selectedIds = if (message.id in selectedIds) {
                                selectedIds - message.id
                            } else {
                                selectedIds + message.id
                            }
                        },
                        onStartSelection = { selectedIds = selectedIds + message.id },
                        // Editing happens in the composer, so the message keeps its
                        // attachments while it is being rewritten.
                        onEdit = { viewModel.beginEdit(message) },
                        onRegenerate = { viewModel.regenerate(message.id) },
                        onForkModel = { forkMessageId = message.id },
                        onDelete = {
                            // Captures `messages`, not `state`.
                            //
                            // This looks like a cosmetic narrowing and is not. The
                            // compose compiler memoises these lambdas on what they
                            // capture; capturing the whole ui state meant a new
                            // lambda whenever *any* field changed, so `MessageBubble`
                            // received fresh callbacks and could never skip. Every
                            // streamed token therefore recomposed every visible
                            // bubble. `messages` is the same list instance across a
                            // stream, so now they skip.
                            val index = messages.indexOfFirst { it.id == message.id }
                            val following = if (index < 0) 0 else messages.size - index - 1
                            // Deleting the last message cannot orphan anything, so it
                            // goes straight through. Deleting from the middle can, so
                            // it always asks first.
                            if (following == 0) {
                                viewModel.deleteMessage(message.id)
                            } else {
                                pendingDelete = message
                            }
                        }
                    )
                }

                state.streaming?.let { streaming ->
                    item(key = "streaming") {
                        StreamingBubble(
                            text = streaming.text,
                            activeTool = streaming.activeTool,
                            step = streaming.step,
                            toolRuns = streaming.toolRuns,
                            codeFontSize = codeFontSize
                        )
                    }
                }
            }

            // Kept in its own composable: inside this Box the Column receiver from
            // the screen root is still in scope, and AnimatedVisibility would bind
            // to the ColumnScope overload it cannot reach from here.
            JumpToBottomButton(
                visible = !atBottom && itemCount > 2,
                onClick = {
                    scope.launch { listState.scrollToTranscriptEnd(smooth = true) }
                },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = SiriusSpacing.xs)
            )
        }

        // Failures used to snap in above the composer, which read as a layout
        // glitch rather than an answer to the tap. It rises like the review
        // banner, and announces itself so the error is not silent.
        val (errorEnter, errorExit) = siriusRise(distancePx = 16)
        // The text has to outlive the state that produced it, otherwise the
        // banner blanks out for the length of its own exit animation.
        var lastError by remember { mutableStateOf("") }
        LaunchedEffect(state.error) {
            state.error?.let { lastError = it }
        }
        AnimatedVisibility(
            visible = state.error != null,
            enter = errorEnter,
            exit = errorExit
        ) {
            ErrorBanner(
                message = lastError,
                retryable = state.retryable,
                onRetry = viewModel::retry,
                onDismiss = viewModel::dismissError
            )
        }

        ChatInputBar(
            input = viewModel.input,
            onValueChange = viewModel::onInputChange,
            onSend = viewModel::send,
            onStop = viewModel::stop,
            // Toggle, not open: the button now shows an open/close state, so a
            // second tap has to be able to close what the first one opened.
            onAttach = { showAttachMenu = !showAttachMenu },
            attachMenuItems = attachMenuItems,
            attachMenuExpanded = showAttachMenu,
            onAttachMenuDismiss = { showAttachMenu = false },
            onPickModel = { showModelPicker = true },
            generating = state.isGenerating,
            modelLabel = state.session?.model ?: stringResource(R.string.chat_no_model),
            attachments = state.attachments,
            onRemoveAttachment = viewModel::removeAttachment,
            editing = editingMessageId != null,
            onCancelEdit = viewModel::cancelEdit,
            contextFill = state.contextFill,
            // Absent where the endpoint has nothing to configure: a meter that
            // can never move is a control that lies.
            powerMode = state.powerMode.takeIf { state.powerCapabilities.configurable },
            onPickPower = { showPowerPicker = true }
        )
    }

        ChatSettingsPanel(
            visible = state.settingsOpen,
            features = state.features,
            support = state.featureSupport,
            busyFeature = state.busyFeature,
            modelLabel = state.session?.model ?: stringResource(R.string.chat_no_model),
            onToggle = viewModel::toggleFeature,
            contextMeter = state.contextMeter,
            onToggleContextMeter = viewModel::setContextMeter,
            memory = state.memory,
            onToggleMemory = viewModel::setMemory,
            onOpenMemory = onOpenMemory,
            powerMode = state.powerMode,
            powerSupported = state.powerCapabilities.configurable,
            onOpenPower = {
                // The panel slides away first: the sheet is about the same next
                // answer, and two overlays for one decision is one too many.
                viewModel.closeSettings()
                showPowerPicker = true
            },
            onDismiss = viewModel::closeSettings
        )
    }

    if (showModelPicker) {
        ModelPickerSheet(
            providers = state.providers,
            activeProviderId = state.session?.providerId,
            activeModel = state.session?.model,
            onSelect = { providerId, model ->
                viewModel.selectModel(providerId, model)
                showModelPicker = false
            },
            onManageProviders = {
                showModelPicker = false
                onOpenProviders()
            },
            powerMode = state.powerMode,
            powerSupported = state.powerCapabilities.configurable,
            onOpenPower = {
                showModelPicker = false
                showPowerPicker = true
            },
            onDismiss = { showModelPicker = false }
        )
    }

    if (showPowerPicker) {
        PowerModeSheet(
            mode = state.powerMode,
            capabilities = state.powerCapabilities,
            custom = state.powerCustom,
            modelLabel = state.session?.model ?: stringResource(R.string.chat_no_model),
            onSelect = { mode ->
                viewModel.selectPowerMode(mode)
                // CUSTOM keeps the sheet open: its fields are the point, and
                // dismissing would hide them the instant they were asked for.
                if (mode != PowerMode.CUSTOM) showPowerPicker = false
            },
            onSaveCustom = { config ->
                viewModel.saveCustomPower(config)
                showPowerPicker = false
            },
            onDismiss = { showPowerPicker = false }
        )
    }

    // The same picker, doing something different: here the choice does not change
    // this chat's model, it decides which model the branch is asked on.
    forkMessageId?.let { messageId ->
        ModelPickerSheet(
            providers = state.providers,
            activeProviderId = state.session?.providerId,
            activeModel = state.session?.model,
            onSelect = { providerId, model ->
                forkMessageId = null
                viewModel.forkOnModel(messageId, providerId, model, onOpenChat)
            },
            onManageProviders = {
                forkMessageId = null
                onOpenProviders()
            },
            onDismiss = { forkMessageId = null }
        )
    }

    // A sheet rather than an inline card, and placed with the other sheets: the
    // run is suspended until this is answered, so it is genuinely modal. An
    // inline card competed with the composer for the same strip and could be
    // scrolled away from, leaving a stalled agent with no visible cause.
    state.question?.let { question ->
        AgentQuestionSheet(
            question = question,
            onAnswer = viewModel::answerQuestion
        )
    }

    if (showAttachments) {
        AttachmentSheet(
            results = attachmentResults,
            query = attachmentQuery,
            onQueryChange = viewModel::searchAttachments,
            onPick = { node ->
                viewModel.attach(node)
                showAttachments = false
            },
            onDismiss = { showAttachments = false },
            hasWorkspace = state.project?.hasWorkspace == true
        )
    }


    if (pendingBulkDelete) {
        AlertDialog(
            onDismissRequest = { pendingBulkDelete = false },
            title = { Text(stringResource(R.string.chat_selection_delete_title)) },
            text = {
                Text(stringResource(R.string.chat_selection_delete_body, selectedIds.size))
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteMessages(selectedIds)
                        selectedIds = emptySet()
                        pendingBulkDelete = false
                    }
                ) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingBulkDelete = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    pendingDelete?.let { message ->
        val index = state.messages.indexOfFirst { it.id == message.id }
        val following = if (index < 0) 0 else state.messages.size - index - 1
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(stringResource(R.string.chat_delete_title)) },
            text = { Text(stringResource(R.string.chat_delete_body, following)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteMessage(message.id, withFollowing = true)
                    pendingDelete = null
                }) {
                    Text(stringResource(R.string.chat_delete_with_following, following))
                }
            },
            dismissButton = {
                // Deleting only this message is a real choice, not a cancel: the
                // history stays, which is what someone removing one bad answer from
                // the middle of a long conversation wants.
                TextButton(onClick = {
                    viewModel.deleteMessage(message.id)
                    pendingDelete = null
                }) {
                    Text(stringResource(R.string.chat_delete_only))
                }
            }
        )
    }
}

/**
 * The button that returns the reader to the live end of the transcript. It uses
 * the shared fade-through so it honours reduce-motion like every other element
 * that swaps in, and it lives here rather than inline because at the call site
 * an outer ColumnScope shadows the plain [AnimatedVisibility] overload.
 */
@Composable
private fun JumpToBottomButton(
    visible: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (enter, exit) = siriusFadeThrough()
    AnimatedVisibility(
        visible = visible,
        enter = enter,
        exit = exit,
        modifier = modifier
    ) {
        GlassIconButton(
            icon = Icons.Rounded.KeyboardArrowDown,
            contentDescription = stringResource(R.string.chat_scroll_to_bottom),
            onClick = onClick
        )
    }
}

@Composable
private fun EmptyConversation() {
    val colors = SiriusTheme.colors
    // A fresh conversation is the one moment with nothing to read, so the orb
    // gets to be the subject rather than an icon next to a title.
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = SiriusSpacing.xxl, bottom = SiriusSpacing.lg)
            .padding(horizontal = SiriusSpacing.md),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SiriusOrb(size = 72.dp, active = true)
        Spacer(Modifier.height(SiriusSpacing.lg))
        Text(
            text = stringResource(R.string.chat_agent_mode),
            style = MaterialTheme.typography.headlineSmall,
            color = colors.textPrimary,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(SiriusSpacing.xs))
        Text(
            text = stringResource(R.string.chat_empty_agent_body),
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
            // Keeps the line length in the comfortable 45-75 character band
            // instead of stretching edge to edge on a tablet.
            modifier = Modifier.widthIn(max = 340.dp)
        )
    }
}

@Composable
private fun StreamingBubble(
    text: String,
    activeTool: String?,
    step: Int,
    toolRuns: List<ToolRun>,
    codeFontSize: Int
) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.lg)
    val label = when {
        activeTool != null -> stringResource(R.string.chat_running_tool, activeTool)
        step > 1 -> stringResource(R.string.chat_thinking_step, step)
        else -> stringResource(R.string.chat_thinking)
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = SiriusSpacing.xxs)
            .glassSurface(shape = shape, elevation = 6.dp)
            // The beam earns its place here: this is the one element on screen
            // that is genuinely mid-flight.
            .beamBorder(shape = shape, active = true)
            .padding(SiriusSpacing.sm)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SiriusOrb(size = 16.dp, active = true, contentDescription = label)
            Spacer(Modifier.width(SiriusSpacing.xs))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = colors.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            Spacer(Modifier.width(SiriusSpacing.xs))
            SiriusTypingDots(dotSize = 4.dp)
        }
        if (toolRuns.isNotEmpty()) {
            Spacer(Modifier.height(SiriusSpacing.xs))
            ToolRunList(toolRuns)
        }
        // Shown mid-generation as well as after it: a search that finished thirty
        // seconds ago should be inspectable while the model is still writing.
        val sources = remember(toolRuns) { sourcesFrom(toolRuns) }
        if (sources.isNotEmpty()) {
            Spacer(Modifier.height(SiriusSpacing.xs))
            MessageSources(sources)
        }
        if (text.isNotBlank()) {
            Spacer(Modifier.height(SiriusSpacing.xs))
            // Not cached: this text changes on every flush, so every version
            // would be a cache key that is never read again.
            MarkdownText(markdown = text, codeFontSize = codeFontSize, cacheable = false)
        }
    }
}

/**
 * The agent's question, as a bottom sheet.
 *
 * Modal on purpose. The agent's coroutine is parked on this answer, so anything
 * the user does elsewhere is against a frozen assistant — an inline card let them
 * scroll it out of view and wonder why nothing was happening.
 *
 * The free text field is always present rather than hidden behind an "other"
 * option. Suggestions are a shortcut; the case the model failed to anticipate is
 * exactly the case worth typing, and putting that behind an extra tap penalises
 * the situation the tool exists for.
 *
 * Dismissal is a real answer, not a cancel. Swiping down sends blank, which
 * `AskUserTool` reports as "decide for yourself" — the run continues instead of
 * hanging on a sheet the user has already closed.
 */
@Composable
private fun AgentQuestionSheet(
    question: AgentQuestion,
    onAnswer: (String) -> Unit
) {
    val colors = SiriusTheme.colors
    var custom by remember(question.id) { mutableStateOf("") }
    val picked = remember(question.id) { mutableStateListOf<String>() }

    // A typed line is one more answer, not a replacement for the ticks. Picking
    // two options and then adding “and also billing” is an ordinary thing to
    // want, and sending only the typed half silently threw away the taps.
    val typed = custom.trim()
    val composed = (picked + listOfNotNull(typed.takeIf { it.isNotEmpty() }))
        .joinToString(", ")
    val answerCount = picked.size + if (typed.isEmpty()) 0 else 1

    SiriusBottomSheet(
        title = stringResource(R.string.chat_ask_title),
        subtitle = question.question,
        onDismiss = { onAnswer("") },
        actions = {
            if (question.multiSelect) {
                // Multi select has no natural commit point, so it gets an explicit
                // one. Single select does not: tapping the option *is* the answer.
                SiriusPrimaryButton(
                    // Counts what is selected, so the button doubles as the
                    // answer to "did that tap register".
                    text = if (answerCount == 0) {
                        stringResource(R.string.chat_ask_confirm)
                    } else {
                        stringResource(R.string.chat_ask_confirm_count, answerCount)
                    },
                    onClick = { onAnswer(composed) },
                    enabled = answerCount > 0,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    ) {
        if (question.options.isNotEmpty()) {
            // Says what a tap will do before the user makes one: in single
            // select the tap *is* the answer and the sheet closes, which is
            // surprising if you expected to confirm afterwards.
            Text(
                text = stringResource(
                    if (question.multiSelect) {
                        R.string.chat_ask_hint_multi
                    } else {
                        R.string.chat_ask_hint_single
                    }
                ),
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary
            )
            VSpace(SiriusSpacing.xs)
        }
        question.options.forEachIndexed { index, option ->
            if (index > 0) VSpace(SiriusSpacing.xxs)
            SheetOptionRow(
                label = option,
                selected = if (question.multiSelect) option in picked else false,
                // Checkbox rows, and a checkbox to TalkBack: in multi select the
                // tap does not close the sheet, and nothing else on the row says
                // so before it is pressed.
                multiSelect = question.multiSelect,
                supportingMaxLines = 3,
                // Numbered: three long options are far easier to scan with an
                // anchor per row, and a numbered list is how the answer gets
                // referred to afterwards -- "the second one".
                index = index + 1,
                onClick = {
                    if (question.multiSelect) {
                        if (!picked.remove(option)) picked.add(option)
                    } else {
                        onAnswer(option)
                    }
                }
            )
        }

        if (question.options.isNotEmpty()) VSpace(SiriusSpacing.sm)

        Row(verticalAlignment = Alignment.CenterVertically) {
            SiriusTextField(
                value = custom,
                onValueChange = { custom = it },
                modifier = Modifier.weight(1f),
                placeholder = stringResource(R.string.chat_ask_custom_placeholder),
                imeAction = ImeAction.Send,
                onImeAction = { if (composed.isNotEmpty()) onAnswer(composed) }
            )
            Spacer(Modifier.width(SiriusSpacing.xs))
            GlassIconButton(
                icon = Icons.AutoMirrored.Rounded.Send,
                contentDescription = stringResource(R.string.chat_send),
                // Sends the ticked options too, so the arrow beside a typed line
                // never means “and drop everything I selected”.
                enabled = composed.isNotEmpty(),
                onClick = { onAnswer(composed) }
            )
        }

        VSpace(SiriusSpacing.xs)
        // A real button rather than a line of small print. Skipping is a valid
        // answer -- it tells the agent to decide for itself -- and a 12sp label
        // is a target that gets missed on a phone.
        SiriusGhostButton(
            text = stringResource(R.string.chat_ask_skip),
            onClick = { onAnswer("") },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun ReviewBanner(count: Int, onReview: () -> Unit, modifier: Modifier = Modifier) {
    val colors = SiriusTheme.colors
    GlassCard(
        modifier = modifier.fillMaxWidth(),
        onClick = onReview,
        tint = colors.warning.copy(alpha = 0.14f),
        contentPadding = SiriusSpacing.sm
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.AutoMirrored.Rounded.CompareArrows,
                contentDescription = null,
                tint = colors.warning,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(SiriusSpacing.xs))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = pluralStringResource(R.plurals.chat_review_banner_title, count, count),
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textPrimary
                )
                Text(
                    text = stringResource(R.string.chat_review_banner_subtitle),
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary
                )
            }
            Text(
                text = stringResource(R.string.action_review),
                style = MaterialTheme.typography.labelLarge,
                color = colors.primary,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

@Composable
private fun ErrorBanner(
    message: String,
    retryable: Boolean,
    onRetry: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xxs)
            .glassSurface(
                shape = RoundedCornerShape(SiriusRadius.md),
                tint = colors.error.copy(alpha = 0.18f),
                elevation = 4.dp
            )
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
            // TalkBack has no reason to look at the bottom of the screen after a
            // send, so the failure has to speak for itself.
            .semantics { liveRegion = LiveRegionMode.Polite },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Rounded.ErrorOutline,
            contentDescription = null,
            tint = colors.error,
            modifier = Modifier.size(16.dp)
        )
        Spacer(Modifier.width(SiriusSpacing.xs))
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f)
        )
        if (retryable) {
            GlassIconButton(
                icon = Icons.Rounded.Refresh,
                contentDescription = stringResource(R.string.action_retry),
                onClick = onRetry,
                size = 30.dp,
                iconSize = 15.dp,
                tint = colors.primary
            )
            Spacer(Modifier.width(SiriusSpacing.xxs))
        }
        GlassIconButton(
            icon = Icons.Rounded.Close,
            contentDescription = stringResource(R.string.action_dismiss),
            onClick = onDismiss,
            size = 30.dp,
            iconSize = 15.dp
        )
    }
}


/**
 * How far past the last item a jump to the end aims for.
 *
 * `scrollToItem(index)` aligns an item's *top* with the top of the viewport, so
 * jumping to a streaming answer three screens tall showed its first line and
 * then corrected itself downwards a frame later: one scroll, two visible
 * movements, which is exactly what "it skipped somewhere" describes. Asking for
 * an offset no item can be that tall lets the list clamp itself at the bottom of
 * its own content in a single pass.
 */
private const val END_ANCHOR_PX = 1_000_000

/**
 * Scrolls so the very end of the transcript sits on the bottom edge of the
 * viewport.
 *
 * `animateScrollToItem`, which this replaces, aligns an item's *top* with the top
 * of the viewport. For a streaming answer that grows past one screen that is the
 * worst possible target: it pins the start of the answer just under the question
 * and writes the new text off screen below. Here the last item is brought into
 * view first, then whatever hangs below the fold is scrolled away; the pass runs
 * a few times because the item is still growing between frames, and because
 * `layoutInfo` only catches up after a remeasure.
 */
private suspend fun LazyListState.scrollToTranscriptEnd(smooth: Boolean) {
    repeat(3) { _ ->
        val info = layoutInfo
        val target = info.totalItemsCount - 1
        if (target < 0) return
        val item = info.visibleItemsInfo.lastOrNull { it.index == target }
        if (item == null) {
            // The end is off screen entirely: land on the bottom of the content
            // in one move rather than on the top of its last item, then measure
            // again. See END_ANCHOR_PX for why there is an offset.
            if (smooth) animateScrollToItem(target) else scrollToItem(target, END_ANCHOR_PX)
        } else {
            val overflow = (item.offset + item.size -
                (info.viewportEndOffset - info.afterContentPadding)).toFloat()
            if (overflow <= 1f) return
            if (smooth) animateScrollBy(overflow) else scrollBy(overflow)
        }
        withFrameNanos { }
    }
}

/**
 * The top bar while messages are being picked.
 *
 * It replaces the chat's own bar rather than adding to it. In multi-select the
 * actions apply to the selection, not to the conversation, and leaving
 * “settings” and “back to chats” sitting next to “delete 4 messages” is how
 * people delete the wrong thing. Back clears the selection, so the bar is also
 * the way out of the mode.
 */
@Composable
private fun SelectionTopBar(
    count: Int,
    onClear: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit
) {
    SiriusTopBar(
        title = stringResource(R.string.chat_selection_count, count),
        subtitle = stringResource(R.string.chat_selection_hint),
        onBack = onClear,
        actions = {
            GlassIconButton(
                icon = Icons.Rounded.ContentCopy,
                contentDescription = stringResource(R.string.chat_selection_copy),
                onClick = onCopy
            )
            Spacer(Modifier.width(SiriusSpacing.xxs))
            GlassIconButton(
                icon = Icons.Rounded.DeleteOutline,
                contentDescription = stringResource(R.string.chat_selection_delete),
                onClick = onDelete
            )
        }
    )
}
