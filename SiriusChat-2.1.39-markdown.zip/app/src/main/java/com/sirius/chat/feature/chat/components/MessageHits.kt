package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.domain.model.MessageHit

/**
 * Messages matching the current search, above the chat list.
 *
 * ### Why this is a section and not a screen
 * The question being answered is "where did we discuss this", and the answer is
 * a chat to open. A dedicated search screen would make the person choose between
 * browsing and searching before they know which one helps; showing hits above the
 * list lets the same typing do both.
 *
 * Tapping a hit opens its chat. It does not scroll to the message: the chat can
 * be mid-generation and the history is loaded lazily, so a jump would sometimes
 * land nowhere. Opening the right conversation is the part that matters.
 */
@Composable
fun MessageHitsSection(
    hits: List<MessageHit>,
    onOpen: (MessageHit) -> Unit,
    modifier: Modifier = Modifier
) {
    if (hits.isEmpty()) return
    val colors = SiriusTheme.colors
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
    ) {
        Text(
            text = stringResource(R.string.chats_hits_title, hits.size),
            style = MaterialTheme.typography.labelMedium,
            color = colors.textTertiary,
            modifier = Modifier.padding(bottom = SiriusSpacing.xxs)
        )
        hits.forEach { hit ->
            key(hit.messageId) {
                GlassCard(
                    onClick = { onOpen(hit) },
                    onClickLabel = stringResource(R.string.chats_hits_open),
                    contentPadding = SiriusSpacing.sm
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = hit.sessionTitle,
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = hit.snippet,
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
