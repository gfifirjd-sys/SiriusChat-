package com.sirius.chat.feature.chat.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import kotlinx.coroutines.flow.StateFlow
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sirius.chat.R
import com.sirius.chat.domain.model.PowerMode
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.MorphMenu
import com.sirius.chat.core.designsystem.components.MorphMenuItem
import com.sirius.chat.core.designsystem.effects.LiquidMetalPreset
import com.sirius.chat.core.designsystem.effects.SiriusHairline
import com.sirius.chat.core.designsystem.effects.ambientGlow
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.effects.liquidMetalRing
import com.sirius.chat.core.designsystem.effects.metalBevelBrush
import com.sirius.chat.core.designsystem.siriusFadeThrough
import com.sirius.chat.core.designsystem.siriusRise
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.designsystem.touchTarget
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.domain.model.MessageAttachment
import com.sirius.chat.domain.model.AttachmentKind

/**
 * Composer.
 *
 * One flat panel, one line of controls: attach, mode, model, send. Everything is
 * inert dark chrome except the send button, which wears the liquid-metal ring —
 * it is the only decorated pixel on the screen, which is precisely what makes it
 * read as "this is the action" without a coloured fill or a label.
 *
 * The ring also carries state instead of a second signal being invented for it:
 * dormant while there is nothing to send, chromatic once the field is armed, gold
 * while the model is answering. The old composer stacked a focus bloom, a
 * travelling beam border, a tinted gradient send plate and a metal-plate body on
 * top of each other; all four are gone.
 */
@Composable
fun ChatInputBar(
    /**
     * The composer's text, as a flow.
     *
     * ### Why a flow and not a String
     * A `String` parameter forces whoever calls this to read the text, and in
     * Compose reading a state is what subscribes you to it. `ChatScreen` would
     * therefore recompose on every keystroke, and with it the transcript and every
     * visible bubble -- which is exactly the typing lag this replaces.
     *
     * Collected here instead, so the only thing that recomposes while typing is
     * the composer itself. The flow reference is stable, so passing it costs
     * nothing.
     */
    input: StateFlow<String>,
    /** New text and the caret offset after it, which is where files anchor. */
    onValueChange: (String, Int) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onAttach: () -> Unit,
    onPickModel: () -> Unit,
    /** Sources the attach button offers; rendered as a menu morphing out of it. */
    attachMenuItems: List<MorphMenuItem> = emptyList(),
    /** Whether that menu is open. Owned by the screen, like every other overlay. */
    attachMenuExpanded: Boolean = false,
    onAttachMenuDismiss: () -> Unit = {},
    generating: Boolean,
    modelLabel: String,
    attachments: List<MessageAttachment>,
    onRemoveAttachment: (String) -> Unit,
    /** True while an existing message is being edited in place. */
    editing: Boolean = false,
    onCancelEdit: () -> Unit = {},
    modifier: Modifier = Modifier,
    /**
     * Window fill from 0..1, or `null` to hide the meter entirely.
     *
     * Nullable rather than a `Boolean` plus a `Float`: the two can never
     * disagree this way, and "no number to show" and "switched off" want the
     * same rendering anyway.
     */
    contextFill: Float? = null,
    /**
     * Current answer power, or null when this endpoint has no knob at all.
     *
     * Nullable rather than a mode plus a Boolean: "nothing to show" and "showing
     * a control that cannot move" are not the same thing, and only the first is
     * honest on an endpoint with no power settings.
     */
    powerMode: PowerMode? = null,
    onPickPower: (() -> Unit)? = null
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val pickModelLabel = stringResource(R.string.chat_pick_model)
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val composerShape = RoundedCornerShape(28.dp)

    // The composer owns selection state so the caret offset can be reported: an
    // attachment is anchored where the user is typing, and a plain String field
    // cannot say where that is. The text itself stays owned by the ViewModel, so
    // clearing it after send and filling it for an edit keep working.
    var field by remember { mutableStateOf(TextFieldValue("")) }

    // Collected with `collectAsStateWithLifecycle` rather than read from a
    // parameter, so this subscription belongs to the composer and not to the
    // screen above it.
    val external by input.collectAsStateWithLifecycle()
    LaunchedEffect(external) {
        // Guarded, and the guard matters: without it every keystroke would round
        // trip through the ViewModel and come back to reset the caret to the end
        // of the text, so editing anywhere but the end would be impossible.
        if (field.text != external) {
            field = TextFieldValue(external, TextRange(external.length))
        }
    }

    // Derived locally from the text the composer already owns, instead of being
    // passed in. Sending depends on the text, so a `canSend` parameter would drag
    // the text back up into the caller's recomposition scope and undo the split
    // above.
    val canSend = !generating && (field.text.isNotBlank() || attachments.isNotEmpty())
    val armed = canSend || generating

    val sendScale by animateFloatAsState(
        targetValue = if (armed) 1f else 0.94f,
        animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
        label = "sendScale"
    )
    // Focus is worth exactly one hairline getting brighter. Anything louder and
    // the ring next to it stops being the thing you look at.
    val edgeAlpha by animateFloatAsState(
        targetValue = if (focused) 1f else 0.55f,
        animationSpec = siriusSpring(),
        label = "composerEdge"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .imePadding()
            .navigationBarsPadding()
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
            .glassSurface(shape = composerShape, elevation = 0.dp, borderAlpha = edgeAlpha)
            // While answering, the panel edge picks up the same metal as the
            // button: one material saying "live", not a second colour.
            .liquidMetalRing(
                shape = composerShape,
                width = SiriusHairline,
                preset = LiquidMetalPreset.Gold,
                active = generating,
                opacity = if (generating) 0.85f else 0f
            )
            .padding(SiriusSpacing.sm)
    ) {
        contextFill?.let { fill ->
            ContextMeter(
                fill = fill,
                modifier = Modifier.padding(bottom = SiriusSpacing.xs)
            )
        }

        // Editing is a mode, and a mode needs to be visible: without this the
        // composer looks like a normal draft and pressing send silently rewrites
        // history instead of adding a message.
        AnimatedVisibility(visible = editing) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = SiriusSpacing.xs),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Edit,
                    contentDescription = null,
                    tint = colors.accent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(SiriusSpacing.xxs))
                Text(
                    text = stringResource(R.string.chat_editing_banner),
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textSecondary,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = stringResource(R.string.chat_editing_cancel),
                    tint = colors.textTertiary,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onCancelEdit)
                        .touchTarget(36.dp)
                        .size(16.dp)
                )
            }
        }

        val (chipEnter, chipExit) = siriusRise(distancePx = 16)
        AnimatedVisibility(visible = attachments.isNotEmpty(), enter = chipEnter, exit = chipExit) {
            LazyRow(
                modifier = Modifier.padding(bottom = SiriusSpacing.xs),
                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
            ) {
                items(attachments, key = { it.id }) { attachment ->
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(SiriusRadius.pill))
                            .background(colors.surfaceMuted, RoundedCornerShape(SiriusRadius.pill))
                            .border(SiriusHairline, metalBevelBrush(colors), RoundedCornerShape(SiriusRadius.pill))
                            .padding(start = SiriusSpacing.xs, end = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // The icon carries the one thing the name often does not:
                        // whether the model will actually be able to read it.
                        Icon(
                            imageVector = attachmentIcon(attachment.kind),
                            contentDescription = null,
                            tint = if (attachment.kind == AttachmentKind.Opaque) {
                                colors.warning
                            } else {
                                colors.textTertiary
                            },
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = attachment.name,
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 160.dp)
                        )
                        Spacer(Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = stringResource(R.string.chat_remove_attachment),
                            tint = colors.textTertiary,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable(
                                    role = Role.Button,
                                    onClick = { onRemoveAttachment(attachment.id) }
                                )
                                // 15dp of ink, 36dp of target.
                                .touchTarget(36.dp)
                                .size(15.dp)
                        )
                    }
                }
            }
        }

        BasicTextField(
            value = field,
            onValueChange = {
                field = it
                onValueChange(it.text, it.selection.start)
            },
            textStyle = LocalTextStyle.current.merge(
                MaterialTheme.typography.bodyLarge.copy(
                    color = colors.textPrimary,
                    // The prompt is the primary content of this screen, so it is
                    // set larger than body text rather than at chrome size.
                    fontSize = 19.sp,
                    lineHeight = 26.sp
                )
            ),
            cursorBrush = SolidColor(colors.textPrimary),
            interactionSource = interaction,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp, max = 168.dp)
                .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xxs),
            decorationBox = { inner ->
                Box {
                    if (field.text.isEmpty()) {
                        Text(
                            text = stringResource(R.string.chat_input_hint),
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontSize = 19.sp,
                                lineHeight = 26.sp
                            ),
                            color = colors.textTertiary
                        )
                    }
                    inner()
                }
            }
        )

        Spacer(Modifier.size(SiriusSpacing.sm))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
        ) {
            // The menu is anchored to this button and grows out of it, so the
            // control and the surface it produces are visibly the same object.
            MorphMenu(
                expanded = attachMenuExpanded,
                onDismissRequest = onAttachMenuDismiss,
                items = attachMenuItems
            ) { menuOpen ->
                ComposerCircleButton(
                    icon = Icons.Rounded.Add,
                    description = stringResource(R.string.chat_attach_file),
                    onClick = onAttach,
                    menuOpen = menuOpen
                )
            }

            // The pills live in a weighted box and the send button does not.
            // A Row measures its unweighted children first, so at natural width
            // the model pill plus the new power pill claimed the whole line and
            // send was laid out past the right edge -- present, unreachable, and
            // invisible. Weighting the pills instead means send is measured
            // first and always fits.
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
            ) {
                // Only the model name gives ground: a truncated model id is
                // still recognisable, and the power ladder is four bars wide --
                // shrink it and it stops being readable at all.
                ComposerPill(
                    label = modelLabel,
                    onClick = onPickModel,
                    onClickLabel = pickModelLabel,
                    modifier = Modifier.weight(1f, fill = false),
                    maxWidth = 116.dp
                )

                if (powerMode != null && onPickPower != null) {
                    PowerPill(mode = powerMode, onClick = onPickPower)
                }
            }

            Box(
                modifier = Modifier
                    .scale(sendScale)
                    .ambientGlow(
                        color = if (generating) colors.warning else colors.accent,
                        shape = CircleShape,
                        radius = if (armed) 16.dp else 0.dp,
                        alpha = if (armed) 0.35f else 0f
                    )
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (armed) colors.surfaceMuted else colors.metalTrough, CircleShape)
                    .border(SiriusHairline, metalBevelBrush(colors), CircleShape)
                    // The ring is the whole affordance: 2dp of live metal when
                    // armed, nothing at all when there is no message to send.
                    .liquidMetalRing(
                        shape = CircleShape,
                        width = 2.dp,
                        preset = if (generating) LiquidMetalPreset.Gold else LiquidMetalPreset.Chromatic,
                        active = armed,
                        opacity = if (armed) 1f else 0f
                    )
                    .clickable(enabled = armed, role = Role.Button) {
                        haptics.light()
                        if (generating) onStop() else onSend()
                    },
                contentAlignment = Alignment.Center
            ) {
                // Send and stop are the same button doing two jobs, so the glyph
                // is swapped with a fade-through rather than replaced between
                // frames: at this size a hard cut looks like a rendering glitch.
                val (glyphEnter, glyphExit) = siriusFadeThrough()
                AnimatedContent(
                    targetState = generating,
                    transitionSpec = { glyphEnter togetherWith glyphExit },
                    label = "sendGlyph"
                ) { busy ->
                    Icon(
                        imageVector = if (busy) Icons.Rounded.Stop else Icons.Rounded.ArrowUpward,
                        contentDescription = stringResource(
                            if (busy) R.string.action_stop else R.string.chat_send
                        ),
                        tint = if (armed) colors.textPrimary else colors.textTertiary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

/**
 * Icon for an attachment kind, shared with the transcript.
 *
 * Same glyph in the composer and in the sent message, so a chip stays
 * recognisable after it scrolls up.
 */
internal fun attachmentIcon(kind: AttachmentKind): ImageVector = when (kind) {
    AttachmentKind.Image -> Icons.Rounded.Image
    AttachmentKind.Document -> Icons.Rounded.PictureAsPdf
    AttachmentKind.TextFile -> Icons.Rounded.Description
    AttachmentKind.WorkspaceFile -> Icons.Rounded.Folder
    AttachmentKind.Opaque -> Icons.Rounded.Warning
}

/**
 * Round control in the composer row: attach, and nothing else so far.
 *
 * [menuOpen] is not decoration. The button opens a menu that covers part of the
 * transcript, and a plus sign that stays a plus sign gives no way to tell that
 * tapping again will close it. Rotating it 45 degrees turns it into a close
 * glyph without swapping icons, which keeps the motion continuous with the
 * panel unfolding above it.
 */
@Composable
private fun ComposerCircleButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    menuOpen: Boolean = false
) {
    val colors = SiriusTheme.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val rotation by animateFloatAsState(
        targetValue = if (menuOpen) 45f else 0f,
        animationSpec = siriusSpring(SiriusMotion.SpringGentle),
        label = "composerAddRotation"
    )
    val plate by animateColorAsState(
        targetValue = if (menuOpen) colors.primarySoft else colors.surfaceMuted,
        animationSpec = siriusTween(SiriusMotion.Quick),
        label = "composerAddPlate"
    )
    val ink by animateColorAsState(
        targetValue = if (menuOpen) colors.primary else colors.textSecondary,
        animationSpec = siriusTween(SiriusMotion.Quick),
        label = "composerAddInk"
    )
    // Flat chrome gives no shading to press "into", so the press has to be felt
    // in the geometry instead.
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
        label = "composerIconPress"
    )
    Box(
        modifier = Modifier
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = onClick
            )
            .touchTarget(48.dp)
            // Smaller plate, same 48dp target: the row got crowded, the finger
            // did not get smaller.
            .size(40.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(plate, CircleShape)
            .border(SiriusHairline, metalBevelBrush(colors), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = ink,
            modifier = Modifier
                .size(20.dp)
                .rotate(rotation)
        )
    }
}

/**
 * A value-and-chevron pill. The chevron is not decoration: both pills open a
 * picker, and without it the mode pill would look like a static badge.
 */
@Composable
private fun ComposerPill(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onClickLabel: String? = null,
    role: Role = Role.Button,
    maxWidth: Dp = 132.dp,
    tint: Color? = null
) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.pill)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
        label = "composerPillPress"
    )
    Row(
        modifier = modifier
            // Click node above the press-scale, like every other pressable in
            // the app: below it, the outer pixels stop answering mid-shrink.
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = role,
                onClickLabel = onClickLabel,
                onClick = onClick
            )
            .scale(scale)
            .clip(shape)
            .background(colors.surfaceMuted, shape)
            .border(SiriusHairline, metalBevelBrush(colors), shape)
            .heightIn(min = 40.dp)
            .padding(start = SiriusSpacing.sm, end = SiriusSpacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = tint ?: colors.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = maxWidth)
        )
        Spacer(Modifier.width(SiriusSpacing.xxs))
        Icon(
            imageVector = Icons.Rounded.KeyboardArrowDown,
            contentDescription = null,
            tint = colors.textTertiary,
            modifier = Modifier.size(16.dp)
        )
    }
}
