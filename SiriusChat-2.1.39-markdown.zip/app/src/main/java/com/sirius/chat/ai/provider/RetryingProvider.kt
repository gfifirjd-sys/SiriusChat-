package com.sirius.chat.ai.provider

import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.domain.model.AiModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow

/**
 * Tries a request again when it failed for a reason that is not the request's
 * fault.
 *
 * Rate limits, 5xx and sockets dropped by a phone changing networks are the
 * everyday failures of a mobile client, and each one used to end the turn: the
 * agent stopped mid-plan, the summariser abandoned a compaction, the chat kept
 * its placeholder title. None of that needed a person to intervene -- it needed
 * one more attempt a moment later.
 *
 * Two boundaries keep this honest. Nothing is retried once text has reached the
 * screen, because a second attempt would restart the answer and print it twice.
 * And nothing is retried that the provider is entitled to reject the same way
 * forever -- a bad key, a malformed body, an unsupported field -- since those
 * fail identically however many times they are sent, and hiding them behind
 * three attempts only delays the message that explains what to fix.
 *
 * Placed around every provider by [ProviderFactory], so chat, agent steps, the
 * summariser and the titler inherit it without asking. Capability probing stays
 * outside deliberately: [ProviderProbe] builds its own requests, and a probe has
 * to see the raw rejection to learn anything from it.
 */
class RetryingProvider(
    private val delegate: AiProvider,
    private val policy: RetryPolicy = RetryPolicy()
) : AiProvider {

    override val id: String get() = delegate.id
    override val label: String get() = delegate.label
    override val models: List<AiModel> get() = delegate.models

    override fun chat(request: ChatRequest): Flow<ChatStreamEvent> = flow {
        var attempt = 0
        var waited = 0L
        var announced = false

        while (true) {
            attempt++
            var streamed = false
            var failure: AiError? = null

            delegate.chat(request)
                // Providers report failures as an event, but a socket that dies
                // mid-body throws instead. Both paths have to reach the same
                // decision, so the throw is folded into the event shape here.
                // `catch` sees upstream faults only, so a cancelled collector
                // still cancels rather than being mistaken for a provider fault.
                .catch { cause -> emit(ChatStreamEvent.Failure(cause.toAiError())) }
                .collect { event ->
                    when (event) {
                        // One Started per request, not one per attempt: consumers
                        // read it as "the answer begins here" and clear what they
                        // are holding when it arrives.
                        ChatStreamEvent.Started -> if (!announced) {
                            announced = true
                            emit(event)
                        }

                        is ChatStreamEvent.Delta -> {
                            streamed = true
                            emit(event)
                        }

                        // Forwarded, but deliberately not counted as `streamed`:
                        // thinking text and keep-alives never reach the screen, so
                        // a retry after them still cannot print an answer twice --
                        // while swallowing them here would hide the only proof
                        // that a slow reasoning phase is alive.
                        is ChatStreamEvent.Reasoning -> emit(event)

                        ChatStreamEvent.Heartbeat -> emit(event)

                        is ChatStreamEvent.Completed -> {
                            streamed = true
                            emit(event)
                        }

                        // Held back rather than forwarded: whether this ends the
                        // request is decided below, once the stream has finished.
                        is ChatStreamEvent.Failure -> failure = event.error
                    }
                }

            val error = failure ?: return@flow
            val pause = if (streamed) null else policy.delayFor(error, attempt, waited)
            if (pause == null) {
                emit(ChatStreamEvent.Failure(error))
                return@flow
            }
            // delay() is cancellable, so stopping generation during a backoff
            // stops it now instead of after the wait.
            delay(pause)
            waited += pause
        }
    }
}
