package com.sirius.chat.ai.provider

import com.sirius.chat.ai.capability.EndpointCapabilityTable
import com.sirius.chat.ai.capability.PowerWire

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiContentPart
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.AiToolCall
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.streaming.SseParser
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.TokenUsage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.job
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Anthropic Messages API. The wire format differs enough from OpenAI (system
 * prompt is a top level field, deltas arrive as typed events) to justify its
 * own implementation rather than a shared adapter full of conditionals.
 */
class AnthropicProvider(
    private val config: ProviderConfig,
    private val apiKey: String?,
    private val client: OkHttpClient = HttpClientProvider.client
) : AiProvider {

    override val id: String = config.id
    override val label: String = config.label
    override val models: List<AiModel> = config.models

    private val json = Json { ignoreUnknownKeys = true }

    override fun chat(request: ChatRequest): Flow<ChatStreamEvent> = flow {
        emit(ChatStreamEvent.Started)

        // Anthropic requires alternating user/assistant turns starting with user.
        val normalised = normaliseTurns(request)

        // `max_tokens` is required here and is never renamed, so only the
        // temperature is in question: an extended-thinking model accepts its own
        // default and nothing else, and says so with a 400 that used to cost the
        // whole turn.
        val quirks = ModelQuirks.of(config.id, request.model)

        val capabilities = EndpointCapabilityTable.narrow(
            EndpointCapabilityTable.of(config, request.model),
            quirks
        )
        val powerFields = PowerWire.fields(request.params.power, capabilities)
        // Extended thinking fixes the temperature to its default, so a thinking
        // request drops the field even on a model that otherwise accepts one.
        // Sending both is a 400 that reads as if the model were unavailable.
        val thinking = powerFields.containsKey("thinking")

        val payload = buildJsonObject {
            put("model", request.model)
            // Required here, and sized to fit the thinking budget: on this API
            // thinking is spent from the same cap as the reply, so a cap equal to
            // the budget produces a turn that thinks and then says nothing.
            put(
                "max_tokens",
                PowerWire.maxTokens(request.params.power, capabilities, request.params.maxTokens)
            )
            if (quirks.sendTemperature && !thinking) {
                put("temperature", request.params.temperature)
            }
            powerFields.forEach { (key, value) -> put(key, value) }
            put("stream", request.stream)
            request.systemPrompt?.takeIf { it.isNotBlank() }?.let { put("system", it) }
            putJsonArray("messages") {
                normalised.forEach { message ->
                    add(buildJsonObject {
                        put("role", if (message.role == AiRole.Assistant) "assistant" else "user")
                        putJsonArray("content") {
                            // Blocks in the order the user assembled them. A message
                            // without attachments still sends exactly one text block,
                            // byte for byte what it sent before.
                            if (message.parts.isEmpty()) {
                                add(textBlock(message.content))
                            } else {
                                message.parts.forEach { part -> add(contentBlock(part)) }
                            }
                        }
                    })
                }
            }
            // Same idea as the OpenAI shape, under a different key: Anthropic
            // takes the schema as `input_schema` and has no `tool_choice`
            // default worth overriding.
            if (request.tools.isNotEmpty()) {
                putJsonArray("tools") {
                    request.tools.forEach { spec ->
                        add(buildJsonObject {
                            put("name", spec.name)
                            put("description", spec.description)
                            put("input_schema", schemaOf(spec.parametersJson, json))
                        })
                    }
                }
            }
        }

        // Same reason as the OpenAI path: a key with a stray newline throws
        // while the header is being built, long before anything is sent.
        val key = apiKey?.trim().orEmpty()
        if (key.isNotEmpty() && !key.isHeaderSafe()) {
            emit(ChatStreamEvent.Failure(invalidKeyError()))
            return@flow
        }

        val httpRequest = Request.Builder()
            .url(config.baseUrl.trimEnd('/') + "/messages")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .apply {
                header("Content-Type", "application/json")
                header("anthropic-version", ANTHROPIC_VERSION)
                if (key.isNotEmpty()) header("x-api-key", key)
                if (request.stream) header("Accept", "text/event-stream")
            }
            .build()

        val call = client.newCall(httpRequest)
        currentCoroutineContext().job.invokeOnCompletion { if (!call.isCanceled()) call.cancel() }

        val response = runCatching { call.execute() }.getOrElse { error ->
            emit(ChatStreamEvent.Failure(error.toAiError()))
            return@flow
        }

        response.use { httpResponse ->
            if (!httpResponse.isSuccessful) {
                val body = runCatching { httpResponse.body?.string() }.getOrNull().orEmpty()
                emit(
                    ChatStreamEvent.Failure(
                        httpError(httpResponse.code, body, httpResponse.retryHintMillis())
                    )
                )
                return@flow
            }
            val source = httpResponse.body?.source()
            if (source == null) {
                emit(
                    ChatStreamEvent.Failure(
                        AiError(
                            AiError.Kind.Server,
                            AppStrings.get(R.string.error_empty_body, fallback = "Empty response body")
                        )
                    )
                )
                return@flow
            }

            val builder = StringBuilder()
            var stopReason: String? = null
            // Extended thinking is measured, not discarded: a turn that spent
            // its whole budget thinking otherwise arrives as an empty answer.
            var reasoningChars = 0
            var usage: TokenUsage? = null
            var toolCalls: List<AiToolCall> = emptyList()
            // Keyed by the block index the stream reports, because one turn can
            // open several tool_use blocks and their argument deltas interleave.
            val toolBuffer = LinkedHashMap<Int, ToolCallBuilder>()

            if (!request.stream) {
                val text = source.readUtf8()
                val root = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
                val content = (root?.get("content") as? JsonArray)
                    ?.mapNotNull { it.jsonObject["text"]?.jsonPrimitive?.contentOrNull }
                    ?.joinToString("")
                    .orEmpty()
                stopReason = root?.get("stop_reason")?.jsonPrimitive?.contentOrNull
                usage = root?.usageBlock()
                toolCalls = (root?.get("content") as? JsonArray)?.toolUseCalls().orEmpty()
                if (content.isNotEmpty()) {
                    builder.append(content)
                    emit(ChatStreamEvent.Delta(content))
                }
            } else {
                SseParser.read(
                    source,
                    // A keep-alive is not silence. Forwarding it is what stops a
                    // long thinking phase from being read as a dead stream.
                    onKeepAlive = { emit(ChatStreamEvent.Heartbeat) }
                ) { event ->
                    val parsed = runCatching { json.parseToJsonElement(event.data).jsonObject }.getOrNull()
                    // Every frame is proof of life, whatever it turns out to
                    // carry: a ping, a block boundary, or a type added since.
                    emit(ChatStreamEvent.Heartbeat)
                    when (parsed?.get("type")?.jsonPrimitive?.contentOrNull) {
                        "content_block_start" -> {
                            // A tool call announces itself here, with its id and
                            // name; only the arguments are streamed afterwards.
                            val block = parsed?.get("content_block") as? JsonObject
                            if ((block?.get("type") as? JsonPrimitive)?.contentOrNull == "tool_use") {
                                val index = parsed?.blockIndex(toolBuffer.size) ?: toolBuffer.size
                                val slot = toolBuffer.getOrPut(index) { ToolCallBuilder() }
                                slot.id = (block["id"] as? JsonPrimitive)?.contentOrNull
                                slot.name = (block["name"] as? JsonPrimitive)?.contentOrNull
                            }
                        }
                        "content_block_delta" -> {
                            val delta = parsed?.get("delta") as? JsonObject
                            val chunk = (delta?.get("text") as? JsonPrimitive)?.contentOrNull
                            if (!chunk.isNullOrEmpty()) {
                                builder.append(chunk)
                                emit(ChatStreamEvent.Delta(chunk))
                            }
                            // Tool arguments arrive as a delta type of their own,
                            // one JSON fragment at a time, and parse only once the
                            // block has closed -- so they are buffered here and
                            // never appended to the answer the user reads.
                            val partial =
                                (delta?.get("partial_json") as? JsonPrimitive)?.contentOrNull
                            if (!partial.isNullOrEmpty()) {
                                toolBuffer.getOrPut(parsed?.blockIndex(0) ?: 0) { ToolCallBuilder() }
                                    .arguments.append(partial)
                            }
                            // Extended thinking streams through the same event
                            // under a delta field of its own. It never joins the
                            // answer, but it is counted and forwarded: on a model
                            // that thinks for minutes this is the only traffic
                            // there is, and dropping it is what used to make the
                            // agent give up on a model that was working.
                            val thinking =
                                (delta?.get("thinking") as? JsonPrimitive)?.contentOrNull
                            if (!thinking.isNullOrEmpty()) {
                                reasoningChars += thinking.length
                                emit(ChatStreamEvent.Reasoning(thinking))
                            }
                        }
                        "message_start" -> {
                            // Anthropic sends the input count once, here, and the output
                            // count later in message_delta. Neither event repeats the other.
                            usage = mergeUsage(usage, parsed["message"]?.jsonObject?.usageBlock())
                        }
                        "message_delta" -> {
                            stopReason = parsed["delta"]?.jsonObject
                                ?.get("stop_reason")?.jsonPrimitive?.contentOrNull ?: stopReason
                                usage = mergeUsage(usage, parsed.usageBlock())
                        }
                        "error" -> {
                            val message = parsed["error"]?.jsonObject
                                ?.get("message")?.jsonPrimitive?.contentOrNull
                            emit(
                                ChatStreamEvent.Failure(
                                    AiError(
                                        AiError.Kind.Server,
                                        message ?: AppStrings.get(
                                            R.string.error_provider,
                                            fallback = "Provider error"
                                        )
                                    )
                                )
                            )
                            return@read false
                        }
                    }
                    true
                }
            }

            if (toolBuffer.isNotEmpty()) toolCalls = toolBuffer.reassemble()
            emit(
                ChatStreamEvent.Completed(
                    stopReason,
                    builder.toString(),
                    reasoningChars = reasoningChars,
                    usage = usage,
                    toolCalls = toolCalls
                )
            )
        }
    }.flowOn(Dispatchers.IO)

    /** The `index` a content-block event refers to, or [fallback]. */
    private fun JsonObject.blockIndex(fallback: Int): Int =
        (this["index"] as? JsonPrimitive)?.contentOrNull?.toIntOrNull() ?: fallback

    /**
     * Tool calls among the content blocks of a non-streamed reply.
     *
     * Anthropic returns them inline with the text blocks rather than in a field
     * of their own, so the array is filtered by block type. `input` is already a
     * complete object here; it is re-encoded to text only because that is the
     * shape a streamed call has to arrive in, and one shape downstream beats two.
     */
    private fun JsonArray.toolUseCalls(): List<AiToolCall> =
        mapIndexedNotNull { position, element ->
            val obj = element as? JsonObject ?: return@mapIndexedNotNull null
            if ((obj["type"] as? JsonPrimitive)?.contentOrNull != "tool_use") {
                return@mapIndexedNotNull null
            }
            val name = (obj["name"] as? JsonPrimitive)?.contentOrNull
                ?.takeIf { it.isNotBlank() } ?: return@mapIndexedNotNull null
            AiToolCall(
                id = (obj["id"] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }
                    ?: "call_$position",
                name = name,
                argumentsJson = (obj["input"] as? JsonObject)?.toString() ?: "{}"
            )
        }

    /** Input and output counts from a `usage` block, wherever it appears. */
    private fun JsonObject.usageBlock(): TokenUsage? {
        val block = this["usage"]?.jsonObject ?: return null
        fun field(name: String) =
            runCatching { block[name]?.jsonPrimitive?.contentOrNull?.toIntOrNull() }.getOrNull() ?: 0
        val prompt = field("input_tokens")
        val completion = field("output_tokens")
        if (prompt <= 0 && completion <= 0) return null
        return TokenUsage(prompt, completion)
    }

    /** Highest of each field, since the two events each report only their half. */
    private fun mergeUsage(current: TokenUsage?, incoming: TokenUsage?): TokenUsage? {
        if (incoming == null) return current
        if (current == null) return incoming
        return TokenUsage(
            promptTokens = maxOf(current.promptTokens, incoming.promptTokens),
            completionTokens = maxOf(current.completionTokens, incoming.completionTokens)
        )
    }

    private fun normaliseTurns(request: ChatRequest): List<AiMessage> = buildList<AiMessage> {
        var expectUser = true
        request.messages.filter { it.role != AiRole.System }.forEach { message ->
            val isUser = message.role == AiRole.User
            if (isUser == expectUser) {
                add(message)
                expectUser = !expectUser
            } else if (isNotEmpty()) {
                // Merge consecutive same-role turns instead of dropping content.
                // Blocks are concatenated in the same order, so a merged turn keeps
                // its images: rebuilding it from `content` alone would silently drop
                // every attachment in the earlier of the two turns.
                val last = removeAt(lastIndex)
                add(
                    last.copy(
                        content = last.content + "\n\n" + message.content,
                        parts = if (last.parts.isEmpty() && message.parts.isEmpty()) {
                            emptyList()
                        } else {
                            blocksOf(last) + blocksOf(message)
                        }
                    )
                )
            } else if (isUser) {
                add(message)
                expectUser = false
            }
        }
        if (isEmpty() || last().role == AiRole.Assistant) {
            // The API requires the conversation to end with a user turn.
            if (isNotEmpty()) removeAt(lastIndex)
        }
    }

    private companion object {
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        const val ANTHROPIC_VERSION = "2023-06-01"
    }

    /** A message as blocks, whatever it was built from. */
    private fun blocksOf(message: AiMessage): List<AiContentPart> =
        message.parts.ifEmpty { listOf(AiContentPart.Text(message.content)) }

    private fun textBlock(text: String): JsonObject = buildJsonObject {
        put("type", "text")
        put("text", text)
    }

    /**
     * One content block in Anthropic's wire format.
     *
     * Images and PDFs use the same `source` envelope with a different block type,
     * which is why they are built together rather than in two places.
     */
    private fun contentBlock(part: AiContentPart): JsonObject = when (part) {
        is AiContentPart.Text -> textBlock(part.text)
        is AiContentPart.Image -> buildJsonObject {
            put("type", "image")
            putJsonObject("source") {
                put("type", "base64")
                put("media_type", part.mediaType)
                put("data", part.base64)
            }
        }
        is AiContentPart.Document -> buildJsonObject {
            put("type", "document")
            putJsonObject("source") {
                put("type", "base64")
                put("media_type", part.mediaType)
                put("data", part.base64)
            }
        }
    }

}
