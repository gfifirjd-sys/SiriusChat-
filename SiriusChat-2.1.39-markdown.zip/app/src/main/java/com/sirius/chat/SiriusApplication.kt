package com.sirius.chat

import android.app.Application
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.core.util.CrashReporter
import com.sirius.chat.di.AppContainer

class SiriusApplication : Application() {

    /** Created eagerly but populated lazily; nothing heavy runs at startup. */
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        // Installed before anything else so a failure in the lines below, or
        // anywhere later, still leaves a readable trace on disk.
        CrashReporter.install(this)
        container = AppContainer(this)
        // Lets non-Compose layers (transport, use cases, terminal) localize too.
        AppStrings.install(container.strings)
    }
}
