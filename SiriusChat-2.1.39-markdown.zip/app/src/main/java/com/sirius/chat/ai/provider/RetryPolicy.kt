package com.sirius.chat.ai.provider

import com.sirius.chat.ai.model.AiError
import okhttp3.Response
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

/**
 * When a failed request may be tried again, and how long to wait first.
 *
 * Two rules shape every number here. A wait the provider asked for beats a wait
 * this app invented: retrying before its window resets earns another 429 and
 * nothing else. And the total wait is bounded, because on a phone a request that
 * silently sleeps for a minute is indistinguishable from a frozen app -- past
 * the bound the error is shown and the person decides what to do.
 */
data class RetryPolicy(
    /** Attempts in total, not extra ones: 3 means one try and two retries. */
    val maxAttempts: Int = 3,
    val baseDelayMs: Long = 700L,
    /**
     * Rate limits start higher than dropped sockets. A 429 says a window is
     * genuinely full, and 700 ms later it almost always still is.
     */
    val rateLimitBaseDelayMs: Long = 2_000L,
    val maxDelayMs: Long = 8_000L,
    /**
     * A `Retry-After` longer than this is reported instead of slept on: the
     * provider is asking for a pause no foreground request should hide.
     */
    val maxHintMs: Long = 20_000L,
    /** Ceiling on all waiting within one request, provider hints included. */
    val maxTotalWaitMs: Long = 25_000L,
    /** Plus or minus 25 %, so devices that failed together do not return together. */
    val jitter: Double = 0.25
) {

    /**
     * Milliseconds to wait before the next attempt, or `null` when this request
     * is finished -- the fault is permanent, the attempts are spent, or the wait
     * no longer fits the budget.
     */
    fun delayFor(error: AiError, attempt: Int, waitedMs: Long): Long? {
        if (attempt >= maxAttempts) return null
        if (!error.isRetryable) return null

        val hint = error.retryAfterMillis
        val wait = when {
            hint == null -> {
                val base =
                    if (error.kind == AiError.Kind.RateLimited) rateLimitBaseDelayMs
                    else baseDelayMs
                val grown = base.toDouble() * 2.0.pow(attempt - 1)
                spread(min(grown, maxDelayMs.toDouble()).toLong())
            }
            hint > maxHintMs -> return null
            // Later than asked is harmless, earlier is not: the hint marks the
            // edge of the window, and crossing it early wastes the attempt.
            else -> hint + extra(hint)
        }
        if (waitedMs + wait > maxTotalWaitMs) return null
        return wait.coerceAtLeast(0L)
    }

    private fun spread(value: Long): Long {
        val width = (value * jitter).toLong()
        if (width <= 0L) return value
        return (value + Random.nextLong(-width, width + 1)).coerceAtLeast(0L)
    }

    private fun extra(value: Long): Long {
        val width = (value * jitter).toLong()
        return if (width <= 0L) 0L else Random.nextLong(0L, width + 1)
    }
}

/** Headers that state a wait as a duration: "6m0s", "1.5s", "300ms", "20". */
private val RESET_DURATION_HEADERS = listOf(
    "x-ratelimit-reset-requests",
    "x-ratelimit-reset-tokens",
    "x-ratelimit-reset"
)

/** Headers that state the moment the window reopens, as an ISO-8601 instant. */
private val RESET_INSTANT_HEADERS = listOf(
    "anthropic-ratelimit-requests-reset",
    "anthropic-ratelimit-tokens-reset",
    "anthropic-ratelimit-input-tokens-reset"
)

private val durationField = Regex("([0-9]+(?:\\.[0-9]+)?)\\s*(ms|s|m|h)")

/** Past a day the header is not a wait, it is a value read the wrong way. */
private const val MAX_PLAUSIBLE_HINT_MS = 24L * 60L * 60L * 1000L

/** Bare numbers this large are unix timestamps, not durations. */
private const val EPOCH_SECONDS_FLOOR = 1_000_000_000.0

/**
 * How long the provider asked the client to wait, or `null` when it said
 * nothing usable.
 *
 * `Retry-After` is the standard answer and is read first, in both of its legal
 * shapes -- seconds, or an HTTP date. Vendors that omit it still publish when
 * their window reopens, so those headers are read next: the difference matters,
 * because a retry sent before the window reopens is guaranteed to fail again.
 */
internal fun Response.retryHintMillis(): Long? {
    header("Retry-After")?.let { raw -> retryAfterMillis(raw)?.let { return it } }
    for (name in RESET_DURATION_HEADERS) {
        header(name)?.let { raw -> durationMillis(raw)?.let { return it } }
    }
    for (name in RESET_INSTANT_HEADERS) {
        header(name)?.let { raw -> instantMillis(raw)?.let { return it } }
    }
    return null
}

private fun retryAfterMillis(raw: String): Long? {
    val text = raw.trim()
    if (text.isEmpty()) return null
    text.toDoubleOrNull()?.let { seconds -> return plausible((seconds * 1_000).toLong()) }
    val instant = runCatching {
        ZonedDateTime.parse(text, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant()
    }.recoverCatching { Instant.parse(text) }.getOrNull() ?: return null
    return plausible(instant.toEpochMilli() - System.currentTimeMillis())
}

private fun durationMillis(raw: String): Long? {
    val text = raw.trim().lowercase()
    if (text.isEmpty()) return null
    text.toDoubleOrNull()?.let { value ->
        // Gateways disagree about bare numbers: some mean seconds, some send a
        // unix timestamp. Read as a duration, a timestamp looks like a fifty
        // year wait and would silence retries entirely, so it is caught by size.
        if (value >= EPOCH_SECONDS_FLOOR) {
            return plausible((value * 1_000).toLong() - System.currentTimeMillis())
        }
        return plausible((value * 1_000).toLong())
    }
    var total = 0.0
    var seen = false
    for (match in durationField.findAll(text)) {
        val value = match.groupValues[1].toDoubleOrNull() ?: continue
        total += when (match.groupValues[2]) {
            "ms" -> value
            "s" -> value * 1_000
            "m" -> value * 60_000
            "h" -> value * 3_600_000
            else -> 0.0
        }
        seen = true
    }
    return if (seen) plausible(total.toLong()) else null
}

private fun instantMillis(raw: String): Long? {
    val instant = runCatching { Instant.parse(raw.trim()) }.getOrNull() ?: return null
    return plausible(instant.toEpochMilli() - System.currentTimeMillis())
}

/**
 * Keeps a stray header from stalling a request or disabling its retry: a window
 * that has already reopened means "no wait", and an implausible value means "no
 * hint at all", which leaves the ordinary backoff in charge.
 */
private fun plausible(millis: Long): Long? = when {
    millis > MAX_PLAUSIBLE_HINT_MS -> null
    millis <= 0L -> 0L
    else -> millis
}
