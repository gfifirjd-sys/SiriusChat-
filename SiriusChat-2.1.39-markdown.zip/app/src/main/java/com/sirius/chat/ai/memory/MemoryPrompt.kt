package com.sirius.chat.ai.memory

import com.sirius.chat.domain.model.MemoryNode
import com.sirius.chat.domain.model.memoryPath

/**
 * Turns stored facts into the block that goes at the end of the system prompt.
 *
 * ### Why the rules travel with the facts
 * A bare list of facts makes a model perform them: it opens with "As a Kotlin
 * developer working on Sirius, ..." when the question was about a shell script.
 * The instructions below are what turn recall into behaviour -- use it when it
 * changes the answer, never announce it, and never volunteer a sensitive
 * subject the user has not raised in this conversation.
 *
 * ### Why the facts arrive grouped by file
 * The same grouping the extractor writes into and the graph draws lines for. A
 * model reading five loose lines about food and one about a deadline treats them
 * as six equal trivia; reading them under `/topics/food.md` it can tell which
 * ones belong together, and it is far likelier to file the next one in the same
 * place instead of inventing a neighbouring heading.
 *
 * ### Why there is a budget
 * This block is prepended to every single request in the chat, so its size is
 * paid for on every turn, forever. Newest first inside the cap, because a fact
 * learned this week describes the user better than one learned in March.
 */
object MemoryPrompt {

    /** The block for [nodes], or null when there is nothing worth sending. */
    fun block(nodes: List<MemoryNode>): String? {
        if (nodes.isEmpty()) return null

        // Pick first, group second: the cap has to fall on the least recently
        // touched facts overall, not on whichever file happens to sort last.
        val chosen = ArrayList<MemoryNode>()
        var budget = MAX_CHARS
        for (node in nodes.sortedByDescending { it.updatedAt }) {
            val content = line(node)
            if (content.isEmpty()) continue
            if (chosen.isNotEmpty() && budget - content.length < 0) break
            budget -= content.length
            chosen += node
            if (chosen.size >= MAX_FACTS) break
        }
        if (chosen.isEmpty()) return null

        val files = LinkedHashMap<String, MutableList<MemoryNode>>()
        for (node in chosen) files.getOrPut(node.memoryPath()) { ArrayList() } += node

        return buildString {
            appendLine(HEADER)
            for ((path, group) in files) {
                appendLine()
                appendLine(path)
                for (node in group) appendLine("- " + line(node) + " [stated]")
            }
            appendLine()
            appendLine(RULES)
        }.trim()
    }

    private fun line(node: MemoryNode): String =
        node.content.trim().replace('\n', ' ').take(MAX_FACT_CHARS)

    private const val HEADER =
        "Long-term memory about this user, carried over from earlier conversations. " +
            "These are facts about the person, filed by subject -- not a transcript. " +
            "Every line is something the user stated themselves:"

    private const val RULES =
        "How to use it: rely on a fact only when it changes the answer. Never say that " +
            "you remember, never refer to \"your memory\" or \"stored data\", and never " +
            "list these facts back to the user -- just answer as someone who already " +
            "knows them. One line is one thing the user said once, not a label: \"likes " +
            "ice cream\" does not make them a dessert person, and nothing here should be " +
            "widened into a summary of who they are. If a fact contradicts what the user " +
            "says now, the user is right. " +
            "Do not raise health, sexuality, religion or politics from memory unless the " +
            "user brings the subject up in this conversation."

    /** Enough to describe a person; past this it is a transcript again. */
    private const val MAX_FACTS = 40

    private const val MAX_CHARS = 2_400

    private const val MAX_FACT_CHARS = 160
}
