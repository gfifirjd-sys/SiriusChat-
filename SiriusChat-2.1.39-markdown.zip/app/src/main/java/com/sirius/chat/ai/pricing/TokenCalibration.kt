package com.sirius.chat.ai.pricing

import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Learns how many characters a token is worth, per model, from real answers.
 *
 * ### Why 3.5 was not enough
 * [TokenEstimate.CHARS_PER_TOKEN] is an average of English prose. Cyrillic runs
 * closer to two characters per token and dense code closer to three, so on a
 * Russian conversation the estimate can be half the real count. Everything
 * downstream inherits that error: the meter above the composer reads 60% while
 * the prompt is already full, the compactor waits for a threshold it reaches
 * too late, and the turn dies on a context-overflow the app said was far away.
 *
 * ### Where the truth comes from
 * Providers report `usage.prompt_tokens` for the exact text just sent, so the
 * ratio does not have to be guessed at all -- it can be measured, once per
 * turn, for free. Each observation is folded in with a smoothing factor rather
 * than replacing the last: one turn dominated by an attachment or a tool schema
 * is not representative, and a ratio that swings per message would make the
 * meter jump for no visible reason.
 *
 * Kept in memory. Two turns rebuild it, and a stale ratio carried across an app
 * update -- possibly for a model whose tokenizer changed -- is worth less than
 * the default it would be overriding.
 */
object TokenCalibration {

    private val ratios = ConcurrentHashMap<String, Float>()

    /** Characters per token for this model, or the shared default until measured. */
    fun charsPerToken(modelId: String?): Float {
        val id = modelId?.lowercase(Locale.US).orEmpty()
        if (id.isEmpty()) return TokenEstimate.CHARS_PER_TOKEN
        return ratios[id] ?: TokenEstimate.CHARS_PER_TOKEN
    }

    /** Tokens in [text] for this model, using whatever has been learned so far. */
    fun tokens(text: String, modelId: String?): Int =
        if (text.isEmpty()) 0 else (text.length / charsPerToken(modelId)).toInt().coerceAtLeast(1)

    /**
     * Folds one measured prompt into the running ratio.
     *
     * Short prompts are ignored: a two-word message is mostly the fixed cost of
     * the message envelope, which would drag the ratio toward nonsense. The
     * result is clamped because a provider that reports cached or reused prompt
     * tokens can produce a ratio of twenty, and one bad sample must not be able
     * to tell the app a 200k window is empty.
     */
    fun record(modelId: String?, promptChars: Int, promptTokens: Int) {
        val id = modelId?.lowercase(Locale.US).orEmpty()
        if (id.isEmpty() || promptChars < MIN_SAMPLE_CHARS || promptTokens <= 0) return

        val observed = (promptChars.toFloat() / promptTokens).coerceIn(MIN_RATIO, MAX_RATIO)
        val current = ratios[id]
        ratios[id] = if (current == null) observed else current + (observed - current) * SMOOTHING
    }

    /** How much of each new observation is kept. Low enough to stay steady. */
    private const val SMOOTHING = 0.3f

    /** Below this, the envelope outweighs the content and the sample lies. */
    private const val MIN_SAMPLE_CHARS = 400

    /** No real tokenizer packs more than this. */
    private const val MIN_RATIO = 1.2f

    /** Nor less. Anything outside the range is a reporting quirk, not a measurement. */
    private const val MAX_RATIO = 6f
}
