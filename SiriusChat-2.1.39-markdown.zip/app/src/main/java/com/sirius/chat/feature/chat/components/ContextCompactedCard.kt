package com.sirius.chat.feature.chat.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.ai.context.ContextCompactor
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.domain.model.ChatMessage

/**
 * The marker left in the transcript where a compaction happened.
 *
 * ### Why it is visible at all
 * Compaction changes what the model can see, and a change like that has to be
 * legible or it becomes the explanation for every later oddity that the user
 * cannot check. A centred divider says "the conversation was folded here";
 * opening it shows exactly what was kept. Nothing was deleted -- the original
 * turns are still above it, in the transcript and in the database -- and being
 * able to read the summary is what makes that believable.
 *
 * ### Why a separator rather than a bubble
 * It is not a turn. Nobody said it, it has no author, and it should not carry
 * copy, edit or regenerate actions. Drawn as a rule across the thread it reads
 * as punctuation in the conversation, which is what it is.
 */
@Composable
fun ContextCompactedCard(
    message: ChatMessage,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val body = remember(message.content) { ContextCompactor.summaryBody(message.content) }
    var expanded by remember(message.id) { mutableStateOf(false) }
    val chevron by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = siriusTween(SiriusMotion.Quick, SiriusMotion.Standard),
        label = "compactedChevron"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = SiriusSpacing.xs),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
        ) {
            Rule(Modifier.weight(1f))
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(SiriusRadius.pill))
                    .softSurface(RoundedCornerShape(SiriusRadius.pill))
                    .then(
                        // Nothing to open when the summary is somehow empty, and a
                        // control that does nothing is worse than no control.
                        if (body.isBlank()) Modifier else Modifier.clickable(role = Role.Button) {
                            haptics.light()
                            expanded = !expanded
                        }
                    )
                    .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xxs),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Compress,
                    contentDescription = null,
                    tint = colors.textSecondary,
                    modifier = Modifier.size(IconSize)
                )
                Text(
                    text = stringResource(R.string.chat_context_compacted),
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textSecondary
                )
                if (body.isNotBlank()) {
                    Icon(
                        imageVector = Icons.Rounded.ExpandMore,
                        contentDescription = null,
                        tint = colors.textTertiary,
                        modifier = Modifier
                            .size(IconSize)
                            .graphicsLayer { rotationZ = chevron }
                    )
                }
            }
            Rule(Modifier.weight(1f))
        }

        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(siriusTween(SiriusMotion.Quick, SiriusMotion.Standard)) +
                expandVertically(siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)),
            exit = fadeOut(siriusTween(SiriusMotion.Instant, SiriusMotion.Exit)) +
                shrinkVertically(siriusTween(SiriusMotion.Quick, SiriusMotion.Exit))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(SiriusRadius.md))
                    .softSurface(RoundedCornerShape(SiriusRadius.md), alpha = 0.7f)
                    .padding(SiriusSpacing.sm),
                verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
            ) {
                Text(
                    text = stringResource(R.string.chat_context_compacted_detail),
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary
                )
                // Rendered as markdown because the summary is written as labelled
                // bullets with paths in backticks, and this is the renderer that
                // already knows what to do with those.
                MarkdownText(markdown = body, codeFontSize = 12)
            }
        }
    }
}

/** One hairline of the divider the pill sits in. */
@Composable
private fun Rule(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(1.dp)
            .background(SiriusTheme.colors.outline.copy(alpha = RuleAlpha))
    )
}

private val IconSize = 14.dp
private const val RuleAlpha = 0.35f
