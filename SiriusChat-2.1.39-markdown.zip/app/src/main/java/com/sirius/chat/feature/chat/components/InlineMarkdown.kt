package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.LinkInteractionListener
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import com.sirius.chat.core.util.ColorTokens

/**
 * Inline markdown: bold, italic, inline code, strikethrough, links and colour
 * swatches. Deliberately single-pass and allocation-light because it runs on
 * every token while an answer streams in.
 *
 * Two things go beyond text styling. Links are real [LinkAnnotation.Url]s, so
 * they are tappable and screen-reader-announced instead of merely being blue.
 * And any colour literal — in code or in prose — gets an inline swatch
 * placeholder, which is the only way `#3B82F6` becomes readable in a chat
 * bubble. The swatch ids are returned rather than resolved here because the
 * chips are composables and this is a pure function.
 */
object InlineMarkdown {

    /** Rendered span text plus the swatch ids it references, in first-use order. */
    data class Inline(
        val text: AnnotatedString,
        val swatches: List<Pair<String, Color>>
    )

    fun render(
        text: String,
        codeColor: Color,
        codeBackground: Color,
        linkColor: Color,
        /**
         * Who gets the tap. Null keeps the platform default — straight out to the
         * browser — which is what previews and any caller that has not opted in
         * still get. The app passes one so a link can also be downloaded,
         * photographed or opened as a picture; see LinkActionsHost.
         */
        onLink: LinkInteractionListener? = null,
        /**
         * Background for `==marked==` runs. Defaults to the code background so a
         * caller that never thought about highlighting still draws something
         * visible instead of marking text with nothing.
         */
        highlightBackground: Color = codeBackground
    ): Inline {
        val swatches = LinkedHashMap<String, Color>()
        val annotated = buildAnnotatedString {
            var index = 0
            while (index < text.length) {
                when {
                    // The escape is checked first, or the character it protects is
                    // read as the very marker it was escaping.
                    text.startsWith("\\", index) &&
                        ESCAPABLE.contains(text.getOrNull(index + 1) ?: ' ') -> {
                        append(text[index + 1])
                        index += 2
                    }

                    // Double backticks: inline code that contains a backtick.
                    text.startsWith("``", index) -> {
                        val end = text.indexOf("``", index + 2)
                        if (end > 0) {
                            pushStyle(
                                SpanStyle(
                                    fontFamily = FontFamily.Monospace,
                                    color = codeColor,
                                    background = codeBackground
                                )
                            )
                            append(text.substring(index + 2, end))
                            pop()
                            index = end + 2
                        } else {
                            append(text[index]); index++
                        }
                    }

                    text.startsWith("==", index) -> {
                        val end = text.indexOf("==", index + 2)
                        // `a == b` is a comparison, not a highlight. The marks have
                        // to hug the text they cover, or every equality in an
                        // unquoted line paints the words between two of them.
                        val hugs = end > index + 2 &&
                            !text[index + 2].isWhitespace() &&
                            !text[end - 1].isWhitespace()
                        if (hugs) {
                            pushStyle(SpanStyle(background = highlightBackground))
                            appendColorAware(text.substring(index + 2, end), swatches)
                            pop()
                            index = end + 2
                        } else {
                            append(text[index]); index++
                        }
                    }

                    // `[^1]` is a footnote marker, not a link. Checked before the
                    // link branch so that branch never sees it.
                    text.startsWith("[^", index) -> {
                        val end = text.indexOf(']', index + 2)
                        val id = if (end > index + 2) text.substring(index + 2, end) else ""
                        // An id is one word. Requiring that keeps `[^\d]` and the
                        // other inline regexes this app is full of out of the
                        // superscript.
                        if (id.isNotEmpty() && id.all { it.isLetterOrDigit() || it == '-' || it == '_' }) {
                            pushStyle(
                                SpanStyle(
                                    baselineShift = BaselineShift.Superscript,
                                    color = linkColor
                                )
                            )
                            append(id)
                            pop()
                            index = end + 1
                        } else {
                            append(text[index]); index++
                        }
                    }

                    // `<https://…>`: a link whose label is the address itself.
                    text.startsWith("<http", index) -> {
                        val end = text.indexOf('>', index + 1)
                        if (end > 0) {
                            val url = text.substring(index + 1, end)
                            withLink(urlAnnotation(url, linkColor, onLink)) { append(url) }
                            index = end + 1
                        } else {
                            append(text[index]); index++
                        }
                    }

                    // A break the author wrote as HTML, which is the only way to
                    // split a line inside a table cell.
                    text.startsWith("<br", index) -> {
                        val end = text.indexOf('>', index)
                        if (end in index until index + 6) {
                            append('\n')
                            index = end + 1
                        } else {
                            append(text[index]); index++
                        }
                    }

                    // A bare address. Chat is full of them, and one that cannot be
                    // tapped reads as a broken app rather than as plain text.
                    text.startsWith("http://", index) || text.startsWith("https://", index) -> {
                        val end = urlEnd(text, index)
                        val url = text.substring(index, end)
                        withLink(urlAnnotation(url, linkColor, onLink)) { append(url) }
                        index = end
                    }

                    text.startsWith("**", index) -> {
                        val end = text.indexOf("**", index + 2)
                        if (end > 0) {
                            pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                            appendColorAware(text.substring(index + 2, end), swatches)
                            pop()
                            index = end + 2
                        } else {
                            append(text[index]); index++
                        }
                    }

                    text.startsWith("`", index) -> {
                        val end = text.indexOf('`', index + 1)
                        if (end > 0) {
                            pushStyle(
                                SpanStyle(
                                    fontFamily = FontFamily.Monospace,
                                    color = codeColor,
                                    background = codeBackground
                                )
                            )
                            appendColorAware(text.substring(index + 1, end), swatches)
                            pop()
                            index = end + 1
                        } else {
                            append(text[index]); index++
                        }
                    }

                    text.startsWith("*", index) || text.startsWith("_", index) -> {
                        val marker = text[index]
                        val end = emphasisEnd(text, index, marker)
                        if (end > index + 1) {
                            pushStyle(SpanStyle(fontStyle = FontStyle.Italic))
                            appendColorAware(text.substring(index + 1, end), swatches)
                            pop()
                            index = end + 1
                        } else {
                            append(text[index]); index++
                        }
                    }

                    text.startsWith("~~", index) -> {
                        val end = text.indexOf("~~", index + 2)
                        if (end > 0) {
                            pushStyle(SpanStyle(textDecoration = TextDecoration.LineThrough))
                            append(text.substring(index + 2, end))
                            pop()
                            index = end + 2
                        } else {
                            append(text[index]); index++
                        }
                    }

                    text.startsWith("[", index) -> {
                        val labelEnd = text.indexOf(']', index)
                        val urlStart = if (labelEnd > 0) labelEnd + 1 else -1
                        if (labelEnd > 0 && urlStart < text.length && text.getOrNull(urlStart) == '(') {
                            val urlEnd = text.indexOf(')', urlStart)
                            if (urlEnd > 0) {
                                val label = text.substring(index + 1, labelEnd)
                                val url = text.substring(urlStart + 1, urlEnd)
                                withLink(
                                    LinkAnnotation.Url(
                                        url = url,
                                        styles = TextLinkStyles(
                                            style = SpanStyle(
                                                color = linkColor,
                                                textDecoration = TextDecoration.Underline
                                            )
                                        ),
                                        linkInteractionListener = onLink
                                    )
                                ) {
                                    append(label)
                                }
                                index = urlEnd + 1
                            } else {
                                append(text[index]); index++
                            }
                        } else {
                            append(text[index]); index++
                        }
                    }

                    else -> {
                        // Plain run: consume up to the next marker in one go so
                        // colour scanning happens on whole words, not characters.
                        val next = nextMarker(text, index + 1)
                        appendColorAware(text.substring(index, next), swatches)
                        index = next
                    }
                }
            }
        }
        return Inline(annotated, swatches.entries.map { it.key to it.value })
    }

    /** One link style for every form an address can arrive in. */
    private fun urlAnnotation(
        url: String,
        linkColor: Color,
        onLink: LinkInteractionListener?
    ): LinkAnnotation.Url = LinkAnnotation.Url(
        url = url,
        styles = TextLinkStyles(
            style = SpanStyle(
                color = linkColor,
                textDecoration = TextDecoration.Underline
            )
        ),
        linkInteractionListener = onLink
    )

    /**
     * Where a bare address ends: at whitespace or a bracket that was never part
     * of it, and short of the punctuation that ends the sentence around it.
     *
     * Without the second pass, "see https://sirius.dev." links the full stop as
     * well and the address 404s when tapped.
     */
    private fun urlEnd(text: String, start: Int): Int {
        var end = start
        while (end < text.length && !text[end].isWhitespace() && text[end] !in "<>\"'`") end++
        while (end > start && text[end - 1] in ".,;:!?)]}") end--
        return end
    }

    /** Stable id for a swatch chip: same colour, same key, one map entry. */
    fun swatchId(color: Color): String = "sw:" + color.toArgb().toUInt().toString(16)

    private fun AnnotatedString.Builder.appendColorAware(
        run: String,
        swatches: MutableMap<String, Color>
    ) {
        val matches = ColorTokens.findAll(run)
        if (matches.isEmpty()) {
            append(run)
            return
        }
        var cursor = 0
        for (match in matches) {
            if (match.range.first > cursor) append(run.substring(cursor, match.range.first))
            val id = swatchId(match.color)
            swatches[id] = match.color
            appendInlineContent(id, "\u25FB")
            append(match.text)
            cursor = match.range.last + 1
        }
        if (cursor < run.length) append(run.substring(cursor))
    }

    /**
     * Where the italic run opened at [start] closes, or -1 if it never does.
     *
     * ### Why underscores are stricter than asterisks
     * `tool_calls` is not emphasis, and treating it as such is how a tool name
     * reached the transcript as "tool*calls*" with its middle italicised.
     * CommonMark answers this with the flanking rule; this is the useful half
     * of it. An underscore touching a word character is a literal underscore,
     * both when opening and when closing, so snake_case survives intact and
     * `_really_` still works.
     */
    private fun emphasisEnd(text: String, start: Int, marker: Char): Int {
        if (text.startsWith("$marker$marker", start)) return -1
        if (marker == '_' && text.getOrNull(start - 1)?.isWordChar() == true) return -1
        var i = start + 1
        while (true) {
            val at = text.indexOf(marker, i)
            if (at < 0 || at == start + 1) return -1
            if (marker != '_' || text.getOrNull(at + 1)?.isWordChar() != true) return at
            i = at + 1
        }
    }

    private fun Char.isWordChar(): Boolean = isLetterOrDigit() || this == '_'

    private fun nextMarker(text: String, from: Int): Int {
        var i = from
        while (i < text.length) {
            when {
                text[i] in MARKERS -> return i
                // Only an `h` that opens an address counts. Stopping at every `h`
                // would split the plain-run scan on one of the commonest letters
                // in the language, which is the cost this scan exists to avoid.
                text[i] == 'h' && text.startsWith("http", i) -> return i
                else -> i++
            }
        }
        return text.length
    }

    private const val MARKERS = "*_`~[<=\\"

    /** The characters a backslash may protect. */
    private const val ESCAPABLE = """\`*_{}[]()#+-.!|~<>="""
}
