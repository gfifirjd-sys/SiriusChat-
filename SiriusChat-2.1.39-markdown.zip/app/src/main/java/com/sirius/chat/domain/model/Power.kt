package com.sirius.chat.domain.model

/**
 * How hard the model is asked to work on one answer.
 *
 * ### Why this is not a token slider
 * `max_tokens` is a length cap, not an effort dial. On a reasoning model it does
 * not buy any more thinking -- it only decides where the answer gets cut off --
 * and on the o-series it is not even called that. The mode is therefore an
 * intent ("think harder") that is translated per endpoint into whatever that
 * endpoint actually understands: an effort tier, a thinking budget, or, only
 * when nothing else exists, a length.
 *
 * [CUSTOM] is the escape hatch: the user sets the underlying fields by hand, and
 * only the ones the selected endpoint really accepts are offered.
 */
enum class PowerMode { LOW, MEDIUM, HIGH, MAX, CUSTOM }

/** What a new (endpoint, model) pair starts on. */
val DefaultPowerMode: PowerMode = PowerMode.MEDIUM

/**
 * What one endpoint+model really accepts, as opposed to what a spec suggests.
 *
 * Every field is a claim about a concrete API. Nothing is written into a request
 * unless it is declared here, which is the whole point: an unknown key is a 400
 * on strict gateways (llama.cpp, older vLLM), and a 400 costs the user the turn.
 *
 * Adding a new endpoint means adding one of these. The resolver never changes.
 */
data class EndpointCapabilities(
    /** The endpoint takes a named effort tier, e.g. OpenAI's `reasoning_effort`. */
    val supportsReasoningEffort: Boolean = false,
    /**
     * The tiers this endpoint accepts, weakest first.
     *
     * A list rather than a fixed low/medium/high because providers disagree:
     * xAI's mini models take only `low` and `high`, Groq's qwen3 takes `none`
     * and `default`, and Z.ai spells the same idea as `disabled`/`enabled`. The
     * scale is read off this list, so "MAX" means "the strongest tier this
     * endpoint has" instead of a hardcoded word it may not know.
     */
    val reasoningTiers: List<String> = emptyList(),
    /** Wire path for the tier. Dots mean nesting: `reasoning.effort`. */
    val reasoningEffortKey: String = "reasoning_effort",
    /** The endpoint takes an explicit thinking budget in tokens. */
    val supportsThinkingBudget: Boolean = false,
    /** Wire path for the budget, e.g. `thinking.budget_tokens`. */
    val thinkingBudgetKey: String = "",
    /** Smallest budget the API will accept; Anthropic rejects anything under 1024. */
    val thinkingBudgetMin: Int = 0,
    /** Real ceiling for this model's budget, not a guess. */
    val thinkingBudgetMax: Int = 0,
    /**
     * Fields that must travel with a budget for it to mean anything --
     * `thinking.type = enabled` on Anthropic, `enable_thinking = true` on
     * DashScope. Kept next to the budget so a caller cannot send half of it.
     */
    val thinkingEnableFlags: Map<String, Any> = emptyMap(),
    val supportsMaxTokens: Boolean = true,
    /** The model's real output ceiling, or null when the endpoint never says. */
    val maxTokensLimit: Int? = null,
    /** Other wire paths this endpoint accepts and CUSTOM may set. */
    val extraParams: Set<String> = emptySet(),
    /**
     * True when a knob above was read off the model's name rather than a listed
     * endpoint.
     *
     * The table can only know the endpoints somebody added to it, which left
     * every hand-added gateway with length as its only knob even while it served
     * a thinking model. An inference is still a claim, so it is marked: the sheet
     * says where it came from, and one refusal removes it for good.
     */
    val inferred: Boolean = false,
    /**
     * This endpoint refused a tier, so nothing may send one again.
     *
     * Kept apart from [supportsReasoningEffort] because "never declared" and
     * "tried and rejected" have to lead to different places: the first still
     * allows a hand-set value on an endpoint only the user knows anything about,
     * the second is final.
     */
    val refusedReasoningEffort: Boolean = false,
    /** The same, for a thinking budget. */
    val refusedThinkingBudget: Boolean = false
) {

    /**
     * Whether power means anything at all here.
     *
     * False is a real answer and the UI has to say it out loud. A fixed endpoint
     * that silently ignores the picker is indistinguishable from a broken one.
     */
    val configurable: Boolean
        get() = supportsReasoningEffort || supportsThinkingBudget || supportsMaxTokens

    /** Tiers without duplicates, for the CUSTOM chips. */
    val offeredTiers: List<String>
        get() = reasoningTiers.distinct()

    /**
     * Whether manual mode may set a tier here.
     *
     * Wider than [supportsReasoningEffort] on purpose. A private gateway is the
     * one case where the app cannot know and the user can, and `reasoning_effort`
     * is the single field every OpenAI-shaped server spells the same way -- so
     * manual mode is allowed to try it until this endpoint says no. Presets stay
     * conservative and use only what was declared or inferred.
     */
    val manualEffortAllowed: Boolean
        get() = configurable && !refusedReasoningEffort && reasoningEffortKey.isNotBlank()

    /** The same for a budget, which needs a wire path its protocol defines. */
    val manualBudgetAllowed: Boolean
        get() = configurable && !refusedThinkingBudget && thinkingBudgetKey.isNotBlank()

    /**
     * Tiers manual mode may offer, falling back to the three words every
     * OpenAI-shaped gateway understands when the table lists none.
     */
    val manualTiers: List<String>
        get() = offeredTiers.ifEmpty { STANDARD_TIERS }

    companion object {

        /** Nothing is adjustable. Produces a no-op config, never a guess. */
        val None = EndpointCapabilities(supportsMaxTokens = false)

        /** What an unlisted endpoint is offered in manual mode. */
        val STANDARD_TIERS = listOf("low", "medium", "high")
    }
}

/**
 * The resolved parameters for one mode on one endpoint.
 *
 * A value being null means "do not send this field", not "send a default". That
 * distinction is the contract with the providers: they write exactly what is
 * here and nothing else.
 */
data class PowerConfig(
    val maxTokens: Int? = null,
    val reasoningEffort: String? = null,
    val thinkingBudget: Int? = null,
    /** Extra wire paths to values, already checked against the capabilities. */
    val extra: Map<String, Any> = emptyMap()
) {

    val isNoOp: Boolean
        get() = maxTokens == null &&
            reasoningEffort == null &&
            thinkingBudget == null &&
            extra.isEmpty()

    companion object {

        /** The honest empty result for an endpoint with no knobs. */
        val NoOp = PowerConfig()
    }
}

/**
 * A stored choice for one (endpoint, model) pair.
 *
 * [custom] is kept even while another mode is active, so switching to CUSTOM and
 * back does not throw away hand-tuned numbers.
 */
data class PowerSelection(
    val mode: PowerMode = DefaultPowerMode,
    val custom: PowerConfig? = null
)

/**
 * Storage key for one pair.
 *
 * The choice is per pair and not global because the same word means different
 * things on different endpoints: HIGH is an effort tier on OpenAI, a 16k
 * thinking budget on Anthropic and a length on Ollama. One global value would
 * have to be re-interpreted on every switch, and the user would see their
 * setting change meaning without touching it.
 */
fun powerKey(endpointId: String, modelId: String): String = endpointId + "|" + modelId

/**
 * The stored choice for one pair, with MEDIUM for a pair never chosen.
 *
 * MEDIUM rather than LOW because a new pair should behave the way the model
 * normally does; starting everyone at the cheapest setting would make new
 * models look worse than they are.
 */
fun AppSettings.powerSelection(endpointId: String, modelId: String): PowerSelection {
    val pair = endpointId to modelId
    return PowerSelection(
        mode = powerModes[pair] ?: DefaultPowerMode,
        custom = powerCustom[pair]
    )
}
