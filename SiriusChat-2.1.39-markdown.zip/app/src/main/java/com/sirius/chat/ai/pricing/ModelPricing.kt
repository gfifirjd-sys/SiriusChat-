package com.sirius.chat.ai.pricing

import com.sirius.chat.domain.model.TokenUsage
import java.util.Locale

/** Price of one million tokens in US dollars, input and output priced apart. */
data class ModelPrice(
    val inputPerMillion: Double,
    val outputPerMillion: Double
)

/** Token counts for endpoints that report none. */
object TokenEstimate {

    /**
     * Characters per token.
     *
     * Deliberately the same 3.5 the context compactor budgets with. Two
     * different constants would let the meter above the composer and the
     * counter under the answer disagree about the same conversation, and a user
     * who noticed would be right to trust neither number.
     */
    const val CHARS_PER_TOKEN = 3.5f

    fun tokens(text: String): Int =
        if (text.isEmpty()) 0 else (text.length / CHARS_PER_TOKEN).toInt().coerceAtLeast(1)
}

/**
 * Published list prices, matched by model id.
 *
 * ### Why a table and not a request
 * There is no cross-provider pricing endpoint, and the alternative to a table
 * is showing nothing. A table does go stale, so the failure mode is chosen
 * carefully: an unrecognised model returns `null` and the UI then shows tokens
 * only. Being silent about cost is recoverable; inventing a number is not.
 *
 * Matching is by substring, longest and most specific first, because a model id
 * arrives decorated in practice -- `openai/gpt-4o-mini-2024-07-18`,
 * `anthropic/claude-opus-4.1`, `gpt-4o-mini` -- and an exact-match map would
 * miss nearly every real id while looking correct in tests.
 *
 * Gateways resell at their own margins, so this is the list price of the
 * upstream model, not necessarily what a given key is billed.
 */
object ModelPricing {

    private val table: List<Pair<String, ModelPrice>> = listOf(
        // OpenAI -- mini/nano variants first, they are substrings of the rest.
        "gpt-4.1-nano" to ModelPrice(0.10, 0.40),
        "gpt-4.1-mini" to ModelPrice(0.40, 1.60),
        "gpt-4.1" to ModelPrice(2.00, 8.00),
        "gpt-4o-mini" to ModelPrice(0.15, 0.60),
        "gpt-4o" to ModelPrice(2.50, 10.00),
        "o4-mini" to ModelPrice(1.10, 4.40),
        "o3-mini" to ModelPrice(1.10, 4.40),
        "o3" to ModelPrice(2.00, 8.00),
        "gpt-3.5" to ModelPrice(0.50, 1.50),
        // Anthropic
        "claude-3-5-haiku" to ModelPrice(0.80, 4.00),
        "claude-3-haiku" to ModelPrice(0.25, 1.25),
        "claude-haiku-4" to ModelPrice(1.00, 5.00),
        "claude-3-opus" to ModelPrice(15.00, 75.00),
        "claude-opus" to ModelPrice(15.00, 75.00),
        "claude-3-5-sonnet" to ModelPrice(3.00, 15.00),
        "claude-3-7-sonnet" to ModelPrice(3.00, 15.00),
        "claude-sonnet" to ModelPrice(3.00, 15.00),
        // Google
        "gemini-2.5-flash-lite" to ModelPrice(0.10, 0.40),
        "gemini-2.5-flash" to ModelPrice(0.30, 2.50),
        "gemini-2.5-pro" to ModelPrice(1.25, 10.00),
        "gemini-2.0-flash" to ModelPrice(0.10, 0.40),
        // DeepSeek
        "deepseek-reasoner" to ModelPrice(0.55, 2.19),
        "deepseek-r1" to ModelPrice(0.55, 2.19),
        "deepseek-chat" to ModelPrice(0.27, 1.10),
        "deepseek-v3" to ModelPrice(0.27, 1.10)
    )

    fun of(modelId: String): ModelPrice? {
        if (modelId.isBlank()) return null
        val id = modelId.lowercase(Locale.US)
        return table.firstOrNull { (key, _) -> id.contains(key) }?.second
    }

    /**
     * Dollar cost of a turn, or `null` when it cannot be known.
     *
     * An estimated [usage] returns `null` on purpose: its prompt half is not
     * measured, so any cost derived from it would be an undercount presented
     * with four decimals of false precision.
     */
    fun cost(modelId: String?, usage: TokenUsage?): Double? {
        if (modelId == null || usage == null || usage.isEmpty || usage.estimated) return null
        val price = of(modelId) ?: return null
        return usage.promptTokens / 1_000_000.0 * price.inputPerMillion +
            usage.completionTokens / 1_000_000.0 * price.outputPerMillion
    }

    /** Floored rather than rounded to zero: a turn that cost something never reads as free. */
    fun format(cost: Double): String = when {
        cost <= 0.0 -> "\$0"
        cost < 0.0001 -> "<\$0.0001"
        cost < 1.0 -> "\$" + String.format(Locale.US, "%.4f", cost)
        else -> "\$" + String.format(Locale.US, "%.2f", cost)
    }
}
