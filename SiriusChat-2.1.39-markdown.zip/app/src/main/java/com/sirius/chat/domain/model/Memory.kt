package com.sirius.chat.domain.model

/**
 * What kind of fact a memory node holds -- the folder it would live in if this
 * were a set of files.
 *
 * ### The ordering contract
 * [wireName] is what the model writes and what the database stores, so it is
 * the stable identity -- the enum may be reordered, renamed or extended without
 * rewriting a single stored row. Anything unrecognised reads back as [Profile]
 * rather than throwing: a fact with an odd label is still a fact, and losing it
 * because a future build invented another category would be the worse failure.
 */
enum class MemoryCategory(val wireName: String) {
    /** Who the user is: name, job, city, languages. Their `/profile.md`. */
    Profile("profile"),

    /** What they are building, and what it is. Their `/areas/`. */
    Project("project"),

    /**
     * Tastes, interests and subjects they keep returning to. Their `/topics/`.
     *
     * "Likes ice cream" belongs here and not in [Preference]: it says something
     * about the person, not about how they want to be answered. Keeping those
     * two apart is the difference between a profile and a style guide.
     */
    Topic("topic"),

    /** How they work: recurring routines, tools, schedules. */
    Habit("habit"),

    /** People and teams around them. */
    People("people"),

    /** How the user wants to be answered -- and nothing else. */
    Preference("preference");

    companion object {
        fun ofWire(raw: String?): MemoryCategory {
            val name = raw?.trim()?.lowercase().orEmpty()
            return entries.firstOrNull { it.wireName == name } ?: Profile
        }
    }
}

/**
 * One durable fact about the user.
 *
 * ### Why this is not the chat history
 * The transcript is already in the prompt and already scrolls on screen. This is
 * the part that has to survive *between* conversations: the name, the project,
 * the preference stated three chats ago. Storing turns here would grow without
 * bound and would leak one chat's context into another; storing facts keeps it
 * small enough to send in full with every request.
 *
 * ### Why links live on the node
 * The graph is small -- tens of nodes, not thousands -- and it is read whole
 * every time it is read at all, both by the prompt builder and by the 3D view.
 * A join table would add a second query and a migration for no gain at this
 * size. Ids that no longer resolve are ignored on read rather than cleaned up on
 * write, so deleting a node can never corrupt its neighbours.
 */
data class MemoryNode(
    val id: String,
    /** The fact, in the user's own words where possible. One sentence. */
    val content: String,
    val category: MemoryCategory = MemoryCategory.Profile,
    /**
     * The file this fact was filed under, as a slug: `food`, `sirius-chat`.
     *
     * Empty is allowed and means "not filed yet" -- every fact written before
     * this field existed reads that way, and they still group by category.
     */
    val topic: String = "",
    /** Ids of nodes this one explains, follows from, or shares a subject with. */
    val links: List<String> = emptyList(),
    /** How it was learned. "chat" for anything the extractor found. */
    val source: String = SOURCE_CHAT,
    /** The conversation it was learned in, kept for provenance only. */
    val sessionId: String? = null,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L
) {
    companion object {
        /** Learned from something the user actually said, in a conversation. */
        const val SOURCE_CHAT = "chat"

        /** Written by hand in the memory screen rather than learned. */
        const val SOURCE_USER = "user"
    }
}

/**
 * Where this fact would live if memory were a folder of notes.
 *
 * ### Why a path and not just a category
 * This string is the one grouping the whole feature agrees on: the prompt lists
 * facts under it, the graph draws a line between facts that share it, and the
 * extractor is shown it so the next fact about food joins `/topics/food.md`
 * instead of starting `/topics/ice-cream.md` beside it. A category alone is too
 * coarse for that -- every project would share one heading -- and a free-form
 * label alone is too loose, because nothing would stop the same subject being
 * spelled three ways.
 */
fun MemoryNode.memoryPath(): String {
    val slug = topic.trim()
    return when {
        slug.isNotBlank() && category == MemoryCategory.Project -> "/areas/$slug.md"
        slug.isNotBlank() && category == MemoryCategory.Profile -> "/profile.md"
        slug.isNotBlank() && category == MemoryCategory.Preference -> "/preferences.md"
        slug.isNotBlank() && category == MemoryCategory.People -> "/people/$slug.md"
        slug.isNotBlank() -> "/topics/$slug.md"
        category == MemoryCategory.Profile -> "/profile.md"
        category == MemoryCategory.Preference -> "/preferences.md"
        category == MemoryCategory.Project -> "/areas/projects.md"
        category == MemoryCategory.People -> "/people/people.md"
        else -> "/topics/" + category.wireName + ".md"
    }
}

/** The file name a person would read: `food` -> "Food", `sirius-chat` -> "Sirius Chat". */
fun memoryTopicTitle(slug: String): String = slug
    .split('-', '_', ' ')
    .filter { it.isNotBlank() }
    .joinToString(" ") { part -> part.replaceFirstChar { it.uppercaseChar() } }

/**
 * What to show as the name of a file.
 *
 * [stored] wins when the model gave the file a real heading, because "Food
 * preferences" says more than "Food". Everything else is derived from the path,
 * so a file always has a readable name even when nothing named it.
 */
fun memoryFileTitle(path: String, stored: String = ""): String {
    val given = stored.trim()
    if (given.isNotEmpty()) return given
    return when (path) {
        MEMORY_PROFILE_PATH -> "Profile"
        MEMORY_PREFERENCES_PATH -> "Preferences"
        else -> memoryTopicTitle(memoryPathSlug(path)).ifBlank { path }
    }
}

/**
 * A file name the same subject always lands on.
 *
 * Lowercased, spaces to dashes, punctuation dropped. Letters are kept whatever
 * the alphabet, so a Russian subject files under a Russian slug rather than
 * collapsing to an empty string and losing its grouping.
 */
fun memoryTopicSlug(raw: String?): String {
    val text = raw?.trim()?.lowercase().orEmpty()
    if (text.isEmpty()) return ""
    val out = StringBuilder(text.length)
    for (symbol in text) {
        when {
            symbol.isLetterOrDigit() -> out.append(symbol)
            symbol == '-' || symbol == '_' || symbol.isWhitespace() ->
                if (out.isNotEmpty() && out.last() != '-') out.append('-')
            else -> Unit
        }
    }
    return out.toString().trim('-').take(MAX_TOPIC_CHARS).trim('-')
}

/** How the two ends of a line got connected. */
enum class MemoryLinkKind {
    /** The extractor said these two facts explain or refine each other. */
    Stated,

    /** They share a file: same topic, or same category when neither is filed. */
    Topic
}

/** One undirected connection between two stored nodes. */
data class MemoryEdge(
    val from: String,
    val to: String,
    val kind: MemoryLinkKind = MemoryLinkKind.Stated
)

/**
 * The links in this list, as edges that both ends actually exist for.
 *
 * Undirected and de-duplicated: the extractor links A to B and often B to A as
 * well, and drawing that twice puts a visibly heavier line between them for no
 * reason. Self-links are dropped -- a node explaining itself is a model slip,
 * not a relationship.
 */
fun List<MemoryNode>.memoryEdges(): List<MemoryEdge> {
    val known = mapTo(HashSet(size)) { it.id }
    val seen = HashSet<String>()
    val edges = ArrayList<MemoryEdge>()
    for (node in this) {
        for (target in node.links) {
            if (target == node.id || target !in known) continue
            if (!seen.add(pairKey(node.id, target))) continue
            edges += MemoryEdge(node.id, target, MemoryLinkKind.Stated)
        }
    }
    return edges
}

/**
 * Lines that hold a file together: every fact in `/topics/food.md` tied to the
 * first one written there.
 *
 * ### Why a star and not a mesh
 * Joining every pair inside a group is `n(n-1)/2` lines -- eight facts about one
 * project would draw twenty-eight of them and the cluster turns into a solid
 * blob. A star is `n-1` lines, reads as one group at a glance, and pulls exactly
 * as hard in the layout, because the force that clusters them is the link force
 * either way.
 *
 * The anchor is the oldest fact in the file, so the shape of a cluster does not
 * reshuffle every time something is added to it.
 *
 * Pairs already joined by a stated link are skipped: a real relationship is
 * worth drawing, and drawing it twice only makes it thicker for no reason.
 */
fun List<MemoryNode>.topicEdges(stated: List<MemoryEdge> = emptyList()): List<MemoryEdge> {
    if (size < 2) return emptyList()
    val taken = HashSet<String>(stated.size * 2 + 8)
    for (edge in stated) taken += pairKey(edge.from, edge.to)

    val groups = LinkedHashMap<String, MutableList<MemoryNode>>()
    for (node in this) groups.getOrPut(node.memoryPath()) { ArrayList() } += node

    val edges = ArrayList<MemoryEdge>()
    for (group in groups.values) {
        if (group.size < 2) continue
        var anchor = group[0]
        for (node in group) if (node.createdAt < anchor.createdAt) anchor = node
        for (node in group) {
            if (node.id == anchor.id) continue
            if (!taken.add(pairKey(node.id, anchor.id))) continue
            edges += MemoryEdge(node.id, anchor.id, MemoryLinkKind.Topic)
        }
    }
    return edges
}

private fun pairKey(first: String, second: String): String =
    if (first < second) "$first|$second" else "$second|$first"

/** Long enough for "multi-dimensional-force", short enough to stay a file name. */
private const val MAX_TOPIC_CHARS = 32

/** `/profile.md` -- who the user is. Always this one path. */
const val MEMORY_PROFILE_PATH = "/profile.md"

/** `/preferences.md` -- how the user wants to be answered, and nothing else. */
const val MEMORY_PREFERENCES_PATH = "/preferences.md"

/**
 * One memory file: where it lives, what else it answers to, and its version.
 *
 * ### Why a version
 * Two things write here -- the extractor after a turn, and the user pressing
 * "forget" in the memory screen -- and the extractor decides what to write from
 * a listing it was shown *before* the answer came back. Without a version that
 * decision is applied blind: a line the user deleted in between gets "corrected"
 * back into place, or the same fact is appended twice because the second write
 * was planned against a file that no longer looked like that. The version is the
 * cheapest possible check that the file is still the one that was read, and a
 * write that fails it is rejected rather than merged.
 *
 * ### Why aliases
 * The same subject arrives spelled differently every time -- `еда`, `food`,
 * `вкусы`. Aliases are how the second one finds the file the first one opened,
 * instead of opening `/topics/eda.md` beside `/topics/food.md`.
 */
data class MemoryFile(
    val path: String,
    val aliases: List<String> = emptyList(),
    val version: Int = 1,
    val updatedAt: Long = 0L,
    /**
     * The heading a person reads above the lines: "Food preferences".
     *
     * Empty until something names the file, and [memoryFileTitle] falls back to
     * the path so a file is never shown as `/topics/food.md` to the user.
     */
    val title: String = "",
    /** One line saying what the file is for, shown under the heading. */
    val summary: String = ""
) {
    companion object {
        /** The version a file that does not exist yet is at. */
        const val NEW_FILE = 0

        /** What a file implied by older facts reads as until something writes to it. */
        const val DERIVED_VERSION = 1
    }
}

/**
 * One edit to one file: append a line, or replace a line that changed.
 *
 * There is deliberately no "write the whole file" operation. Everything the
 * model is allowed to do here touches a single line, so a bad answer can cost at
 * most that one line -- it can never restate a file from memory and quietly drop
 * the four facts it forgot to repeat.
 */
sealed interface MemoryWrite {
    /** The file this edit belongs to, already normalised. */
    val path: String

    /** The version the edit was planned against, or [NEW_FILE] for a new file. */
    val ifVersion: Int

    /** Adds one line to the end of a file, creating the file when [ifVersion] is [NEW_FILE]. */
    data class Append(
        override val path: String,
        override val ifVersion: Int,
        val content: String,
        val category: MemoryCategory = MemoryCategory.Topic,
        val aliases: List<String> = emptyList(),
        val links: List<String> = emptyList(),
        /** The heading for the file, used only when it does not have one yet. */
        val title: String = "",
        /** One line saying what the file is about, used only when it has none. */
        val summary: String = ""
    ) : MemoryWrite

    /** Rewrites one existing line, for a fact that changed rather than a new one. */
    data class Replace(
        override val path: String,
        override val ifVersion: Int,
        val oldLine: String,
        val newLine: String
    ) : MemoryWrite

    /**
     * Replaces every line in a file at once.
     *
     * For the edit a line-by-line correction cannot express: several facts
     * changing together, or a file that has grown into the wrong shape. It is
     * the one write that can drop something, so it is version-checked like the
     * rest and refuses to leave a file empty -- a rewrite with nothing in it is
     * a deletion, and deletions are the user's to ask for.
     */
    data class Rewrite(
        override val path: String,
        override val ifVersion: Int,
        val lines: List<String>,
        val category: MemoryCategory = MemoryCategory.Topic
    ) : MemoryWrite

    companion object {
        /** No version was supplied at all, which is not the same as "new file". */
        const val UNVERSIONED = -1
    }
}

/**
 * The canonical path for whatever the model called a file.
 *
 * `food`, `Food.md`, `/topics/Food`, `topics/еда.md` all have to land on one
 * string or the version check is meaningless -- two spellings would be two files
 * at two versions holding the same subject. Anything without a recognised folder
 * is filed under `/topics/`, which is where a subject with no better home goes.
 *
 * Returns an empty string for input that cannot be a file name at all.
 */
fun memoryNormalisePath(raw: String?): String {
    val text = raw?.trim()?.trim('"', '`')?.lowercase().orEmpty()
    if (text.isEmpty()) return ""
    val body = text.removePrefix("/").removeSuffix(".md").trim('/')
    if (body.isEmpty()) return ""
    val folder = body.substringBeforeLast('/', "")
    val slug = memoryTopicSlug(body.substringAfterLast('/'))
    if (slug.isEmpty()) return ""
    return when {
        folder.isEmpty() && slug == "profile" -> MEMORY_PROFILE_PATH
        folder.isEmpty() && (slug == "preferences" || slug == "preference") -> MEMORY_PREFERENCES_PATH
        folder == "areas" || folder == "area" || folder == "projects" -> "/areas/$slug.md"
        folder == "people" || folder == "person" -> "/people/$slug.md"
        else -> "/topics/$slug.md"
    }
}

/** The file name without folder or extension: `/topics/food.md` -> `food`. */
fun memoryPathSlug(path: String): String =
    path.substringAfterLast('/').removeSuffix(".md")

/** The folder a path lives in: `/topics/food.md` -> `/topics`, `/profile.md` -> `""`. */
fun memoryPathFolder(path: String): String = path.substringBeforeLast('/', "")

/**
 * What a fact written into [path] has to be categorised as.
 *
 * The folder wins over whatever the model labelled the fact, because the folder
 * is what the rest of the app reads back: a `project` line sitting in
 * `/topics/food.md` would be drawn in the wrong colour, grouped with the wrong
 * cluster and pathed back to a third file the next time it is touched. Inside
 * `/topics/` the label is kept as-is -- habits, people and tastes genuinely
 * share that folder -- except for the two labels that name a different folder.
 */
fun memoryPathCategory(path: String, fallback: MemoryCategory): MemoryCategory = when {
    path == MEMORY_PROFILE_PATH -> MemoryCategory.Profile
    path == MEMORY_PREFERENCES_PATH -> MemoryCategory.Preference
    memoryPathFolder(path) == "/areas" -> MemoryCategory.Project
    memoryPathFolder(path) == "/people" -> MemoryCategory.People
    fallback == MemoryCategory.Project || fallback == MemoryCategory.Preference ->
        MemoryCategory.Topic
    else -> fallback
}
