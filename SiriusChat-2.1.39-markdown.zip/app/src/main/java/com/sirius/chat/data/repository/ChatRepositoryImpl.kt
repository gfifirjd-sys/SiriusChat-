package com.sirius.chat.data.repository

import com.sirius.chat.core.common.AppDispatchers
import com.sirius.chat.data.local.db.dao.ChatDao
import com.sirius.chat.data.local.db.entity.ChatMessageEntity
import com.sirius.chat.data.local.db.entity.ChatSessionEntity
import com.sirius.chat.data.local.db.entity.SessionWithStats
import com.sirius.chat.domain.model.AttachmentKind
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.MessageAttachment
import com.sirius.chat.domain.model.MessageHit
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.model.MessageStatus
import com.sirius.chat.domain.model.TokenUsage
import com.sirius.chat.domain.model.ToolRun
import com.sirius.chat.domain.repository.ChatRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
private data class AttachmentDto(
    val id: String,
    val name: String,
    val uri: String,
    val sizeBytes: Long = 0L,
    val language: String? = null,
    val mimeType: String? = null,
    // Stored as the enum name, with a fallback on read: a row written by an older
    // build has no kind at all, and a renamed constant must not lose the row.
    val kind: String? = null,
    val anchor: Int = 0
)

@Serializable
private data class ToolRunDto(
    val id: String,
    val toolName: String,
    val argumentsPreview: String,
    val output: String,
    val success: Boolean,
    val durationMs: Long = 0L
)

class ChatRepositoryImpl(
    private val dao: ChatDao,
    private val dispatchers: AppDispatchers
) : ChatRepository {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    override fun observeSessions(projectId: String?): Flow<List<ChatSession>> {
        val source = if (projectId == null) dao.observeSessions() else dao.observeSessionsForProject(projectId)
        return source.map { list -> list.map { it.toDomain() } }
    }

    override fun observeMessages(sessionId: String): Flow<List<ChatMessage>> =
        dao.observeMessages(sessionId).map { list -> list.map { it.toDomain() } }

    override suspend fun getSession(id: String): ChatSession? = withContext(dispatchers.io) {
        dao.getSession(id)?.toDomain()
    }

    override suspend fun createSession(session: ChatSession): ChatSession = withContext(dispatchers.io) {
        dao.upsertSession(session.toEntity())
        session
    }

    /**
     * Updates the session's metadata only.
     *
     * A targeted UPDATE rather than rewriting the row: the old read-draft-then-upsert
     * round-trip could lose a draft saved in between, and any full-row rewrite of a
     * parent that children cascade from is a way to delete a conversation by
     * accident.
     */
    override suspend fun updateSession(session: ChatSession) = withContext(dispatchers.io) {
        dao.updateSessionMeta(
            id = session.id,
            title = session.title,
            projectId = session.projectId,
            providerId = session.providerId,
            model = session.model,
            agentMode = session.agentMode,
            pinned = session.pinned,
            featureFlags = ChatFeatureFlags.encode(session.features),
            contextMeter = encodeMeter(session.contextMeter),
            updatedAt = System.currentTimeMillis()
        )
    }

    override suspend fun deleteSession(id: String) = withContext(dispatchers.io) {
        dao.deleteSession(id)
    }

    override suspend fun setPinned(id: String, pinned: Boolean) = withContext(dispatchers.io) {
        dao.setPinned(id, pinned)
    }

    override suspend fun messages(sessionId: String): List<ChatMessage> = withContext(dispatchers.io) {
        dao.messages(sessionId).map { it.toDomain() }
    }

    override suspend fun addMessage(message: ChatMessage) = withContext(dispatchers.io) {
        dao.insertMessageAndTouch(message.toEntity(), System.currentTimeMillis())
    }

    override suspend fun updateMessage(message: ChatMessage) = withContext(dispatchers.io) {
        dao.upsertMessage(message.toEntity())
    }

    override suspend fun deleteMessage(id: String) = withContext(dispatchers.io) {
        dao.deleteMessage(id)
    }

    /**
     * Deletes [messageId] and everything after it.
     *
     * By position, not by timestamp. The old `createdAt >= t` deleted every message
     * sharing that millisecond, so regenerating an answer that arrived in the same
     * millisecond as the question deleted the question as well -- the user watched
     * part of the conversation vanish.
     */
    override suspend fun truncateFrom(sessionId: String, messageId: String) = withContext(dispatchers.io) {
        val ordered = dao.messageIdsOrdered(sessionId)
        val from = ordered.indexOf(messageId)
        if (from < 0) return@withContext
        // Chunked: SQLite caps the number of bound parameters in one statement.
        ordered.drop(from).chunked(400).forEach { dao.deleteByIds(it) }
    }

    override suspend fun saveDraft(sessionId: String, draft: String) = withContext(dispatchers.io) {
        dao.setDraft(sessionId, draft)
    }

    override suspend fun draft(sessionId: String): String = withContext(dispatchers.io) {
        dao.draft(sessionId).orEmpty()
    }

    /**
     * Searches every chat and returns a ready-to-show fragment per hit.
     *
     * The needle goes to SQL twice, lower-cased and capitalised, for the reason
     * given on the DAO query; the match is then located again in Kotlin, where
     * case folding is Unicode-aware, so the fragment is centred on the real match
     * rather than on whichever variant the database happened to match.
     */
    override suspend fun searchMessages(query: String, limit: Int): List<MessageHit> =
        withContext(dispatchers.io) {
            val needle = query.trim()
            if (needle.length < MIN_SEARCH_NEEDLE) return@withContext emptyList()
            val lowered = needle.lowercase()
            val loweredPattern = "%" + lowered + "%"
            val capitalisedPattern = "%" + lowered.replaceFirstChar { it.uppercase() } + "%"
            dao.searchMessages(loweredPattern, capitalisedPattern, limit).map { row ->
                MessageHit(
                    messageId = row.messageId,
                    sessionId = row.sessionId,
                    sessionTitle = row.sessionTitle,
                    snippet = searchSnippet(row.content, needle),
                    createdAt = row.createdAt
                )
            }
        }

    private fun SessionWithStats.toDomain() = ChatSession(
        id = id,
        title = title,
        projectId = projectId,
        providerId = providerId,
        model = model,
        agentMode = agentMode,
        createdAt = createdAt,
        updatedAt = updatedAt,
        pinned = pinned,
        messageCount = messageCount,
        lastMessagePreview = lastMessagePreview.orEmpty().lineSequence().firstOrNull().orEmpty().take(120)
    )

    private fun ChatSessionEntity.toDomain() = ChatSession(
        id = id,
        title = title,
        projectId = projectId,
        providerId = providerId,
        model = model,
        agentMode = agentMode,
        createdAt = createdAt,
        updatedAt = updatedAt,
        pinned = pinned,
        features = ChatFeatureFlags.decode(featureFlags),
        contextMeter = decodeMeter(contextMeter),
        memory = decodeMeter(memory),
        titleAuto = titleAuto
    )

    private fun ChatSession.toEntity(keepDraft: String = "") = ChatSessionEntity(
        id = id,
        title = title,
        projectId = projectId,
        providerId = providerId,
        model = model,
        agentMode = agentMode,
        createdAt = createdAt,
        updatedAt = updatedAt,
        pinned = pinned,
        draft = keepDraft,
        featureFlags = ChatFeatureFlags.encode(features),
        contextMeter = encodeMeter(contextMeter),
        memory = encodeMeter(memory),
        titleAuto = titleAuto
    )

    private fun ChatMessageEntity.toDomain() = ChatMessage(
        id = id,
        sessionId = sessionId,
        role = MessageRole.entries.firstOrNull { it.name == role } ?: MessageRole.Assistant,
        content = content,
        createdAt = createdAt,
        model = model,
        providerId = providerId,
        status = MessageStatus.entries.firstOrNull { it.name == status } ?: MessageStatus.Complete,
        error = error,
        attachments = decodeAttachments(attachmentsJson),
        toolRuns = decodeToolRuns(toolRunsJson),
        usage = decodeUsage(usageJson)
    )

    private fun ChatMessage.toEntity() = ChatMessageEntity(
        id = id,
        sessionId = sessionId,
        role = role.name,
        content = content,
        createdAt = createdAt,
        model = model,
        providerId = providerId,
        status = status.name,
        error = error,
        attachmentsJson = json.encodeToString(
            attachments.map {
                AttachmentDto(
                    id = it.id,
                    name = it.name,
                    uri = it.uri,
                    sizeBytes = it.sizeBytes,
                    language = it.language,
                    mimeType = it.mimeType,
                    kind = it.kind.name,
                    anchor = it.anchor
                )
            }
        ),
        toolRunsJson = json.encodeToString(
            toolRuns.map { ToolRunDto(it.id, it.toolName, it.argumentsPreview, it.output, it.success, it.durationMs) }
        ),
        usageJson = encodeUsage(usage)
    )

    @Serializable
    private data class UsageDto(
        val promptTokens: Int = 0,
        val completionTokens: Int = 0,
        val estimated: Boolean = false
    )

    /** Empty string for an uncounted turn, so it stays distinguishable from zero. */
    private fun encodeUsage(usage: TokenUsage?): String =
        if (usage == null || usage.isEmpty) ""
        else json.encodeToString(
            UsageDto.serializer(),
            UsageDto(usage.promptTokens, usage.completionTokens, usage.estimated)
        )

    private fun decodeUsage(raw: String): TokenUsage? {
        if (raw.isBlank()) return null
        return runCatching {
            val dto = json.decodeFromString(UsageDto.serializer(), raw)
            TokenUsage(dto.promptTokens, dto.completionTokens, dto.estimated)
                .takeIf { !it.isEmpty }
        }.getOrNull()
    }

    private fun encodeMeter(value: Boolean?): Int = when (value) {
        null -> -1
        true -> 1
        false -> 0
    }

    /** Any negative value inherits, matching how the feature flags degrade. */
    private fun decodeMeter(stored: Int): Boolean? =
        if (stored < 0) null else stored > 0

    private fun decodeAttachments(raw: String): List<MessageAttachment> = runCatching {
        json.decodeFromString<List<AttachmentDto>>(raw)
            .map { MessageAttachment(
                    id = it.id,
                    name = it.name,
                    uri = it.uri,
                    sizeBytes = it.sizeBytes,
                    language = it.language,
                    mimeType = it.mimeType,
                    kind = AttachmentKind.entries.firstOrNull { kind -> kind.name == it.kind }
                        ?: AttachmentKind.WorkspaceFile,
                    anchor = it.anchor
                ) }
    }.getOrDefault(emptyList())

    private fun decodeToolRuns(raw: String): List<ToolRun> = runCatching {
        json.decodeFromString<List<ToolRunDto>>(raw)
            .map { ToolRun(it.id, it.toolName, it.argumentsPreview, it.output, it.success, it.durationMs) }
    }.getOrDefault(emptyList())
}

/** Two characters is the shortest query that narrows anything down. */
private const val MIN_SEARCH_NEEDLE = 2

private const val SNIPPET_LEAD = 40
private const val SNIPPET_TRAIL = 90

/**
 * A one-line fragment centred on the match.
 *
 * Newlines are flattened because a result row is one line tall: a code block in
 * the matched message would otherwise push every other result off the screen.
 * Ellipses are added only on the side that was actually cut.
 */
private fun searchSnippet(content: String, needle: String): String {
    val flat = content.replace('\n', ' ').replace('\r', ' ')
    val index = flat.indexOf(needle, ignoreCase = true)
    if (index < 0) return flat.take(SNIPPET_LEAD + SNIPPET_TRAIL).trim()
    val from = (index - SNIPPET_LEAD).coerceAtLeast(0)
    val to = (index + needle.length + SNIPPET_TRAIL).coerceAtMost(flat.length)
    val head = if (from > 0) "\u2026" else ""
    val tail = if (to < flat.length) "\u2026" else ""
    return head + flat.substring(from, to).trim() + tail
}
