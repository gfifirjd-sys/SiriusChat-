package com.sirius.chat.core.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.ui.graphics.vector.ImageVector
import com.sirius.chat.R

/** Every route in the app, in one place. */
object Routes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val CHATS = "chats"
    const val FILES = "files"
    const val TERMINAL = "terminal"
    const val SETTINGS = "settings"

    const val PROJECTS = "projects"
    const val EDITOR = "editor"
    const val REVIEW = "review"
    const val GIT = "git"
    const val GITHUB = "github"
    const val SETTINGS_PROVIDERS = "settings/providers"
    const val SETTINGS_APPEARANCE = "settings/appearance"
    const val SETTINGS_EDITOR = "settings/editor"
    const val ABOUT = "about"
    const val MEMORY = "memory"

    /** The same memory, read as the files it is written to. */
    const val MEMORY_FILES = "memory/files"

    private const val CHAT_BASE = "chat"
    const val CHAT = "$CHAT_BASE/{sessionId}"
    fun chat(sessionId: String) = "$CHAT_BASE/$sessionId"

    private const val PROJECT_BASE = "project"
    const val PROJECT_DETAIL = "$PROJECT_BASE/{projectId}"
    fun project(projectId: String) = "$PROJECT_BASE/$projectId"
}

/** Bottom bar entries. Five is the maximum that stays comfortable one-handed. */
enum class TopLevelDestination(
    val route: String,
    @StringRes val labelRes: Int,
    val icon: ImageVector
) {
    Home(Routes.HOME, R.string.nav_home, Icons.Rounded.Home),
    Chats(Routes.CHATS, R.string.nav_chats, Icons.Rounded.AutoAwesome),
    Files(Routes.FILES, R.string.nav_files, Icons.Rounded.FolderOpen),
    Terminal(Routes.TERMINAL, R.string.nav_terminal, Icons.Rounded.Terminal),
    Settings(Routes.SETTINGS, R.string.nav_settings, Icons.Rounded.Settings);

    companion object {
        fun fromRoute(route: String?): TopLevelDestination? =
            entries.firstOrNull { it.route == route }
    }
}
