package com.sirius.chat.data.repository

import com.sirius.chat.core.common.AppDispatchers
import com.sirius.chat.data.local.db.dao.MemoryDao
import com.sirius.chat.data.local.db.dao.MemoryFileDao
import com.sirius.chat.data.local.db.entity.MemoryEntity
import com.sirius.chat.data.local.db.entity.MemoryFileEntity
import com.sirius.chat.domain.model.MemoryCategory
import com.sirius.chat.domain.model.MemoryFile
import com.sirius.chat.domain.model.MemoryNode
import com.sirius.chat.domain.model.memoryPath
import com.sirius.chat.domain.model.memoryTopicSlug
import com.sirius.chat.domain.repository.MemoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/**
 * Long-term memory on disk.
 *
 * ### Why links are stored as text
 * A join table would be the textbook answer and would buy nothing here: the
 * graph is read whole every time it is read at all -- once per request to build
 * the prompt, once to draw it -- so there is no query that a second table would
 * make cheaper, and there is a migration and a foreign key it would make more
 * expensive. Newline separated rather than JSON because ids are UUIDs and
 * cannot contain the separator, so the parse cannot fail.
 *
 * ### Why the table is capped
 * Memory is sent with every single request, so its size is a running cost, not
 * a storage cost. Past [MAX_NODES] the oldest facts are dropped: a profile that
 * grows without limit stops being a profile and starts being a log, and the
 * facts most likely to still be true are the ones touched most recently.
 */
class MemoryRepositoryImpl(
    private val dao: MemoryDao,
    private val fileDao: MemoryFileDao,
    private val dispatchers: AppDispatchers
) : MemoryRepository {

    override fun observeNodes(): Flow<List<MemoryNode>> =
        dao.observeAll().map { rows -> rows.map { it.toDomain() } }

    override suspend fun nodes(): List<MemoryNode> = withContext(dispatchers.io) {
        dao.recent(MAX_NODES).map { it.toDomain() }
    }

    override suspend fun save(nodes: List<MemoryNode>) {
        if (nodes.isEmpty()) return
        withContext(dispatchers.io) {
            dao.upsert(nodes.map { it.toEntity() })
            val overflow = dao.count() - MAX_NODES
            if (overflow > 0) dao.trimOldest(overflow)
        }
    }

    override suspend fun files(): List<MemoryFile> = withContext(dispatchers.io) {
        fileDao.all().map { it.toDomain() }
    }

    override fun observeFiles(): Flow<List<MemoryFile>> =
        fileDao.observeAll().map { rows -> rows.map { it.toDomain() } }

    override suspend fun saveFiles(files: List<MemoryFile>) {
        if (files.isEmpty()) return
        withContext(dispatchers.io) {
            fileDao.upsert(
                files.map { file ->
                    MemoryFileEntity(
                        path = file.path,
                        aliases = file.aliases.filter { it.isNotBlank() }.joinToString("\n"),
                        version = file.version,
                        updatedAt = if (file.updatedAt > 0L) file.updatedAt else System.currentTimeMillis(),
                        title = file.title.trim(),
                        summary = file.summary.trim()
                    )
                }
            )
        }
    }

    override suspend fun delete(id: String) {
        withContext(dispatchers.io) { dao.delete(id) }
    }

    /**
     * Deleting a file means deleting what is in it.
     *
     * Facts do not carry their path -- it is derived from the category and the
     * topic -- so the rows are read, matched against the same derivation the
     * rest of the app uses, and removed by id. Leaving the row behind would
     * leave a version pointing at nothing; leaving the lines behind would keep
     * sending facts the user just erased.
     */
    override suspend fun deleteFile(path: String) {
        if (path.isBlank()) return
        withContext(dispatchers.io) {
            dao.recent(MAX_NODES)
                .map { it.toDomain() }
                .filter { it.memoryPath() == path }
                .forEach { dao.delete(it.id) }
            fileDao.delete(path)
        }
    }

    override suspend fun clear() {
        withContext(dispatchers.io) {
            dao.clear()
            // The versions go with the facts. Leaving them behind would mean a
            // user who erased everything still had to write against v7 of a
            // file that no longer has a single line in it.
            fileDao.clear()
        }
    }

    private fun MemoryFileEntity.toDomain(): MemoryFile = MemoryFile(
        path = path,
        aliases = aliases.split('\n').map { it.trim() }.filter { it.isNotEmpty() },
        version = version,
        updatedAt = updatedAt,
        title = title,
        summary = summary
    )

    private fun MemoryEntity.toDomain(): MemoryNode = MemoryNode(
        id = id,
        content = content,
        category = MemoryCategory.ofWire(category),
        topic = topic,
        links = links.split('\n').map { it.trim() }.filter { it.isNotEmpty() },
        source = source,
        sessionId = sessionId,
        createdAt = createdAt,
        updatedAt = updatedAt
    )

    private fun MemoryNode.toEntity(): MemoryEntity = MemoryEntity(
        id = id,
        content = content,
        category = category.wireName,
        // Slugged on the way in, so the same subject cannot end up as two files
        // because the model wrote "Food" once and "food " the next time.
        topic = memoryTopicSlug(topic),
        links = links.filter { it.isNotBlank() }.joinToString("\n"),
        source = source,
        sessionId = sessionId,
        createdAt = if (createdAt > 0L) createdAt else System.currentTimeMillis(),
        updatedAt = if (updatedAt > 0L) updatedAt else System.currentTimeMillis()
    )

    private companion object {
        /** Comfortably more than a person accumulates, far less than a transcript. */
        private const val MAX_NODES = 240
    }
}
