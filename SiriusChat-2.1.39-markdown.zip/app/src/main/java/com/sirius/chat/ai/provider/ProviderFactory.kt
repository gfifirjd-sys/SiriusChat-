package com.sirius.chat.ai.provider

import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import com.sirius.chat.domain.model.requiresApiKey
import com.sirius.chat.domain.repository.ProviderRepository

/**
 * Turns a stored [ProviderConfig] plus its secret into a live [AiProvider].
 * Instances are cheap and short-lived; only the HTTP client is shared.
 */
class ProviderFactory(private val providerRepository: ProviderRepository) {

    suspend fun create(providerId: String): AiProvider? {
        val config = providerRepository.get(providerId) ?: return null
        return create(config, providerRepository.apiKey(providerId))
    }

    fun create(config: ProviderConfig, apiKey: String?): AiProvider {
        val provider = when (config.type) {
            ProviderType.AnthropicCompatible -> AnthropicProvider(config, apiKey)
            ProviderType.OpenAiCompatible, ProviderType.Custom -> OpenAiCompatibleProvider(config, apiKey)
        }
        // Wrapped once, here, so every caller -- chat, agent steps, the
        // summariser, the titler -- survives a rate limit or a dropped socket
        // without each of them growing its own retry loop. Capability probing is
        // not routed through this factory, and must not be: a probe can only
        // learn from the raw rejection.
        return RetryingProvider(provider)
    }

    /**
     * Local endpoints (Ollama, LM Studio) legitimately need no key. The rule
     * itself lives in the domain so every screen agrees on what "ready" means.
     */
    fun requiresApiKey(config: ProviderConfig): Boolean = config.requiresApiKey
}
