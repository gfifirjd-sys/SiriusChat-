package com.sirius.chat.feature.chat.components

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.SheetActionRow
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.util.CodeLanguage
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.data.files.FileExportResult
import com.sirius.chat.data.files.FileExporter
import kotlinx.coroutines.launch

/**
 * A named file the model produced, shown as one line instead of forty.
 *
 * ### Why a card and not just a code block
 * A code block is the right shape for three lines of shell. It is the wrong
 * shape for a 400-line `index.html`: on a phone it turns the answer into a
 * scroll trap, and the one thing the user actually wants — the file, on their
 * device — is not offered at all. The card says what the thing is and gets out of
 * the way; the contents are one tap behind it and so is the download.
 *
 * ### Why the fence's info string decides
 * There is no separate protocol for the model to learn. Any model already writes
 * ```` ```html index.html ````, so a fence whose tag ends in a real file name
 * becomes a file, and everything else stays a code block. Nothing regresses when
 * the model does not know about this at all.
 *
 * ### Why expanding beats a viewer screen
 * A separate screen loses the conversation, and coming back re-anchors the
 * transcript somewhere else. Expanding in place keeps the answer around the file
 * and reuses [CodeBlockView], so highlighting, folding and copy behave exactly as
 * they do everywhere else.
 */
@Composable
fun FileCardView(
    name: String,
    code: String,
    language: CodeLanguage,
    modifier: Modifier = Modifier,
    fontSize: Int = 13
) {
    val colors = SiriusTheme.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val haptics = rememberHaptics()

    // Keyed by name only: while an answer streams, `code` changes on every token,
    // and keying on it would fold the file shut under the user's finger.
    var expanded by rememberSaveable(name) { mutableStateOf(false) }
    var sheetOpen by remember { mutableStateOf(false) }

    val bytes = remember(code) { code.toByteArray() }
    val lines = remember(code) { code.count { it == '\n' } + 1 }
    val meta = stringResource(
        R.string.chat_file_meta,
        language.displayName,
        lines,
        FileExporter.readableSize(bytes.size.toLong())
    )

    val savedText = stringResource(R.string.chat_file_saved, FileExporter.FOLDER)
    val failedText = stringResource(R.string.chat_file_save_failed)
    val permissionText = stringResource(R.string.chat_file_permission)
    val copiedText = stringResource(R.string.chat_copied)
    val shareTitle = stringResource(R.string.chat_file_share)
    val shareFailed = stringResource(R.string.chat_file_share_failed)

    val save: () -> Unit = {
        scope.launch {
            val message = when (FileExporter.saveToDownloads(context, name, bytes)) {
                is FileExportResult.Saved -> savedText
                FileExportResult.NeedsPermission -> permissionText
                FileExportResult.Failed -> failedText
            }
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    // Only ever launched on API 26-28. On Android 10+ MediaStore needs nothing
    // and the user is never asked.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) save() else Toast.makeText(context, permissionText, Toast.LENGTH_SHORT).show()
    }

    val openLabel = stringResource(R.string.chat_file_open_actions)

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(SiriusRadius.md))
                .background(colors.surfaceMuted)
                .clickable(role = Role.Button, onClickLabel = openLabel) {
                    haptics.light()
                    sheetOpen = true
                }
                .padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(SiriusRadius.sm))
                    .background(colors.primarySoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Code,
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = meta,
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ChevronRight,
                contentDescription = null,
                tint = colors.textTertiary,
                modifier = Modifier.size(20.dp)
            )
        }

        if (expanded) {
            Spacer(Modifier.height(SiriusSpacing.xxs))
            CodeBlockView(
                code = code,
                language = language,
                tag = name,
                fontSize = fontSize
            )
        }
    }

    if (sheetOpen) {
        SiriusBottomSheet(
            title = name,
            subtitle = meta,
            onDismiss = { sheetOpen = false }
        ) {
            SheetActionRow(
                icon = if (expanded) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                label = stringResource(
                    if (expanded) R.string.chat_file_hide else R.string.chat_file_view
                ),
                supporting = stringResource(R.string.chat_file_view_hint),
                onClick = {
                    sheetOpen = false
                    expanded = !expanded
                }
            )
            SheetActionRow(
                icon = Icons.Rounded.Download,
                label = stringResource(R.string.chat_file_download),
                supporting = stringResource(R.string.chat_file_download_hint, FileExporter.FOLDER),
                onClick = {
                    sheetOpen = false
                    // Asked for before the write rather than after it fails, so the
                    // user sees one dialog instead of an error and then a dialog.
                    if (FileExporter.needsLegacyPermission(context)) {
                        permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    } else {
                        save()
                    }
                }
            )
            SheetActionRow(
                icon = Icons.Rounded.ContentCopy,
                label = stringResource(R.string.action_copy),
                supporting = stringResource(R.string.chat_file_copy_hint),
                onClick = {
                    sheetOpen = false
                    clipboard.setText(AnnotatedString(code))
                    Toast.makeText(context, copiedText, Toast.LENGTH_SHORT).show()
                }
            )
            SheetActionRow(
                icon = Icons.Rounded.Share,
                label = shareTitle,
                supporting = stringResource(R.string.chat_file_share_hint),
                onClick = {
                    sheetOpen = false
                    val chooser = FileExporter.shareChooser(context, name, bytes, shareTitle)
                    if (chooser == null) {
                        Toast.makeText(context, shareFailed, Toast.LENGTH_SHORT).show()
                    } else {
                        runCatching { context.startActivity(chooser) }.onFailure {
                            Toast.makeText(context, shareFailed, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }
    }
}

/**
 * The file name inside a fence tag, or null when the fence is just a language.
 *
 * Accepts every shape a model actually writes: ```` ```html index.html ````,
 * ```` ```index.html ````, ```` ```kotlin title="Main.kt" ````, and paths like
 * `app/src/Main.kt` — only the last segment is kept, because the card is not a
 * file browser.
 *
 * The extension must start with a letter, which is the whole reason this does not
 * turn ```` ```python3.11 ```` into a file called `3.11`.
 */
internal fun fileNameFromTag(tag: String): String? {
    if (tag.isBlank()) return null
    val tokens = tag.trim().split(' ', '\t', ',', ';').filter { it.isNotBlank() }
    for (raw in tokens.asReversed()) {
        val token = raw.substringAfterLast('=').trim('"', '\'', '`', '(', ')', '<', '>')
        val name = token.substringAfterLast('/').substringAfterLast('\\')
        if (name.length > MAX_CARD_NAME_CHARS) continue
        val dot = name.lastIndexOf('.')
        if (dot <= 0 || dot == name.length - 1) continue
        val extension = name.substring(dot + 1)
        if (extension.length !in 1..8) continue
        if (!extension.first().isLetter()) continue
        if (!extension.all { it.isLetterOrDigit() }) continue
        val stem = name.substring(0, dot)
        if (stem.none { it.isLetterOrDigit() }) continue
        return name
    }
    return null
}

private const val MAX_CARD_NAME_CHARS = 64
