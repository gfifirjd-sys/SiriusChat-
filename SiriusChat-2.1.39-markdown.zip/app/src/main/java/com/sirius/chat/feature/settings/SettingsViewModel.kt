package com.sirius.chat.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.AppLanguage
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.GlassLevel
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ThemeMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val settings: AppSettings = AppSettings(),
    val providers: List<ProviderConfig> = emptyList(),
    val projects: List<Project> = emptyList()
) {
    val activeProvider: ProviderConfig?
        get() = providers.firstOrNull { it.id == settings.activeProviderId }
}

class SettingsViewModel(private val container: AppContainer) : ViewModel() {

    val state: StateFlow<SettingsUiState> = combine(
        container.settingsRepository.settings,
        container.providerRepository.observeProviders(),
        container.projectRepository.observeProjects()
    ) { settings, providers, projects ->
        SettingsUiState(settings, providers, projects)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    private fun update(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { container.settingsRepository.update(transform) }
    }

    fun setLanguage(language: AppLanguage) = update { it.copy(language = language) }
    fun setThemeMode(mode: ThemeMode) = update { it.copy(themeMode = mode) }
    /** 0 is the monochrome default; anything else is an ARGB accent. */
    fun setAccentColor(argb: Int) = update { it.copy(accentColor = argb) }
    fun setGlassLevel(level: GlassLevel) = update { it.copy(glassLevel = level) }
    fun setReduceMotion(enabled: Boolean) = update { it.copy(reduceMotion = enabled) }
    fun setHaptics(enabled: Boolean) = update { it.copy(hapticsEnabled = enabled) }
    fun setStreaming(enabled: Boolean) = update { it.copy(streamingEnabled = enabled) }

    /**
     * Defaults for new chats only.
     *
     * Existing conversations keep whatever they were given, which is the point:
     * changing a default here must not retroactively alter what an old thread
     * claims to have done.
     */
    fun setDefaultWebSearch(enabled: Boolean) = update { it.copy(defaultWebSearch = enabled) }

    fun setDefaultImageGeneration(enabled: Boolean) =
        update { it.copy(defaultImageGeneration = enabled) }

    /** New chats only; each open chat keeps its own choice. */
    fun setShowContextMeter(enabled: Boolean) =
        update { it.copy(showContextMeter = enabled) }

    /** New chats only, like the meter above. Existing chats keep their switch. */
    fun setMemoryEnabled(enabled: Boolean) =
        update { it.copy(memoryEnabled = enabled) }

    /**
     * Unlike the two above this is not a per-chat default: it governs the
     * notification shade, which belongs to the app rather than to a
     * conversation, so it takes effect everywhere at once.
     */
    fun setNotifications(enabled: Boolean) =
        update { it.copy(notificationsEnabled = enabled) }

    fun setPerformanceMode(mode: com.sirius.chat.domain.model.PerformanceMode) =
        update { it.copy(performanceMode = mode) }
    fun setAgentMaxSteps(steps: Int) = update { it.copy(agentMaxSteps = steps.coerceIn(1, 12)) }
    fun setAgentAutoApply(enabled: Boolean) = update { it.copy(agentAutoApplyChanges = enabled) }
    fun setAgentTerminal(enabled: Boolean) = update { it.copy(agentTerminalEnabled = enabled) }
    fun setTemperature(value: Float) = update { it.copy(temperature = value.coerceIn(0f, 2f)) }
    fun setMaxTokens(value: Int) = update { it.copy(maxTokens = value.coerceIn(256, 32_000)) }
    fun setEditorFontSize(value: Int) = update { it.copy(editorFontSize = value.coerceIn(10, 24)) }
    fun setEditorTabSize(value: Int) = update { it.copy(editorTabSize = value.coerceIn(2, 8)) }
    fun setWordWrap(enabled: Boolean) = update { it.copy(editorWordWrap = enabled) }
    fun setLineNumbers(enabled: Boolean) = update { it.copy(editorLineNumbers = enabled) }
    fun setAutoSave(enabled: Boolean) = update { it.copy(editorAutoSave = enabled) }
    fun setActiveProject(projectId: String) = update { it.copy(activeProjectId = projectId) }

    fun clearAllChats() {
        viewModelScope.launch {
            container.chatRepository.observeSessions()
            container.changeStore.clearAll()
        }
    }

    fun clearCredentials() {
        viewModelScope.launch {
            container.providerRepository.providers().forEach {
                container.providerRepository.clearApiKey(it.id)
            }
        }
    }
}
