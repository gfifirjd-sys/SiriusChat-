package com.sirius.chat.core.util

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Writes the stack trace of an uncaught exception to a file the user can reach
 * without adb.
 *
 * Sirius is built and installed on the same device it runs on, so `adb logcat`
 * is usually not an option: once the process dies the trace is gone. That is
 * exactly the situation where "it crashed, then would not start until I wiped
 * the data" leaves nothing to work from. The last two traces are kept in the
 * app's own external files directory, which any file manager can open.
 *
 * This only records. It deliberately does not swallow the crash: the platform
 * handler still runs afterwards, so the process dies exactly as it did before
 * and no half-dead process is left on screen.
 */
object CrashReporter {

    private const val TAG = "SiriusCrash"
    private const val DIR = "crash"
    private const val CURRENT = "last-crash.txt"
    private const val PREVIOUS = "previous-crash.txt"

    fun install(context: Context) {
        val appContext = context.applicationContext
        val platform = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            // A failure while reporting must never replace the original crash.
            runCatching { write(appContext, thread, error) }
            platform?.uncaughtException(thread, error)
        }
    }

    /** Directory holding the traces, or null when external storage is absent. */
    fun directory(context: Context): File? = context.getExternalFilesDir(null)?.resolve(DIR)

    private fun write(context: Context, thread: Thread, error: Throwable) {
        val dir = directory(context) ?: return
        if (!dir.isDirectory && !dir.mkdirs()) return
        val current = File(dir, CURRENT)
        // One rotation, because a crash loop would otherwise overwrite the first
        // trace -- and the first one is what explains the loop.
        if (current.exists()) {
            runCatching { current.copyTo(File(dir, PREVIOUS), overwrite = true) }
        }
        val trace = StringWriter().also { error.printStackTrace(PrintWriter(it)) }.toString()
        current.writeText(
            buildString {
                appendLine("time:    " + timestamp())
                appendLine("thread:  " + thread.name)
                appendLine("app:     " + versionOf(context))
                appendLine("device:  " + Build.MANUFACTURER + " " + Build.MODEL)
                appendLine("android: " + Build.VERSION.RELEASE + " (sdk " + Build.VERSION.SDK_INT + ")")
                appendLine()
                append(trace)
            }
        )
        Log.e(TAG, "uncaught exception on thread " + thread.name, error)
    }

    private fun timestamp(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    private fun versionOf(context: Context): String = runCatching {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName
    }.getOrNull().orEmpty().ifBlank { "unknown" }
}
