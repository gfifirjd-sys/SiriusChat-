package com.sirius.chat.core.util

/** Structural pieces the chat renderer understands. */
sealed interface MarkdownBlock {
    data class Paragraph(val text: String) : MarkdownBlock
    data class Heading(val level: Int, val text: String) : MarkdownBlock
    data class Code(val language: CodeLanguage, val tag: String, val code: String, val complete: Boolean) : MarkdownBlock
    data class ListBlock(val items: List<ListItem>, val ordered: Boolean) : MarkdownBlock
    data class Quote(val text: String) : MarkdownBlock
    data class Table(val header: List<String>, val rows: List<List<String>>, val aligns: List<ColumnAlign>) : MarkdownBlock
    data class Math(val latex: String) : MarkdownBlock
    data class Progress(val rows: List<ProgressRow>) : MarkdownBlock
    data class Tree(val lines: List<TreeLine>) : MarkdownBlock
    /**
     * A picture on its own line: `![alt](uri)`.
     *
     * Only standalone images become a block. An image inside a sentence stays
     * inline text, because promoting it would break the paragraph in two and
     * reflow the prose around a 200dp square -- which is right for a generated
     * illustration and wrong for a 16px inline badge.
     */
    data class Image(val alt: String, val uri: String) : MarkdownBlock

    /**
     * A quote whose first line is `[!NOTE]` or one of its four siblings.
     *
     * Kept apart from [Quote] because it is not a quotation at all: the author is
     * marking the paragraph's importance, and rendering it as someone else's
     * words is the wrong reading.
     */
    data class Alert(val kind: AlertKind, val text: String) : MarkdownBlock

    /**
     * `<details><summary>…</summary>…</details>`, collapsed until tapped.
     *
     * The body is parsed rather than stored as text, so a spoiler can hold code,
     * tables and lists -- which is the whole reason to fold something away.
     */
    data class Spoiler(val summary: String, val body: List<MarkdownBlock>) : MarkdownBlock

    /** Every `[^id]: …` definition in the document, printed once at the bottom. */
    data class Footnotes(val items: List<Footnote>) : MarkdownBlock

    data object Divider : MarkdownBlock
}

/** The five callout kinds GitHub defines; anything else stays a plain quote. */
enum class AlertKind { Note, Tip, Important, Warning, Caution }

/**
 * One footnote. [id] is kept as written rather than renumbered, so `[^1]` prints
 * `1` and `[^why]` prints `why` -- a made-up number would not match the marker
 * the reader just tapped past.
 */
data class Footnote(val id: String, val text: String)

/**
 * A list row. [depth] is the nesting level and [ordinal] the number to print for
 * ordered lists — kept from the source rather than recomputed, so `1. 1. 1.` and
 * `1. 2. 3.` both render the way the author wrote them. [checked] is null for a
 * plain bullet and non-null for a task list, which is what lets one list mix
 * prose items and checkboxes.
 */
data class ListItem(
    val text: String,
    val depth: Int,
    val ordinal: Int? = null,
    val checked: Boolean? = null
)

enum class ColumnAlign { Start, Center, End }

/** One bar in a ```progress block. [fraction] is already clamped to 0..1. */
data class ProgressRow(val label: String, val fraction: Float, val caption: String)

/**
 * One line of a ```tree block. [last] drives the box-drawing glyph, and
 * [ancestorsLast] tells the renderer which vertical guides to keep drawing at
 * shallower depths — without it, deep trees lose their connecting lines.
 */
data class TreeLine(
    val depth: Int,
    val name: String,
    val directory: Boolean,
    val last: Boolean,
    val ancestorsLast: List<Boolean>
)

/**
 * Streaming-friendly markdown splitter: an unterminated code fence is still
 * emitted (marked incomplete) so tokens appear as they arrive instead of the
 * block popping into existence at the end. The same tolerance applies to the
 * richer blocks — a half-typed table renders as far as its rows go.
 *
 * Beyond CommonMark this understands three things the assistant is told about in
 * the system prompt: `$$…$$` math, ```progress bars and ```tree listings. They
 * exist because an agent that edits projects constantly reports *proportions*
 * and *file layouts*, and both are unreadable as plain text in a chat bubble.
 */
object MarkdownParser {

    fun parse(markdown: String): List<MarkdownBlock> = parse(markdown, 0)

    /**
     * [nesting] counts how deep this call already sits inside `<details>` bodies,
     * the only construct here that parses markdown of its own. Without a bound, a
     * document that opens a thousand of them recurses a thousand frames deep.
     */
    private fun parse(markdown: String, nesting: Int): List<MarkdownBlock> {
        val blocks = ArrayList<MarkdownBlock>()
        val footnotes = ArrayList<Footnote>()
        val lines = markdown.lines()
        var index = 0
        val paragraph = StringBuilder()

        fun flushParagraph() {
            val text = paragraph.toString().trim()
            if (text.isNotEmpty()) blocks += MarkdownBlock.Paragraph(text)
            paragraph.setLength(0)
        }

        while (index < lines.size) {
            val line = lines[index]
            val trimmed = line.trimStart()

            when {
                isFence(trimmed) -> {
                    flushParagraph()
                    // The fence closes on the marker that opened it. A ``` example
                    // inside a ~~~ block would otherwise end the block early --
                    // which is the entire reason the tilde form exists.
                    val marker = trimmed.take(3)
                    val tag = trimmed.drop(3).trim()
                    val body = ArrayList<String>()
                    index++
                    var complete = false
                    while (index < lines.size) {
                        if (lines[index].trimStart().startsWith(marker)) {
                            complete = true
                            index++
                            break
                        }
                        body += lines[index]
                        index++
                    }
                    blocks += when (tag.lowercase()) {
                        "progress" -> MarkdownBlock.Progress(parseProgress(body))
                        "tree" -> MarkdownBlock.Tree(parseTree(body))
                        else -> MarkdownBlock.Code(
                            language = CodeLanguages.fromTag(tag),
                            tag = tag,
                            code = body.joinToString("\n").trimEnd('\n'),
                            complete = complete
                        )
                    }
                }

                // An HTML comment is a note to the author, not to the reader.
                // Left in the flow it printed `<!-- TODO -->` mid-answer, which
                // reads as the model leaking its own draft.
                trimmed.startsWith("<!--") -> {
                    flushParagraph()
                    while (index < lines.size && !lines[index].contains("-->")) index++
                    if (index < lines.size) index++
                }

                nesting < MAX_SPOILER_NESTING &&
                    trimmed.startsWith("<details", ignoreCase = true) -> {
                    flushParagraph()
                    val body = ArrayList<String>()
                    var open = 1
                    index++
                    while (index < lines.size) {
                        val current = lines[index].trimStart()
                        if (current.startsWith("<details", ignoreCase = true)) open++
                        if (current.startsWith("</details", ignoreCase = true)) {
                            open--
                            if (open == 0) {
                                index++
                                break
                            }
                        }
                        body += lines[index]
                        index++
                    }
                    // An unclosed spoiler still renders: while an answer streams,
                    // the opening tag arrives long before its match.
                    val summaryLine = body.indexOfFirst { it.contains("<summary", ignoreCase = true) }
                    val inner = body.filterIndexed { position, _ -> position != summaryLine }
                    blocks += MarkdownBlock.Spoiler(
                        summary = if (summaryLine >= 0) stripTags(body[summaryLine]) else "",
                        body = parse(inner.joinToString("\n").trim(), nesting + 1)
                    )
                }

                // Display math. Either fully inline on one line ($$x$$) or fenced
                // across several, which is how anything with a fraction arrives.
                trimmed.startsWith("$$") -> {
                    flushParagraph()
                    val single = trimmed.length > 4 && trimmed.endsWith("$$")
                    if (single) {
                        blocks += MarkdownBlock.Math(trimmed.removeSurrounding("$$").trim())
                        index++
                    } else {
                        val latex = StringBuilder()
                        index++
                        while (index < lines.size && !lines[index].trimStart().startsWith("$$")) {
                            latex.appendLine(lines[index])
                            index++
                        }
                        if (index < lines.size) index++
                        blocks += MarkdownBlock.Math(latex.toString().trim())
                    }
                }

                trimmed.startsWith("#") && trimmed.takeWhile { it == '#' }.length <= 6 &&
                    trimmed.dropWhile { it == '#' }.startsWith(" ") -> {
                    flushParagraph()
                    val level = trimmed.takeWhile { it == '#' }.length
                    blocks += MarkdownBlock.Heading(level, stripClosingHashes(trimmed.drop(level).trim()))
                    index++
                }

                trimmed.startsWith("> ") -> {
                    flushParagraph()
                    val quote = StringBuilder()
                    while (index < lines.size && lines[index].trimStart().startsWith(">")) {
                        quote.appendLine(lines[index].trimStart().removePrefix(">").trim())
                        index++
                    }
                    val body = quote.toString().trim()
                    val kind = alertKind(body)
                    blocks += if (kind == null) {
                        MarkdownBlock.Quote(body)
                    } else {
                        // The marker line is consumed: the renderer prints the
                        // kind as a label, and leaving `[!NOTE]` in the text would
                        // show it twice.
                        MarkdownBlock.Alert(kind, body.substringAfter('\n', "").trim())
                    }
                }

                // A standalone image. Checked before the paragraph fallback so
                // the line never reaches the inline renderer, which would show
                // the alt text and silently drop the picture.
                isStandaloneImage(trimmed) -> {
                    flushParagraph()
                    parseImage(trimmed)?.let { blocks += it }
                    index++
                }

                trimmed == "---" || trimmed == "***" || trimmed == "___" -> {
                    flushParagraph()
                    blocks += MarkdownBlock.Divider
                    index++
                }

                // A table is only a table once the delimiter row confirms it;
                // otherwise a sentence containing a pipe would become one.
                isTableRow(trimmed) && index + 1 < lines.size && isTableDelimiter(lines[index + 1]) -> {
                    flushParagraph()
                    val header = splitRow(trimmed)
                    val aligns = parseAligns(lines[index + 1])
                    index += 2
                    val rows = ArrayList<List<String>>()
                    while (index < lines.size && isTableRow(lines[index].trimStart())) {
                        rows += splitRow(lines[index].trimStart())
                        index++
                    }
                    blocks += MarkdownBlock.Table(header, rows, aligns)
                }

                isBullet(trimmed) || isOrdered(trimmed) -> {
                    flushParagraph()
                    val ordered = isOrdered(trimmed)
                    val items = ArrayList<ListItem>()
                    while (index < lines.size) {
                        val raw = lines[index]
                        val candidate = raw.trimStart()
                        // A nested ordered list inside a bulleted one (and the
                        // reverse) stays in the same block: splitting them would
                        // reset the indent and break the visual hierarchy.
                        if (!isBullet(candidate) && !isOrdered(candidate)) break
                        val depth = indentDepth(raw)
                        if (isOrdered(candidate)) {
                            // `1.` and `1)` are both ordered markers, so the number
                            // ends wherever the digits do rather than at a dot.
                            val digits = candidate.takeWhile { it.isDigit() }
                            items += ListItem(
                                text = candidate.drop(digits.length + 1).trim(),
                                depth = depth,
                                ordinal = digits.toIntOrNull()
                            )
                        } else {
                            val content = candidate.drop(2).trim()
                            val task = taskState(content)
                            items += ListItem(
                                text = if (task == null) content else content.drop(3).trim(),
                                depth = depth,
                                checked = task
                            )
                        }
                        index++
                    }
                    blocks += MarkdownBlock.ListBlock(items, ordered)
                }

                // `[^1]: text`. Lifted out of the flow wherever it sits, because
                // an author may keep a definition beside its reference while the
                // reader expects to find all of them at the bottom.
                FOOTNOTE_DEFINITION.matches(trimmed) -> {
                    flushParagraph()
                    val id = trimmed.substringAfter("[^").substringBefore("]").trim()
                    val text = StringBuilder(trimmed.substringAfter("]:").trim())
                    index++
                    while (index < lines.size && lines[index].isNotBlank() && lines[index].startsWith("  ")) {
                        text.append(' ').append(lines[index].trim())
                        index++
                    }
                    if (id.isNotEmpty()) footnotes += Footnote(id, text.toString().trim())
                }

                // `Title` underlined with `===`. The `---` form is deliberately not
                // read as a heading: after a sentence it is far more often a
                // divider, and promoting it would silently retitle the paragraph
                // above it in front of the reader.
                trimmed.isNotEmpty() && index + 1 < lines.size &&
                    isSetextUnderline(lines[index + 1]) -> {
                    flushParagraph()
                    blocks += MarkdownBlock.Heading(1, trimmed)
                    index += 2
                }

                trimmed.isEmpty() -> {
                    flushParagraph()
                    index++
                }

                else -> {
                    paragraph.appendLine(line)
                    index++
                }
            }
        }
        flushParagraph()
        if (footnotes.isNotEmpty()) blocks += MarkdownBlock.Footnotes(footnotes)
        return blocks
    }

    /**
     * Whether the whole line is one image and nothing else.
     *
     * Anchored at both ends on purpose. `![a](b) and text` is a paragraph that
     * happens to contain an image, and treating it as a block would drop the
     * words after it -- a silent content loss, which is the worst class of
     * markdown bug because nothing looks broken.
     */
    private fun isStandaloneImage(line: String): Boolean = IMAGE_REGEX.matches(line.trim())

    private fun parseImage(line: String): MarkdownBlock.Image? {
        val match = IMAGE_REGEX.matchEntire(line.trim()) ?: return null
        val uri = match.groupValues[2].trim()
        if (uri.isEmpty()) return null
        return MarkdownBlock.Image(alt = match.groupValues[1].trim(), uri = uri)
    }

    /**
     * `![alt](uri)`.
     *
     * The alt group excludes `]` and the uri group excludes `)` and whitespace,
     * so the match cannot run past the end of its own link into following text.
     * A greedy version of this pattern on a line with two images would swallow
     * both into one broken reference.
     */
    private val IMAGE_REGEX = Regex("!\\[([^\\]]*)\\]\\(([^)\\s]+)\\)")

    private fun isBullet(line: String): Boolean =
        line.startsWith("- ") || line.startsWith("* ") || line.startsWith("+ ")

    private fun isOrdered(line: String): Boolean = ORDERED_MARKER.containsMatchIn(line)

    /** `- [x] ` / `- [ ] ` -> true / false, anything else -> null. */
    private fun taskState(content: String): Boolean? = when {
        content.startsWith("[x] ", ignoreCase = true) -> true
        content.startsWith("[ ] ") -> false
        else -> null
    }

    /** Two spaces or one tab per level, capped so pathological input can't run off screen. */
    private fun indentDepth(raw: String): Int {
        var spaces = 0
        for (ch in raw) {
            when (ch) {
                ' ' -> spaces++
                '\t' -> spaces += 2
                else -> return (spaces / 2).coerceAtMost(4)
            }
        }
        return 0
    }

    private fun isTableRow(line: String): Boolean = line.startsWith("|") && line.count { it == '|' } >= 2

    private fun isTableDelimiter(line: String): Boolean {
        val body = line.trim()
        if (!body.startsWith("|")) return false
        val cells = splitRow(body)
        return cells.isNotEmpty() && cells.all { cell ->
            val c = cell.trim()
            c.length >= 3 && c.all { it == '-' || it == ':' } && c.contains('-')
        }
    }

    /**
     * Table cells, honouring `\|` as a literal pipe.
     *
     * Splitting on every pipe pushed half a cell into the next column whenever a
     * row mentioned a shell pipeline or an alternation, and a table that silently
     * shifts its columns is worse than one that refuses to parse.
     */
    private fun splitRow(line: String): List<String> {
        val body = line.trim().trim('|')
        val cells = ArrayList<String>()
        val cell = StringBuilder()
        var i = 0
        while (i < body.length) {
            val ch = body[i]
            when {
                ch == '\\' && body.getOrNull(i + 1) == '|' -> {
                    cell.append('|')
                    i += 2
                }
                ch == '|' -> {
                    cells += cell.toString().trim()
                    cell.setLength(0)
                    i++
                }
                else -> {
                    cell.append(ch)
                    i++
                }
            }
        }
        cells += cell.toString().trim()
        return cells
    }

    private fun isFence(line: String): Boolean =
        line.startsWith("```") || line.startsWith("~~~")

    /** `[!NOTE]` on the first line of a quote turns the quote into a callout. */
    private fun alertKind(quote: String): AlertKind? {
        val head = quote.lineSequence().firstOrNull()?.trim().orEmpty()
        if (!head.startsWith("[!") || !head.endsWith("]")) return null
        return when (head.removePrefix("[!").removeSuffix("]").trim().uppercase()) {
            "NOTE" -> AlertKind.Note
            "TIP" -> AlertKind.Tip
            "IMPORTANT" -> AlertKind.Important
            "WARNING" -> AlertKind.Warning
            "CAUTION" -> AlertKind.Caution
            else -> null
        }
    }

    /**
     * `## Title ##` -> `Title`, while `## C#` keeps its hash.
     *
     * CommonMark only closes a heading with a run of hashes that a space
     * precedes, and that rule exists for exactly the language names this app is
     * full of.
     */
    private fun stripClosingHashes(text: String): String {
        if (!text.endsWith("#")) return text
        val withoutHashes = text.trimEnd('#')
        return if (withoutHashes.endsWith(" ")) withoutHashes.trim() else text
    }

    private fun isSetextUnderline(line: String): Boolean {
        val body = line.trim()
        return body.length >= 2 && body.all { it == '=' }
    }

    /** Strips the one line of HTML this parser reads: `<summary>…</summary>`. */
    private fun stripTags(line: String): String = line.replace(TAG_REGEX, "").trim()

    private val ORDERED_MARKER = Regex("""^\d+[.)]\s""")

    private val FOOTNOTE_DEFINITION = Regex("""^\[\^[^\]]+\]:.*""")

    private val TAG_REGEX = Regex("<[^>]*>")

    /** Deep enough for a spoiler inside a spoiler, shallow enough to stay cheap. */
    private const val MAX_SPOILER_NESTING = 3

    private fun parseAligns(delimiter: String): List<ColumnAlign> =
        splitRow(delimiter).map { cell ->
            val c = cell.trim()
            when {
                c.startsWith(':') && c.endsWith(':') -> ColumnAlign.Center
                c.endsWith(':') -> ColumnAlign.End
                else -> ColumnAlign.Start
            }
        }

    /**
     * `label: 62%`, `label 0.62` or a bare `62%`. Percent and fraction are both
     * accepted because models write both, and guessing wrong turns a 62% bar
     * into a full one.
     */
    private fun parseProgress(body: List<String>): List<ProgressRow> = body
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .map { raw ->
            val label = raw.substringBeforeLast(' ', "").trim().trimEnd(':').trim()
            val value = raw.substringAfterLast(' ').trim()
            val percent = value.endsWith("%")
            val number = value.trimEnd('%').toFloatOrNull()
            val fraction = when {
                number == null -> 0f
                percent -> number / 100f
                number > 1f -> number / 100f
                else -> number
            }
            ProgressRow(
                label = label,
                fraction = fraction.coerceIn(0f, 1f),
                caption = if (number == null) "" else "${(fraction * 100).toInt()}%"
            )
        }

    /**
     * Indented listing -> tree lines. The last-child flags are resolved in a
     * second pass, because whether a node is last is only knowable once the
     * following lines have been read.
     */
    private fun parseTree(body: List<String>): List<TreeLine> {
        data class Raw(val depth: Int, val name: String)

        val raws = body
            .filter { it.isNotBlank() }
            .map { line ->
                val depth = indentDepth(line)
                Raw(depth, line.trim().trimStart('|', '-', '`').trim())
            }
            .filter { it.name.isNotEmpty() }

        val lastAtDepth = BooleanArray(6)
        val result = ArrayList<TreeLine>(raws.size)
        raws.forEachIndexed { i, raw ->
            val next = raws.drop(i + 1).firstOrNull { it.depth <= raw.depth }
            val isLast = next == null || next.depth < raw.depth
            if (raw.depth < lastAtDepth.size) lastAtDepth[raw.depth] = isLast
            result += TreeLine(
                depth = raw.depth,
                name = raw.name.trimEnd('/'),
                directory = raw.name.endsWith("/"),
                last = isLast,
                ancestorsLast = (0 until raw.depth).map { lastAtDepth.getOrElse(it) { true } }
            )
        }
        return result
    }
}
