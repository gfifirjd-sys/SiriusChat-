package com.sirius.chat.data.local.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.ProbeVerdict
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import com.sirius.chat.domain.model.VisionSupport
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.IOException

private val Context.providerDataStore: DataStore<Preferences> by preferencesDataStore(name = "sirius_providers")

@Serializable
private data class ModelDto(
    val id: String,
    val label: String = id,
    val contextWindow: Int = 0,
    val supportsStreaming: Boolean = true,
    val supportsTools: Boolean = true,
    /**
     * What a real image request proved about this model, as an enum *name*.
     *
     * Stored as a string rather than an ordinal because the ordinal is not a
     * stable identifier: inserting a case into [VisionSupport] would silently
     * reinterpret every stored row. The default covers both a file written by an
     * older build and an unrecognised value from a newer one, and it defaults to
     * "never measured" rather than to an answer.
     */
    val vision: String = VisionSupport.Unknown.name,
    /** Enum *names*, for the stability reason given above [vision]. */
    val toolsProbe: String = ProbeVerdict.Unknown.name,
    val streamProbe: String = ProbeVerdict.Unknown.name
)

@Serializable
private data class ProviderDto(
    val id: String,
    val label: String,
    val type: String,
    val baseUrl: String,
    val models: List<ModelDto> = emptyList(),
    val defaultModel: String = "",
    val enabled: Boolean = true,
    val builtIn: Boolean = false,
    val labelKey: String? = null,
    val iconKey: String? = null,
    val iconImagePath: String? = null
)

/**
 * Persists provider endpoints as JSON. Credentials are deliberately absent
 * here: they live in the encrypted credential store.
 */
class ProviderDataStore(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val key = stringPreferencesKey("providers_json")

    val providers: Flow<List<ProviderConfig>> = context.providerDataStore.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { prefs -> decode(prefs[key]) }

    suspend fun current(): List<ProviderConfig> = providers.first()

    suspend fun upsert(config: ProviderConfig) {
        mutate { list ->
            val index = list.indexOfFirst { it.id == config.id }
            if (index >= 0) list[index] = config else list += config
        }
    }

    /**
     * Removes the provider outright. Nothing is shipped into this list any more,
     * so there is no template to preserve: what the user deletes is gone, and the
     * catalogue is where they get another one.
     */
    suspend fun delete(id: String) {
        mutate { list -> list.removeAll { it.id == id } }
    }

    suspend fun setEnabled(id: String, enabled: Boolean) {
        mutate { list ->
            val index = list.indexOfFirst { it.id == id }
            if (index >= 0) list[index] = list[index].copy(enabled = enabled)
        }
    }

    private suspend fun mutate(block: (MutableList<ProviderConfig>) -> Unit) {
        context.providerDataStore.edit { prefs ->
            val list = decode(prefs[key]).toMutableList()
            block(list)
            prefs[key] = json.encodeToString(list.map { it.toDto() })
        }
    }

    /**
     * A fresh install has no providers at all. Nothing is seeded here on purpose:
     * a list the user did not ask for is a list they have to clean up, and every
     * shipped endpoint is one tap away in [ProviderPresets].
     */
    private fun decode(raw: String?): List<ProviderConfig> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching {
            json.decodeFromString<List<ProviderDto>>(raw).map { it.toDomain() }
        }.getOrElse { emptyList() }
    }

    private fun ProviderConfig.toDto() = ProviderDto(
        id = id,
        label = label,
        type = type.name,
        baseUrl = baseUrl,
        models = models.map {
            ModelDto(
                id = it.id,
                label = it.label,
                contextWindow = it.contextWindow,
                supportsStreaming = it.supportsStreaming,
                supportsTools = it.supportsTools,
                vision = it.vision.name,
                toolsProbe = it.toolsProbe.name,
                streamProbe = it.streamProbe.name
            )
        },
        defaultModel = defaultModel,
        enabled = enabled,
        builtIn = builtIn,
        labelKey = labelKey,
        iconKey = iconKey,
        iconImagePath = iconImagePath
    )

    private fun ProviderDto.toDomain() = ProviderConfig(
        id = id,
        label = label,
        type = ProviderType.entries.firstOrNull { it.name == type } ?: ProviderType.OpenAiCompatible,
        baseUrl = baseUrl,
        models = models.map {
            AiModel(
                id = it.id,
                label = it.label,
                contextWindow = it.contextWindow,
                supportsStreaming = it.supportsStreaming,
                supportsTools = it.supportsTools,
                // An unknown name degrades to "never measured", which makes the
                // capability layer fall back to its id heuristic instead of
                // trusting a value it cannot read.
                vision = VisionSupport.entries.firstOrNull { entry -> entry.name == it.vision }
                    ?: VisionSupport.Unknown,
                toolsProbe = ProbeVerdict.entries.firstOrNull { entry -> entry.name == it.toolsProbe }
                    ?: ProbeVerdict.Unknown,
                streamProbe = ProbeVerdict.entries.firstOrNull { entry -> entry.name == it.streamProbe }
                    ?: ProbeVerdict.Unknown
            )
        },
        defaultModel = defaultModel,
        enabled = enabled,
        builtIn = builtIn,
        labelKey = labelKey,
        iconKey = iconKey,
        iconImagePath = iconImagePath
    )
}
