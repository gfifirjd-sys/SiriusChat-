package com.sirius.chat.ai.provider

import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * How one endpoint wants generation parameters spelled.
 *
 * Only the two fields that are actually refused in practice are modelled. Every
 * other parameter this app sends is accepted everywhere, and a knob nobody
 * turns is a knob that rots.
 */
data class ParamQuirks(
    val maxTokensKey: String = "max_tokens",
    val sendTemperature: Boolean = true,
    /**
     * Whether a length cap may be sent at all.
     *
     * Almost always true -- every `/chat/completions` server takes one. It is
     * here for the gateway that does not, where repeating the field is a 400 on
     * every single message.
     */
    val sendMaxTokens: Boolean = true,
    /** Whether an effort tier may be sent. Cleared when the endpoint refuses one. */
    val sendReasoningEffort: Boolean = true,
    /** Whether a thinking budget may be sent. Cleared the same way. */
    val sendThinking: Boolean = true
)

/**
 * What each model refuses, seeded by name and corrected by experience.
 *
 * ### The problem this solves
 * Reasoning models rejected the request outright: `max_tokens` is
 * `max_completion_tokens` on the o-series and gpt-5, and any temperature but
 * the default is a 400 there and on Anthropic's extended-thinking models. The
 * app sent both to everything, so picking one of the strongest models available
 * turned every message into "the provider rejected the request" -- an error the
 * user could not act on, because nothing they typed caused it.
 *
 * ### Why a guess plus a correction
 * The name check catches the known families before the first request, so the
 * common case never sees an error at all. But model ids arrive decorated by
 * gateways and new families appear faster than any table is updated, so the
 * refusal itself is also read: when a 400 names a parameter, that answer is
 * recorded against the model and the caller retries. Learning beats listing,
 * and the list only has to cover the first attempt.
 *
 * Held in memory rather than on disk on purpose. A quirk costs one wasted
 * request to re-learn after a restart, while a wrong quirk written to storage
 * would quietly disable temperature for a model that never refused it.
 */
object ModelQuirks {

    private val learned = ConcurrentHashMap<String, ParamQuirks>()

    /** What to send this model, before it has had a chance to complain. */
    fun of(providerId: String, modelId: String): ParamQuirks =
        learned[key(providerId, modelId)] ?: seed(modelId)

    /**
     * Reads a rejection and records what it taught.
     *
     * @return true when something changed, which means the same request is
     * worth sending again. False means the 400 was about something else and the
     * caller must surface it -- retrying an unchanged request is how a loop
     * starts.
     */
    fun learn(providerId: String, modelId: String, message: String?): Boolean {
        val text = message?.lowercase(Locale.US).orEmpty()
        if (text.isBlank() || modelId.isBlank()) return false

        val current = of(providerId, modelId)
        var next = current

        // Named explicitly by the endpoint, which is the whole reason this is
        // readable rather than guessable: "Use 'max_completion_tokens' instead".
        if (current.maxTokensKey == MAX_TOKENS && text.contains(MAX_COMPLETION_TOKENS)) {
            next = next.copy(maxTokensKey = MAX_COMPLETION_TOKENS)
        }
        // Dropping temperature costs nothing the user will notice on a model
        // that refuses it -- it only ever accepts its own default anyway.
        // A range complaint is not a refusal: "temperature must be between 0 and
        // 2" says the value was wrong, not that the field is unknown, and
        // reading it as a refusal silently dropped the user's temperature for
        // the rest of the session. Anthropic's "may only be set to 1 when
        // thinking is enabled" still lands here, which is the case that has to
        // keep working.
        if (current.sendTemperature && text.contains("temperature") && !text.isRange()) {
            next = next.copy(sendTemperature = false)
        }
        // A rejection that names a power field is the endpoint saying the
        // capability table was wrong about it. Believing the endpoint is the only
        // thing that makes the retry succeed -- and it also feeds back into the
        // UI, which then honestly reports the knob as unavailable instead of
        // offering a setting that costs a turn each time it is used.
        //
        // Gated on rejection wording so that "max_tokens must be less than N" is
        // read as a limit, not as "this endpoint has no length cap".
        // "Only one of "reasoning.effort" and "reasoning.max_tokens" can be
        // specified": not a refusal of either field, so the wording check below
        // never sees it. The budget is the one dropped, because the tier is what
        // every gateway with a reasoning knob understands.
        if (current.sendThinking && text.contains(ONLY_ONE_OF) && text.mentions(REASONING_FIELDS)) {
            next = next.copy(sendThinking = false)
        }
        if (text.isRejection()) {
            if (current.sendReasoningEffort && text.mentions(REASONING_FIELDS)) {
                next = next.copy(sendReasoningEffort = false)
            }
            if (current.sendThinking && text.mentions(THINKING_FIELDS)) {
                next = next.copy(sendThinking = false)
            }
            if (current.sendMaxTokens &&
                text.contains(MAX_TOKENS) &&
                !text.contains(MAX_COMPLETION_TOKENS)
            ) {
                next = next.copy(sendMaxTokens = false)
            }
        }

        if (next == current) return false
        learned[key(providerId, modelId)] = next
        return true
    }

    /** Forgets everything learned. Exists so a changed base URL starts clean. */
    fun reset() = learned.clear()

    /**
     * Forgets one endpoint's lessons, for a base URL that changed under them.
     *
     * A quirk is a fact about a server, not about a model id: point the same
     * preset at a different gateway and every refusal it taught is now a guess
     * about somewhere else. Nothing called this before, so a single bad 400
     * narrowed a model until the process died -- and the power sheet kept
     * reporting knobs as unavailable on an endpoint that had never refused them.
     */
    fun forget(providerId: String) {
        val prefix = providerId + "|"
        learned.keys.filter { it.startsWith(prefix) }.forEach { learned.remove(it) }
    }

    /**
     * The families that are known to be different before anyone asks.
     *
     * Matched on the id with any gateway prefix removed, because the same model
     * arrives as `o3-mini`, `openai/o3-mini` and `azure/openai/o3-mini`. Prefix
     * matching rather than substring matching keeps `claude-3-opus` out of it.
     */
    private fun seed(modelId: String): ParamQuirks {
        val id = modelId.lowercase(Locale.US).substringAfterLast('/')
        val reasoning = REASONING_PREFIXES.any { id.startsWith(it) }
        return if (reasoning) {
            ParamQuirks(maxTokensKey = MAX_COMPLETION_TOKENS, sendTemperature = false)
        } else {
            ParamQuirks()
        }
    }

    private fun key(providerId: String, modelId: String): String =
        providerId + "|" + modelId.lowercase(Locale.US)

    private const val MAX_TOKENS = "max_tokens"

    private const val MAX_COMPLETION_TOKENS = "max_completion_tokens"

    private val REASONING_PREFIXES = listOf("o1", "o3", "o4", "gpt-5")

    /** Whether a 400 is about a field the endpoint does not know at all. */
    private fun String.isRejection(): Boolean = REJECTION_WORDS.any { contains(it) }

    private fun String.mentions(fields: List<String>): Boolean = fields.any { contains(it) }

    /** Whether a 400 is about a value being out of range rather than a field. */
    private fun String.isRange(): Boolean = RANGE_WORDS.any { contains(it) }

    /**
     * How the gateways in the wild word "I do not know this field".
     *
     * Deliberately narrow. A message about a value being out of range must not
     * be read as the field being unsupported, or one oversized budget would
     * disable thinking for the model permanently.
     */
    private const val ONLY_ONE_OF = "only one of"

    private val REJECTION_WORDS = listOf(
        "unsupported",
        "not supported",
        "unknown",
        "unrecognized",
        "unrecognised",
        "unexpected",
        "not allowed",
        "not permitted"
    )

    /**
     * How the same gateways word "that number is wrong".
     *
     * Only phrasings that cannot also mean "unknown field", so a real refusal is
     * never mistaken for a range and left unlearned.
     */
    private val RANGE_WORDS = listOf(
        "between",
        "less than",
        "greater than",
        "out of range",
        "at most",
        "at least",
        "maximum",
        "minimum"
    )

    private val REASONING_FIELDS = listOf("reasoning_effort", "reasoning")

    private val THINKING_FIELDS =
        listOf("thinking", "budget_tokens", "thinking_budget", "enable_thinking")
}
