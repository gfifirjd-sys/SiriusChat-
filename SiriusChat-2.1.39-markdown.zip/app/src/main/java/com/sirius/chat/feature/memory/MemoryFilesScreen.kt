package com.sirius.chat.feature.memory

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.relativeTimeText

/**
 * Memory as a folder of files, which is how it is written.
 *
 * ### Why this exists next to the graph
 * The graph answers "what does it know about me" as a shape. It cannot answer
 * "what exactly is written in the file about food, and who named it that" --
 * the thing a person checks before trusting a feature that writes about them
 * unprompted. This screen is that answer: the files, their headings, the lines
 * inside them, and one button to delete any of it.
 *
 * ### Why one screen and not two routes
 * The open file is state, not a destination: it is looked up from the same list
 * on every emission, so a file that changes while it is open changes on screen,
 * and one that is deleted closes itself. Back closes the file before it leaves
 * the screen, which is what the gesture means here.
 */
@Composable
fun MemoryFilesScreen(onBack: () -> Unit, contentPadding: PaddingValues) {
    val viewModel: MemoryFilesViewModel = siriusViewModel { MemoryFilesViewModel(it) }
    val state by viewModel.state.collectAsState()
    val colors = SiriusTheme.colors
    val open = state.open

    // Asking twice is remembered per file: opening another one must not inherit
    // a confirmation the user left behind somewhere else.
    var confirming by remember(open?.path) { mutableStateOf(false) }

    BackHandler(enabled = confirming || open != null) {
        when {
            confirming -> confirming = false
            else -> viewModel.close()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(contentPadding)
    ) {
        SiriusTopBar(
            title = open?.title ?: stringResource(R.string.memory_files_title),
            subtitle = if (open != null) {
                open.path
            } else {
                stringResource(R.string.memory_files_count, state.files.size)
            },
            scrolled = false,
            onBack = { if (open != null) viewModel.close() else onBack() },
            actions = {
                if (open != null) {
                    GlassIconButton(
                        icon = Icons.Rounded.DeleteOutline,
                        contentDescription = stringResource(R.string.memory_file_delete),
                        tint = colors.error,
                        highlighted = confirming,
                        onClick = { confirming = !confirming }
                    )
                }
            }
        )

        when {
            open != null -> MemoryFileDetail(
                file = open,
                confirming = confirming,
                onConfirm = {
                    confirming = false
                    viewModel.forget(open.path)
                },
                onCancel = { confirming = false },
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            )

            state.loaded && state.files.isEmpty() -> Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(SiriusSpacing.lg),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.memory_files_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
            }

            else -> MemoryFileList(
                state = state,
                onOpen = viewModel::open,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            )
        }
    }
}

@Composable
private fun MemoryFileList(
    state: MemoryFilesUiState,
    onOpen: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(SiriusSpacing.sm),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
    ) {
        MemoryFileGroup.entries.forEach { group ->
            val files = state.inGroup(group)
            if (files.isEmpty()) return@forEach

            item(key = "header-" + group.name) {
                Text(
                    text = stringResource(group.label()),
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.textTertiary,
                    modifier = Modifier.padding(
                        start = SiriusSpacing.xs,
                        top = SiriusSpacing.sm,
                        bottom = SiriusSpacing.xxs
                    )
                )
            }

            items(files, key = { it.path }) { file ->
                MemoryFileRow(file = file, onClick = { onOpen(file.path) })
            }
        }
    }
}

@Composable
private fun MemoryFileRow(file: MemoryFileCard, onClick: () -> Unit) {
    val colors = SiriusTheme.colors
    val updated = relativeTimeText(file.updatedAt)
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick,
        onClickLabel = file.title,
        contentPadding = SiriusSpacing.sm
    ) {
        Text(
            text = file.title,
            style = MaterialTheme.typography.bodyLarge,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        VSpace(2.dp)
        // The name the file is addressed by, and how much is in it, before
        // anything else. A heading on its own gives no sense of whether a file
        // holds one line or twenty, and the name in monospace is a reminder
        // that these are files a model writes to, not cards the app invented.
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = file.name,
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = colors.textTertiary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            Text(
                text = "  \u00b7  " + stringResource(R.string.memory_file_facts, file.lines.size),
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary,
                maxLines = 1
            )
        }
        VSpace(2.dp)
        Text(
            text = if (file.summary.isNotBlank()) {
                file.summary
            } else {
                stringResource(R.string.memory_file_updated, updated)
            },
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun MemoryFileDetail(
    file: MemoryFileCard,
    confirming: Boolean,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    val updated = relativeTimeText(file.updatedAt)
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = SiriusSpacing.sm)
    ) {
        VSpace(SiriusSpacing.xs)

        // The header the file was written with, in the shape it is written in.
        // Showing the real fields rather than a prettied summary is the point:
        // this is what the model reads back before it decides where a new fact
        // goes.
        GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = SiriusSpacing.sm) {
            MemoryFrontMatter("name", file.name)
            if (file.summary.isNotBlank()) MemoryFrontMatter("description", file.summary)
            MemoryFrontMatter("sources", "[chat]")
            if (file.aliases.isNotEmpty()) {
                MemoryFrontMatter("aliases", file.aliases.joinToString(", ", "[", "]"))
            }
            MemoryFrontMatter("updated", updated)
        }

        VSpace(SiriusSpacing.sm)

        if (file.lines.isEmpty()) {
            Text(
                text = stringResource(R.string.memory_file_no_lines),
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                modifier = Modifier.padding(SiriusSpacing.sm)
            )
        } else {
            file.lines.forEach { line ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xxs)
                ) {
                    Text(
                        text = "\u2022 ",
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textTertiary
                    )
                    Text(
                        text = line,
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textPrimary
                    )
                }
            }
        }

        if (confirming) {
            VSpace(SiriusSpacing.sm)
            GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = SiriusSpacing.sm) {
                Text(
                    text = stringResource(R.string.memory_file_delete_confirm),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textPrimary
                )
                VSpace(SiriusSpacing.xs)
                Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                    SiriusGhostButton(
                        text = stringResource(R.string.action_delete),
                        onClick = onConfirm,
                        icon = Icons.Rounded.DeleteOutline,
                        tint = colors.error
                    )
                    SiriusGhostButton(
                        text = stringResource(R.string.action_cancel),
                        onClick = onCancel
                    )
                }
            }
        }

        VSpace(SiriusSpacing.xl)
    }
}

@Composable
private fun MemoryFrontMatter(field: String, value: String) {
    val colors = SiriusTheme.colors
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = field + ": ",
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            color = colors.textTertiary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            color = colors.textSecondary
        )
    }
}

private fun MemoryFileGroup.label(): Int = when (this) {
    MemoryFileGroup.You -> R.string.memory_files_group_you
    MemoryFileGroup.Topics -> R.string.memory_files_group_topics
    MemoryFileGroup.Areas -> R.string.memory_files_group_areas
    MemoryFileGroup.People -> R.string.memory_files_group_people
}
