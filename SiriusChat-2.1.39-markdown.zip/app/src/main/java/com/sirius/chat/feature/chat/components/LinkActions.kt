package com.sirius.chat.feature.chat.components

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
// Aliased because androidx.compose.foundation.Image is imported above: this one
// is an extension property on Icons.Rounded, so it is used as Icons.Rounded.ImageIcon.
import androidx.compose.material.icons.rounded.Image as ImageIcon
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.SheetActionRow
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.ui.LocalAppContainer
import com.sirius.chat.data.files.FileExportResult
import com.sirius.chat.data.files.FileExporter
import com.sirius.chat.data.image.GeneratedImageStore
import com.sirius.chat.data.image.ImageExportResult
import com.sirius.chat.data.image.ImageExporter
import java.io.File
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/**
 * Where a tapped link in a message goes.
 *
 * A mutable holder rather than a lambda in the CompositionLocal on purpose: the
 * annotated string that carries the link is built inside `remember`, so whatever
 * it captures is captured for the lifetime of that text. Capturing a stable
 * object whose field is refreshed each composition keeps the tap wired up;
 * capturing the lambda directly would freeze the first one forever.
 */
@Stable
class LinkActionHandler internal constructor() {

    internal var onLink: ((String) -> Unit)? = null

    /**
     * True when something took the tap. False means nothing is hosting the
     * sheet — a preview, a test — and the caller should fall back to the browser,
     * because a link that does nothing at all is worse than a link that leaves.
     */
    fun handle(url: String): Boolean {
        val callback = onLink ?: return false
        callback(url)
        return true
    }
}

val LocalLinkActions = staticCompositionLocalOf { LinkActionHandler() }

/**
 * Hosts the link sheet for everything drawn inside it.
 *
 * ### Why the work lives here and not in the sheet
 * Every action closes the sheet first — anything else leaves a modal sitting over
 * a five second download. A coroutine started in the sheet would be cancelled by
 * that dismissal, so the scope belongs to the host, which stays composed for as
 * long as the app is on screen.
 *
 * ### Why a sheet instead of just opening the browser
 * A link in an answer is not always a page to read. It is a PNG the user wants in
 * their gallery, a JSON file they want on disk, or a site they want to *see*
 * without leaving the conversation. Jumping straight to the browser makes the
 * other three impossible, and each of them costs one row here.
 */
@Composable
fun LinkActionsHost(content: @Composable () -> Unit) {
    val handler = remember { LinkActionHandler() }
    var target by remember { mutableStateOf<String?>(null) }
    var preview by remember { mutableStateOf<File?>(null) }

    val container = LocalAppContainer.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val loadingText = stringResource(R.string.chat_link_loading)
    val shootingText = stringResource(R.string.chat_link_shooting)
    val failedText = stringResource(R.string.chat_link_failed)
    val notImageText = stringResource(R.string.chat_link_not_image)
    val shotFailedText = stringResource(R.string.chat_link_shot_failed)
    val savedText = stringResource(R.string.chat_file_saved, FileExporter.FOLDER)
    val saveFailedText = stringResource(R.string.chat_file_save_failed)
    val permissionText = stringResource(R.string.chat_file_permission)

    SideEffect { handler.onLink = { url -> target = url } }

    CompositionLocalProvider(LocalLinkActions provides handler) {
        content()
    }

    val openImage: (String) -> Unit = { link ->
        scope.launch {
            Toast.makeText(context, loadingText, Toast.LENGTH_SHORT).show()
            val stored = try {
                val remote = container.webCapture.download(link)
                if (remote.isImage) container.generatedImages.save(remote.bytes) else null
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Throwable) {
                null
            }
            if (stored == null) {
                Toast.makeText(context, notImageText, Toast.LENGTH_SHORT).show()
            } else {
                preview = File(stored.path)
            }
        }
    }

    val screenshot: (String) -> Unit = { link ->
        scope.launch {
            Toast.makeText(context, shootingText, Toast.LENGTH_SHORT).show()
            val bytes = try {
                container.webCapture.screenshot(link)
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Throwable) {
                null
            }
            val stored = if (bytes == null) null else container.generatedImages.save(bytes)
            if (stored == null) {
                Toast.makeText(context, shotFailedText, Toast.LENGTH_SHORT).show()
            } else {
                preview = File(stored.path)
            }
        }
    }

    val download: (String) -> Unit = { link ->
        scope.launch {
            Toast.makeText(context, loadingText, Toast.LENGTH_SHORT).show()
            val remote = try {
                container.webCapture.download(link)
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Throwable) {
                null
            }
            if (remote == null) {
                Toast.makeText(context, failedText, Toast.LENGTH_SHORT).show()
            } else {
                val message = when (
                    FileExporter.saveToDownloads(context, remote.name, remote.bytes)
                ) {
                    is FileExportResult.Saved -> savedText
                    FileExportResult.NeedsPermission -> permissionText
                    FileExportResult.Failed -> saveFailedText
                }
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    val link = target
    if (link != null) {
        LinkActionSheet(
            url = link,
            onDismiss = { target = null },
            onImage = openImage,
            onScreenshot = screenshot,
            onDownload = download
        )
    }

    val file = preview
    if (file != null) {
        ImagePreviewDialog(
            file = file,
            store = container.generatedImages,
            onDismiss = { preview = null }
        )
    }
}

@Composable
private fun LinkActionSheet(
    url: String,
    onDismiss: () -> Unit,
    onImage: (String) -> Unit,
    onScreenshot: (String) -> Unit,
    onDownload: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val uriHandler = LocalUriHandler.current

    val host = remember(url) {
        runCatching { Uri.parse(url).host }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: url.take(TITLE_CHARS)
    }
    val imageish = remember(url) { looksLikeImage(url) }
    val noAppText = stringResource(R.string.chat_link_no_app)
    val copiedText = stringResource(R.string.chat_copied)
    val shareTitle = stringResource(R.string.chat_link_share)

    SiriusBottomSheet(title = host, subtitle = url, onDismiss = onDismiss) {
        SheetActionRow(
            icon = Icons.Rounded.OpenInNew,
            label = stringResource(R.string.chat_link_open),
            supporting = stringResource(R.string.chat_link_open_hint),
            onClick = {
                onDismiss()
                runCatching { uriHandler.openUri(url) }.onFailure {
                    Toast.makeText(context, noAppText, Toast.LENGTH_SHORT).show()
                }
            }
        )
        SheetActionRow(
            icon = Icons.Rounded.ImageIcon,
            label = stringResource(R.string.chat_link_image),
            supporting = stringResource(R.string.chat_link_image_hint),
            onClick = {
                onDismiss()
                onImage(url)
            }
        )
        // Offered for pages, not for a link that is already a picture: rendering
        // a PNG in a browser and photographing it gives a worse copy of the file
        // the row above downloads directly.
        if (!imageish) {
            SheetActionRow(
                icon = Icons.Rounded.PhotoCamera,
                label = stringResource(R.string.chat_link_shot),
                supporting = stringResource(R.string.chat_link_shot_hint),
                onClick = {
                    onDismiss()
                    onScreenshot(url)
                }
            )
        }
        SheetActionRow(
            icon = Icons.Rounded.Download,
            label = stringResource(R.string.chat_link_download),
            supporting = stringResource(R.string.chat_file_download_hint, FileExporter.FOLDER),
            onClick = {
                onDismiss()
                onDownload(url)
            }
        )
        SheetActionRow(
            icon = Icons.Rounded.ContentCopy,
            label = stringResource(R.string.chat_link_copy),
            onClick = {
                onDismiss()
                clipboard.setText(AnnotatedString(url))
                Toast.makeText(context, copiedText, Toast.LENGTH_SHORT).show()
            }
        )
        SheetActionRow(
            icon = Icons.Rounded.Share,
            label = shareTitle,
            onClick = {
                onDismiss()
                val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(android.content.Intent.EXTRA_TEXT, url)
                }
                runCatching {
                    context.startActivity(android.content.Intent.createChooser(send, shareTitle))
                }.onFailure {
                    Toast.makeText(context, noAppText, Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
}

/**
 * Full-screen look at a picture the app just fetched or rendered.
 *
 * Deliberately thin: it decodes through [GeneratedImageStore] like the transcript
 * does, and hands saving to [ImageExporter], so a screenshot ends up in the same
 * album as a generated image and behaves the same way.
 */
@Composable
private fun ImagePreviewDialog(
    file: File,
    store: GeneratedImageStore,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var bitmap by remember(file.path) { mutableStateOf<ImageBitmap?>(null) }

    val savedText = stringResource(R.string.chat_image_saved, ImageExporter.ALBUM)
    val failedText = stringResource(R.string.chat_image_save_failed)
    val permissionText = stringResource(R.string.chat_image_permission_needed)

    LaunchedEffect(file.path) {
        bitmap = store.decode(file, PREVIEW_MAX_PX)?.asImageBitmap()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.94f)),
            contentAlignment = Alignment.Center
        ) {
            val loaded = bitmap
            if (loaded == null) {
                CircularProgressIndicator(color = colors.primary)
            } else {
                Image(
                    bitmap = loaded,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(SiriusSpacing.sm)
                )
            }
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(SiriusSpacing.sm),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(onClick = {
                    scope.launch {
                        val message = when (ImageExporter.saveToGallery(context, file)) {
                            is ImageExportResult.Saved -> savedText
                            ImageExportResult.NeedsPermission -> permissionText
                            ImageExportResult.Failed -> failedText
                        }
                        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Text(
                        text = stringResource(R.string.chat_preview_save),
                        color = colors.primary
                    )
                }
                TextButton(onClick = onDismiss) {
                    Text(
                        text = stringResource(R.string.action_close),
                        color = colors.textSecondary
                    )
                }
            }
        }
    }
}

/** Extension-based guess, used only to decide which rows are worth showing. */
private fun looksLikeImage(url: String): Boolean {
    val path = url.substringBefore('?').substringBefore('#').lowercase(Locale.ROOT)
    return IMAGE_EXTENSIONS.any { path.endsWith(it) }
}

private val IMAGE_EXTENSIONS = listOf(".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp")
private const val TITLE_CHARS = 40
private const val PREVIEW_MAX_PX = 2048
