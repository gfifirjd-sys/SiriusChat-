package com.sirius.chat.ai.model

import com.sirius.chat.domain.model.GenerationParams
import com.sirius.chat.domain.model.TokenUsage

/**
 * Provider-neutral message.
 *
 * [content] is the whole message as plain text and stays authoritative for
 * everything that reasons about text: the agent loop, history trimming, and any
 * provider that only speaks strings.
 *
 * [parts] is the same message as an ordered list of blocks, and is only set when
 * the message carries attachments. Keeping both means multimodal support did not
 * have to be threaded through every caller: a provider that understands blocks
 * uses [parts] when it is there, and every other path keeps working off
 * [content] exactly as before.
 */
data class AiMessage(
    val role: AiRole,
    val content: String,
    val parts: List<AiContentPart> = emptyList()
)

/**
 * One block of a message, in the order the user assembled it.
 *
 * Order is the point. The provider array must read "text, image, text,
 * document" if that is how it was typed, because that adjacency is the only
 * thing telling the model which sentence refers to which file.
 */
sealed interface AiContentPart {
    data class Text(val text: String) : AiContentPart

    /** Base64 image. [mediaType] must be one the provider accepts. */
    data class Image(val base64: String, val mediaType: String) : AiContentPart

    /** Base64 document (PDF), sent natively where supported. */
    data class Document(val base64: String, val mediaType: String, val name: String) :
        AiContentPart
}

enum class AiRole { System, User, Assistant }

/**
 * One tool, in the shape a vendor `tools` field expects.
 *
 * [parametersJson] is a JSON Schema object as *text* rather than a parsed tree,
 * so this layer stays free of serialization types and each provider can hand it
 * to its own encoder under whichever key it uses. A schema that fails to parse
 * is never fatal: providers substitute an open object, because losing the turn
 * over a schema is worse than letting the model send what the description
 * already told it to send.
 */
data class AiToolSpec(
    val name: String,
    val description: String,
    val parametersJson: String
)

/**
 * A tool call the model made through the vendor channel.
 *
 * [argumentsJson] is raw text, exactly as the endpoint sent it. It has to be:
 * a streamed call delivers its arguments in fragments that are only valid JSON
 * once concatenated, and some gateways re-serialize the field so the object
 * arrives double-encoded. Both are the caller's problem to notice, which it
 * cannot do if this type pretends the text was already an object.
 */
data class AiToolCall(
    val id: String,
    val name: String,
    val argumentsJson: String
)

data class ChatRequest(
    val model: String,
    val messages: List<AiMessage>,
    val systemPrompt: String? = null,
    val params: GenerationParams = GenerationParams(),
    val stream: Boolean = true,
    /**
     * Tools to offer through the vendor `tools` field.
     *
     * Empty means "do not send the field at all", and that is the fallback path
     * rather than a degraded one: the agent's fenced-block contract lives in the
     * system prompt and works on every endpoint, including the ones that reject
     * unknown request keys outright.
     */
    val tools: List<AiToolSpec> = emptyList()
)

/** Everything a provider can emit while answering. */
sealed interface ChatStreamEvent {
    data object Started : ChatStreamEvent
    data class Delta(val text: String) : ChatStreamEvent

    /**
     * Thinking text from a reasoning model, streamed as it arrives.
     *
     * Kept out of [Delta] because it is not the answer: it is a draft, often in
     * another language, and the tool-call parser would try to read it. It is
     * forwarded rather than silently counted, because a thinking phase is the
     * one time a perfectly healthy stream carries nothing the user can see --
     * and a watchdog that cannot tell that apart from a dead socket ends the
     * turn with "the provider timed out" while the model is still working.
     */
    data class Reasoning(val text: String) : ChatStreamEvent

    /**
     * The endpoint is alive and working, with nothing to show yet.
     *
     * Emitted for frames that carry no answer text: Anthropic's `ping`, the
     * `: keep-alive` comment lines gateways send while a reasoning model
     * thinks, and any frame type this client does not model. Purely a liveness
     * signal -- consumers that only want the answer ignore it.
     */
    data object Heartbeat : ChatStreamEvent
    data class Completed(
        val finishReason: String?,
        val fullText: String,
        /**
         * Reasoning/thinking characters received and deliberately kept out of
         * [fullText].
         *
         * A reasoning model can spend its entire token budget thinking and
         * return no answer at all. Without this count that arrives as an empty
         * string and is indistinguishable from a dead endpoint, which is how
         * "the model returned an empty response" came to be shown for a model
         * that had just written four thousand characters of thought.
         */
        val reasoningChars: Int = 0,
        /**
         * Tokens the endpoint reported, or `null` when it reported none.
         *
         * Never requested with `stream_options`: a local llama.cpp build or an
         * older vLLM rejects unknown request fields outright, and losing the
         * whole turn to obtain a counter is the wrong trade. Whatever arrives
         * unasked is read; the rest is estimated further up.
         */
        val usage: TokenUsage? = null,
        /**
         * Tool calls made through the vendor channel, already reassembled from
         * however many stream fragments they arrived in.
         *
         * Empty for every provider and every model that did not use the field,
         * which is what keeps the text-block parser a genuine fallback instead
         * of a second code path to keep in sync.
         */
        val toolCalls: List<AiToolCall> = emptyList()
    ) : ChatStreamEvent
    data class Failure(val error: AiError) : ChatStreamEvent
}

/** Normalised error so the UI can react without knowing the provider. */
data class AiError(
    val kind: Kind,
    val message: String,
    val statusCode: Int? = null,
    /**
     * How long the provider asked the client to wait before trying again, in
     * milliseconds, or `null` when it asked for nothing.
     *
     * Read from `Retry-After` and the vendor rate-limit reset headers. A stated
     * wait always beats a guessed one: retrying before the window reopens spends
     * an attempt on a certainty.
     */
    val retryAfterMillis: Long? = null
) {
    enum class Kind { Network, Unauthorized, RateLimited, BadRequest, Server, Cancelled, Unknown }

    val isRetryable: Boolean
        get() = kind == Kind.Network || kind == Kind.RateLimited || kind == Kind.Server
}
