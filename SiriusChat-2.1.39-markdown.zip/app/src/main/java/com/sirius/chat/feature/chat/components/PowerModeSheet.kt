package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.ai.capability.DefaultPowerModeResolver
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.SheetOptionRow
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.effects.ambientGlow
import com.sirius.chat.core.designsystem.effects.beamBorder
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.domain.model.EndpointCapabilities
import com.sirius.chat.domain.model.PowerConfig
import com.sirius.chat.domain.model.PowerMode

/**
 * How hard this model is asked to work, for this chat's endpoint and model.
 *
 * ### Why every row carries a second line
 * "High" on its own is a promise the app cannot keep everywhere: on one endpoint
 * it buys a reasoning tier, on another a 16k thinking budget, on a third only a
 * longer answer. Each row therefore states what it will actually send *here*,
 * computed by the same resolver that builds the request -- so the sheet cannot
 * describe one thing and the request do another.
 *
 * ### Why the empty case is loud
 * Plenty of endpoints have no power knob at all. Showing five rows that quietly
 * do nothing would be worse than showing none: the user would keep coming back
 * to a setting that never changes an answer. So the sheet says so outright and
 * offers nothing to press.
 */
@Composable
fun PowerModeSheet(
    mode: PowerMode,
    capabilities: EndpointCapabilities,
    custom: PowerConfig?,
    modelLabel: String,
    onSelect: (PowerMode) -> Unit,
    onSaveCustom: (PowerConfig) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors
    SiriusBottomSheet(
        title = stringResource(R.string.chat_power_title),
        subtitle = modelLabel,
        onDismiss = onDismiss
    ) {
        if (!capabilities.configurable) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .softSurface(RoundedCornerShape(SiriusRadius.md))
                    .padding(SiriusSpacing.sm),
                verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
            ) {
                Text(
                    text = stringResource(R.string.chat_power_unsupported),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textPrimary
                )
                Text(
                    text = stringResource(R.string.chat_power_unsupported_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary
                )
            }
        } else {
            CapabilityNotes(capabilities = capabilities)
            VSpace(SiriusSpacing.xs)
            // Whether CUSTOM has anything left after filtering. An empty one
            // sends no power field at all, and its row has to look like it.
            val customConfigured = !DefaultPowerModeResolver.sanitise(custom, capabilities).isNoOp
            PowerMode.entries.forEachIndexed { index, entry ->
                val selected = entry == mode
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            // Light on the active row only: a glow on every row is
                            // decoration, a glow on one is an answer to "which is
                            // on". MAX gets a wider halo because it is the one
                            // choice with a cost worth noticing.
                            if (selected) {
                                Modifier
                                    .ambientGlow(
                                        shape = RoundedCornerShape(SiriusRadius.md),
                                        radius = if (entry == PowerMode.MAX) 16.dp else 10.dp,
                                        alpha = 0.32f
                                    )
                                    .beamBorder(shape = RoundedCornerShape(SiriusRadius.md))
                            } else {
                                Modifier
                            }
                        )
                ) {
                    SheetOptionRow(
                        label = stringResource(powerLabelRes(entry)),
                        supporting = effectLabel(
                            mode = entry,
                            capabilities = capabilities,
                            custom = custom
                        ),
                        supportingMaxLines = 2,
                        selected = selected,
                        onClick = { onSelect(entry) },
                        index = index,
                        trailing = {
                            PowerLevelBars(
                                mode = entry,
                                active = selected,
                                configured = entry != PowerMode.CUSTOM || customConfigured
                            )
                        }
                    )
                }
            }
            if (mode == PowerMode.CUSTOM) {
                VSpace(SiriusSpacing.sm)
                CustomFields(
                    capabilities = capabilities,
                    custom = custom,
                    onSave = onSaveCustom
                )
            }
        }
    }
}

/** The label for one mode, for rows outside this sheet as well. */
fun powerLabelRes(mode: PowerMode): Int = when (mode) {
    PowerMode.LOW -> R.string.chat_power_low
    PowerMode.MEDIUM -> R.string.chat_power_medium
    PowerMode.HIGH -> R.string.chat_power_high
    PowerMode.MAX -> R.string.chat_power_max
    PowerMode.CUSTOM -> R.string.chat_power_custom
}

/**
 * What this endpoint reacts to at all, in its own words.
 *
 * Printed above the rows so the numbers below are not mysterious: a budget of
 * 16k reads very differently once it is clear the model tops out at 24k.
 */
@Composable
private fun CapabilityNotes(capabilities: EndpointCapabilities) {
    val colors = SiriusTheme.colors
    val effort = if (capabilities.supportsReasoningEffort) {
        stringResource(
            R.string.chat_power_supports_effort,
            capabilities.offeredTiers.joinToString(" / ")
        )
    } else {
        null
    }
    val budget = if (capabilities.supportsThinkingBudget) {
        stringResource(
            R.string.chat_power_supports_budget,
            tokenLabel(capabilities.thinkingBudgetMax)
        )
    } else {
        null
    }
    val tokens = if (capabilities.supportsMaxTokens) {
        stringResource(
            R.string.chat_power_supports_tokens,
            tokenLabel(capabilities.maxTokensLimit ?: 0)
        )
    } else {
        null
    }
    // Both knobs declared means neither can be combined. Saying it here stops
    // the budget line above from reading as a promise the request cannot keep.
    val exclusive = if (capabilities.supportsReasoningEffort && capabilities.supportsThinkingBudget) {
        stringResource(R.string.chat_power_effort_or_budget)
    } else {
        null
    }
    // Where the claim came from. A knob read off the model's name is the one line
    // here that the endpoint has not confirmed, and it can disappear after the
    // next request, so it does not get to look like the others.
    val assumed = if (capabilities.inferred) {
        stringResource(R.string.chat_power_assumed)
    } else {
        null
    }
    // Nothing declared, but manual mode can still try. Worth saying, because the
    // rows below will only talk about length, which reads as "this model cannot
    // think" when the truth is that nobody has listed this endpoint.
    val manual = if (!capabilities.supportsReasoningEffort &&
        !capabilities.supportsThinkingBudget &&
        capabilities.manualEffortAllowed
    ) {
        stringResource(R.string.chat_power_manual_hint)
    } else {
        null
    }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        listOfNotNull(effort, budget, tokens, exclusive, assumed, manual).forEach { line ->
            Text(
                text = line,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary
            )
        }
    }
}

/**
 * The second line of a row: what pressing it will actually send.
 *
 * Asks the resolver rather than describing the scale, because the scale is not
 * the truth -- clamping is. On a model whose real ceiling is 8k, HIGH and MAX
 * say the same number here, which is exactly what the request will do.
 */
@Composable
private fun effectLabel(
    mode: PowerMode,
    capabilities: EndpointCapabilities,
    custom: PowerConfig?
): String {
    // CUSTOM reads its own saved numbers back through the same filter the request
    // uses, so a field this endpoint no longer accepts is not still advertised
    // here. Nothing saved means nothing sent, and the row keeps the hint rather
    // than describing a request it will not make.
    val resolved = if (mode == PowerMode.CUSTOM) {
        DefaultPowerModeResolver.sanitise(custom, capabilities)
    } else {
        DefaultPowerModeResolver.resolve(mode, capabilities)
    }
    if (mode == PowerMode.CUSTOM && resolved.isNoOp) {
        return stringResource(R.string.chat_power_custom_hint)
    }
    val effort = resolved.reasoningEffort
    val budget = resolved.thinkingBudget
    val tokens = resolved.maxTokens
    return when {
        effort != null -> stringResource(R.string.chat_power_effect_effort, effort)
        budget != null -> stringResource(
            R.string.chat_power_effect_budget,
            tokenLabel(budget),
            tokenLabel(tokens ?: budget)
        )
        tokens != null -> stringResource(R.string.chat_power_effect_tokens, tokenLabel(tokens))
        else -> stringResource(R.string.chat_power_effect_none)
    }
}

/**
 * The manual fields -- only the ones this endpoint really takes.
 *
 * A form that offered a thinking budget to a model without thinking would be
 * teaching the user a setting that cannot work, and the value would be dropped
 * on the way to the request anyway.
 */
@Composable
private fun CustomFields(
    capabilities: EndpointCapabilities,
    custom: PowerConfig?,
    onSave: (PowerConfig) -> Unit
) {
    val colors = SiriusTheme.colors
    var effort by remember(custom) { mutableStateOf(custom?.reasoningEffort) }
    var budget by remember(custom) { mutableStateOf(custom?.thinkingBudget?.toString().orEmpty()) }
    var tokens by remember(custom) { mutableStateOf(custom?.maxTokens?.toString().orEmpty()) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .softSurface(RoundedCornerShape(SiriusRadius.md))
            .padding(SiriusSpacing.sm),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
    ) {
        if (capabilities.manualEffortAllowed) {
            Text(
                text = stringResource(R.string.chat_power_custom_effort),
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)) {
                capabilities.manualTiers.forEach { tier ->
                    SiriusChip(
                        text = tier,
                        selected = tier == effort,
                        // Tapping the active chip clears it. That is the only way
                        // back to a budget on an endpoint that offers both and
                        // accepts exactly one.
                        onClick = { effort = if (tier == effort) null else tier }
                    )
                }
            }
        }
        // Hidden while a tier is chosen: only one of the two reaches the
        // request, and a field whose value is silently dropped is worse than a
        // field that is not offered.
        if (capabilities.manualBudgetAllowed && effort == null) {
            SiriusTextField(
                value = budget,
                // Digits only, filtered on the way in: a text field that accepts
                // "16k" and then silently parses to null is a saved setting that
                // does nothing.
                onValueChange = { entered -> budget = entered.filter { it.isDigit() } },
                label = stringResource(R.string.chat_power_custom_budget),
                placeholder = stringResource(
                    R.string.chat_power_custom_limit,
                    tokenLabel(capabilities.thinkingBudgetMax)
                ),
                keyboardType = KeyboardType.Number
            )
        }
        if (capabilities.supportsMaxTokens) {
            SiriusTextField(
                value = tokens,
                onValueChange = { entered -> tokens = entered.filter { it.isDigit() } },
                label = stringResource(R.string.chat_power_custom_tokens),
                placeholder = stringResource(
                    R.string.chat_power_custom_limit,
                    tokenLabel(capabilities.maxTokensLimit ?: 0)
                ),
                keyboardType = KeyboardType.Number
            )
        }
        SiriusPrimaryButton(
            text = stringResource(R.string.chat_power_custom_save),
            onClick = {
                onSave(
                    PowerConfig(
                        maxTokens = tokens.toIntOrNull(),
                        reasoningEffort = effort,
                        // Never both, for the same reason the field is hidden.
                        thinkingBudget = if (effort == null) budget.toIntOrNull() else null
                    )
                )
            },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** 16384 reads as 16k. Exact numbers matter in the field, not in a caption. */
private fun tokenLabel(value: Int): String =
    if (value >= 1_000) (value / 1_000).toString() + "k" else value.toString()
