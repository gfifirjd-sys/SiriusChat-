package com.sirius.chat.data.repository

import com.sirius.chat.data.local.preferences.ProviderDataStore
import com.sirius.chat.data.local.security.SecureCredentialStore
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.repository.ProviderRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class ProviderRepositoryImpl(
    private val store: ProviderDataStore,
    private val credentials: SecureCredentialStore
) : ProviderRepository {

    override fun observeAllProviders(): Flow<List<ProviderConfig>> =
        combine(store.providers, credentials.providersWithKeys) { providers, withKeys ->
            providers.map { it.copy(hasKey = it.id in withKeys) }
        }

    // Callers that pick a provider to talk to must never see a removed one, so the
    // filtering happens here instead of at each call site.
    override fun observeProviders(): Flow<List<ProviderConfig>> =
        observeAllProviders().map { providers -> providers.filter { it.enabled } }

    override suspend fun providers(): List<ProviderConfig> = observeProviders().first()

    override suspend fun get(id: String): ProviderConfig? = providers().firstOrNull { it.id == id }

    override suspend fun upsert(config: ProviderConfig) = store.upsert(config)

    override suspend fun delete(id: String) {
        credentials.remove(id)
        store.delete(id)
    }

    override suspend fun setEnabled(id: String, enabled: Boolean) = store.setEnabled(id, enabled)

    // Trimmed on the way in and on the way out. A key is copied from a web page,
    // and a web page hands out a trailing newline with it; that newline cannot go
    // into an HTTP header, so an otherwise valid key failed every request with an
    // error that pointed at everything except the whitespace.
    override suspend fun setApiKey(providerId: String, key: String) =
        credentials.put(providerId, key.trim())

    override suspend fun apiKey(providerId: String): String? = credentials.get(providerId)?.trim()

    override suspend fun clearApiKey(providerId: String) = credentials.remove(providerId)
}
