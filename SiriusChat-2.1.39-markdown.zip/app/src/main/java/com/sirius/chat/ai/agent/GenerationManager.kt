package com.sirius.chat.ai.agent

import com.sirius.chat.R
import com.sirius.chat.ai.capability.DefaultPowerModeResolver
import com.sirius.chat.ai.capability.EndpointCapabilityTable
import com.sirius.chat.ai.capability.ModelCapabilities
import com.sirius.chat.ai.memory.MemoryPrompt
import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.pricing.TokenEstimate
import com.sirius.chat.ai.provider.AiProvider
import com.sirius.chat.core.locale.displayLabel
import com.sirius.chat.data.terminal.TerminalEvent
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.ChatFeatures
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.GenerationParams
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.model.MessageStatus
import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.TokenUsage
import com.sirius.chat.domain.model.ToolRun
import com.sirius.chat.domain.model.defaultChatFeatures
import com.sirius.chat.domain.model.powerSelection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.CompletableDeferred
import android.net.Uri
import android.os.Environment
import java.io.File
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Live assistant answer that is not persisted yet. */
data class StreamingAnswer(
    /** What the user sees: prose only, tool blocks removed. */
    val text: String = "",
    /** Everything the model emitted, needed to strip partial tool fences. */
    val raw: String = "",
    val toolRuns: List<ToolRun> = emptyList(),
    val activeTool: String? = null,
    val step: Int = 0,
    /** Title of the session, so a notification can name it without a lookup. */
    val sessionTitle: String = "",
    /** Tokens this turn has cost so far, when the provider reports them. */
    val usage: TokenUsage? = null
)

/** A failure attached to a session, kept until the user dismisses or retries. */
data class GenerationFailure(
    val message: String,
    val retryable: Boolean
)

/**
 * Owns every running generation in the app.
 *
 * This used to live in `ChatViewModel`, which made the model's answer a property
 * of a screen: closing the chat cancelled `viewModelScope`, and the answer died
 * mid-sentence. Generation is not a screen concern — the user asked a question and
 * expects the answer to exist whether or not they are looking at it. So the work
 * runs on the application scope, keyed by session, and the chat screen is just one
 * observer of it.
 *
 * Several sessions can run at once. That is deliberate: with the work no longer
 * tied to the visible chat there is nothing left to serialise, and a user who
 * starts a long agent run and then asks something else in another chat should not
 * be told to wait.
 */
class GenerationManager(
    private val container: AppContainer,
    private val scope: CoroutineScope
) {

    private val _streams = MutableStateFlow<Map<String, StreamingAnswer>>(emptyMap())

    /** Live answers by session id. A session absent from the map is idle. */
    val streams: StateFlow<Map<String, StreamingAnswer>> = _streams.asStateFlow()

    private val _failures = MutableStateFlow<Map<String, GenerationFailure>>(emptyMap())
    val failures: StateFlow<Map<String, GenerationFailure>> = _failures.asStateFlow()

    private val _questions = MutableStateFlow<Map<String, AgentQuestion>>(emptyMap())

    /** Unanswered `ask_user` questions by session id. */
    val questions: StateFlow<Map<String, AgentQuestion>> = _questions.asStateFlow()

    // Keyed by question id, not session id: a run is single threaded, but keying
    // by session would let a stale sheet from a cancelled run resume the wrong
    // coroutine if the user starts a new turn quickly.
    private val answers = ConcurrentHashMap<String, CompletableDeferred<String>>()

    /**
     * Delivers the user's answer. Blank means skipped, which [AskUserTool] treats
     * as a legitimate "decide for me" rather than an error.
     */
    fun answerQuestion(sessionId: String, questionId: String, answer: String) {
        _questions.update { if (it[sessionId]?.id == questionId) it - sessionId else it }
        answers.remove(questionId)?.complete(answer)
    }

    /** Session ids currently generating, for the chat list indicator. */
    val activeSessions: StateFlow<Set<String>> = MutableStateFlow<Set<String>>(emptySet()).also { flow ->
        scope.launch {
            _streams.map { it.keys }.distinctUntilChanged().collect { flow.value = it }
        }
    }.asStateFlow()

    // Concurrent: sessions start and finish from different coroutines, and a plain
    // HashMap here can lose an entry or corrupt itself under exactly the case this
    // class exists for -- two chats generating at once.
    private val jobs = ConcurrentHashMap<String, Job>()

    /**
     * Sessions whose partial answer is being written after a manual stop.
     *
     * Marks the window in which the cancelled job's cleanup must not clear the
     * streaming bubble, because `stop()` is still moving that bubble into the
     * database.
     */
    private val handovers = ConcurrentHashMap.newKeySet<String>()

    fun stream(sessionId: String): Flow<StreamingAnswer?> =
        _streams.map { it[sessionId] }.distinctUntilChanged()

    fun failure(sessionId: String): Flow<GenerationFailure?> =
        _failures.map { it[sessionId] }.distinctUntilChanged()

    fun isRunning(sessionId: String): Boolean = _streams.value.containsKey(sessionId)

    fun clearFailure(sessionId: String) {
        _failures.update { it - sessionId }
    }

    /**
     * Starts generating an answer for [sessionId].
     *
     * A second call while the session is already running is ignored rather than
     * queued: two concurrent answers to one conversation would interleave their
     * tool calls over the same files.
     */
    fun start(sessionId: String) {
        if (jobs[sessionId]?.isActive == true) return
        _failures.update { it - sessionId }
        jobs[sessionId] = scope.launch {
            try {
                generate(sessionId)
            } finally {
                jobs.remove(sessionId)
                // Whatever happened — success, failure, cancellation — the session
                // must not stay marked as running, or the chat list pulses forever.
                //
                // Skipped while a handover is in flight: `stop()` cancels this job and
                // then persists the partial answer itself, and clearing the stream here
                // would pull the bubble out from under that write.
                if (!handovers.contains(sessionId)) {
                    _streams.update { it - sessionId }
                }
            }
        }
    }

    /** Stops [sessionId], keeping whatever the model already said. */
    fun stop(sessionId: String) {
        // Keeping the partial itself rather than a separate boolean means the
        // write below cannot be reached without the text it is about to store.
        val keep = _streams.value[sessionId]
            ?.takeIf { it.text.isNotBlank() || it.toolRuns.isNotEmpty() }

        // Claim the handover *before* cancelling, so the job's own cleanup cannot
        // clear the bubble in the gap between the cancel and the write.
        if (keep != null) handovers.add(sessionId)
        jobs.remove(sessionId)?.cancel()

        if (keep != null) {
            // Clear inside the coroutine, after the row is visible. Clearing here
            // instead would drop the bubble while the write was still in flight and
            // blank the answer the user just chose to keep.
            scope.launch {
                try {
                    val stored = persist(sessionId, keep, MessageStatus.Cancelled)
                    if (stored != null) awaitVisible(sessionId, stored)
                } finally {
                    handovers.remove(sessionId)
                    _streams.update { it - sessionId }
                }
            }
        } else {
            _streams.update { it - sessionId }
        }
    }

    // ------------------------------------------------------------------ internals

    /** Atomic read-modify-write: two sessions stream into this map at the same time. */
    /**
     * Learns durable facts from a finished turn, out of band.
     *
     * Launched on the manager's own scope rather than inside the run: the run is
     * ending, and a second request that outlives it must not be cancelled by its
     * completion. Every failure is swallowed for the same reason the titler
     * swallows them -- nothing the user just read depends on this, so it is never
     * allowed to surface an error or delay the chat.
     *
     * Deliberately runs even when this chat has memory switched off. That switch
     * decides whether the model is *told* what is known, not whether the app may
     * keep listening; forgetting is what the memory screen's delete buttons are
     * for.
     */
    private fun learn(sessionId: String) {
        scope.launch {
            runCatching { container.memoryExtractor.learn(sessionId) }
        }
    }

    /**
     * Names the conversation once there is an answer in it, out of band.
     *
     * The composer asks for a name the moment a message is sent, which is
     * before the model has said anything -- and a chat whose opening is only
     * "привет" cannot be named from that alone. Asking again here is what
     * turns it into "Приветствие" instead of leaving it "Новый чат" for good.
     *
     * A no-op for any chat that already has a real name: the titler refuses to
     * touch one the user or an earlier call has settled.
     */
    private fun retitle(sessionId: String) {
        scope.launch {
            runCatching { container.sessionTitler.retitle(sessionId) }
        }
    }

    private fun update(sessionId: String, block: (StreamingAnswer) -> StreamingAnswer) {
        _streams.update { current ->
            current + (sessionId to block(current[sessionId] ?: StreamingAnswer()))
        }
    }

    private suspend fun generate(sessionId: String) {
        val session = container.chatRepository.getSession(sessionId) ?: return
        val settings = container.settingsRepository.current()
        val provider = container.providerFactory.create(session.providerId)
        if (provider == null) {
            fail(sessionId, container.strings.get(R.string.chat_error_provider_missing), false)
            return
        }
        val config = container.providerRepository.get(session.providerId)
        if (config != null && container.providerFactory.requiresApiKey(config) && !config.hasKey) {
            fail(
                sessionId,
                container.strings.get(
                    R.string.chat_error_no_key,
                    config.displayLabel(container.strings)
                ),
                false
            )
            return
        }

        _streams.update { it + (sessionId to StreamingAnswer(sessionTitle = session.title)) }

        // The session's own switches, falling back to the user's defaults when
        // this chat has never had them set (every conversation created before the
        // settings panel existed, and every brand-new one).
        //
        // Clamped to the model's real capabilities here rather than at the UI, so
        // it holds for a session whose model changed after the switches were set
        // -- the panel is not necessarily open, and the request must not carry a
        // capability the endpoint will reject.
        val features = (session.features ?: settings.defaultChatFeatures())
            .clampTo(ModelCapabilities.of(config, session.model))

        // Resolved once for this request. The same numbers decide how much room
        // the compactor leaves for the answer and what the provider finally
        // writes, so reserving one budget and sending another is impossible.
        val capabilities = EndpointCapabilityTable.effective(config, session.model)
        val power = DefaultPowerModeResolver.resolve(
            settings.powerSelection(session.providerId, session.model),
            capabilities
        )

        val project = session.projectId?.let { container.projectRepository.get(it) }
        // Context compression. As the conversation approaches the model's window
        // its oldest turns are folded into a running summary, instead of falling
        // off the front of a character cap with nothing left behind to say so.
        // Every failure path inside returns the old trimmed history, so a slow or
        // dead summariser can never block an answer.
        val history = container.contextCompactor.prepare(
            sessionId = sessionId,
            stored = container.chatRepository.messages(sessionId),
            provider = provider,
            modelId = session.model,
            // Known only when the preset declares it. Zero means unknown, and the
            // compactor deliberately falls back to a conservative budget rather
            // than guessing a window a local endpoint may not have.
            contextWindow = config?.models?.firstOrNull { it.id == session.model }?.contextWindow ?: 0,
            // The power mode's cap when it set one: reserving the Settings
            // default while sending a 16k answer is how a reply gets cut off by
            // the very compaction that was supposed to make room for it.
            reserveTokens = power.maxTokens ?: settings.maxTokens,
            // The chat's context switch, or the Settings default for a chat that
            // has never set one. Off means the user asked for the feature to stop
            // working here, and folding is the part of it that actually touches
            // the conversation -- so it has to be gated by the same flag as the
            // meter, not just hidden behind it.
            compact = session.contextMeter ?: settings.showContextMeter
        ).prompt
        val projectContext = runCatching {
            container.projectContextBuilder.projectSummary(project)
        }.getOrNull()
        // Attachments become ordered content blocks: images and PDFs as native
        // blocks, text files inlined where they were attached. Previously every
        // attachment on the last message was flattened into one "Attached files:"
        // tail, which lost both the ordering and any file that was not text.
        val attachmentParts = runCatching {
            container.attachmentPromptBuilder.build(
                treeUri = project?.treeUri,
                messages = history,
                vision = features.vision
            )
        }.getOrDefault(emptyMap())

        val wire = history.map { message ->
            val role = if (message.role == MessageRole.User) AiRole.User else AiRole.Assistant
            AiMessage(role, message.content, attachmentParts[message.id].orEmpty())
        }.toMutableList()

        runAgent(
            sessionId = sessionId,
            provider = provider,
            session = session,
            project = project,
            wire = wire,
            projectContext = projectContext,
            params = GenerationParams(
                temperature = settings.temperature,
                maxTokens = settings.maxTokens,
                // A no-op result travels as null, which is how both payload
                // builders know to add nothing at all. Temperature stays exactly
                // where the user left it: power is about effort, not randomness.
                power = power.takeIf { !it.isNoOp },
                // The ceiling the request will really be clamped to, so a retry
                // cannot ask for more than this endpoint accepts.
                maxTokensLimit = capabilities.maxTokensLimit
            ),
            maxSteps = settings.agentMaxSteps,
            autoApply = settings.agentAutoApplyChanges,
            allowTerminal = settings.agentTerminalEnabled,
            features = features,
            memoryDefault = settings.memoryEnabled,
            economical = settings.performanceMode.economical(container.weakDevice)
        )
    }

    private suspend fun runAgent(
        sessionId: String,
        provider: AiProvider,
        session: ChatSession,
        project: Project?,
        wire: List<AiMessage>,
        projectContext: String?,
        params: GenerationParams,
        maxSteps: Int,
        autoApply: Boolean,
        allowTerminal: Boolean,
        features: ChatFeatures,
        /**
         * Whether memory is on for chats that have never chosen -- the Settings
         * default. The session's own switch wins when it has one.
         */
        memoryDefault: Boolean = true,
        /** Whether this device (or this user) asked for the cheap path. */
        economical: Boolean = false
    ) {
        // Needed by the streaming strip below. Without it a call the model wrote
        // in a ```json fence stays visible in the bubble while it streams and
        // then vanishes when the final text is stored, which reads as a glitch.
        val knownTools = container.agentEngine.toolList().mapTo(HashSet()) { it.name }

        val context = AgentContext(
            sessionId = sessionId,
            projectId = project?.id,
            treeUri = project?.treeUri,
            workspace = container.workspaceRepository,
            askUser = { question ->
                val pending = CompletableDeferred<String>()
                answers[question.id] = pending
                // File what has already been said before the run stops on a
                // person. They may never come back to this sheet: the turn then
                // ends unanswered, and everything they stated on the way here
                // would be lost with it.
                learn(sessionId)
                _questions.update { it + (sessionId to question) }
                // The run is now blocked on a person, and a person who is not in
                // the app has no way of finding that out: the sheet is on a
                // screen they are not looking at. This is the one event in the
                // whole pipeline worth interrupting for.
                container.notifier.question(
                    sessionId = sessionId,
                    chat = _streams.value[sessionId]?.sessionTitle.orEmpty(),
                    question = question.question
                )
                try {
                    // Cancelling the turn cancels this await, which unwinds the
                    // agent loop normally. Without the finally the sheet would
                    // outlive the run and hang the next one.
                    pending.await()
                } finally {
                    answers.remove(question.id)
                    _questions.update { if (it[sessionId]?.id == question.id) it - sessionId else it }
                    // Answered, skipped or cancelled -- either way the request in
                    // the shade is stale, and tapping it would open a chat that
                    // is waiting for nothing.
                    container.notifier.clear(sessionId)
                }
            },
            runCommand = { command, timeoutMs -> runShell(command, project, timeoutMs) },
            providerId = session.providerId,
            // Auto-apply is only real when there is somewhere to write, so the
            // flag the tools see is the setting AND an attached folder. Claiming
            // "written to disk" for a project with no workspace would be the
            // same class of lie this whole change removes.
            autoApply = autoApply && project?.treeUri != null,
            applyChange = { change -> applyOne(project?.treeUri, change) }
        )

        // Read once per turn rather than per step: the facts cannot change while
        // the model is thinking, and the system prompt is built from them exactly
        // once. A chat with memory off skips the read entirely instead of loading
        // facts it is not allowed to use.
        val memory = if (session.memory ?: memoryDefault) {
            runCatching { MemoryPrompt.block(container.memoryRepository.nodes()) }.getOrNull()
        } else {
            null
        }

        // Deltas arrive far faster than a phone can draw them: a token every few
        // milliseconds, and each one rebuilds the whole answer string, re-runs the
        // tool-block strip over it, pushes a new map through a StateFlow and
        // re-parses the markdown for the bubble. That is O(n^2) work in the length
        // of the answer, and none of it is legible -- nobody reads sixty updates a
        // second. Characters are buffered and published on a clock instead, so the
        // cost per second is bounded by the cadence rather than by how fast the
        // provider sends. 60ms is ~16 updates a second, which still looks like
        // typing; a slow device gets 140ms, which still looks alive.
        val publishGap = if (economical) 140L else 60L
        val pending = StringBuilder()
        var lastPublish = 0L

        fun publish(force: Boolean) {
            if (pending.isEmpty()) return
            val now = System.currentTimeMillis()
            if (!force && now - lastPublish < publishGap) return
            val chunk = pending.toString()
            pending.setLength(0)
            lastPublish = now
            update(sessionId) {
                val raw = it.raw + chunk
                it.copy(raw = raw, text = ToolCallParser.stripToolBlocks(raw, knownTools))
            }
        }

        container.agentEngine.run(
            provider = provider,
            model = session.model,
            history = wire,
            context = context,
            projectContext = projectContext,
            params = params,
            maxSteps = maxSteps,
            autoApply = autoApply,
            allowTerminal = allowTerminal,
            features = features,
            memory = memory
        ).collect { event ->
            when (event) {
                is AgentEvent.StepStarted -> update(sessionId) { it.copy(step = event.step) }
                is AgentEvent.Delta -> {
                    // Buffered, not dropped. The strip still runs on everything
                    // that reaches the screen, so tool JSON is never visible --
                    // it just runs on the published cadence instead of per token.
                    pending.append(event.text)
                    publish(force = false)
                }
                is AgentEvent.ToolStarted -> {
                    // Whatever was written before the call has to appear before
                    // the tool card does, or the two arrive out of order.
                    publish(force = true)
                    update(sessionId) { it.copy(activeTool = event.toolName) }
                }
                is AgentEvent.ToolFinished -> {
                    publish(force = true)
                    update(sessionId) {
                        it.copy(toolRuns = it.toolRuns + event.run, activeTool = null)
                    }
                }
                is AgentEvent.Proposals -> {
                    // Auto-apply deliberately no longer runs here. It used to,
                    // and that was the bug: this event is emitted once, *after*
                    // the agent loop has already finished, so "applied here so the
                    // agent's next step reads the file it just wrote" in practice
                    // applied after the last step. Every run_command in between
                    // saw a filesystem the writes had not reached, which is how a
                    // created file was followed by "cd: No such file or directory"
                    // and then created a second time.
                    //
                    // Writing now happens inside the mutating tool, between steps,
                    // through AgentContext.applyChange. What still arrives here is
                    // everything that was NOT written: the whole queue in review
                    // mode, and in auto-apply mode only the failed writes.
                    container.changeStore.submit(event.changes)
                }
                is AgentEvent.Completed -> {
                    // Last chance for anything still buffered: the stored message
                    // is built from the stream state a few lines below.
                    publish(force = true)
                    val current = _streams.value[sessionId] ?: StreamingAnswer()
                    // Write first, clear second: the other order left a window with
                    // no streaming bubble and no stored message, and the answer
                    // blinked out of the chat.
                    // Image links are checked against the folder before the
                    // answer is stored, not when it is drawn: a name the model
                    // mistyped is repaired from what this turn's tools actually
                    // produced, and one that matches nothing at all loses the
                    // link rather than leaving a dead picture in the history
                    // for as long as the chat exists.
                    val stored = persist(
                        sessionId,
                        current.copy(
                            text = container.generatedImages.repair(
                                event.text.ifBlank { current.text },
                                current.toolRuns.map { it.output }
                            ),
                            usage = event.usage ?: current.usage
                        ),
                        MessageStatus.Complete
                    )
                    // Writing is not enough -- the row also has to have travelled
                    // through Room's Flow into the message list before the bubble
                    // goes away, or the chat is briefly missing the answer entirely
                    // and looks like it reset. Wait for the id to actually show up.
                    if (stored != null) awaitVisible(sessionId, stored)
                    _streams.update { it - sessionId }
                    container.projectContextBuilder.invalidate()
                    learn(sessionId)
                    retitle(sessionId)
                    // Posted last, once the answer is actually stored and
                    // visible: a notification for something the chat cannot show
                    // yet is a notification that opens an empty conversation.
                    container.notifier.done(
                        sessionId = sessionId,
                        chat = current.sessionTitle,
                        preview = event.text.ifBlank { current.text }
                    )
                }
                is AgentEvent.Failure -> {
                    publish(force = true)
                    val partial = _streams.value[sessionId]
                    if (partial != null && (partial.text.isNotBlank() || partial.toolRuns.isNotEmpty())) {
                        // Half an answer plus an error is recoverable; an empty chat
                        // plus an error is not.
                        val stored = persist(sessionId, partial, MessageStatus.Failed)
                        if (stored != null) awaitVisible(sessionId, stored)
                    }
                    _streams.update { it - sessionId }
                    fail(sessionId, event.error.message, event.error.isRetryable)
                    container.notifier.failed(
                        sessionId = sessionId,
                        chat = partial?.sessionTitle.orEmpty(),
                        message = event.error.message
                    )
                }
            }
        }
    }

    /**
     * Stores a finished (or stopped, or failed) answer.
     *
     * [NonCancellable] is the point: an answer that reached the screen must reach
     * the database, even if the caller is being cancelled at that exact moment.
     * An empty answer with no tool runs is dropped — a blank bubble is worse than
     * no bubble.
     *
     * Returns the id of the stored message, or null when nothing was worth storing.
     */
    /**
     * Fallback count for endpoints that report no usage at all.
     *
     * Only the answer is counted, and the result is flagged as an estimate. The
     * prompt is not visible from here, and reconstructing it from stored history
     * would be wrong in exactly the conversations where the number matters --
     * the compactor may have folded half of that history away before the call.
     * An output-only approximation is the largest honest claim available, which
     * is also why cost is not derived from it.
     */
    private fun estimatedUsage(text: String): TokenUsage? {
        if (text.isBlank()) return null
        return TokenUsage(
            promptTokens = 0,
            completionTokens = TokenEstimate.tokens(text),
            estimated = true
        )
    }

    private suspend fun persist(
        sessionId: String,
        answer: StreamingAnswer,
        status: MessageStatus
    ): String? {
        val session = container.chatRepository.getSession(sessionId) ?: return null
        val text = answer.text.trim()
        if (text.isEmpty() && answer.toolRuns.isEmpty()) return null
        val id = UUID.randomUUID().toString()
        withContext(NonCancellable) {
            container.chatRepository.addMessage(
                ChatMessage(
                    id = id,
                    sessionId = sessionId,
                    role = MessageRole.Assistant,
                    content = text,
                    createdAt = System.currentTimeMillis(),
                    model = session.model,
                    providerId = session.providerId,
                    status = status,
                    toolRuns = answer.toolRuns,
                    usage = answer.usage ?: estimatedUsage(text)
                )
            )
        }
        return id
    }

    /**
     * Suspends until [messageId] is observable in the session's message list.
     *
     * The insert and the UI's `observeMessages` collection are separate hops. Between
     * them the streaming bubble and the stored row can both be absent for a frame or
     * two, which reads as the chat wiping itself right as the answer lands. Handing
     * over only once the row is actually visible removes the gap.
     *
     * The timeout keeps this a smoothing step rather than a new way to hang: if the
     * row never arrives the bubble is cleared anyway.
     */
    private suspend fun awaitVisible(sessionId: String, messageId: String) {
        // Only the timeout is caught. A bare `runCatching` here would also swallow
        // the CancellationException that `withTimeout` throws to unwind, which
        // breaks cancellation for the caller.
        try {
            withTimeout(HANDOVER_TIMEOUT_MS) {
                container.chatRepository.observeMessages(sessionId)
                    .first { messages -> messages.any { it.id == messageId } }
            }
        } catch (timeout: TimeoutCancellationException) {
            // The row did not surface in time; the caller clears the bubble anyway.
        }
    }

    private fun fail(sessionId: String, message: String, retryable: Boolean) {
        _failures.update { it + (sessionId to GenerationFailure(message, retryable)) }
        _streams.update { it - sessionId }
    }

    /**
     * Terminal engine that timed out without reporting a single event, and when.
     *
     * An engine that never spoke once will not speak for the next command
     * either: a Termux stopped by the battery optimiser stays stopped, and a
     * device that refuses to fork a child process keeps refusing. Without this
     * memory a turn spent sixteen minutes rediscovering the same silence, once
     * per generous per-command timeout, and burned its step budget doing it.
     * The mute expires on its own, so a Termux that was restarted is usable
     * again without restarting Sirius.
     */
    @Volatile
    private var mutedEngineId: String? = null

    @Volatile
    private var mutedSince: Long = 0L

    private companion object {
        /** Upper bound on the stream-to-database handover wait. */
        const val HANDOVER_TIMEOUT_MS = 2_000L

        /** How long a terminal engine that reported nothing is skipped. */
        const val MUTE_WINDOW_MS = 5 * 60_000L

        /**
         * Held in memory per command. Generous enough for a full Gradle failure,
         * small enough that a `yes` loop cannot exhaust the heap.
         */
        const val OUTPUT_CAP = 200_000
    }

    /**
     * Writes one auto-applied change, returning null on success or a short
     * reason for the model on failure.
     *
     * Per change rather than per batch because it is called from inside a tool
     * call, between agent steps. That is the entire point of auto-apply: the next
     * tool the agent reaches for has to see the file. A batch that waits for the
     * run to end cannot deliver that, however early it is queued.
     */
    private suspend fun applyOne(treeUri: String?, change: PendingChange): String? {
        if (treeUri == null) return "no workspace folder is attached to this project"
        val result = container.applyChanges(treeUri, listOf(change))
        if (result.applied == 0) {
            return "the workspace rejected the write " +
                "(permission, storage, or a folder grant that no longer holds)"
        }
        // The cached project summary now describes a tree that has moved on.
        container.projectContextBuilder.invalidate()
        return null
    }

    /**
     * Executes [command] on the configured terminal engine and waits for it.
     *
     * The backend already models a run as a flow ending in
     * [TerminalEvent.Exited], so this is mostly a fold — but three details matter.
     *
     * The working directory is the project's own folder when there is one.
     * Running `./gradlew` from the app scratch directory finds nothing, and the
     * resulting "no such file" would send the agent hunting for a build script it
     * had already written correctly.
     *
     * Output is capped while collecting, not afterwards. A runaway command can
     * emit gigabytes, and a `StringBuilder` that accepts all of it takes the
     * process down long before the tool gets a chance to truncate.
     *
     * [withTimeoutOrNull] wraps the collection rather than the backend, so a hung
     * process still yields whatever it printed before it stopped responding —
     * usually the line that explains what it was waiting for.
     */
    private suspend fun runShell(
        command: String,
        project: Project?,
        timeoutMs: Long
    ): CommandOutcome {
        val engine = container.settingsRepository.settings.first().terminalEngine
        val backend = container.terminalBackend(engine)
        if (!backend.isAvailable()) {
            return CommandOutcome(
                exitCode = -1,
                stdout = "",
                stderr = backend.unavailableReason()
                    ?: "Terminal engine ${backend.displayName} is not available.",
                durationMs = 0
            )
        }

        val workingDir = project?.treeUri?.let(::shellPathForTree)
            ?: backend.home
            ?: container.terminalHome

        // An engine that already proved silent is not asked again: the answer
        // would be another full timeout, and the agent needs the turn.
        if (mutedEngineId == backend.id &&
            System.currentTimeMillis() - mutedSince < MUTE_WINDOW_MS
        ) {
            return CommandOutcome(
                exitCode = -1,
                stdout = "",
                stderr = "Terminal engine ${backend.displayName} did not report anything " +
                    "at all for an earlier command in this session, so it is treated as " +
                    "unavailable for a few minutes and this command was not run. Do not " +
                    "retry commands: tell the user the terminal is not responding and " +
                    "continue without it.",
                durationMs = 0,
                workingDirectory = workingDir.absolutePath
            )
        }

        val out = StringBuilder()
        val err = StringBuilder()
        var exit = -1
        var duration = 0L
        // Whether the engine ever spoke. A timeout after output is a command
        // that is still working; a timeout with total silence is an engine that
        // is not running commands at all, and the two deserve different answers.
        var heard = false
        val started = System.currentTimeMillis()

        val completed = withTimeoutOrNull(timeoutMs) {
            backend.execute(command, workingDir).collect { event ->
                heard = true
                when (event) {
                    is TerminalEvent.Stdout -> out.appendCapped(event.line, OUTPUT_CAP)
                    is TerminalEvent.Stderr -> err.appendCapped(event.line, OUTPUT_CAP)
                    is TerminalEvent.Notice -> err.appendCapped(event.message, OUTPUT_CAP)
                    is TerminalEvent.Exited -> {
                        exit = event.code
                        duration = event.durationMs
                    }
                    is TerminalEvent.Failed -> {
                        err.appendCapped(event.reason, OUTPUT_CAP)
                        exit = -1
                    }
                    is TerminalEvent.Started -> Unit
                }
            }
            true
        }

        if (completed == null) {
            // Leaving the process alive would keep it fighting the next command
            // for the same working directory.
            backend.stop()
            if (!heard) {
                // Total silence is a diagnosis, not a slow command, and the
                // old outcome hid it behind a bare "TIMED OUT ... (no output)".
                mutedEngineId = backend.id
                mutedSince = System.currentTimeMillis()
                err.appendCapped(
                    "The engine (${backend.displayName}) reported nothing at all: no " +
                        "start, no output, no exit code. That is not a slow command, it " +
                        "is a terminal that is not executing anything — Termux stopped " +
                        "by the system, a missing RUN_COMMAND permission, or a device " +
                        "that refuses to start child processes. Report this instead of " +
                        "retrying, and do not claim any command succeeded.",
                    OUTPUT_CAP
                )
            }
            return CommandOutcome(
                exitCode = -1,
                stdout = out.toString(),
                stderr = err.toString(),
                durationMs = System.currentTimeMillis() - started,
                timedOut = true,
                workingDirectory = workingDir.absolutePath
            )
        }

        // Something came back, so the engine is alive whatever the exit code
        // says, and a previous mute must not outlive that proof.
        if (heard && mutedEngineId == backend.id) mutedEngineId = null

        return CommandOutcome(
            exitCode = exit,
            stdout = out.toString(),
            stderr = err.toString(),
            durationMs = if (duration > 0) duration else System.currentTimeMillis() - started,
            workingDirectory = workingDir.absolutePath
        )
    }

    /**
     * Best-effort filesystem path for a SAF tree, or null.
     *
     * The workspace is a Storage Access Framework tree and the terminal is a
     * process. Those are different worlds: a SAF grant belongs to this app's uid,
     * while Termux runs under its own, so there is no general way to hand one to
     * the other. Pretending otherwise is how an agent ends up running `./gradlew`
     * in an empty scratch directory and reporting that the build script is
     * missing.
     *
     * One case does map cleanly and it is the common one. A folder picked on
     * shared storage arrives as `.../tree/primary%3AProjects%2FApp`, and `primary`
     * is the external storage root that a shell with storage access reaches as
     * `/sdcard`. That is resolved here; everything else — SD cards under a volume
     * uuid, Downloads, another app's provider — returns null so the caller falls
     * back to the terminal's own home and the model is told which directory it
     * actually got.
     */
    private fun shellPathForTree(treeUri: String): File? {
        val decoded = runCatching { Uri.decode(treeUri) }.getOrNull() ?: return null
        val marker = "/tree/primary:"
        val index = decoded.indexOf(marker)
        if (index < 0) return null
        val relative = decoded.substring(index + marker.length)
            .substringBefore("/document/")
            .trim('/')
        val root = Environment.getExternalStorageDirectory() ?: return null
        val dir = if (relative.isEmpty()) root else File(root, relative)
        // Existence is checked from our own uid. A directory we cannot see is one
        // the shell probably cannot either, and guessing wrong wastes a whole turn.
        return dir.takeIf { it.isDirectory }
    }

    /** Appends a line, then stops growing once [cap] is reached. */
    private fun StringBuilder.appendCapped(line: String, cap: Int) {
        if (length >= cap) return
        append(line).append('\n')
    }
}
