package com.sirius.chat.ai.context

import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.provider.AiProvider
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.GenerationParams
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.repository.ChatRepository
import com.sirius.chat.domain.usecase.BuildPromptUseCase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

/**
 * What the provider will actually be sent, and what happened to get there.
 *
 * [foldedCount] is only non-zero on the turn a fold actually ran, which is the
 * turn the transcript grows a "context compacted" card.
 */
data class CompactedPrompt(
    val prompt: List<ChatMessage>,
    val summary: String?,
    val foldedCount: Int
)

/**
 * Keeps a long conversation inside the model's context window by folding its
 * oldest turns into a running summary.
 *
 * ### The problem this replaces
 * [BuildPromptUseCase] walks the history backwards, adds messages until 24 000
 * characters are used, and stops. Everything older is dropped -- silently, with
 * no record, mid-sentence. On a long debugging session that means the decision
 * made twenty turns ago is simply gone, and the model confidently contradicts
 * it. The user's experience of that is "it forgot", and there is nothing in the
 * UI to explain why.
 *
 * ### The approach
 * When the conversation approaches the window, the oldest turns are sent to the
 * same model in one cheap non-streaming request and come back as a dense factual
 * summary. That summary is stored as a `System` row in the transcript and sent
 * as the first message of every later prompt. The original rows are never
 * deleted -- they stay in the database and on screen, they are only absent from
 * the prompt -- so nothing the user wrote is destroyed by a compaction.
 *
 * ### Why fold the minimum rather than everything
 * Verbatim recent turns beat any summary of them, so folding stops as soon as
 * what remains fits comfortably. A conversation is compacted repeatedly and
 * gently, not once and drastically.
 *
 * ### Failure is not fatal
 * Every path out of [prepare] returns a usable prompt. If the summariser is
 * slow, offline, out of quota or returns nothing, the old character-cap trim is
 * used for that turn and the user gets their answer. A memory optimisation that
 * can block an answer is worse than no memory optimisation.
 */
class ContextCompactor(
    private val chatRepository: ChatRepository,
    private val buildPrompt: BuildPromptUseCase
) {

    /**
     * Builds the prompt for one generation, compacting first if it is needed.
     *
     * @param stored the full stored history, newest last, summaries included.
     * @param provider the same provider the answer will come from -- the summary
     *   is written by the model the user chose, so it inherits their language and
     *   their key rather than needing one of ours.
     * @param contextWindow the model's window in tokens, or 0 when unknown.
     * @param reserveTokens room to leave for the answer itself.
     * @param compact whether this chat allows compaction at all. `false` is the
     *   chat's context switch turned off: nothing is folded, nothing is
     *   summarised, no summary row is written, and no model round-trip happens.
     */
    suspend fun prepare(
        sessionId: String,
        stored: List<ChatMessage>,
        provider: AiProvider,
        modelId: String,
        contextWindow: Int,
        reserveTokens: Int,
        compact: Boolean = true
    ): CompactedPrompt {
        val budget = budgetChars(contextWindow, reserveTokens, modelId)

        if (!compact) {
            // The feature is off for this conversation, so the whole mechanism is
            // off: no fold, no summariser call, and any summary row from back when
            // it was on is skipped rather than prepended -- the turns it describes
            // are right there in the history, and sending both would say
            // everything twice.
            //
            // [buildPrompt] still runs. That is not compaction, it is the plain
            // character cap this app has always had, and it is the only thing
            // standing between a thousand-message thread and a provider rejecting
            // the request outright. Turning off context management is allowed to
            // cost the model its memory of the oldest turns; it is not allowed to
            // turn every later turn into an error.
            val verbatim = stored.filter {
                it.role != MessageRole.System && it.content.isNotBlank()
            }
            return CompactedPrompt(
                prompt = buildPrompt(verbatim, budget),
                summary = null,
                foldedCount = 0
            )
        }

        // Everything up to the last fold is represented by its summary; only what
        // came after it is still verbatim history.
        val summaryRow = stored.lastOrNull { isSummary(it) }
        val carried = summaryRow?.let { summaryBody(it.content) }.orEmpty()
        val live = stored.drop(tailStart(stored, summaryRow))
            .filter { it.role != MessageRole.System && it.content.isNotBlank() }

        val liveChars = live.sumOf { it.content.length }
        if (carried.length + liveChars <= (budget * TRIGGER_FILL).toInt()) {
            // The common case, and it costs nothing: no model call, no latency,
            // no card. Compaction only ever happens when it has to.
            return CompactedPrompt(
                prompt = assemble(carried, live, sessionId, budget),
                summary = carried.ifBlank { null },
                foldedCount = 0
            )
        }

        // Fold from the oldest end until what remains is comfortably inside the
        // window, leaving room for the summary that will front it.
        val target = ((budget * TARGET_FILL).toInt() - SUMMARY_BUDGET_CHARS)
            .coerceAtLeast(MIN_TARGET_CHARS)
        val fold = mutableListOf<ChatMessage>()
        val tail = live.toMutableList()
        var remaining = liveChars
        while (tail.size > KEEP_RECENT && remaining > target) {
            val oldest = tail.removeAt(0)
            fold += oldest
            remaining -= oldest.content.length
        }
        // The kept tail has to open on a user turn. An assistant reply whose
        // question was folded away reads as an answer to nothing, and models
        // pattern-match on that badly.
        while (tail.size > 1 && tail.first().role != MessageRole.User) {
            val oldest = tail.removeAt(0)
            fold += oldest
            remaining -= oldest.content.length
        }

        if (fold.size < MIN_FOLD) {
            // One enormous message, or a short thread against a small window.
            // A round-trip would not buy enough to justify itself.
            return CompactedPrompt(
                prompt = assemble(carried, live, sessionId, budget),
                summary = carried.ifBlank { null },
                foldedCount = 0
            )
        }

        val folded = summarise(provider, modelId, carried, fold, budget)
            ?: return CompactedPrompt(
                prompt = assemble(carried, live, sessionId, budget),
                summary = carried.ifBlank { null },
                foldedCount = 0
            )

        persist(sessionId, modelId, folded, fold)
        return CompactedPrompt(
            prompt = assemble(folded, tail, sessionId, budget),
            summary = folded,
            foldedCount = fold.size
        )
    }

    // ------------------------------------------------------------------ internals

    /**
     * Index of the first message that is still verbatim history.
     *
     * Resolved through the message id recorded in the summary rather than the
     * summary row's position, because position is fragile: two messages written
     * in the same millisecond order by insertion id, and an edit or a regenerate
     * rewrites the tail underneath us. The id is exact.
     */
    private fun tailStart(stored: List<ChatMessage>, summaryRow: ChatMessage?): Int {
        if (summaryRow == null) return 0
        val boundary = boundaryId(summaryRow.content)
        if (boundary != null) {
            val index = stored.indexOfFirst { it.id == boundary }
            if (index >= 0) return index + 1
        }
        // Boundary message gone -- rewound by an edit or a regenerate. The
        // summary row's own position is still after everything it describes.
        return stored.indexOfFirst { it.id == summaryRow.id } + 1
    }

    /**
     * Prepends the summary to the kept turns and enforces the hard ceiling.
     *
     * The summary goes in as a **user** message, not a system one: the system
     * slot already carries the agent prompt and its tool contract, and several
     * providers accept exactly one system message. A leading user turn is the
     * one shape every backend here handles identically.
     *
     * [buildPrompt] still runs on the tail as a last line of defence, so even a
     * pathological six-message tail cannot exceed the window.
     */
    private fun assemble(
        summary: String,
        tail: List<ChatMessage>,
        sessionId: String,
        budget: Int
    ): List<ChatMessage> {
        val room = (budget - summary.length).coerceAtLeast(MIN_TAIL_CHARS)
        val trimmed = buildPrompt(tail, room)
        if (summary.isBlank()) return trimmed
        val head = ChatMessage(
            id = PROMPT_ID,
            sessionId = sessionId,
            role = MessageRole.User,
            content = PROMPT_PREFIX + summary,
            createdAt = trimmed.firstOrNull()?.createdAt ?: System.currentTimeMillis()
        )
        return listOf(head) + trimmed
    }

    /** Asks the conversation's own model to compress the folded turns. */
    private suspend fun summarise(
        provider: AiProvider,
        modelId: String,
        carried: String,
        fold: List<ChatMessage>,
        budget: Int
    ): String? {
        val cap = (budget * FOLD_REQUEST_FILL).toInt().coerceAtMost(MAX_FOLD_CHARS)
        val turns = mutableListOf<String>()
        var size = 0
        // Filled newest-first so that if the fold is too large for a single
        // request it is the oldest turns that are left out: they are the least
        // likely to still matter and the most likely to be covered by [carried].
        for (message in fold.asReversed()) {
            val label = if (message.role == MessageRole.User) "USER" else "ASSISTANT"
            val line = label + ": " + message.content.take(PER_MESSAGE_CHARS)
            if (turns.isNotEmpty() && size + line.length > cap) break
            turns += line
            size += line.length
        }
        val omitted = fold.size - turns.size
        val transcript = turns.asReversed().joinToString("\n\n")

        val instruction = buildString {
            if (carried.isNotBlank()) {
                appendLine("SUMMARY SO FAR (already compacted; carry forward everything still relevant):")
                appendLine(carried)
                appendLine()
                appendLine("NEW TURNS TO FOLD INTO IT:")
            } else {
                appendLine("CONVERSATION TURNS TO COMPACT:")
            }
            appendLine(transcript)
            if (omitted > 0) {
                appendLine()
                appendLine(
                    "(" + omitted + " older turns were too large to include. " +
                        "Note that gap in one short line rather than guessing at them.)"
                )
            }
        }

        val request = ChatRequest(
            model = modelId,
            messages = listOf(AiMessage(AiRole.User, instruction)),
            systemPrompt = SUMMARY_SYSTEM,
            // Deterministic and non-streaming: this is a background transform,
            // not a turn in the conversation, and nothing is waiting to render it
            // token by token.
            params = GenerationParams(
                temperature = 0f,
                topP = 1f,
                maxTokens = SUMMARY_MAX_TOKENS
            ),
            stream = false
        )
        return withTimeoutOrNull(SUMMARY_TIMEOUT_MS) { ask(provider, request) }
    }

    /** Collects one non-streaming answer, or null for anything that went wrong. */
    private suspend fun ask(provider: AiProvider, request: ChatRequest): String? {
        val text = StringBuilder()
        var failed = false
        try {
            provider.chat(request).collect { event ->
                when (event) {
                    is ChatStreamEvent.Delta -> text.append(event.text)
                    is ChatStreamEvent.Completed ->
                        if (event.fullText.isNotBlank()) {
                            // Authoritative: a provider answering a non-streaming
                            // request may send no deltas at all and still fill this.
                            text.setLength(0)
                            text.append(event.fullText)
                        }
                    is ChatStreamEvent.Failure -> failed = true
                    // A start marker, thinking text and keep-alives carry no
                    // summary for this one-shot helper to collect.
                    ChatStreamEvent.Started,
                    ChatStreamEvent.Heartbeat,
                    is ChatStreamEvent.Reasoning -> Unit
                }
            }
        } catch (cancelled: CancellationException) {
            // The user stopped the generation: that must propagate, not be eaten.
            throw cancelled
        } catch (error: Exception) {
            return null
        }
        return if (failed) null else text.toString().trim().ifBlank { null }
    }

    /**
     * Writes the summary into the transcript.
     *
     * Stored with the same timestamp as the last folded message so the ordering
     * the transcript reads by -- createdAt, then insertion id -- puts the card
     * exactly where the fold happened instead of at the end of the thread.
     */
    private suspend fun persist(
        sessionId: String,
        modelId: String,
        summary: String,
        fold: List<ChatMessage>
    ) {
        val boundary = fold.last()
        val row = ChatMessage(
            id = UUID.randomUUID().toString(),
            sessionId = sessionId,
            role = MessageRole.System,
            content = MARKER + " " + boundary.id + "\n" + summary,
            createdAt = boundary.createdAt,
            model = modelId
        )
        try {
            chatRepository.addMessage(row)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            // The prompt for this turn is already built and correct. Losing the
            // row only means the next turn folds again.
        }
    }

    /**
     * Characters of history the prompt may use.
     *
     * An unknown window deliberately falls back to the character cap this app
     * shipped with rather than to a guess. A local endpoint that reports no
     * window is as likely to be an 8k model as a 200k one, and handing it 70 000
     * characters would turn a working conversation into a wall of provider
     * errors. Compaction against the old cap is still a strict improvement: the
     * same amount of text goes out, but what falls off the front is summarised
     * instead of discarded.
     */
    private fun budgetChars(contextWindow: Int, reserveTokens: Int, modelId: String): Int {
        if (contextWindow <= 0) return LEGACY_BUDGET_CHARS
        val usable = (contextWindow - reserveTokens.coerceAtLeast(0) - SYSTEM_RESERVE_TOKENS)
            .coerceAtLeast(MIN_USABLE_TOKENS)
        // Measured for this model once a turn has reported its usage, and the
        // old constant until then. Russian packs closer to two characters per
        // token, so a fixed 3.5 handed the prompt nearly twice the history the
        // window could actually hold -- and the overflow landed on the user.
        val charsPerToken =
            com.sirius.chat.ai.pricing.TokenCalibration.charsPerToken(modelId)
        return (usable * charsPerToken).toInt().coerceIn(MIN_BUDGET_CHARS, MAX_BUDGET_CHARS)
    }

    companion object {
        /** First token of a summary row, and the only way to recognise one. */
        const val MARKER = "[sirius:context-compacted]"

        /** True for a transcript row that is a stored compaction summary. */
        fun isSummary(message: ChatMessage): Boolean =
            message.role == MessageRole.System && message.content.startsWith(MARKER)

        /** The readable summary, without the marker line. */
        fun summaryBody(content: String): String = content.substringAfter('\n', "").trim()

        /** Id of the last message the summary covers, if it is still recorded. */
        private fun boundaryId(content: String): String? = content
            .lineSequence()
            .firstOrNull()
            ?.removePrefix(MARKER)
            ?.trim()
            ?.takeIf { it.isNotEmpty() }

        private const val PROMPT_ID = "sirius-context-summary"

        private const val PROMPT_PREFIX =
            "Compacted context from earlier in this conversation. Treat every line as " +
                "established fact that you already know, continue from it directly, and do " +
                "not mention or quote this block back to the user.\n\n"

        private const val SUMMARY_SYSTEM =
            "You compact a coding conversation so it can continue in a smaller context " +
                "window. Rewrite what you are given as one dense summary that a model can " +
                "work from without ever seeing the original turns.\n" +
                "Preserve exactly, in backticks: file paths, identifiers, versions, commands, " +
                "urls and numbers. Preserve every decision that was actually made and every " +
                "constraint the user stated.\n" +
                "Use short labelled sections in this order: Task, Decisions, State, Open, " +
                "Preferences. One fact per bullet.\n" +
                "Drop greetings, restatements, and anything already superseded. Never invent " +
                "a fact that is not in the material. Never write about the conversation " +
                "itself. Write in the language of the conversation. Stay under 300 words."

        /** Fraction of the budget that triggers a fold. */
        private const val TRIGGER_FILL = 0.7f

        /** Fraction of the budget the kept tail is folded back down to. */
        private const val TARGET_FILL = 0.45f

        /** Fraction of the budget one summary request may spend on transcript. */
        private const val FOLD_REQUEST_FILL = 0.5f

        /** Turns that are never folded, however long the conversation gets. */
        private const val KEEP_RECENT = 6

        /** Below this, a fold is not worth a model round-trip. */
        private const val MIN_FOLD = 4

        private const val CHARS_PER_TOKEN = 3.5f
        private const val SYSTEM_RESERVE_TOKENS = 1_500
        private const val MIN_USABLE_TOKENS = 2_000
        private const val LEGACY_BUDGET_CHARS = 24_000
        private const val MIN_BUDGET_CHARS = 8_000
        private const val MAX_BUDGET_CHARS = 400_000
        private const val MIN_TARGET_CHARS = 4_000
        private const val MIN_TAIL_CHARS = 4_000
        private const val SUMMARY_BUDGET_CHARS = 3_000
        private const val SUMMARY_MAX_TOKENS = 700
        private const val PER_MESSAGE_CHARS = 4_000
        private const val MAX_FOLD_CHARS = 120_000
        // Raised from forty-five seconds: losing a compaction to a model that was
        // merely thinking costs the whole conversation's history.
        private const val SUMMARY_TIMEOUT_MS = 180_000L
    }
}
