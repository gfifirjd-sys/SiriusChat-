package com.sirius.chat.feature.files

import androidx.activity.compose.BackHandler
import androidx.annotation.StringRes
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.automirrored.rounded.NoteAdd
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.AccountTree
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.BreadcrumbSegment
import com.sirius.chat.core.designsystem.components.EmptyState
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.InlineBusyRow
import com.sirius.chat.core.designsystem.components.ListSkeleton
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.MorphMenu
import com.sirius.chat.core.designsystem.components.MorphMenuItem
import com.sirius.chat.core.designsystem.components.SheetActionRow
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusConfirmSheet
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.ToastTone
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.core.util.relativeTimeText
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.domain.model.FileNode
import com.sirius.chat.domain.model.FileSort

@Composable
fun FilesScreen(
    onOpenEditor: () -> Unit,
    onOpenProjects: () -> Unit,
    onOpenGit: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: FilesViewModel = siriusViewModel { FilesViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors

    var contextNode by remember { mutableStateOf<FileNode?>(null) }
    var renaming by remember { mutableStateOf<FileNode?>(null) }
    var creating by remember { mutableStateOf<Boolean?>(null) } // true = folder
    var pendingDelete by remember { mutableStateOf<FileNode?>(null) }
    var showSort by remember { mutableStateOf(false) }

    // One toast channel for the whole screen: repository errors arrive as state,
    // clipboard confirmations are raised here, and two stacked popups would fight.
    var toast by remember { mutableStateOf<String?>(null) }
    var toastTone by remember { mutableStateOf(ToastTone.Error) }

    LaunchedEffect(state.message) {
        val message = state.message ?: return@LaunchedEffect
        toastTone = ToastTone.Error
        toast = message
        viewModel.consumeMessage()
    }

    val listState = rememberLazyListState()
    val scrolled by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 4 }
    }

    BackHandler(enabled = state.breadcrumbs.size > 1 && !state.inSearch) { viewModel.up() }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = state.currentDirectory?.name ?: stringResource(R.string.files_title),
            subtitle = state.project?.name?.let { stringResource(R.string.chat_project_prefix, it) }
                ?: stringResource(R.string.files_no_workspace_subtitle),
            scrolled = scrolled,
            actions = {
                // Without a linked folder every one of these actions is a no-op.
                if (!state.hasWorkspace) return@SiriusTopBar
                if (state.clipboard != null) {
                    GlassIconButton(
                        icon = Icons.Rounded.ContentPaste,
                        contentDescription = stringResource(R.string.files_paste),
                        highlighted = true,
                        onClick = viewModel::paste
                    )
                }
                GlassIconButton(
                    icon = Icons.Rounded.AccountTree,
                    contentDescription = stringResource(R.string.git_title),
                    onClick = onOpenGit
                )
                // Four sort orders do not need a full-width sheet thrown up from
                // the bottom of the screen: the menu morphs out of the button
                // that asked for it, next to the list it reorders.
                MorphMenu(
                    expanded = showSort,
                    onDismissRequest = { showSort = false },
                    items = FileSort.entries.map { sort ->
                        MorphMenuItem(
                            icon = Icons.AutoMirrored.Rounded.Sort,
                            label = stringResource(sort.labelRes()),
                            selected = sort == state.sort,
                            onClick = { viewModel.setSort(sort) }
                        )
                    },
                    minWidth = 200.dp
                ) {
                    GlassIconButton(
                        icon = Icons.AutoMirrored.Rounded.Sort,
                        contentDescription = stringResource(R.string.files_sort),
                        highlighted = showSort,
                        onClick = { showSort = !showSort }
                    )
                }
                GlassIconButton(
                    icon = Icons.AutoMirrored.Rounded.NoteAdd,
                    contentDescription = stringResource(R.string.files_new_file),
                    onClick = { creating = false }
                )
                GlassIconButton(
                    icon = Icons.Rounded.CreateNewFolder,
                    contentDescription = stringResource(R.string.files_new_folder),
                    onClick = { creating = true }
                )
            }
        )

        if (!state.hasWorkspace) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                EmptyState(
                    icon = Icons.Rounded.FolderOpen,
                    title = stringResource(R.string.files_empty_workspace_title),
                    message = stringResource(R.string.files_empty_workspace_message),
                    actionLabel = stringResource(R.string.files_open_projects),
                    onAction = onOpenProjects
                )
            }
            return@Column
        }

        SiriusTextField(
            value = state.query,
            onValueChange = viewModel::search,
            placeholder = stringResource(R.string.files_search_placeholder),
            leadingIcon = Icons.Rounded.Search,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SiriusSpacing.sm)
        )

        if (!state.inSearch) {
            val pathLabel = stringResource(R.string.files_path_label)
            LazyRow(
                modifier = Modifier
                    .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xxs)
                    .semantics { contentDescription = pathLabel },
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(state.breadcrumbs.size, key = { state.breadcrumbs[it].documentId }) { index ->
                    BreadcrumbSegment(
                        label = state.breadcrumbs[index].name,
                        isLast = index == state.breadcrumbs.lastIndex,
                        onClick = { viewModel.navigateTo(index) }
                    )
                }
            }
        }

        // Search reports itself inline; a directory listing gets a skeleton the
        // shape of the rows that are about to land, so nothing jumps.
        if (state.searching) {
            InlineBusyRow(
                label = stringResource(R.string.files_searching),
                modifier = Modifier.padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xxs)
            )
        }

        if (state.loading && state.children.isEmpty()) {
            ListSkeleton(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs),
                rows = 7,
                lines = 2
            )
            return@Column
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            state = listState,
            contentPadding = PaddingValues(
                start = SiriusSpacing.sm,
                end = SiriusSpacing.sm,
                top = SiriusSpacing.xs,
                bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
            ),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
        ) {
            if (state.inSearch) {
                if (state.fileMatches.isNotEmpty()) {
                    item(key = "files-title") {
                        SearchGroupLabel(stringResource(R.string.files_title))
                    }
                    items(state.fileMatches, key = { "f-${it.documentId}" }) { node ->
                        FileRow(
                            node = node,
                            // Search narrows as the user types, so rows leave and
                            // arrive constantly. Animating that keeps it readable.
                            modifier = Modifier.animateItem(),
                            onClick = { viewModel.openInEditor(node, onOpenEditor) },
                            onLongClick = { contextNode = node }
                        )
                    }
                }
                if (state.textMatches.isNotEmpty()) {
                    item(key = "matches-title") {
                        SearchGroupLabel(stringResource(R.string.files_section_matches))
                    }
                    items(state.textMatches.size, key = { "m-$it" }) { index ->
                        val match = state.textMatches[index]
                        GlassCard(
                            modifier = Modifier.animateItem(),
                            onClick = { viewModel.openMatch(match, onOpenEditor) },
                            onClickLabel = match.path,
                            contentPadding = SiriusSpacing.sm,
                            shape = RoundedCornerShape(SiriusRadius.md)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
                            ) {
                                Text(
                                    text = match.path,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colors.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                SiriusChip(
                                    text = stringResource(R.string.files_match_position, match.lineNumber)
                                )
                            }
                            Spacer(Modifier.size(SiriusSpacing.xxs))
                            Text(
                                text = match.line.trim(),
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
                if (state.fileMatches.isEmpty() && state.textMatches.isEmpty() && !state.searching) {
                    item(key = "no-results") {
                        EmptyState(
                            icon = Icons.Rounded.Search,
                            title = stringResource(R.string.files_nothing_found),
                            message = stringResource(R.string.files_no_match, state.query)
                        )
                    }
                }
            } else {
                val entries = state.sorted
                if (entries.isEmpty() && !state.loading) {
                    item(key = "empty-dir") {
                        EmptyState(
                            icon = Icons.Rounded.Folder,
                            title = stringResource(R.string.files_empty_folder),
                            message = stringResource(R.string.files_empty_folder_message),
                            actionLabel = stringResource(R.string.files_new_file),
                            onAction = { creating = false }
                        )
                    }
                }
                items(entries, key = { it.documentId }) { node ->
                    FileRow(
                        node = node,
                        modifier = Modifier.animateItem(),
                        onClick = {
                            if (node.isDirectory) viewModel.enter(node)
                            else viewModel.openInEditor(node, onOpenEditor)
                        },
                        onLongClick = { contextNode = node }
                    )
                }
            }
        }
    }

    contextNode?.let { node ->
        val copied = stringResource(R.string.files_clipboard_copy, node.name)
        val cut = stringResource(R.string.files_clipboard_cut, node.name)
        FileContextSheet(
            node = node,
            onDismiss = { contextNode = null },
            onOpen = {
                contextNode = null
                if (node.isDirectory) viewModel.enter(node) else viewModel.openInEditor(node, onOpenEditor)
            },
            onRename = {
                contextNode = null
                renaming = node
            },
            onDelete = {
                contextNode = null
                pendingDelete = node
            },
            onCopy = {
                contextNode = null
                viewModel.copyToClipboard(node, cut = false)
                toastTone = ToastTone.Success
                toast = copied
            },
            onCut = {
                contextNode = null
                viewModel.copyToClipboard(node, cut = true)
                toastTone = ToastTone.Success
                toast = cut
            }
        )
    }

    pendingDelete?.let { node ->
        SiriusConfirmSheet(
            title = stringResource(R.string.files_delete_title, node.name),
            message = if (node.isDirectory) {
                stringResource(R.string.files_delete_message_folder)
            } else {
                stringResource(R.string.files_delete_message_file)
            },
            confirmLabel = stringResource(R.string.action_delete),
            icon = Icons.Rounded.DeleteOutline,
            onConfirm = {
                pendingDelete = null
                viewModel.delete(node)
            },
            onDismiss = { pendingDelete = null }
        )
    }

    renaming?.let { node ->
        NamePromptSheet(
            title = stringResource(R.string.action_rename),
            initial = node.name,
            confirmLabel = stringResource(R.string.action_rename),
            onDismiss = { renaming = null },
            onConfirm = { newName ->
                renaming = null
                viewModel.rename(node, newName)
            }
        )
    }

    creating?.let { isFolder ->
        NamePromptSheet(
            title = if (isFolder) stringResource(R.string.files_new_folder)
            else stringResource(R.string.files_new_file),
            initial = if (isFolder) "" else "untitled.kt",
            confirmLabel = stringResource(R.string.action_create),
            onDismiss = { creating = null },
            onConfirm = { name ->
                creating = null
                if (isFolder) viewModel.createFolder(name) else viewModel.createFile(name)
            }
        )
    }


    MessageToast(
        message = toast,
        tone = toastTone,
        bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.sm
    )
}

@Composable
private fun SearchGroupLabel(text: String) = Text(
    text = text,
    style = MaterialTheme.typography.labelLarge,
    color = SiriusTheme.colors.textSecondary,
    modifier = Modifier.padding(start = SiriusSpacing.xxs, top = SiriusSpacing.xs, bottom = SiriusSpacing.xxs)
)

/**
 * A single entry in the tree.
 *
 * Rows are dense on purpose — a file manager is read by scanning — so the type
 * of the entry is carried by the plate colour behind the icon *and* by an
 * explicit label for screen readers, never by the icon alone. Long-press opens
 * the actions sheet, so the row advertises that as its long-click label.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(
    node: FileNode,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.985f else 1f,
        animationSpec = siriusSpring(),
        label = "filePress"
    )
    val kind = if (node.isDirectory) {
        stringResource(R.string.files_a11y_folder)
    } else {
        stringResource(R.string.files_a11y_file)
    }
    val shape = RoundedCornerShape(SiriusRadius.md)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(shape)
            .softSurface(shape)
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClickLabel = node.name,
                onLongClickLabel = stringResource(R.string.files_row_actions),
                onLongClick = {
                    haptics.strong()
                    onLongClick()
                },
                onClick = {
                    haptics.light()
                    onClick()
                }
            )
            .heightIn(min = 56.dp)
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(SiriusRadius.xs))
                .background(
                    if (node.isDirectory) colors.primarySoft else colors.surfaceMuted.copy(alpha = 0.5f)
                )
                .semantics { contentDescription = kind },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (node.isDirectory) Icons.Rounded.Folder else Icons.AutoMirrored.Rounded.InsertDriveFile,
                contentDescription = null,
                tint = if (node.isDirectory) colors.primary else colors.textSecondary,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(Modifier.width(SiriusSpacing.sm))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = node.name,
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = if (node.isDirectory) {
                    relativeTimeText(node.lastModified)
                } else {
                    "${Formatters.fileSize(node.sizeBytes)} \u00B7 ${relativeTimeText(node.lastModified)}"
                },
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary,
                maxLines = 1
            )
        }
        if (!node.isDirectory && node.extension.isNotBlank()) {
            Spacer(Modifier.width(SiriusSpacing.xs))
            // The extension repeats the tail of the name for a screen reader.
            Box(modifier = Modifier.clearAndSetSemantics { }) {
                SiriusChip(text = node.extension)
            }
        }
    }
}

@Composable
private fun FileContextSheet(
    node: FileNode,
    onDismiss: () -> Unit,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit
) {
    SiriusBottomSheet(
        title = node.name,
        // A deep path overflowed the one-line subtitle and got cut mid-segment,
        // so it is trimmed from the front where the least meaning lives.
        subtitle = if (node.isDirectory) {
            Formatters.shortPath(node.path)
        } else {
            "${Formatters.shortPath(node.path)} \u00B7 ${Formatters.fileSize(node.sizeBytes)}"
        },
        onDismiss = onDismiss
    ) {
        SheetActionRow(
            icon = Icons.Rounded.FolderOpen,
            label = if (node.isDirectory) {
                stringResource(R.string.files_open_folder)
            } else {
                stringResource(R.string.files_open_in_editor)
            },
            onClick = onOpen
        )
        SheetActionRow(
            icon = Icons.Rounded.DriveFileRenameOutline,
            label = stringResource(R.string.action_rename),
            onClick = onRename
        )
        SheetActionRow(
            icon = Icons.Rounded.ContentCopy,
            label = stringResource(R.string.action_copy),
            onClick = onCopy
        )
        SheetActionRow(
            icon = Icons.Rounded.ContentCut,
            label = stringResource(R.string.action_move),
            onClick = onCut
        )
        SheetActionRow(
            icon = Icons.Rounded.DeleteOutline,
            label = stringResource(R.string.action_delete),
            onClick = onDelete,
            destructive = true
        )
    }
}

@Composable
private fun NamePromptSheet(
    title: String,
    initial: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var value by remember { mutableStateOf(initial) }
    val trimmed = value.trim()
    val valid = isValidFileName(trimmed)
    // Naming a file is the only reason this sheet exists, so it opens with the
    // keyboard up instead of asking for a tap on the field first.
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    SiriusBottomSheet(title = title, onDismiss = onDismiss) {
        SiriusTextField(
            value = value,
            onValueChange = { value = it },
            placeholder = stringResource(R.string.files_name_placeholder),
            isError = trimmed.isNotEmpty() && !valid,
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(focus),
            onImeAction = { if (valid) onConfirm(trimmed) }
        )
        if (trimmed.isNotEmpty() && !valid) {
            VSpace(SiriusSpacing.xs)
            Text(
                text = stringResource(R.string.files_invalid_name),
                style = MaterialTheme.typography.labelSmall,
                color = SiriusTheme.colors.error
            )
        }
        VSpace(SiriusSpacing.md)
        SiriusPrimaryButton(
            text = confirmLabel,
            onClick = { onConfirm(trimmed) },
            enabled = valid,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** Rejects path separators and reserved names before they reach the SAF provider. */
private fun isValidFileName(name: String): Boolean =
    name.isNotBlank() &&
        name != "." &&
        name != ".." &&
        name.none { it == '/' || it == '\\' || it == '\u0000' } &&
        name.length <= 255

/** Localized label for each sort mode, so the sheet never shows enum names. */
@StringRes
private fun FileSort.labelRes(): Int = when (this) {
    FileSort.Name -> R.string.files_sort_name
    FileSort.Modified -> R.string.files_sort_modified
    FileSort.Size -> R.string.files_sort_size
    FileSort.Type -> R.string.files_sort_type
}
