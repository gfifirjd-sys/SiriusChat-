package com.sirius.chat.data.image

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * What happened to a request to put a generated picture somewhere the user can
 * keep it.
 *
 * A `Boolean` was the obvious return type and it is the wrong one: "it did not
 * save" and "it did not save *yet*, because storage permission was never asked
 * for" need different words on screen and a different next step. Collapsing them
 * produces the failure mode where a user taps Save, reads "could not save", and
 * has no idea that one dialog would have fixed it.
 */
sealed interface ImageExportResult {

    /** In the gallery, under its own album. */
    data class Saved(val album: String) : ImageExportResult

    /** Pre-Android 10 only: the legacy storage permission has not been granted. */
    data object NeedsPermission : ImageExportResult

    data object Failed : ImageExportResult
}

/**
 * Copies a generated image out of the app's private directory.
 *
 * ### Why this exists at all
 * Generated pictures live in `filesDir/generated-images`, which nothing else on
 * the device can read. That is the right place to *keep* them -- they are part of
 * a transcript, and the gallery should not fill up with every draft -- but it also
 * means a picture the user is happy with is trapped: no wallpaper, no send to a
 * friend, gone with the app. This is the export path, taken only when asked for.
 *
 * ### Why MediaStore and not a raw file write
 * On Android 10 and up an app cannot write to `Pictures/` directly no matter what
 * it declares in the manifest; scoped storage routes it through MediaStore, which
 * also registers the image so it appears in the gallery immediately instead of
 * whenever the media scanner next runs. The legacy branch below is for API 26-28,
 * where the opposite is true and a direct write plus an explicit scan is the only
 * thing that works.
 *
 * ### Why sharing does not copy the file
 * `FileProvider` hands out a temporary, read-only grant for the file in place, so
 * the receiving app reads the original bytes and nothing is duplicated. The
 * provider is scoped to this one directory in `file_paths.xml`, so a chooser
 * cannot be talked into reading the editor's scratch files.
 */
object ImageExporter {

    /** Gallery album name; matches the app so the pictures are findable. */
    const val ALBUM = "SiriusChat"

    private const val MIME = "image/png"

    /** `${applicationId}.files`, as declared in the manifest. */
    private fun authority(context: Context): String = context.packageName + ".files"

    /**
     * Copies [source] into the device gallery.
     *
     * Runs on IO: this is a file copy, and on a slow phone with a 1536x1536 PNG it
     * is long enough to drop frames if it happens on the main thread.
     */
    suspend fun saveToGallery(context: Context, source: File): ImageExportResult =
        withContext(Dispatchers.IO) {
            if (!source.isFile || source.length() == 0L) return@withContext ImageExportResult.Failed
            val name = fileName(source)
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    saveViaMediaStore(context, source, name)
                } else {
                    saveLegacy(context, source, name)
                }
            }.getOrElse { ImageExportResult.Failed }
        }

    /**
     * A chooser for sending the picture to another app, or `null` when the file
     * cannot be handed out (pruned between the long-press and the tap).
     *
     * The chooser is built here rather than in the composable so the grant flag
     * and the mime type cannot drift apart from the provider declaration.
     */
    fun shareChooser(context: Context, source: File, title: String): Intent? {
        if (!source.isFile) return null
        val uri = runCatching {
            FileProvider.getUriForFile(context, authority(context), source)
        }.getOrNull() ?: return null
        val send = Intent(Intent.ACTION_SEND).apply {
            type = MIME
            putExtra(Intent.EXTRA_STREAM, uri)
            // Without the grant the receiver gets a uri it is not allowed to read,
            // which surfaces as a blank attachment in the other app.
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = android.content.ClipData.newRawUri(title, uri)
        }
        return Intent.createChooser(send, title).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    /** Whether the legacy write permission still has to be asked for. */
    fun needsLegacyPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) return false
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) != PackageManager.PERMISSION_GRANTED
    }

    private fun saveViaMediaStore(context: Context, source: File, name: String): ImageExportResult {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, MIME)
            put(
                MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + File.separator + ALBUM
            )
            // Pending while the bytes are still being written, so the gallery never
            // shows a half-decoded thumbnail.
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val target = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: return ImageExportResult.Failed
        val copied = runCatching {
            resolver.openOutputStream(target)?.use { out ->
                source.inputStream().use { input -> input.copyTo(out) }
            } != null
        }.getOrDefault(false)
        if (!copied) {
            // A row with no bytes behind it would sit in the gallery as a broken
            // thumbnail forever.
            runCatching { resolver.delete(target, null, null) }
            return ImageExportResult.Failed
        }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        runCatching { resolver.update(target, values, null, null) }
        return ImageExportResult.Saved(ALBUM)
    }

    @Suppress("DEPRECATION")
    private fun saveLegacy(context: Context, source: File, name: String): ImageExportResult {
        if (needsLegacyPermission(context)) return ImageExportResult.NeedsPermission
        val album = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            ALBUM
        )
        if (!album.isDirectory && !album.mkdirs()) return ImageExportResult.Failed
        val target = File(album, name)
        source.inputStream().use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        }
        // Pre-Q the gallery does not know about a file until it is scanned; without
        // this the picture is on disk but invisible, which reads as a failed save.
        MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), arrayOf(MIME), null)
        return ImageExportResult.Saved(ALBUM)
    }

    /**
     * A stable, collision-proof gallery name.
     *
     * The store's own names are random hex, which is fine inside the app and
     * unhelpful in a gallery sorted by name. A timestamped prefix keeps the
     * pictures grouped and in order, and keeps the original stem so the same
     * transcript image saved twice does not produce two unrelated-looking files.
     */
    private fun fileName(source: File): String {
        val stem = source.nameWithoutExtension.takeLast(8).ifBlank { "image" }
        return "sirius-" + System.currentTimeMillis() + "-" + stem + ".png"
    }
}
