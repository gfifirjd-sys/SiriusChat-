package com.sirius.chat.data.files

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/**
 * What happened to a request to put a file from a message on the device.
 *
 * Three outcomes rather than a boolean, for the same reason as
 * [com.sirius.chat.data.image.ImageExportResult]: "it did not save" and "it did
 * not save yet, because storage permission was never asked for" need different
 * words on screen and a different next step.
 */
sealed interface FileExportResult {

    /** In the public Downloads folder, under [FileExporter.FOLDER]. */
    data class Saved(val folder: String) : FileExportResult

    /** Pre-Android 10 only: the legacy storage permission has not been granted. */
    data object NeedsPermission : FileExportResult

    data object Failed : FileExportResult
}

/**
 * Puts a file the model produced — or one pulled from a link — somewhere the
 * user actually owns it.
 *
 * ### Why Downloads and not the app's own folder
 * A snippet the model wrote is worth nothing if it can only be read inside this
 * chat. Downloads is the one directory every file manager, editor and share
 * sheet on the phone already looks in, and on Android 10+ writing there needs no
 * permission at all — MediaStore handles it. The subfolder exists so a week of
 * experimenting does not bury the user's own downloads.
 *
 * ### Why sharing writes to the cache first
 * `FileProvider` can only hand out a Uri for a file that exists on disk, and the
 * contents here live in a chat message, not in a file. The copy goes to
 * `cacheDir/shared-files`, which the system reclaims on its own and which
 * `file_paths.xml` scopes the provider to, so a chooser can never be talked into
 * reading anything else the app owns.
 */
object FileExporter {

    /** Subfolder of Downloads. Same name as the gallery album, on purpose. */
    const val FOLDER = "SiriusChat"

    private const val SHARE_DIR = "shared-files"
    private const val MAX_NAME_CHARS = 96
    private const val FALLBACK_NAME = "file.txt"

    suspend fun saveToDownloads(
        context: Context,
        name: String,
        bytes: ByteArray
    ): FileExportResult = withContext(Dispatchers.IO) {
        val safe = fileName(name)
        try {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ->
                    viaMediaStore(context, safe, bytes)

                needsLegacyPermission(context) -> FileExportResult.NeedsPermission
                else -> legacy(context, safe, bytes)
            }
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (error: Throwable) {
            FileExportResult.Failed
        }
    }

    /**
     * A chooser that sends the bytes on as a real file.
     *
     * Returns null instead of throwing when the copy or the provider lookup
     * fails: the caller is a click handler in the transcript, and a crash there
     * costs the user the conversation.
     */
    fun shareChooser(
        context: Context,
        name: String,
        bytes: ByteArray,
        title: String
    ): Intent? = try {
        val directory = File(context.cacheDir, SHARE_DIR).apply { mkdirs() }
        val file = File(directory, fileName(name))
        file.writeBytes(bytes)
        val uri = FileProvider.getUriForFile(context, authority(context), file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mimeFor(file.name)
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TITLE, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        Intent.createChooser(send, title)
    } catch (cancellation: CancellationException) {
        throw cancellation
    } catch (error: Throwable) {
        null
    }

    /** True only on API 26-28, where Downloads still needs the legacy grant. */
    fun needsLegacyPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) return false
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) != PackageManager.PERMISSION_GRANTED
    }

    /**
     * A file name that cannot escape the folder it is written to.
     *
     * The name arrives from a model or from a `Content-Disposition` header, so
     * `../../shared_prefs/keys.xml` is a thing it can say. Only the last segment
     * survives, and separators cannot come back afterwards.
     */
    fun fileName(raw: String): String {
        val tail = raw.trim()
            .substringAfterLast('/')
            .substringAfterLast('\\')
            .replace(ILLEGAL, "_")
            .trim('.', ' ', '_')
        if (tail.isBlank()) return FALLBACK_NAME
        return if (tail.length <= MAX_NAME_CHARS) {
            tail
        } else {
            // Truncate the stem, never the extension: the extension is what the
            // next app uses to decide it can open this at all.
            val extension = tail.substringAfterLast('.', "")
            val stem = tail.removeSuffix(".$extension")
            val room = (MAX_NAME_CHARS - extension.length - 1).coerceAtLeast(8)
            if (extension.isEmpty()) tail.take(MAX_NAME_CHARS) else stem.take(room) + "." + extension
        }
    }

    fun mimeFor(name: String): String =
        when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
            "html", "htm" -> "text/html"
            "css" -> "text/css"
            "js", "mjs", "ts", "tsx", "jsx" -> "text/javascript"
            "json" -> "application/json"
            "xml", "kts", "gradle" -> "text/plain"
            "md", "markdown" -> "text/markdown"
            "csv" -> "text/csv"
            "yml", "yaml" -> "text/yaml"
            "svg" -> "image/svg+xml"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "pdf" -> "application/pdf"
            "zip", "apk", "jar" -> "application/zip"
            "mp4" -> "video/mp4"
            "mp3" -> "audio/mpeg"
            "" -> "application/octet-stream"
            else -> "text/plain"
        }

    /** "12.4 KB". Short enough to sit under a file name on a phone. */
    fun readableSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
    }

    private fun authority(context: Context): String = context.packageName + ".files"

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun viaMediaStore(
        context: Context,
        name: String,
        bytes: ByteArray
    ): FileExportResult {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mimeFor(name))
            put(
                MediaStore.Downloads.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + File.separator + FOLDER
            )
            // Nothing else may open a half-written file, which matters here more
            // than for a picture: a truncated zip looks like a corrupt download.
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val target = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: return FileExportResult.Failed
        val written = runCatching {
            resolver.openOutputStream(target)?.use { stream -> stream.write(bytes) } != null
        }.getOrDefault(false)
        if (!written) {
            runCatching { resolver.delete(target, null, null) }
            return FileExportResult.Failed
        }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(target, values, null, null)
        return FileExportResult.Saved(FOLDER)
    }

    private fun legacy(
        context: Context,
        name: String,
        bytes: ByteArray
    ): FileExportResult {
        @Suppress("DEPRECATION")
        val downloads = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS
        )
        val directory = File(downloads, FOLDER)
        if (!directory.exists() && !directory.mkdirs()) return FileExportResult.Failed
        val target = File(directory, name)
        target.writeBytes(bytes)
        // Without the scan the file exists but no file manager lists it until the
        // next boot, which reads to the user as a failed save.
        MediaScannerConnection.scanFile(
            context,
            arrayOf(target.absolutePath),
            arrayOf(mimeFor(name)),
            null
        )
        return FileExportResult.Saved(FOLDER)
    }

    private val ILLEGAL = Regex("[\\\\/:*?\"<>|\\r\\n\\t]")
}
