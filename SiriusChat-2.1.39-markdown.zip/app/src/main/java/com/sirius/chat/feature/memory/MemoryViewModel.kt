package com.sirius.chat.feature.memory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.MemoryCategory
import com.sirius.chat.domain.model.MemoryEdge
import com.sirius.chat.domain.model.MemoryNode
import com.sirius.chat.domain.model.memoryEdges
import com.sirius.chat.domain.model.topicEdges
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MemoryUiState(
    val nodes: List<MemoryNode> = emptyList(),
    val edges: List<MemoryEdge> = emptyList(),
    val selectedId: String? = null,
    /**
     * Categories the viewer left switched on. Empty means "no filter", which
     * shows every category in its own colour; anything else greys out the rest
     * rather than hiding it, so the shape of the whole graph stays readable.
     */
    val filters: Set<MemoryCategory> = emptySet(),
    /** Free-text search over the facts. Non-matching facts grey out, like a filter. */
    val query: String = "",
    /**
     * Whether node labels are drawn, or null while the viewer has never chosen.
     *
     * Resolved by the screen and not here, because the fallback depends on the
     * device: this layer has no business knowing how fast the phone is.
     */
    val labels: Boolean? = null,
    val spinning: Boolean = true,
    val showLinks: Boolean = true,
    val showTopics: Boolean = true,
    val loaded: Boolean = false
) {
    val selected: MemoryNode?
        get() = nodes.firstOrNull { it.id == selectedId }
}

/**
 * Backing state for the memory graph.
 *
 * ### Why the selection is held here and not in the canvas
 * The canvas is redrawn on every frame while the scene turns. Keeping the
 * expanded node inside it would tie "what the user tapped" to the lifetime of a
 * drawing surface, so the card would vanish on rotation, on a configuration
 * change, and on the first recomposition that happened to drop the composable.
 * Here it survives all three, and the canvas stays a pure function of state.
 *
 * ### Why the panel switches are in settings and not in the screen
 * Filters, labels, spin and the two kinds of line used to be `remember` state in
 * the composable. That is state with the lifetime of a screen: every switch the
 * user flipped was forgotten the moment they left memory, so the panel appeared
 * to do nothing at all between visits. They are user decisions, so they live in
 * settings and survive the screen, the process and the phone being restarted.
 *
 * The selection and the filters are also re-checked against the current nodes on
 * every emission: forgetting the node that is open must close the card, and a
 * filter on a category that no longer holds a fact must not grey out the entire
 * graph with no way left to switch it back off.
 */
class MemoryViewModel(private val container: AppContainer) : ViewModel() {

    private val _selected = MutableStateFlow<String?>(null)
    private val _query = MutableStateFlow("")

    val state: StateFlow<MemoryUiState> = combine(
        container.memoryRepository.observeNodes(),
        _selected,
        _query,
        container.settingsRepository.settings
    ) { nodes, selected, query, settings ->
        val present = nodes.mapTo(HashSet()) { it.category }
        val kept = settings.memoryFilters.filterTo(HashSet()) { it in present }
        // Two kinds of line, built in this order on purpose: a stated link wins
        // over the file line between the same pair, so a real relationship is
        // never redrawn as a weaker grouping line.
        val stated = nodes.memoryEdges()
        MemoryUiState(
            nodes = nodes,
            edges = stated + nodes.topicEdges(stated),
            selectedId = selected?.takeIf { id -> nodes.any { it.id == id } },
            // Every category switched on is the same picture as no filter at all,
            // and "no filter" is the state that also colours a category that
            // turns up later.
            filters = if (kept.size >= present.size) emptySet() else kept,
            query = query,
            labels = settings.memoryLabels,
            spinning = settings.memorySpin,
            showLinks = settings.memoryLinks,
            showTopics = settings.memoryTopics,
            loaded = true
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MemoryUiState())

    fun select(id: String?) {
        _selected.value = id
    }

    fun setQuery(text: String) {
        _query.value = text
    }

    fun setLabels(on: Boolean) = update { it.copy(memoryLabels = on) }

    fun setSpinning(on: Boolean) = update { it.copy(memorySpin = on) }

    fun setLinks(on: Boolean) = update { it.copy(memoryLinks = on) }

    fun setTopics(on: Boolean) = update { it.copy(memoryTopics = on) }

    /**
     * Switches one category on or off. Several may be on at once, and switching
     * the last one back on returns to the unfiltered view.
     *
     * The stored set is empty while nothing is filtered, so the toggle starts
     * from "everything is on" rather than from an empty set -- otherwise the
     * first tap on a ticked box would switch that category on, which is the
     * opposite of what a ticked box promises.
     */
    fun toggleFilter(category: MemoryCategory) {
        val present = state.value.nodes.mapTo(LinkedHashSet()) { it.category }
        if (present.isEmpty()) return
        update { settings ->
            val stored = settings.memoryFilters.filterTo(LinkedHashSet()) { it in present }
            val current: Set<MemoryCategory> = if (stored.isEmpty()) present else stored
            val next = if (category in current) current - category else current + category
            val cleared = next.isEmpty() || next.containsAll(present)
            settings.copy(memoryFilters = if (cleared) emptySet() else next)
        }
    }

    fun forget(id: String) {
        viewModelScope.launch {
            container.memoryRepository.delete(id)
            if (_selected.value == id) _selected.value = null
        }
    }

    fun forgetEverything() {
        viewModelScope.launch {
            container.memoryRepository.clear()
            _selected.value = null
        }
    }

    private fun update(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { container.settingsRepository.update(transform) }
    }
}
