package com.sirius.chat.core.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.sirius.chat.MainActivity
import com.sirius.chat.R
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.AppSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

/**
 * Tells the user what happened while they were not looking.
 *
 * An agent run is not a chat message: it can take minutes, ask a question in the
 * middle, and finish long after the user has put the phone down. Without this,
 * the only way to find out was to open the app and check -- so a run that needed
 * one tap to continue sat blocked until the user happened to come back.
 *
 * ### What it will not do
 * Nothing is posted while the app is on screen. The chat already shows the
 * streaming answer and the question sheet, so a notification would be a second
 * copy of something the user is looking at. This is also why there is no
 * "message received" notification: the only events worth interrupting for are
 * the ones the user cannot see.
 *
 * Two channels rather than one, because the two events deserve different
 * treatment: a finished answer is news, a blocked run is a request. Android then
 * lets the user silence one without losing the other.
 */
class AgentNotifier(
    private val context: Context,
    settings: Flow<AppSettings>,
    scope: CoroutineScope
) {

    /**
     * Whether an activity of this app is currently on screen.
     *
     * Written from the activity's start/stop, read from generation coroutines on
     * other threads, hence [Volatile]: a stale `true` here means a notification
     * the user needed is silently dropped.
     */
    @Volatile
    var appVisible: Boolean = false

    @Volatile
    private var enabled: Boolean = true

    init {
        // Collected once for the life of the process rather than read per event:
        // posting a notification happens on a coroutine that must not block on
        // disk, and DataStore reads are disk reads.
        scope.launch { settings.collect { enabled = it.notificationsEnabled } }
    }

    /** The answer is finished and stored. */
    fun done(sessionId: String, chat: String, preview: String) {
        post(
            sessionId = sessionId,
            chat = chat,
            heading = AppStrings.get(R.string.notify_done_title, "Answer ready"),
            body = preview.ifBlank {
                AppStrings.get(R.string.notify_done_body, "The assistant finished")
            },
            urgent = false
        )
    }

    /** The run is suspended on `ask_user` and cannot continue without an answer. */
    fun question(sessionId: String, chat: String, question: String) {
        post(
            sessionId = sessionId,
            chat = chat,
            heading = AppStrings.get(R.string.notify_question_title, "A decision is needed"),
            body = question,
            urgent = true
        )
    }

    /** The run ended on an error. */
    fun failed(sessionId: String, chat: String, message: String) {
        post(
            sessionId = sessionId,
            chat = chat,
            heading = AppStrings.get(R.string.notify_failed_title, "The answer failed"),
            body = message.ifBlank {
                AppStrings.get(R.string.notify_failed_body, "Open the chat to try again")
            },
            urgent = false
        )
    }

    /**
     * Removes this chat's notification.
     *
     * Called when a question is answered: a request that has already been dealt
     * with must not stay in the shade, or tapping it reopens a chat that is
     * waiting for nothing.
     */
    fun clear(sessionId: String) {
        runCatching { manager()?.cancel(idFor(sessionId)) }
    }

    private fun post(
        sessionId: String,
        chat: String,
        heading: String,
        body: String,
        urgent: Boolean
    ) {
        if (!enabled || appVisible || !allowed()) return
        val manager = manager() ?: return
        // Newlines and code fences turn a notification into a wall, so the body
        // is flattened to one paragraph before it is trimmed.
        val text = body.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString(" ")
            .take(MAX_BODY_CHARS)
        val channel = if (urgent) CHANNEL_ASKS else CHANNEL_EVENTS
        runCatching {
            createChannels(manager)
            val notification = NotificationCompat.Builder(context, channel)
                .setContentTitle(heading)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setSubText(chat.take(MAX_CHAT_CHARS).takeIf { it.isNotBlank() })
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setPriority(
                    if (urgent) NotificationCompat.PRIORITY_HIGH
                    else NotificationCompat.PRIORITY_DEFAULT
                )
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openChat(sessionId))
                .build()
            manager.notify(idFor(sessionId), notification)
        }
    }

    /**
     * One notification per chat, so a long agent run cannot bury the shade under
     * a notification per step, and "finished" replaces "needs a decision" for the
     * same conversation instead of sitting under it.
     */
    private fun idFor(sessionId: String): Int = NOTIFICATION_BASE + (sessionId.hashCode() and 0xFFFF)

    private fun openChat(sessionId: String): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(EXTRA_SESSION_ID, sessionId)
        return PendingIntent.getActivity(
            context,
            // Per chat, not a constant: a shared request code would let one
            // pending intent overwrite another's extras and open the wrong chat.
            idFor(sessionId),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /**
     * Android 13 turned notifications into a runtime permission. Posting without
     * it is not an error, it is a silent no-op, so the check exists to stop the
     * app from believing it told the user something.
     */
    private fun allowed(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun manager(): NotificationManager? =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

    private fun createChannels(manager: NotificationManager) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        if (manager.getNotificationChannel(CHANNEL_EVENTS) == null) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_EVENTS,
                    AppStrings.get(R.string.notify_channel_events_name, "Finished answers"),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = AppStrings.get(
                        R.string.notify_channel_events_description,
                        "Posted when an answer is finished while the app is closed."
                    )
                }
            )
        }
        if (manager.getNotificationChannel(CHANNEL_ASKS) == null) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ASKS,
                    AppStrings.get(R.string.notify_channel_asks_name, "Questions from the agent"),
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = AppStrings.get(
                        R.string.notify_channel_asks_description,
                        "Posted when a run stops and waits for your decision."
                    )
                }
            )
        }
    }

    companion object {
        /** Extra carrying the chat to open when a notification is tapped. */
        const val EXTRA_SESSION_ID = "com.sirius.chat.extra.SESSION_ID"

        private const val CHANNEL_EVENTS = "sirius_events"
        private const val CHANNEL_ASKS = "sirius_asks"

        // Well clear of the foreground service's 4201, which is a different
        // notification with a different lifetime.
        private const val NOTIFICATION_BASE = 5_000
        private const val MAX_BODY_CHARS = 240
        private const val MAX_CHAT_CHARS = 60
    }
}
