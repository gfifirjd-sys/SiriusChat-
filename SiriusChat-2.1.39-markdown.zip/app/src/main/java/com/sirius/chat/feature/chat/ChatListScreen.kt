package com.sirius.chat.feature.chat

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.EmptyState
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusConfirmSheet
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.ToastTone
import com.sirius.chat.core.designsystem.effects.beamBorder
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.relativeTimeText
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.feature.chat.components.MessageHitsSection

@Composable
fun ChatListScreen(
    onOpenChat: (String) -> Unit,
    onOpenProviders: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: ChatListViewModel = siriusViewModel { ChatListViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()

    val listState = rememberLazyListState()
    // The top bar only earns its seam once a row has slid underneath it.
    val scrolled by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 4
        }
    }

    var pendingDelete by remember { mutableStateOf<ChatSession?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }
    var toastTone by remember { mutableStateOf(ToastTone.Success) }

    // Creating a chat can fail for exactly one reason the user can fix, so that
    // reason is spoken instead of leaving the tap looking ignored.
    LaunchedEffect(state.message) {
        val message = state.message ?: return@LaunchedEffect
        toastTone = ToastTone.Error
        toast = message
        viewModel.consumeMessage()
    }

    val filtering = state.query.isNotBlank() || state.projectFilter != null

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.chats_title),
            subtitle = pluralStringResource(
                R.plurals.chats_count,
                state.filtered.size,
                state.filtered.size
            ),
            scrolled = scrolled,
            actions = {
                GlassIconButton(
                    icon = Icons.Rounded.AutoAwesome,
                    contentDescription = stringResource(R.string.chats_new_agent),
                    highlighted = true,
                    onClick = { viewModel.newChat(onOpenChat, onOpenProviders) }
                )
            }
        )

        SiriusTextField(
            value = state.query,
            onValueChange = viewModel::onQueryChange,
            placeholder = stringResource(R.string.chats_search_placeholder),
            leadingIcon = Icons.Rounded.Search,
            // Clearing a query is a frequent, low-value action, so it lives in
            // the field itself rather than costing the user a trip to the keyboard.
            trailing = if (state.query.isNotBlank()) {
                {
                    GlassIconButton(
                        icon = Icons.Rounded.Close,
                        contentDescription = stringResource(R.string.action_dismiss),
                        size = 28.dp,
                        iconSize = 14.dp,
                        onClick = { viewModel.onQueryChange("") }
                    )
                }
            } else {
                null
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SiriusSpacing.sm)
        )

        if (state.projects.isNotEmpty()) {
            LazyRow(
                modifier = Modifier.padding(
                    horizontal = SiriusSpacing.sm,
                    vertical = SiriusSpacing.xs
                ),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item(key = "all") {
                    SiriusChip(
                        text = stringResource(R.string.action_all),
                        selected = state.projectFilter == null,
                        onClick = { viewModel.onProjectFilter(null) }
                    )
                }
                items(state.projects, key = { it.id }) { project ->
                    // Tapping the active filter again releases it, so the chip row
                    // never traps the user in a project they cannot get out of.
                    val selected = state.projectFilter == project.id
                    SiriusChip(
                        text = project.name,
                        // Projects appear and disappear as they are created or
                        // deleted, so the row slides instead of jumping.
                        modifier = Modifier.animateItem(),
                        selected = selected,
                        onClick = {
                            viewModel.onProjectFilter(if (selected) null else project.id)
                        }
                    )
                }
            }
        }

        when {
            // A filtered-to-nothing list is not the same as an empty app: offering
            // "New chat" here would answer a question the user did not ask.
            // A title matching nothing does not mean the history holds nothing.
            // Message bodies are searched too, and those hits belong here instead
            // of behind a "nothing found" screen that is simply not true.
            state.filtered.isEmpty() && filtering && state.hits.isNotEmpty() -> LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(
                    start = SiriusSpacing.sm,
                    end = SiriusSpacing.sm,
                    top = SiriusSpacing.xs,
                    bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
                ),
                verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
            ) {
                item(key = "hits") {
                    MessageHitsSection(hits = state.hits, onOpen = { onOpenChat(it.sessionId) })
                }
            }

            state.filtered.isEmpty() && filtering -> Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center
            ) {
                EmptyState(
                    icon = Icons.Rounded.SearchOff,
                    title = stringResource(R.string.chats_no_results_title),
                    message = stringResource(R.string.chats_no_results_message),
                    actionLabel = stringResource(R.string.chats_clear_filters),
                    onAction = {
                        viewModel.onQueryChange("")
                        viewModel.onProjectFilter(null)
                    }
                )
            }

            state.filtered.isEmpty() -> Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center
            ) {
                EmptyState(
                    icon = Icons.Rounded.AutoAwesome,
                    title = stringResource(R.string.chats_empty_title),
                    message = stringResource(R.string.chats_empty_message),
                    actionLabel = stringResource(R.string.chats_new_agent),
                    orb = true,
                    onAction = { viewModel.newChat(onOpenChat, onOpenProviders) }
                )
            }

            else -> LazyColumn(
                modifier = Modifier.weight(1f),
                state = listState,
                contentPadding = PaddingValues(
                    start = SiriusSpacing.sm,
                    end = SiriusSpacing.sm,
                    top = SiriusSpacing.xs,
                    bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
                ),
                verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
            ) {
                if (state.hits.isNotEmpty()) item(key = "hits") {
                    MessageHitsSection(hits = state.hits, onOpen = { onOpenChat(it.sessionId) })
                }

                items(state.filtered, key = { it.id }) { session ->
                    val pinned = stringResource(R.string.chats_pinned, session.title)
                    val unpinned = stringResource(R.string.chats_unpinned, session.title)
                    SessionRow(
                        session = session,
                        generating = session.id in state.generating,
                        onStop = { viewModel.stopGeneration(session.id) },
                        // Pinning reorders the list; animating the move keeps it
                        // legible as "that row went to the top".
                        modifier = Modifier.animateItem(),
                        onOpen = { onOpenChat(session.id) },
                        onTogglePin = {
                            viewModel.togglePin(session)
                            toastTone = ToastTone.Success
                            toast = if (session.pinned) unpinned else pinned
                        },
                        onDelete = { pendingDelete = session }
                    )
                }
            }
        }
    }

    // Deleting a conversation is irreversible and used to be one stray tap away
    // from the row's own open target, so it now goes through the shared gate.
    pendingDelete?.let { session ->
        val deleted = stringResource(R.string.chats_deleted, session.title)
        SiriusConfirmSheet(
            title = stringResource(R.string.chats_delete_title, session.title),
            message = stringResource(R.string.chats_delete_message),
            confirmLabel = stringResource(R.string.action_delete),
            icon = Icons.Rounded.DeleteOutline,
            onConfirm = {
                pendingDelete = null
                viewModel.delete(session)
                toastTone = ToastTone.Success
                toast = deleted
            },
            onDismiss = { pendingDelete = null }
        )
    }

    MessageToast(
        message = toast,
        tone = toastTone,
        bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.sm
    )
}

/**
 * One conversation as a plate: mode well, title, preview, model and time.
 *
 * The card is itself a button, so the two trailing controls carry their own
 * labels — a screen reader user meets three targets in this row and needs to
 * know which is which. The mode icon stays decorative because the pinned and
 * agent facts are already spoken by the chips above the preview.
 */
@Composable
private fun SessionRow(
    session: ChatSession,
    generating: Boolean,
    modifier: Modifier = Modifier,
    onOpen: () -> Unit,
    onTogglePin: () -> Unit,
    onStop: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = SiriusTheme.colors

    // A breathing halo on the avatar plus a travelling border on the card. Two
    // channels on purpose: the halo is visible while scrolling past at speed, the
    // border survives a screenshot. Motion is the only honest way to say "this one
    // is working right now" without a label that would be stale a second later.
    val transition = rememberInfiniteTransition(label = "working")
    val pulse by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val reduceMotion = SiriusTheme.reduceMotion
    val haloAlpha = if (generating) (if (reduceMotion) 0.6f else pulse) else 0f

    GlassCard(
        modifier = modifier.beamBorder(
            shape = RoundedCornerShape(SiriusRadius.lg),
            // beamBorder honours reduce-motion itself, falling back to a static rim.
            active = generating,
            head = colors.accent,
            tail = colors.primary
        ),
        onClick = onOpen,
        onClickLabel = if (generating) {
            stringResource(R.string.chats_open_working, session.title)
        } else {
            stringResource(R.string.chats_open_chat, session.title)
        },
        contentPadding = SiriusSpacing.sm
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .drawBehind {
                        if (haloAlpha <= 0f) return@drawBehind
                        drawCircle(
                            color = colors.accent.copy(alpha = haloAlpha * 0.55f),
                            radius = size.minDimension / 2f + 4.dp.toPx() * haloAlpha
                        )
                    }
                    .softSurface(CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = if (generating) colors.accent else colors.accent.copy(alpha = 0.75f),
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(Modifier.width(SiriusSpacing.sm))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (session.pinned) {
                        Icon(
                            Icons.Rounded.PushPin,
                            contentDescription = stringResource(R.string.chats_pinned_state),
                            tint = colors.warning,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(
                        text = session.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = colors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (generating) {
                    // The stored preview is one message behind while the model is
                    // mid-answer, so showing it here would be actively misleading.
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .drawBehind {
                                    drawCircle(color = colors.accent.copy(alpha = haloAlpha))
                                }
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.chats_working),
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.accent,
                            maxLines = 1
                        )
                    }
                } else {
                    Text(
                        text = session.lastMessagePreview.ifBlank {
                            stringResource(R.string.chats_no_messages)
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textTertiary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "${session.model} \u00B7 ${relativeTimeText(session.updatedAt)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(SiriusSpacing.xs))
            // Stopping a run should not require opening the chat it belongs to: with
            // generation in the background, the list is where the user notices it.
            if (generating) {
                GlassIconButton(
                    icon = Icons.Rounded.Stop,
                    contentDescription = stringResource(R.string.action_stop),
                    size = 32.dp,
                    iconSize = 15.dp,
                    highlighted = true,
                    onClick = onStop
                )
                Spacer(Modifier.width(4.dp))
            }
            GlassIconButton(
                icon = Icons.Rounded.PushPin,
                contentDescription = if (session.pinned) {
                    stringResource(R.string.chats_unpin)
                } else {
                    stringResource(R.string.chats_pin)
                },
                size = 32.dp,
                iconSize = 15.dp,
                highlighted = session.pinned,
                onClick = onTogglePin
            )
            Spacer(Modifier.width(4.dp))
            GlassIconButton(
                icon = Icons.Rounded.DeleteOutline,
                contentDescription = stringResource(R.string.chats_delete_chat),
                size = 32.dp,
                iconSize = 15.dp,
                onClick = onDelete
            )
        }
    }
}
