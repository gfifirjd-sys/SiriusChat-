package com.sirius.chat.feature.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.isUsable
import com.sirius.chat.domain.model.resolveModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val settings: AppSettings = AppSettings(),
    val projects: List<Project> = emptyList(),
    val sessions: List<ChatSession> = emptyList(),
    val providers: List<ProviderConfig> = emptyList()
) {
    val activeProject: Project?
        get() = projects.firstOrNull { it.id == settings.activeProjectId } ?: projects.firstOrNull()

    /**
     * The provider the user actually picked. Display follows this and nothing
     * else: silently substituting another provider in the label made a switch
     * look ignored, because only the model half of the line changed.
     */
    val activeProvider: ProviderConfig?
        get() = providers.firstOrNull { it.id == settings.activeProviderId }
            ?: providers.firstOrNull { it.isUsable }
            ?: providers.firstOrNull()

    /** The provider a new chat can actually start on, if any. */
    val readyProvider: ProviderConfig?
        get() = activeProvider?.takeIf { it.isUsable }
            ?: providers.firstOrNull { it.isUsable }

    /** Model shown beside [activeProvider], never one owned by another endpoint. */
    val activeModel: String
        get() = activeProvider?.resolveModel(settings.activeModel).orEmpty()

    val needsProviderSetup: Boolean get() = readyProvider == null
}

class HomeViewModel(private val container: AppContainer) : ViewModel() {

    val state: StateFlow<HomeUiState> = combine(
        container.settingsRepository.settings,
        container.projectRepository.observeProjects(),
        container.chatRepository.observeSessions(),
        container.providerRepository.observeProviders()
    ) { settings, projects, sessions, providers ->
        HomeUiState(settings, projects, sessions, providers)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = HomeUiState()
    )

    /**
     * Creates a session with the best available provider and hands back its id.
     *
     * With no provider configured at all there is nothing to create, and the
     * button used to swallow the tap. [onNeedsProvider] sends the user where the
     * problem is solvable instead.
     */
    fun startChat(
        projectId: String? = null,
        onNeedsProvider: () -> Unit = {},
        onReady: (String) -> Unit
    ) {
        viewModelScope.launch {
            val settings = container.settingsRepository.current()
            val providers = container.providerRepository.providers()
            val provider = providers.firstOrNull { it.id == settings.activeProviderId }
                ?: providers.firstOrNull { it.isUsable }
                ?: providers.firstOrNull()
            if (provider == null) {
                onNeedsProvider()
                return@launch
            }
            val model = provider.resolveModel(settings.activeModel)
            val target = projectId ?: settings.activeProjectId.takeIf { it.isNotBlank() }
            val session = container.createSession(
                providerId = provider.id,
                model = model,
                projectId = target,
                title = container.strings.get(R.string.chats_untitled_agent)
            )
            onReady(session.id)
        }
    }

    fun selectProject(projectId: String) {
        viewModelScope.launch {
            container.settingsRepository.update { it.copy(activeProjectId = projectId) }
            container.projectRepository.touch(projectId)
        }
    }

    fun createProjectFromTree(treeUri: String, onReady: (String) -> Unit) {
        viewModelScope.launch {
            // Blank on purpose: CreateProjectUseCase already asks the document
            // provider for the folder's display name.
            val project = container.createProject(name = "", treeUri = treeUri)
            container.settingsRepository.update { it.copy(activeProjectId = project.id) }
            onReady(project.id)
        }
    }
}
