package com.sirius.chat.data.github

import android.util.Base64
import android.util.Log
import com.sirius.chat.core.common.AppDispatchers
import com.sirius.chat.domain.model.GitHubAccount
import com.sirius.chat.domain.model.GitHubArtifact
import com.sirius.chat.domain.model.GitHubEntry
import com.sirius.chat.domain.model.GitHubRepo
import com.sirius.chat.domain.model.GitHubRun
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Thrown for anything GitHub refused. [status] is the HTTP code so callers can
 * tell "your token is wrong" (401) from "that repo does not exist or your token
 * cannot see it" (404) from "you are being rate limited" (403).
 */
class GitHubException(
    val status: Int,
    message: String,
    /** HTTP method and full URL of the request that failed, when known. */
    val method: String = "",
    val url: String = "",
    /** The raw response body, capped. GitHub explains itself in there. */
    val body: String = "",
    val documentationUrl: String = "",
    val rateLimitRemaining: String = ""
) : IOException(message) {

    /**
     * Everything known about the failure, as text.
     *
     * The agent tools put this in their result and the log carries the same
     * string, because "github_list_files failed" with a red cross and nothing
     * else is unactionable: which request, which status, and what GitHub
     * actually said are the three things that identify the problem.
     */
    val detail: String
        get() = buildString {
            append(message.orEmpty())
            if (method.isNotBlank() && url.isNotBlank()) {
                append("\nRequest: $method $url")
            }
            if (rateLimitRemaining.isNotBlank()) {
                append("\nRate limit remaining: $rateLimitRemaining")
            }
            if (documentationUrl.isNotBlank()) append("\nDocs: $documentationUrl")
            if (body.isNotBlank()) append("\nResponse body: $body")
        }
}

/**
 * What the stored token actually is, according to GitHub.
 *
 * Read at the moment of a failure rather than trusted from when it was saved: a
 * personal access token expires, gets revoked, or loses access to a repository
 * that moved to an organisation, and all three look identical from the app until
 * someone asks `/user`.
 */
data class TokenStatus(
    val present: Boolean,
    val valid: Boolean,
    val login: String = "",
    val scopes: List<String> = emptyList(),
    val error: String = ""
) {
    val summary: String
        get() = when {
            !present -> "No GitHub token is stored: the user connects an account in Settings > GitHub."
            !valid -> "The stored GitHub token was rejected ($error). It has expired or been " +
                "revoked; the user has to reconnect in Settings > GitHub."
            else -> "Token is valid, authenticated as $login" +
                if (scopes.isEmpty()) {
                    " (fine-grained token: scopes are not listed, check its repository " +
                        "permissions include Contents)."
                } else {
                    " with scopes: ${scopes.joinToString(", ")}."
                }
        }
}

/**
 * The GitHub REST client.
 *
 * Hand-rolled on OkHttp rather than generated: the app needs about a dozen
 * endpoints, and every one of them is read straight out of the JSON with the
 * fields we care about. A generated client would add a code-generation step to
 * an on-device build that is already the slowest part of using this app.
 *
 * Three things are worth knowing about the Contents API used for writes:
 *
 * - It commits. There is no staging area, so every `putFile` is one commit with
 *   a message, which is why messages are a required argument everywhere.
 * - Updating a file requires the blob `sha` of what you are replacing. Sending
 *   the wrong one is a 409, so [putFile] always looks the current one up first
 *   and treats a 404 as "this is a create".
 * - Git has no empty directories. [createFolder] therefore writes a `.gitkeep`,
 *   which is the same thing every other tool does.
 */
class GitHubService(
    private val accounts: GitHubAccountStore,
    private val dispatchers: AppDispatchers
) {

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    private val json = Json { ignoreUnknownKeys = true }

    // ------------------------------------------------------------------ account

    /**
     * Checks a token and returns who it belongs to, without storing anything.
     * The connect screen calls this first so a bad paste never becomes a saved
     * account that fails on every later screen.
     */
    suspend fun verify(token: String): GitHubAccount = withContext(dispatchers.io) {
        val request = Request.Builder()
            .url("$API/user")
            .headers(headers(token))
            .get()
            .build()
        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw errorFor(response, body, "GET", "$API/user")
            val obj = json.parseToJsonElement(body).jsonObject
            GitHubAccount(
                login = obj.str("login"),
                name = obj.str("name"),
                avatarUrl = obj.str("avatar_url"),
                // Classic tokens list their scopes in this header; fine-grained
                // tokens omit it entirely.
                scopes = response.header("x-oauth-scopes")
                    .orEmpty()
                    .split(',')
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
            )
        }
    }

    /**
     * Checks the *stored* token, live.
     *
     * Called from the agent's failure path: a 404 on a repository that plainly
     * exists is usually a token problem, and answering "is the token still good"
     * turns a guess into a fact the user can act on.
     */
    suspend fun tokenStatus(): TokenStatus = withContext(dispatchers.io) {
        val token = accounts.token()
            ?: return@withContext TokenStatus(present = false, valid = false)
        try {
            val account = verify(token)
            TokenStatus(
                present = true,
                valid = true,
                login = account.login,
                scopes = account.scopes
            )
        } catch (error: GitHubException) {
            TokenStatus(present = true, valid = false, error = error.message.orEmpty())
        } catch (error: IOException) {
            // A dead network is not an invalid token, and saying so would send the
            // user off to regenerate a credential that was never the problem.
            TokenStatus(
                present = true,
                valid = false,
                error = "could not be checked: ${error.message ?: "network error"}"
            )
        }
    }

    // -------------------------------------------------------------------- repos

    /** Newest activity first, which is the only order that is ever useful here. */
    suspend fun repos(limit: Int = 100): List<GitHubRepo> = withContext(dispatchers.io) {
        val body = get("/user/repos?per_page=${limit.coerceIn(1, 100)}&sort=updated&affiliation=owner,collaborator,organization_member")
        body.jsonArray.map { it.jsonObject.toRepo() }
    }

    suspend fun repo(fullName: String): GitHubRepo = withContext(dispatchers.io) {
        get("/repos/${fullName.trim('/')}").jsonObject.toRepo()
    }

    suspend fun createRepo(
        name: String,
        description: String = "",
        isPrivate: Boolean = true,
        autoInit: Boolean = true
    ): GitHubRepo = withContext(dispatchers.io) {
        val payload = buildJsonObject {
            put("name", JsonPrimitive(name))
            if (description.isNotBlank()) put("description", JsonPrimitive(description))
            put("private", JsonPrimitive(isPrivate))
            // Without an initial commit the repo has no default branch, and every
            // Contents write against it fails with a confusing 404.
            put("auto_init", JsonPrimitive(autoInit))
        }
        post("/user/repos", payload).jsonObject.toRepo()
    }

    /** `private = false` is the "make it public" the user asked for. */
    suspend fun setVisibility(fullName: String, isPrivate: Boolean): GitHubRepo =
        withContext(dispatchers.io) {
            val payload = buildJsonObject { put("private", JsonPrimitive(isPrivate)) }
            patch("/repos/${fullName.trim('/')}", payload).jsonObject.toRepo()
        }

    suspend fun deleteRepo(fullName: String) = withContext(dispatchers.io) {
        delete("/repos/${fullName.trim('/')}", null)
        Unit
    }

    // ----------------------------------------------------------------- contents

    suspend fun list(
        fullName: String,
        path: String = "",
        ref: String = ""
    ): List<GitHubEntry> = withContext(dispatchers.io) {
        val element = get(contentsUrl(fullName, path, ref))
        when (element) {
            is JsonArray -> element.map { it.jsonObject.toEntry() }
            // A file path returns an object, not an array. Reporting it as a
            // single-entry listing is more useful than an error.
            is JsonObject -> listOf(element.toEntry())
            else -> emptyList()
        }
    }

    suspend fun readFile(fullName: String, path: String, ref: String = ""): String =
        withContext(dispatchers.io) {
            val obj = get(contentsUrl(fullName, path, ref)).jsonObject
            val encoding = obj.str("encoding")
            val content = obj.str("content")
            if (encoding != "base64") {
                throw GitHubException(415, "$path is not text (encoding: $encoding)")
            }
            // GitHub wraps its base64 at 60 columns; the strict decoder chokes
            // on the newlines, so they go before decoding rather than after.
            val packed = content.replace("\n", "").replace("\r", "")
            String(Base64.decode(packed, Base64.DEFAULT), Charsets.UTF_8)
        }

    /**
     * True when [path] already exists in the repository.
     *
     * Used before creating a file: `putFile` happily overwrites, so without this
     * check "create" would silently replace someone's work.
     */
    suspend fun exists(fullName: String, path: String, ref: String = ""): Boolean =
        withContext(dispatchers.io) {
            runCatching { get(contentsUrl(fullName, path.trim('/'), ref)) }.isSuccess
        }

    /** Blob sha of an existing file, or null when it is not there yet. */
    private suspend fun shaOf(fullName: String, path: String, branch: String): String? =
        runCatching { get(contentsUrl(fullName, path, branch)).jsonObject.str("sha") }
            .getOrNull()
            ?.takeIf { it.isNotBlank() }

    /**
     * Creates or replaces one file and returns the commit sha.
     *
     * @param branch empty means the repository's default branch.
     */
    suspend fun putFile(
        fullName: String,
        path: String,
        content: String,
        message: String,
        branch: String = ""
    ): String = withContext(dispatchers.io) {
        val clean = path.trim('/')
        val existing = shaOf(fullName, clean, branch)
        val payload = buildJsonObject {
            put("message", JsonPrimitive(message.ifBlank { "Update $clean via Sirius Chat" }))
            put(
                "content",
                JsonPrimitive(
                    Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                )
            )
            if (existing != null) put("sha", JsonPrimitive(existing))
            if (branch.isNotBlank()) put("branch", JsonPrimitive(branch))
        }
        put("/repos/${fullName.trim('/')}/contents/$clean", payload)
            .jsonObject["commit"]?.jsonObject?.str("sha").orEmpty()
    }

    /**
     * Git tracks files, not directories, so a folder is a `.gitkeep` inside it.
     * Anything else would be a lie that disappears on the next clone.
     */
    suspend fun createFolder(
        fullName: String,
        path: String,
        branch: String = ""
    ): String = putFile(
        fullName = fullName,
        path = "${path.trim('/')}/.gitkeep",
        content = "",
        message = "Create ${path.trim('/')}/ via Sirius Chat",
        branch = branch
    )

    suspend fun deleteFile(
        fullName: String,
        path: String,
        message: String,
        branch: String = ""
    ): Unit = withContext(dispatchers.io) {
        val clean = path.trim('/')
        val sha = shaOf(fullName, clean, branch)
            ?: throw GitHubException(404, "$clean does not exist in $fullName")
        val payload = buildJsonObject {
            put("message", JsonPrimitive(message.ifBlank { "Delete $clean via Sirius Chat" }))
            put("sha", JsonPrimitive(sha))
            if (branch.isNotBlank()) put("branch", JsonPrimitive(branch))
        }
        delete("/repos/${fullName.trim('/')}/contents/$clean", payload)
        Unit
    }

    // ------------------------------------------------------------------ actions

    /**
     * Installs the APK workflow if the repo does not have one yet.
     *
     * Returns true when it wrote the file. The workflow is committed rather than
     * run remotely from scratch because Actions can only run what is in the
     * repository — there is no "run this YAML for me" endpoint.
     */
    suspend fun ensureBuildWorkflow(fullName: String, branch: String = ""): Boolean {
        val existing = runCatching { readFile(fullName, WORKFLOW_PATH, branch) }.getOrNull()
        if (existing != null && existing.contains("workflow_dispatch")) return false
        putFile(
            fullName = fullName,
            path = WORKFLOW_PATH,
            content = ANDROID_WORKFLOW,
            message = "Add Android APK workflow via Sirius Chat",
            branch = branch
        )
        return true
    }

    /**
     * Starts a build. The workflow must already contain a `workflow_dispatch`
     * trigger, which is what [ensureBuildWorkflow] guarantees.
     *
     * GitHub answers 204 with no body, so there is no run id to return; callers
     * poll [runs] instead.
     */
    suspend fun dispatchWorkflow(
        fullName: String,
        ref: String,
        workflowFile: String = WORKFLOW_FILE,
        variant: String = "debug"
    ): Unit = withContext(dispatchers.io) {
        val payload = buildJsonObject {
            put("ref", JsonPrimitive(ref))
            put("inputs", buildJsonObject { put("variant", JsonPrimitive(variant)) })
        }
        post(
            "/repos/${fullName.trim('/')}/actions/workflows/$workflowFile/dispatches",
            payload
        )
        Unit
    }

    suspend fun runs(fullName: String, limit: Int = 10): List<GitHubRun> =
        withContext(dispatchers.io) {
            val body = get("/repos/${fullName.trim('/')}/actions/runs?per_page=${limit.coerceIn(1, 50)}")
            body.jsonObject["workflow_runs"]?.jsonArray.orEmpty().map { it.jsonObject.toRun() }
        }

    suspend fun artifacts(fullName: String, runId: Long): List<GitHubArtifact> =
        withContext(dispatchers.io) {
            val body = get("/repos/${fullName.trim('/')}/actions/runs/$runId/artifacts")
            body.jsonObject["artifacts"]?.jsonArray.orEmpty().map {
                val obj = it.jsonObject
                GitHubArtifact(
                    id = obj.num("id"),
                    name = obj.str("name"),
                    sizeBytes = obj.num("size_in_bytes"),
                    expired = obj.bool("expired")
                )
            }
        }

    /**
     * Downloads an artifact zip into [destination].
     *
     * The endpoint answers with a redirect to a signed URL; OkHttp follows it by
     * default, and the auth header must not be sent to that host, so the client
     * strips it on the redirect hop. The body is streamed to disk instead of
     * buffered: an APK zip is tens of megabytes and this runs on a phone.
     */
    suspend fun downloadArtifact(
        fullName: String,
        artifactId: Long,
        destination: File
    ): File = withContext(dispatchers.io) {
        val token = requireToken()
        val request = Request.Builder()
            .url("$API/repos/${fullName.trim('/')}/actions/artifacts/$artifactId/zip")
            .headers(headers(token))
            .get()
            .build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw errorFor(response, response.body?.string().orEmpty())
            }
            val stream = response.body?.byteStream()
                ?: throw GitHubException(500, "Empty artifact response")
            destination.parentFile?.mkdirs()
            destination.outputStream().use { out -> stream.copyTo(out, DEFAULT_BUFFER_SIZE) }
        }
        destination
    }

    // ------------------------------------------------------------------ plumbing

    private suspend fun requireToken(): String =
        accounts.token() ?: throw GitHubException(401, "No GitHub account is connected")

    private fun headers(token: String) = okhttp3.Headers.Builder()
        .add("Authorization", "Bearer $token")
        .add("Accept", "application/vnd.github+json")
        .add("X-GitHub-Api-Version", API_VERSION)
        .add("User-Agent", "SiriusChat")
        .build()

    private suspend fun get(pathOrUrl: String): JsonElement = execute("GET", pathOrUrl, null)

    private suspend fun post(path: String, payload: JsonObject): JsonElement =
        execute("POST", path, payload)

    private suspend fun put(path: String, payload: JsonObject): JsonElement =
        execute("PUT", path, payload)

    private suspend fun patch(path: String, payload: JsonObject): JsonElement =
        execute("PATCH", path, payload)

    private suspend fun delete(path: String, payload: JsonObject?): JsonElement =
        execute("DELETE", path, payload)

    private suspend fun execute(
        method: String,
        pathOrUrl: String,
        payload: JsonObject?
    ): JsonElement = withContext(dispatchers.io) {
        val token = requireToken()
        val url = if (pathOrUrl.startsWith("http")) pathOrUrl else API + pathOrUrl
        val body: RequestBody? = payload?.toString()?.toRequestBody(JSON_MEDIA)
        val request = Request.Builder()
            .url(url)
            .headers(headers(token))
            .method(method, body)
            .build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw errorFor(response, text, method, url)
            // 204 No Content is a success with nothing to parse (workflow
            // dispatch, repo delete).
            if (text.isBlank()) JsonObject(emptyMap()) else json.parseToJsonElement(text)
        }
    }

    /**
     * Turns GitHub's error body into something a user can act on. The raw
     * `message` is usually good ("Bad credentials", "Repository creation failed:
     * name already exists on this account") and the status carries the rest.
     */
    private fun errorFor(
        response: Response,
        body: String,
        method: String = "",
        url: String = ""
    ): GitHubException {
        val parsed = runCatching { json.parseToJsonElement(body).jsonObject }.getOrNull()
        val message = parsed?.str("message").orEmpty()
        // Validation failures (422) keep the real reason in an `errors` array and
        // leave `message` as a useless "Validation Failed", so both are read.
        val errors = parsed?.get("errors")?.let { element ->
            runCatching {
                element.jsonArray.joinToString("; ") { item ->
                    val obj = item.jsonObject
                    listOf(
                        obj.str("resource"),
                        obj.str("field"),
                        obj.str("code"),
                        obj.str("message")
                    ).filter { it.isNotBlank() }.joinToString(" ")
                }
            }.getOrNull()
        }.orEmpty()
        val detail = when {
            message.isNotBlank() && errors.isNotBlank() -> "$message ($errors)"
            message.isNotBlank() -> message
            body.isNotBlank() -> body.take(BODY_LOG_CHARS)
            else -> response.message
        }
        val error = GitHubException(
            status = response.code,
            message = "GitHub ${response.code}: $detail",
            method = method,
            url = url,
            body = body.take(BODY_LOG_CHARS),
            documentationUrl = parsed?.str("documentation_url").orEmpty(),
            rateLimitRemaining = response.header("x-ratelimit-remaining").orEmpty()
        )
        // Logged in full here, once, so the cause survives even when the caller
        // decides to show a shorter version of it.
        Log.w(TAG, "$method $url -> ${response.code}: ${error.detail}")
        return error
    }

    /**
     * Contents endpoint for one path.
     *
     * Every segment is percent-encoded. Unencoded paths worked for
     * `app/src/main` and then produced a bare 404 for any real-world name with a
     * space, a `#`, or a non-Latin character in it — a failure that reads exactly
     * like "the file does not exist". Slashes stay literal because they are the
     * path structure, and `+` is rewritten to `%20` because URLEncoder targets
     * form bodies rather than URLs.
     */
    private fun contentsUrl(fullName: String, path: String, ref: String): String {
        val encodedPath = path.trim('/')
            .split('/')
            .filter { it.isNotEmpty() }
            .joinToString("/") { segment -> encode(segment) }
        val base = "/repos/${fullName.trim('/')}/contents/$encodedPath"
        return if (ref.isBlank()) base else "$base?ref=${encode(ref)}"
    }

    private fun encode(value: String): String =
        URLEncoder.encode(value, "UTF-8").replace("+", "%20")

    private fun JsonObject.toRepo(): GitHubRepo {
        val ownerLogin = this["owner"]?.jsonObject?.str("login").orEmpty()
        return GitHubRepo(
            owner = ownerLogin,
            name = str("name"),
            isPrivate = bool("private"),
            defaultBranch = str("default_branch").ifBlank { "main" },
            description = str("description"),
            htmlUrl = str("html_url"),
            updatedAt = str("updated_at"),
            language = str("language")
        )
    }

    private fun JsonObject.toEntry() = GitHubEntry(
        path = str("path"),
        name = str("name"),
        isDirectory = str("type") == "dir",
        sizeBytes = num("size"),
        sha = str("sha")
    )

    private fun JsonObject.toRun() = GitHubRun(
        id = num("id"),
        name = str("name"),
        status = str("status"),
        conclusion = str("conclusion"),
        branch = str("head_branch"),
        htmlUrl = str("html_url"),
        createdAt = str("created_at"),
        runNumber = num("run_number").toInt()
    )

    /** Missing and JSON `null` both come back as an empty string. */
    private fun JsonObject.str(key: String): String {
        val primitive = this[key] as? JsonPrimitive ?: return ""
        if (primitive is JsonNull) return ""
        return primitive.content
    }

    private fun JsonObject.num(key: String): Long =
        runCatching { this[key]?.jsonPrimitive?.content?.toLong() }.getOrNull() ?: 0L

    private fun JsonObject.bool(key: String): Boolean =
        runCatching { this[key]?.jsonPrimitive?.content?.toBoolean() }.getOrNull() ?: false

    companion object {
        private const val TAG = "SiriusGitHub"

        /** How much of an error body is kept for the log and the agent. */
        private const val BODY_LOG_CHARS = 600

        private const val API = "https://api.github.com"
        private const val API_VERSION = "2022-11-28"
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

        const val WORKFLOW_FILE = "sirius-apk.yml"
        const val WORKFLOW_PATH = ".github/workflows/$WORKFLOW_FILE"

        /**
         * The workflow the app installs into a repository.
         *
         * Checkout, a static gate, JDK 17, Gradle, the APK, and the build log on
         * every run. The `check` variant compiles without packaging, which is the
         * cheapest way to ask whether the code builds at all.
         *
         * `workflow_dispatch` with a `variant` input is what lets both the
         * button in the app and the agent start a build; `push` is left off so
         * connecting an account does not start burning Actions minutes on every
         * commit the agent makes.
         */
        val ANDROID_WORKFLOW: String = """
            name: Sirius APK

            on:
              workflow_dispatch:
                inputs:
                  variant:
                    description: Build variant
                    required: false
                    default: debug
                    type: choice
                    options:
                      - check
                      - debug
                      - release

            permissions:
              contents: read

            jobs:
              build:
                runs-on: ubuntu-latest
                steps:
                  - uses: actions/checkout@v4

                  # A static gate that runs before Gradle: no SDK, no toolchain, seconds.
                  # It catches unbalanced braces, duplicate declarations, unimplemented
                  # interface members, broken Compose call sites and missing string
                  # resources - the mistakes that otherwise cost a full build to discover.
                  # kselftest.py runs first, on synthetic good and bad input, so a green
                  # gate means something and a red gate is not just noise.
                  - name: Static gate
                    run: |
                      if [ ! -f tools/kcheck.py ]; then
                        echo 'tools/kcheck.py is missing, skipping the static gate'
                        exit 0
                      fi
                      if [ -f tools/kselftest.py ]; then
                        if ! python3 tools/kselftest.py > selftest.log 2>&1; then
                          echo '## The static checker failed its own self-test' >> "${'$'}GITHUB_STEP_SUMMARY"
                          echo '```' >> "${'$'}GITHUB_STEP_SUMMARY"
                          tail -40 selftest.log >> "${'$'}GITHUB_STEP_SUMMARY"
                          echo '```' >> "${'$'}GITHUB_STEP_SUMMARY"
                          exit 1
                        fi
                      fi
                      if ! python3 tools/kcheck.py . > kcheck.log 2>&1; then
                        echo '## Static gate findings' >> "${'$'}GITHUB_STEP_SUMMARY"
                        echo '```' >> "${'$'}GITHUB_STEP_SUMMARY"
                        cat kcheck.log >> "${'$'}GITHUB_STEP_SUMMARY"
                        echo '```' >> "${'$'}GITHUB_STEP_SUMMARY"
                        exit 1
                      fi
                      tail -4 kcheck.log >> "${'$'}GITHUB_STEP_SUMMARY"

                  - name: Set up JDK 17
                    uses: actions/setup-java@v4
                    with:
                      distribution: temurin
                      java-version: '17'

                  # The Gradle version is read out of the repository's own wrapper
                  # descriptor and then installed by the action, rather than running
                  # ./gradlew. A wrapper jar is a binary in the repo: it may be missing,
                  # stripped by .gitignore, or hand-built for an on-device IDE, and any of
                  # those turns into a five-minute CI failure that reads like a compile
                  # error.
                  - name: Resolve the Gradle version
                    id: gradle
                    run: |
                      VERSION=8.9
                      PROPS=gradle/wrapper/gradle-wrapper.properties
                      if [ -f "${'$'}PROPS" ]; then
                        FOUND=${'$'}(grep -o 'gradle-[0-9.]*-\(bin\|all\)\.zip' "${'$'}PROPS" | head -1 | sed 's/gradle-//; s/-bin\.zip//; s/-all\.zip//')
                        if [ -n "${'$'}FOUND" ]; then VERSION="${'$'}FOUND"; fi
                      fi
                      echo "version=${'$'}VERSION" >> "${'$'}GITHUB_OUTPUT"

                  - name: Set up Gradle
                    uses: gradle/actions/setup-gradle@v4
                    with:
                      gradle-version: ${'$'}{{ steps.gradle.outputs.version }}

                  - name: Build
                    run: |
                      case "${'$'}{{ inputs.variant }}" in
                        release) TASK=assembleRelease ;;
                        check) TASK=compileDebugKotlin ;;
                        *) TASK=assembleDebug ;;
                      esac
                      echo "Task: ${'$'}TASK" >> "${'$'}GITHUB_STEP_SUMMARY"
                      set -o pipefail
                      gradle "${'$'}TASK" --no-daemon --stacktrace 2>&1 | tee build.log

                  # Kotlin reports errors as `e: file:///.../Foo.kt:12:5 message`, aapt as
                  # `.../values.xml:173:4: message`. Both patterns are needed: the failure
                  # that broke 2.0.3 was an unescaped apostrophe caught by aapt, not by
                  # Kotlin, and it was reported against a merged file nobody wrote.
                  - name: Report the first errors
                    if: failure()
                    run: |
                      [ -f build.log ] || exit 0
                      echo '## First errors' >> "${'$'}GITHUB_STEP_SUMMARY"
                      echo '```' >> "${'$'}GITHUB_STEP_SUMMARY"
                      grep -E '^e: |error:|ERROR:|FAILURE:|^Caused by:|FAILED${'$'}' build.log \
                        | sed 's|file:///home/runner/work/[^/]*/[^/]*/||' \
                        | head -40 >> "${'$'}GITHUB_STEP_SUMMARY" || true
                      echo '```' >> "${'$'}GITHUB_STEP_SUMMARY"

                  - name: Upload the build log
                    if: always()
                    uses: actions/upload-artifact@v4
                    with:
                      name: build-log-${'$'}{{ inputs.variant }}
                      path: build.log
                      if-no-files-found: ignore
                      retention-days: 14

                  - name: Upload APK
                    if: inputs.variant != 'check'
                    uses: actions/upload-artifact@v4
                    with:
                      name: apk-${'$'}{{ inputs.variant }}
                      path: '**/build/outputs/apk/**/*.apk'
                      if-no-files-found: error
                      retention-days: 14
        """.trimIndent() + "\n"
    }
}
