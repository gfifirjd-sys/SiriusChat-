package com.sirius.chat.feature.chat.components

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.SheetActionRow
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.data.image.GeneratedImageStore
import com.sirius.chat.data.image.ImageExportResult
import com.sirius.chat.data.image.ImageExporter
import java.io.File
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

/**
 * Renders a `![alt](uri)` block from the transcript.
 *
 * ### Why decoding happens here and not in the repository
 * The obvious alternative is to decode every image when the message list loads
 * and hand the bubble a ready `ImageBitmap`. That puts a 4 MB bitmap per picture
 * into a `Flow` that re-emits on every streamed token, and holds all of them for
 * the lifetime of the screen regardless of scroll position. Decoding in the
 * composable ties the bitmap's life to the item being on screen, which is what
 * `LazyColumn` already manages well.
 *
 * ### Why there is no image loading library
 * The project has no Coil or Glide, and adding one for this would be a large
 * dependency for a narrow job: these files are local, already-sized PNGs that we
 * wrote ourselves. `BitmapFactory` with `inSampleSize` covers it in the store,
 * and the failure surface is smaller than a cache library's.
 *
 * Remote `http(s)` images are deliberately *not* fetched. A model can emit any
 * URL, and silently loading one would let a prompt-injected link phone home with
 * the user's IP the moment a message renders. Those degrade to a labelled link
 * the user can choose to open.
 *
 * ### Why a long-press opens an export sheet
 * Until it did, a generated picture existed only inside this app: not in the
 * gallery, not sendable, and gone with the app's data. Long-press is the gesture
 * every gallery and chat app already uses for exactly this, and it is the only
 * one available -- a tap is reserved for opening, and the transcript scrolls
 * under everything else.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GeneratedImageView(
    alt: String,
    uri: String,
    store: GeneratedImageStore,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors

    if (!uri.startsWith(GeneratedImageStore.SCHEME)) {
        // Not one of ours: show it as text, not as a request.
        Text(
            text = if (alt.isBlank()) uri else "$alt — $uri",
            style = MaterialTheme.typography.bodySmall,
            color = colors.textTertiary,
            modifier = modifier
        )
        return
    }

    val context = LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<ImageBitmap?>(null) }
    var missing by remember(uri) { mutableStateOf(false) }

    // Kept alongside the bitmap because the export actions need the *file*, and
    // resolving it a second time inside a click handler would have to hit the
    // disk on the main thread.
    var source by remember(uri) { mutableStateOf<File?>(null) }

    // Aspect ratio of the file on disk, read from its header before the pixels
    // are decoded. Null until then, and null for good for a file whose header
    // cannot be read, in which case the placeholder just keeps its own height.
    var ratio by remember(uri) { mutableStateOf<Float?>(null) }

    LaunchedEffect(uri) {
        val file = store.resolve(uri)
        if (file == null) {
            // The file was pruned, or the model invented a name. Both end here,
            // and both must say so rather than leave an empty gap: a picture the
            // user remembers seeing and now cannot find is a bug report.
            missing = true
            return@LaunchedEffect
        }
        source = file
        // Shape first, pixels second. Reading the header is cheap and it lets
        // the placeholder take exactly the height the picture will need, so the
        // bitmap arriving moves nothing below it.
        ratio = store.dimensions(file)?.let { (width, height) ->
            if (height <= 0) null else width.toFloat() / height.toFloat()
        }
        bitmap = store.decode(file)?.asImageBitmap()
        missing = bitmap == null
    }

    val loaded = bitmap
    // The reveal is a fade with a slight upward drift rather than a scale-in: a
    // photograph that grows into place draws attention to the animation, and the
    // picture is the content here, not the transition.
    val appear by animateFloatAsState(
        targetValue = if (loaded != null) 1f else 0f,
        animationSpec = siriusTween(SiriusMotion.Slow, SiriusMotion.Emphasized),
        label = "imageAppear"
    )

    val haptics = rememberHaptics()
    val scope = rememberCoroutineScope()
    var actionsOpen by remember { mutableStateOf(false) }

    // The sheet animation belongs to Material and cannot be improved from here,
    // but the thing being held can answer the finger. Without this the long-press
    // was a dead half-second: nothing moved until the sheet arrived, which reads
    // as a missed tap and makes people press again.
    val pressSource = remember { MutableInteractionSource() }
    val pressed by pressSource.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (pressed && !SiriusTheme.reduceMotion) PressScale else 1f,
        // Gentle rather than precise: the release is the reward, so one soft
        // overshoot is wanted here.
        animationSpec = SiriusMotion.SpringGentle
    )

    val savedText = stringResource(R.string.chat_image_saved, ImageExporter.ALBUM)
    val failedText = stringResource(R.string.chat_image_save_failed)
    val permissionText = stringResource(R.string.chat_image_permission_needed)
    val shareFailedText = stringResource(R.string.chat_image_share_failed)
    val shareTitle = stringResource(R.string.chat_image_share)

    // Declared before the permission launcher so the launcher can retry it, and
    // before the sheet so the sheet can call it. Kotlin scoping, not preference.
    val save: (File) -> Unit = { file ->
        scope.launch {
            val message = when (ImageExporter.saveToGallery(context, file)) {
                is ImageExportResult.Saved -> savedText
                ImageExportResult.NeedsPermission -> permissionText
                ImageExportResult.Failed -> failedText
            }
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    // Only ever launched on API 26-28, where writing to Pictures/ still needs the
    // legacy permission. On Android 10+ MediaStore handles it and this is dead
    // weight the user is never asked about.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val file = source
        when {
            !granted -> Toast.makeText(context, permissionText, Toast.LENGTH_SHORT).show()
            file != null -> save(file)
            else -> Toast.makeText(context, failedText, Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier.widthIn(max = MaxImageWidth),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
    ) {
        when {
            loaded != null -> Image(
                bitmap = loaded,
                contentDescription = alt.ifBlank { stringResource(R.string.chat_image_generated) },
                contentScale = ContentScale.FillWidth,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(SiriusRadius.md))
                    // Tap and long-press both open the same sheet. The transcript
                    // has no image viewer, so a tap that did nothing would just
                    // read as broken; the long-press stays because it is what the
                    // gesture is called in the accessibility label, and it gets the
                    // stronger haptic of the two.
                    //
                    // `indication = null` with a live interaction source is the
                    // point: the default ripple is square-cornered noise over a
                    // photograph, while the scale below reads on any image.
                    .combinedClickable(
                        interactionSource = pressSource,
                        indication = null,
                        onLongClickLabel = stringResource(R.string.chat_image_actions_title),
                        onLongClick = {
                            haptics.strong()
                            actionsOpen = true
                        },
                        onClick = {
                            haptics.light()
                            actionsOpen = true
                        }
                    )
                    .alpha(appear)
                    .graphicsLayer {
                        translationY = (1f - appear) * RevealDriftPx * density
                        // One layer for both animations: the entrance drift and the
                        // press dip would otherwise fight over the same node.
                        scaleX = pressScale
                        scaleY = pressScale
                    }
            )

            // One line, not a picture-shaped hole. The full-width square this
            // replaces looked like a failed download of something that was
            // really there, and for an answer that mentions a picture in
            // passing it spent most of the screen on an apology.
            missing -> Text(
                text = if (alt.isBlank()) {
                    stringResource(R.string.chat_image_missing)
                } else {
                    stringResource(R.string.chat_image_missing_named, alt)
                },
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary,
                modifier = Modifier
                    .clip(RoundedCornerShape(SiriusRadius.md))
                    .background(colors.surfaceMuted)
                    .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
            )

            // Still decoding. The generation card is reused so the transcript
            // shows the same shape it will settle into, and the reserved box
            // holds the picture's real height, so the bitmap arriving a frame or
            // two later moves nothing under it.
            else -> Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .then(ratio?.let { Modifier.aspectRatio(it) } ?: Modifier)
            ) {
                ImageGenerationCard(
                    prompt = alt,
                    label = stringResource(R.string.chat_image_loading)
                )
            }
        }

        if (alt.isNotBlank() && loaded != null) {
            Text(
                text = alt,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary,
                maxLines = 2
            )
        }
    }

    if (actionsOpen) {
        val file = source
        SiriusBottomSheet(
            title = stringResource(R.string.chat_image_actions_title),
            subtitle = alt.takeIf { it.isNotBlank() },
            onDismiss = { actionsOpen = false }
        ) {
            SheetActionRow(
                icon = Icons.Rounded.Download,
                modifier = sheetRevealModifier(index = 0),
                label = stringResource(R.string.chat_image_save),
                supporting = stringResource(R.string.chat_image_save_hint, ImageExporter.ALBUM),
                enabled = file != null,
                onClick = {
                    actionsOpen = false
                    if (file == null) {
                        Toast.makeText(context, failedText, Toast.LENGTH_SHORT).show()
                    } else if (ImageExporter.needsLegacyPermission(context)) {
                        // Asked for before the write rather than after it fails, so
                        // the user sees one dialog instead of an error then a dialog.
                        permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    } else {
                        save(file)
                    }
                }
            )
            SheetActionRow(
                icon = Icons.Rounded.Share,
                modifier = sheetRevealModifier(index = 1),
                label = shareTitle,
                supporting = stringResource(R.string.chat_image_share_hint),
                enabled = file != null,
                onClick = {
                    actionsOpen = false
                    val chooser = file?.let { ImageExporter.shareChooser(context, it, shareTitle) }
                    if (chooser == null) {
                        Toast.makeText(context, shareFailedText, Toast.LENGTH_SHORT).show()
                    } else {
                        // A device with no app that accepts image/png is rare and
                        // not impossible; the throw is caught rather than crashing
                        // the transcript.
                        runCatching { context.startActivity(chooser) }.onFailure {
                            Toast.makeText(context, shareFailedText, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }
    }
}

private val MaxImageWidth = 320.dp
private const val RevealDriftPx = 10f

/**
 * The store, made ambient for the markdown renderer.
 *
 * ### Why a CompositionLocal rather than a parameter
 * Images are discovered deep inside [MarkdownText], which is called by
 * `MessageBubble`, which is called by the transcript, which is called by the
 * screen. Threading a store through all four means every one of them gains a
 * parameter it does not use, and every other caller of `MarkdownText` in the app
 * (the review sheet, the terminal output view) has to supply one too.
 *
 * This is the case CompositionLocal exists for: a process-wide singleton that a
 * leaf needs and no intermediate cares about. It is `staticCompositionLocalOf`
 * because the value never changes after startup, so no recomposition tracking is
 * warranted.
 *
 * The default throws rather than returning a no-op store. A silently missing
 * provider would show every generated image as "file not found" -- a bug that
 * looks like a data problem and would be hunted in the wrong layer.
 */
val LocalGeneratedImageStore = staticCompositionLocalOf<GeneratedImageStore> {
    error("LocalGeneratedImageStore was not provided. Wire it in SiriusApp from AppContainer.")
}

/**
 * Fades a sheet row in with a short delay based on its position.
 *
 * ### Why a modifier and not a wrapper
 * A wrapper composable would sit between the sheet column and the row, and the
 * row is what carries the touch target and the accessibility node. Animating
 * through the row's own modifier keeps the node exactly where it was.
 *
 * The stagger is deliberately small. At 55 ms per row two actions land in about
 * a tenth of a second, which is enough for the eye to see them arrive in order
 * and not enough to make anyone wait for the second one.
 */
@Composable
private fun sheetRevealModifier(index: Int): Modifier {
    val reduceMotion = SiriusTheme.reduceMotion
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        // Reduce motion means no waiting either: a delayed row that then appears
        // instantly is still a row that arrived late.
        if (!reduceMotion) delay(index * RevealStaggerMs)
        shown = true
    }
    val progress by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)
    )
    return Modifier
        .alpha(progress)
        .graphicsLayer { translationY = (1f - progress) * RevealStaggerPx * density }
}

/** How far a sheet row travels while fading in. */
private const val RevealStaggerPx = 10f

/** Gap between consecutive sheet rows. */
private const val RevealStaggerMs = 55L

/** How far the image dips while it is being held. */
private const val PressScale = 0.97f
