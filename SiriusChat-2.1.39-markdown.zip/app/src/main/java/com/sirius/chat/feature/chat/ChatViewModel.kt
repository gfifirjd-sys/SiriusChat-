package com.sirius.chat.feature.chat

import com.sirius.chat.ai.capability.EndpointCapabilityTable
import com.sirius.chat.domain.model.DefaultPowerMode
import com.sirius.chat.domain.model.EndpointCapabilities
import com.sirius.chat.domain.model.PowerConfig
import com.sirius.chat.domain.model.PowerMode
import com.sirius.chat.domain.model.powerSelection
import android.content.Intent
import android.net.Uri
import com.sirius.chat.ai.pricing.TokenCalibration
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.data.attachment.AttachmentReader
import com.sirius.chat.domain.model.AttachmentKind

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.ai.agent.AgentQuestion
import com.sirius.chat.ai.agent.GenerationFailure
import com.sirius.chat.ai.agent.StreamingAnswer
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.ai.capability.ModelCapabilities
import com.sirius.chat.ai.context.ContextCompactor
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.ChatFeature
import com.sirius.chat.domain.model.ChatFeatures
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.FeatureSupport
import com.sirius.chat.domain.model.defaultChatFeatures
import com.sirius.chat.domain.model.FileNode
import com.sirius.chat.domain.model.MessageAttachment
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.ProviderConfig
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class ChatUiState(
    val session: ChatSession? = null,
    val messages: List<ChatMessage> = emptyList(),
    val project: Project? = null,
    val providers: List<ProviderConfig> = emptyList(),
    val attachments: List<MessageAttachment> = emptyList(),
    val streaming: StreamingAnswer? = null,
    val error: String? = null,
    val retryable: Boolean = false,
    val pendingChanges: List<PendingChange> = emptyList(),
    /** Set while `ask_user` is waiting; the run is suspended until answered. */
    val question: AgentQuestion? = null,
    val loading: Boolean = true,
    /** Whether the right-edge settings panel is showing. */
    val settingsOpen: Boolean = false,
    /**
     * The chat's switches, already resolved against the user's defaults.
     *
     * Resolved rather than nullable so the UI never has to know about the
     * "inherit" state: a panel that had to decide between a session value and a
     * global default at render time would get it wrong in exactly the case that
     * matters, the first time a new chat is opened.
     */
    val features: ChatFeatures = ChatFeatures(),
    /** What the current provider and model can actually do. */
    val featureSupport: FeatureSupport = FeatureSupport.Unknown,
    /** The switch whose write is still in flight, for its spinner. */
    val busyFeature: ChatFeature? = null,
    /**
     * Whether context management is on for this chat.
     *
     * One switch, not two: it shows the meter above the composer *and* it is
     * what allows old turns to be folded into a summary. Off means the whole
     * feature is off for this conversation -- no bar, no folding -- because a
     * meter that hides while the folding it measures keeps happening would be a
     * switch that lies about what it controls.
     */
    val contextMeter: Boolean = true,
    /**
     * Whether this chat is told what is known about the user.
     *
     * Off means the model answers as if it were meeting this person for the
     * first time. It does *not* mean the chat stops learning: facts said here
     * are still recorded, because the switch is about the answer, not about
     * making the app deaf.
     */
    val memory: Boolean = true,
    /**
     * How hard this chat's endpoint and model are asked to work.
     *
     * Stored per (endpoint, model) pair rather than per chat, because it is a
     * property of what the pair can do: carrying it across a model switch would
     * mean a mode that silently changes meaning.
     */
    val powerMode: PowerMode = DefaultPowerMode,
    /**
     * What that pair actually accepts.
     *
     * Exposed to the UI so the picker can say "this endpoint has no power
     * settings" instead of offering rows that do nothing.
     */
    val powerCapabilities: EndpointCapabilities = EndpointCapabilities.None,
    /** The hand-tuned fields for this pair, if it has any. */
    val powerCustom: PowerConfig? = null
) {
    val isGenerating: Boolean get() = streaming != null

    /**
     * How full the model's context window is, or `null` when the meter is off.
     *
     * Derived here rather than carried through the state flow because every
     * input it needs is already in this object, and a stored copy would be one
     * more thing that can go stale by a message.
     *
     * Measured against the model's own window, falling back to a conservative
     * 8k when a provider does not declare one -- most local endpoints do not,
     * and pretending the window is unlimited would leave the meter at 0% right
     * up to the request that gets truncated.
     */
    val contextFill: Float?
        get() {
            if (!contextMeter) return null
            val window = provider?.models
                ?.firstOrNull { it.id == session?.model }
                ?.contextWindow
                ?: 0
            val budget = if (window > 0) window else FallbackWindow
            // Only what the next request will actually carry.
            //
            // The old version summed *every* message ever written in the chat,
            // which made the bar fill up in a handful of turns and then stay
            // full forever -- it kept counting text the compactor had already
            // folded away and the provider will never see again. Counting from
            // the last compaction summary onwards is the honest number: after a
            // fold the meter drops, which is exactly what happened to the
            // prompt.
            val lastFold = messages.indexOfLast { ContextCompactor.isSummary(it) }
            val live = if (lastFold >= 0) messages.drop(lastFold) else messages
            val chars = live.sumOf { it.content.length }
            // Calibrated per model from the token counts the provider reports,
            // because the shared 3.5-characters-per-token average is an English
            // one: on a Russian chat it showed roughly half the real fill.
            val charsPerToken = TokenCalibration.charsPerToken(session?.model)
            return (chars / charsPerToken / budget).coerceIn(0f, 1f)
        }
    val provider: ProviderConfig?
        get() = providers.firstOrNull { it.id == session?.providerId }
}

class ChatViewModel(
    private val container: AppContainer,
    private val sessionId: String
) : ViewModel() {

    private val _input = MutableStateFlow("")
    private val _attachments = MutableStateFlow<List<MessageAttachment>>(emptyList())
    private val _session = MutableStateFlow<ChatSession?>(null)
    private val _settingsOpen = MutableStateFlow(false)

    /**
     * The switch currently being written.
     *
     * Exists so [com.sirius.chat.core.designsystem.components.SiriusCheckToggle]
     * can show its spinner phase against real latency instead of a fabricated
     * delay. A DataStore write is usually too fast to see, and that is fine --
     * the spinner simply does not appear, which is the honest outcome.
     */
    private val _busyFeature = MutableStateFlow<ChatFeature?>(null)
    private val _project = MutableStateFlow<Project?>(null)

    /**
     * The answer in flight, owned by [com.sirius.chat.ai.agent.GenerationManager].
     *
     * The ViewModel is an observer here, not the owner. That is the whole point of
     * background generation: this object is destroyed when the user leaves the
     * chat, and the answer has to outlive it.
     */
    private val generations = container.generations
    private val _streaming = generations.stream(sessionId)

    /**
     * Local, screen-level error: the session row could not be read at all.
     *
     * Kept apart from the manager's failures because it is not a generation
     * failure — there is nothing to retry, and it must not be cleared by the next
     * successful answer in another session.
     */
    private val sessionMissing = MutableStateFlow<String?>(null)

    /**
     * A refused attachment.
     *
     * Kept apart from [sessionMissing] so that dismissing it does not clear a
     * generation failure, and surfaced through the same banner the user already
     * knows: a file that was silently not attached is the kind of thing noticed
     * only after the answer comes back wrong.
     */
    private val attachmentError = MutableStateFlow<String?>(null)

    private val _error = combine(
        generations.failure(sessionId),
        sessionMissing,
        attachmentError
    ) { failure, missing, attachment ->
        failure
            ?: missing?.let { GenerationFailure(it, retryable = false) }
            ?: attachment?.let { GenerationFailure(it, retryable = false) }
    }

    private data class CoreState(
        val session: ChatSession?,
        val project: Project?,
        val attachments: List<MessageAttachment>,
        val settingsOpen: Boolean
    )

    private val core = combine(
        _session, _project, _attachments, _settingsOpen
    ) { session, project, attachments, settingsOpen ->
        CoreState(session, project, attachments, settingsOpen)
    }

    /**
     * The composer's text, deliberately **not** part of [ChatUiState].
     *
     * ### Why this is its own flow
     * It used to live in the ui state, which meant every keystroke produced a new
     * `ChatUiState` instance. `ChatScreen` reads that state, so every keystroke
     * recomposed the whole screen -- top bar, transcript, every visible message
     * bubble -- and, because the transcript's item callbacks captured the state
     * object, the bubbles could not skip either. On a fast phone the headroom
     * hides it. On a Helio G88 it is dropped frames while typing.
     *
     * Exposed as a flow rather than a value so the *composer* collects it and
     * nothing above it has to. Compose recomposes whoever reads a state, so
     * moving the read down one level is the entire fix: typing now invalidates
     * one leaf instead of the screen.
     *
     * It stays in the ViewModel rather than becoming local composable state
     * because send, edit, slash-commands and draft persistence all need it, and a
     * composer that owned the text outright would have to hand it back up on
     * every change -- which is the problem again, one layer down.
     */
    val input: StateFlow<String> = _input.asStateFlow()

    private data class Extras(
        val failure: GenerationFailure?,
        val changes: List<PendingChange>,
        val question: AgentQuestion?,
        val settings: AppSettings,
        val busyFeature: ChatFeature?
    )

    // Folded into one flow because `combine` only has typed overloads up to five
    // sources and `state` already uses all five.
    private val extras = combine(
        _error,
        container.changeStore.changes,
        generations.questions,
        container.settingsRepository.settings,
        _busyFeature
    ) { error, changes, questions, settings, busy ->
        Extras(
            failure = error,
            changes = changes.filter { it.sessionId == sessionId },
            question = questions[sessionId],
            settings = settings,
            busyFeature = busy
        )
    }

    val state: StateFlow<ChatUiState> = combine(
        core,
        container.chatRepository.observeMessages(sessionId),
        container.providerRepository.observeProviders(),
        _streaming,
        extras
    ) { coreState, messages, providers, streaming, extra ->
        // Resolved once, here: the sheet and the request builder read the same
        // settings flow, which is what keeps the mode shown and the mode sent
        // from ever drifting apart.
        val powerSelection = extra.settings.powerSelection(
            coreState.session?.providerId.orEmpty(),
            coreState.session?.model.orEmpty()
        )
        ChatUiState(
            session = coreState.session,
            project = coreState.project,
            attachments = coreState.attachments,
            messages = messages,
            providers = providers,
            streaming = streaming,
            error = extra.failure?.message,
            retryable = extra.failure?.retryable ?: false,
            pendingChanges = extra.changes,
                question = extra.question,
            loading = false,
            settingsOpen = coreState.settingsOpen,
            // The session's stored switches, or the user's defaults when this
            // chat has never had them set. Deliberately *not* clamped here: the
            // panel needs the raw preference so it can show a suspended switch
            // differently from one the user turned off.
            features = coreState.session?.features ?: extra.settings.defaultChatFeatures(),
            // The chat's own choice, or the Settings default for a chat that has
            // never had one -- which is what makes the global switch a default
            // for new conversations rather than a retroactive override.
            contextMeter = coreState.session?.contextMeter
                ?: extra.settings.showContextMeter,
            // Same rule as the meter: the chat's own choice, or the Settings
            // default for a chat that has never made one.
            memory = coreState.session?.memory ?: extra.settings.memoryEnabled,
            featureSupport = ModelCapabilities.of(
                providers.firstOrNull { it.id == coreState.session?.providerId },
                coreState.session?.model.orEmpty()
            ),
            busyFeature = extra.busyFeature,
            powerMode = powerSelection.mode,
            powerCustom = powerSelection.custom,
            // Narrowed by what this model has already refused, so an endpoint
            // that turns out to ignore every knob reports that honestly instead
            // of offering settings that cost a turn each.
            powerCapabilities = EndpointCapabilityTable.effective(
                providers.firstOrNull { it.id == coreState.session?.providerId },
                coreState.session?.model.orEmpty()
            )
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ChatUiState())

    val streamingState: StateFlow<StreamingAnswer?> =
        _streaming.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /**
     * Code in a chat answer is the same kind of text as code in the editor, so it
     * follows the same size preference instead of a hardcoded 13sp that ignored the
     * setting entirely.
     */
    val codeFontSize: StateFlow<Int> = container.settingsRepository.settings
        .map { it.editorFontSize }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 14)

    init {
        viewModelScope.launch {
            val session = container.chatRepository.getSession(sessionId)
            _session.value = session
            _input.value = container.chatRepository.draft(sessionId)
            val projectId = session?.projectId ?: return@launch
            // A folder can be attached to the project while this chat is open, so
            // keep following it instead of caching one snapshot.
            container.projectRepository.observeProjects()
                .map { projects -> projects.firstOrNull { it.id == projectId } }
                .distinctUntilChanged()
                .collect { _project.value = it }
        }
    }

    // --------------------------------------------------------------- input

    /**
     * New composer text, plus where the caret ended up.
     *
     * The caret is tracked because it is where the next attachment is anchored, and
     * anchors of existing attachments are shifted by whatever this edit did to the
     * text. Without the shift, typing a sentence in front of an attached image
     * would leave the image anchored mid-word and the model would be handed a
     * request whose block order no longer matches what the user sees.
     */
    fun onInputChange(value: String, caret: Int = value.length) {
        val previous = _input.value
        _input.value = value
        _caret.value = caret.coerceIn(0, value.length)
        if (previous != value && _attachments.value.isNotEmpty()) {
            shiftAnchors(previous, value)
        }
    }

    /** Where the caret is, so an attachment lands where the user is typing. */
    private val _caret = MutableStateFlow(0)

    /**
     * Moves anchors that sit after an edit.
     *
     * The edit is located by the longest common prefix and suffix, which is enough
     * for everything a soft keyboard does: typing, deleting, and pasting all
     * produce one contiguous replacement. Anchors inside the replaced range are
     * clamped to its start, because that text is gone.
     */
    private fun shiftAnchors(before: String, after: String) {
        var prefix = 0
        while (prefix < before.length && prefix < after.length && before[prefix] == after[prefix]) {
            prefix++
        }
        var suffix = 0
        while (
            suffix < before.length - prefix &&
            suffix < after.length - prefix &&
            before[before.length - 1 - suffix] == after[after.length - 1 - suffix]
        ) {
            suffix++
        }
        val removedEnd = before.length - suffix
        val delta = after.length - before.length
        _attachments.value = _attachments.value.map { attachment ->
            when {
                attachment.anchor <= prefix -> attachment
                attachment.anchor >= removedEnd ->
                    attachment.copy(anchor = (attachment.anchor + delta).coerceIn(0, after.length))
                // The anchor was inside the text that was just replaced.
                else -> attachment.copy(anchor = prefix)
            }
        }
    }

    /**
     * Saves whatever is in the composer as this chat's draft.
     *
     * Written unconditionally, including when empty. The screen used to skip the
     * call for blank text, which meant clearing the composer and leaving never
     * cleared the stored draft -- so the old text reappeared on the next visit.
     * An empty write is the correct way to say "there is no draft".
     */
    fun persistDraft() {
        val draft = _input.value
        viewModelScope.launch { container.chatRepository.saveDraft(sessionId, draft) }
    }

    // ---------------------------------------------------------- attachments

    private val _attachmentQuery = MutableStateFlow("")
    val attachmentQuery: StateFlow<String> = _attachmentQuery.asStateFlow()

    private val _attachmentResults = MutableStateFlow<List<FileNode>>(emptyList())
    val attachmentResults: StateFlow<List<FileNode>> = _attachmentResults.asStateFlow()

    private var searchJob: Job? = null

    /** Debounced workspace search powering the attachment sheet. */
    fun searchAttachments(query: String) {
        _attachmentQuery.value = query
        val tree = _project.value?.treeUri
        searchJob?.cancel()
        if (tree == null) {
            _attachmentResults.value = emptyList()
            return
        }
        searchJob = viewModelScope.launch {
            kotlinx.coroutines.delay(220)
            _attachmentResults.value = if (query.isBlank()) {
                val root = container.workspaceRepository.rootNode(tree)
                if (root == null) emptyList()
                else container.workspaceRepository
                    .listChildren(tree, root.documentId, "")
                    .filterNot { it.isDirectory }
                    .take(30)
            } else {
                container.workspaceRepository.searchFiles(tree, query, limit = 40)
            }
        }
    }

    fun attach(node: FileNode) {
        if (_attachments.value.any { it.uri == node.documentId }) return
        if (rejectIfFull()) return
        _attachments.value = _attachments.value + MessageAttachment(
            id = UUID.randomUUID().toString(),
            name = node.name,
            uri = node.documentId,
            sizeBytes = node.sizeBytes,
            kind = AttachmentKind.WorkspaceFile,
            anchor = _caret.value
        )
    }

    /**
     * Attaches files picked from the device.
     *
     * Rejections are reported per file rather than as one silent failure: picking
     * five files where one is a 40 MB archive should attach four and say which one
     * was refused and why.
     */
    fun attachFiles(uris: List<String>) {
        viewModelScope.launch {
            uris.forEach { raw ->
                if (rejectIfFull()) return@launch
                val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return@forEach
                // Long-lived read access: without this the uri stops working as soon
                // as the process dies, and re-generating an old message would lose
                // its attachments.
                runCatching {
                    container.appContext.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                val described = container.attachmentReader.describe(uri, _caret.value)
                if (described == null) {
                    attachmentError.value =
                        container.strings.get(R.string.chat_attachment_unreadable)
                    return@forEach
                }
                if (described.sizeBytes > AttachmentReader.MAX_FILE_BYTES) {
                    attachmentError.value = container.strings.get(
                        R.string.chat_attachment_too_large,
                        described.name,
                        Formatters.fileSize(AttachmentReader.MAX_FILE_BYTES)
                    )
                    return@forEach
                }
                if (_attachments.value.any { it.uri == described.uri }) return@forEach
                _attachments.value = _attachments.value + described
            }
        }
    }

    /** True when the message already holds as many attachments as it may. */
    private fun rejectIfFull(): Boolean {
        if (_attachments.value.size < AttachmentReader.MAX_ATTACHMENTS) return false
        attachmentError.value = container.strings.get(
            R.string.chat_attachment_too_many,
            AttachmentReader.MAX_ATTACHMENTS
        )
        return true
    }

    fun removeAttachment(id: String) {
        _attachments.value = _attachments.value.filterNot { it.id == id }
    }

    fun dismissError() {
        generations.clearFailure(sessionId)
        sessionMissing.value = null
        attachmentError.value = null
    }

    /**
     * Answers a pending `ask_user` question and lets the suspended run continue.
     *
     * An empty [answer] is forwarded as-is rather than ignored: skipping is a
     * valid response that tells the agent to decide for itself, and dropping it
     * would leave the run suspended with no sheet on screen to resume it.
     */
    fun answerQuestion(answer: String) {
        val pending = state.value.question ?: return
        generations.answerQuestion(sessionId, pending.id, answer.trim())
    }

    // ------------------------------------------------- chat settings panel

    fun openSettings() {
        _settingsOpen.value = true
    }

    fun closeSettings() {
        _settingsOpen.value = false
    }

    /**
     * Flips one switch for this conversation.
     *
     * ### Why this writes to the session and not to AppSettings
     * The switches belong to the chat, so this is the write that makes a
     * conversation reproducible: reopening it next month restores the world that
     * produced its answers. Writing to the global settings instead would
     * retroactively change what every other chat claims to have done.
     *
     * ### Why the first flip materialises all five flags
     * A session that has never been touched stores the "inherit" sentinel. The
     * moment the user sets *one* switch, the whole set is frozen from whatever
     * was in effect at that moment -- because from then on this chat has an
     * opinion, and a later change to the user's defaults must not silently move
     * the other four out from under it. `state.value.features` is already the
     * resolved set, so this falls out of using it as the base.
     */
    fun toggleFeature(feature: ChatFeature, enabled: Boolean) {
        val session = _session.value ?: return
        val current = state.value
        // An unsupported switch is not clickable in the panel, but the check is
        // repeated here because the ViewModel is the thing that must not persist
        // an impossible state -- the UI is one caller, not the contract.
        if (!current.featureSupport[feature].usable) return

        val updated = session.copy(features = current.features.with(feature, enabled))
        // Optimistic: the switch animates immediately and the write follows. The
        // toggle's own spinner covers the gap, and a failed write leaves the
        // in-memory session correct until the screen is recreated -- which is a
        // better outcome than a switch that visibly refuses to move.
        _session.value = updated
        _busyFeature.value = feature
        viewModelScope.launch {
            try {
                container.chatRepository.updateSession(updated)
            } finally {
                // `finally`, so a failed write cannot strand the spinner on
                // forever.
                _busyFeature.value = null
            }
        }
    }

    /**
     * Turns the meter off for this chat alone.
     *
     * Writes a concrete value instead of clearing back to inherit, which is the
     * point of a per-chat switch: it has to survive someone changing the global
     * default later.
     */
    fun setContextMeter(enabled: Boolean) {
        val session = _session.value ?: return
        val updated = session.copy(contextMeter = enabled)
        _session.value = updated
        viewModelScope.launch { container.chatRepository.updateSession(updated) }
    }

    /**
     * Turns memory off for this chat alone.
     *
     * Stores a concrete value rather than clearing to inherit, for the same
     * reason as the meter above: the choice has to survive someone changing the
     * global default later. New facts keep being recorded either way -- this
     * only decides whether the model is told what is already known.
     */
    fun setMemory(enabled: Boolean) {
        val session = _session.value ?: return
        val updated = session.copy(memory = enabled)
        _session.value = updated
        viewModelScope.launch { container.chatRepository.updateSession(updated) }
    }

    fun selectModel(providerId: String, model: String) {
        val session = _session.value ?: return
        val updated = session.copy(providerId = providerId, model = model)
        _session.value = updated
        viewModelScope.launch {
            container.chatRepository.updateSession(updated)
            container.settingsRepository.update { it.copy(activeProviderId = providerId, activeModel = model) }
        }
    }

    /**
     * Records the power mode for this chat's (endpoint, model) pair.
     *
     * ### Why the model is left alone
     * The obvious shortcut for "more power" is a bigger model, and it is the
     * wrong one: the user picked this model, and swapping it would change the
     * answer's voice, its price and its abilities to satisfy a request that was
     * only about effort. If a mode cannot be honoured here, the sheet says so
     * and the model stays exactly where it was put.
     *
     * Only the mode is written. The stored CUSTOM fields survive untouched, so
     * stepping through the presets and back does not erase them.
     */
    fun selectPowerMode(mode: PowerMode) {
        val session = _session.value ?: return
        val pair = session.providerId to session.model
        viewModelScope.launch {
            container.settingsRepository.update {
                it.copy(powerModes = it.powerModes + (pair to mode))
            }
        }
    }

    /**
     * Saves hand-tuned fields and switches this pair to CUSTOM.
     *
     * Both in one write: a saved config that did not select itself would look
     * like the save had failed.
     */
    fun saveCustomPower(config: PowerConfig) {
        val session = _session.value ?: return
        val pair = session.providerId to session.model
        viewModelScope.launch {
            container.settingsRepository.update {
                it.copy(
                    powerModes = it.powerModes + (pair to PowerMode.CUSTOM),
                    // An all-empty config is dropped rather than stored: the
                    // encoder already refuses to write one, so keeping it in
                    // memory made CUSTOM look configured until the next launch
                    // and then quietly stop being so.
                    powerCustom = if (config.isNoOp) {
                        it.powerCustom - pair
                    } else {
                        it.powerCustom + (pair to config)
                    }
                )
            }
        }
    }

    /**
     * Asks the same question again on a different model, in its own chat.
     *
     * ### Why a branch and not a second bubble
     * Two answers cannot share one conversation. Whatever is in the history is
     * what the next request contains, so an alternative answer appended below the
     * first would become part of the prompt -- the second model would be reacting
     * to the first one instead of answering the question. Copying the history up
     * to the question into a new chat is the only shape where both models are
     * asked the same thing.
     *
     * The original is left untouched, which is the point: regenerate replaces an
     * answer, this keeps it, and the two chats can be compared by stepping back
     * and forth between them.
     *
     * The branch inherits the feature switches and the context meter, because a
     * comparison where one side had web search and the other did not is not a
     * comparison of models.
     */
    fun forkOnModel(
        messageId: String,
        providerId: String,
        model: String,
        onOpen: (String) -> Unit
    ) {
        val session = _session.value ?: return
        viewModelScope.launch {
            val history = container.chatRepository.messages(sessionId)
            val index = history.indexOfFirst { it.id == messageId }
            // Everything before the forked answer ends with the question that
            // produced it. An answer with nothing in front of it cannot be
            // re-asked, so there is nothing to branch.
            val prefix = if (index <= 0) emptyList() else history.take(index)
            if (prefix.isEmpty()) return@launch

            val branchId = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            container.chatRepository.createSession(
                ChatSession(
                    id = branchId,
                    title = container.strings.get(R.string.chat_fork_title, session.title, model),
                    projectId = session.projectId,
                    providerId = providerId,
                    model = model,
                    agentMode = session.agentMode,
                    createdAt = now,
                    updatedAt = now,
                    features = session.features,
                    contextMeter = session.contextMeter,
                    memory = session.memory
                )
            )
            // Fresh ids: a message belongs to one chat, and reusing ids would make
            // deleting a message in the branch delete it from the original too.
            prefix.forEach { message ->
                container.chatRepository.addMessage(
                    message.copy(id = UUID.randomUUID().toString(), sessionId = branchId)
                )
            }
            generations.start(branchId)
            onOpen(branchId)
        }
    }

    // ------------------------------------------------------------ generate

    /**
     * The user message being edited, if any.
     *
     * Editing happens in the composer rather than in a dialog: the message can
     * carry attachments, and a dialog with a bare text field would either hide
     * them or have to reimplement the whole composer.
     */
    private val _editingMessageId = MutableStateFlow<String?>(null)
    val editingMessageId: StateFlow<String?> = _editingMessageId.asStateFlow()

    /** Loads a user message back into the composer for editing. */
    fun beginEdit(message: ChatMessage) {
        if (generations.isRunning(sessionId)) return
        _editingMessageId.value = message.id
        _input.value = message.content
        _caret.value = message.content.length
        _attachments.value = message.attachments
    }

    fun cancelEdit() {
        _editingMessageId.value = null
        _input.value = ""
        _attachments.value = emptyList()
        _caret.value = 0
    }

    fun send() {
        val text = _input.value.trim()
        val attachments = _attachments.value
        if (text.isEmpty() && attachments.isEmpty()) return
        if (generations.isRunning(sessionId)) return

        // An edit replaces the message and re-runs the conversation from there,
        // rather than appending a second copy of the question.
        _editingMessageId.value?.let { editedId ->
            _editingMessageId.value = null
            _input.value = ""
            _attachments.value = emptyList()
            _caret.value = 0
            editAndResend(editedId, text, attachments)
            return
        }

        _input.value = ""
        _attachments.value = emptyList()
        generations.clearFailure(sessionId)

        viewModelScope.launch {
            val session = _session.value
                ?: container.chatRepository.getSession(sessionId)?.also { _session.value = it }
            if (session == null) {
                // Never swallow what the user typed if the session is not there yet.
                _input.value = text
                _attachments.value = attachments
                sessionMissing.value = container.strings.get(R.string.chat_error_session_missing)
                return@launch
            }
            val message = ChatMessage(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                role = MessageRole.User,
                content = text,
                createdAt = System.currentTimeMillis(),
                attachments = attachments
            )
            container.chatRepository.addMessage(message)
            container.chatRepository.saveDraft(sessionId, "")

            // Memory is written the moment something is said, not when the turn
            // finishes. A fact that waits for the answer is a fact lost to a
            // failed request, a cancelled generation or someone who closes the
            // app after typing -- and "я люблю мороженое" is exactly the kind of
            // aside that gets typed and abandoned.
            //
            // On appScope so leaving the chat cannot cancel it. The pass that
            // still runs after the answer costs nothing when this one already
            // handled the turn: both are keyed on the same user message.
            container.appScope.launch {
                runCatching { container.memoryExtractor.learn(sessionId) }
            }

            // The chat is no longer named from the message.
            //
            // It used to be: shorten what the user typed, write that into the
            // title. That is exactly the row people complain about -- “Как дела?
            // ты любишь м…” is the message with a capital letter, not a name.
            // Naming belongs to the titler alone now: it asks the model what the
            // conversation is *about*, and a chat that is only a greeting is
            // named “Приветствие” without asking anyone. Until an answer
            // comes back the chat stays “Новый чат”, which is at least honest.

            //
            // This runs on every turn while the name is still the app's own
            // guess, not only while it is the placeholder. Asking once was the
            // bug: the heuristic renamed the chat immediately, the placeholder
            // check could never be true again, and a single slow or failed
            // request left the conversation named after the first 48 characters
            // of its opening message for good.
            //
            // On appScope, not viewModelScope: leaving the chat right after
            // sending is the common case, and this has to survive it. The titler
            // re-reads the session before writing, so a rename in the meantime
            // still wins.
            if (session.titleAuto) {
                container.appScope.launch {
                    val generated = container.sessionTitler.retitle(sessionId, text)
                    if (generated != null) {
                        _session.update { current ->
                            if (current?.id == sessionId) {
                                current.copy(title = generated)
                            } else {
                                current
                            }
                        }
                    }
                }
            }
            generate()
        }
    }

    fun stop() = generations.stop(sessionId)

    fun regenerate() {
        viewModelScope.launch {
            val history = container.chatRepository.messages(sessionId)
            val lastAssistant = history.lastOrNull { it.role == MessageRole.Assistant } ?: return@launch
            container.rewindConversation(sessionId, lastAssistant.id)
            generate()
        }
    }

    /** Asks the model to keep going from where it stopped. */
    fun continueGeneration() {
        viewModelScope.launch {
            container.chatRepository.addMessage(
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    sessionId = sessionId,
                    role = MessageRole.User,
                    content = container.strings.get(R.string.chat_continue_prompt),
                    createdAt = System.currentTimeMillis()
                )
            )
            generate()
        }
    }

    fun retry() {
        generations.clearFailure(sessionId)
        generate()
    }

    /**
     * Edits a user message and re-runs the conversation from that point.
     *
     * [attachments] is null when the caller only changed text, so a rename of this
     * behaviour cannot accidentally strip files off an edited message.
     */
    fun editAndResend(
        messageId: String,
        newText: String,
        attachments: List<MessageAttachment>? = null
    ) {
        viewModelScope.launch {
            val history = container.chatRepository.messages(sessionId)
            val target = history.firstOrNull { it.id == messageId } ?: return@launch
            // Everything after the edited message described a different question and
            // is dropped, which is what every other chat app does here.
            container.rewindConversation(sessionId, messageId)
            container.chatRepository.addMessage(
                target.copy(
                    id = UUID.randomUUID().toString(),
                    content = newText,
                    createdAt = System.currentTimeMillis(),
                    attachments = attachments ?: target.attachments
                )
            )
            generate()
        }
    }

    /**
     * Re-runs one specific answer.
     *
     * Rewinding to the assistant message drops it and everything after it, so the
     * request the model sees is exactly the one that produced it — regenerating a
     * reply from the middle of a conversation cannot leave later turns dangling
     * after an answer that no longer exists.
     */
    fun regenerate(messageId: String) {
        viewModelScope.launch {
            container.rewindConversation(sessionId, messageId)
            generate()
        }
    }

    /**
     * Deletes a message.
     *
     * [withFollowing] deletes the rest of the conversation too. Deleting a message
     * from the middle on its own is allowed — sometimes that is exactly what is
     * wanted — but the caller has to have asked the user first, because the
     * remaining history then reads as an answer to a question nobody asked.
     */
    fun deleteMessage(messageId: String, withFollowing: Boolean = false) {
        viewModelScope.launch {
            if (withFollowing) {
                container.rewindConversation(sessionId, messageId)
            } else {
                container.chatRepository.deleteMessage(messageId)
            }
            if (_editingMessageId.value == messageId) cancelEdit()
        }
    }

    /**
     * Deletes a hand-picked set of messages.
     *
     * Nothing is rewound. Multi-select is used to clear a few specific turns out
     * of a conversation that carries on afterwards, so taking every later
     * message with them would be the opposite of what was asked -- that is what
     * [deleteMessage] with `withFollowing` is for. Oldest first, so the
     * transcript never briefly reads as an answer to a question that is already
     * gone.
     */
    fun deleteMessages(messageIds: Set<String>) {
        if (messageIds.isEmpty()) return
        viewModelScope.launch {
            val ordered = container.chatRepository.messages(sessionId)
                .filter { it.id in messageIds }
                .map { it.id }
            val targets = if (ordered.isEmpty()) messageIds.toList() else ordered
            targets.forEach { container.chatRepository.deleteMessage(it) }
            val editing = _editingMessageId.value
            if (editing != null && editing in messageIds) cancelEdit()
        }
    }


    /**
     * Hands the session to the generation manager.
     *
     * Everything that used to live here — prompt assembly, the agent loop, event
     * handling, persistence — moved to `GenerationManager` so it keeps running with
     * the chat closed. What is left is a request.
     */
    private fun generate() {
        // The foreground service is what keeps the process alive while the model
        // talks. Without it Android is free to kill the app the moment the user
        // leaves, which is exactly the case background generation is for.
        // Started before the generation, not after: if the user backgrounds the app
        // in that gap the process is already protected.
        GenerationService.ensureRunning(container.appContext)
        generations.start(sessionId)
    }

    override fun onCleared() {
        super.onCleared()
        // Nothing to cancel: the generation does not belong to this screen. Only
        // the draft is flushed, so reopening the chat finds what was typed.
        val draft = _input.value
        container.appScope.launch { container.chatRepository.saveDraft(sessionId, draft) }
    }
}

/**
 * Assumed window when a provider declares none.
 *
 * Was 8 192, and that single number was the whole "meter fills after two
 * messages" bug: a custom endpoint or a model missing from the preset list
 * declares no window, so a couple of long answers plus one attached file filled
 * a fictional 8k window while the real model had 128k or more free. Modern
 * endpoints -- including the local ones, which are the main reason this fallback
 * exists -- are 128k class, so the guess now errs on the side of not nagging.
 * The compactor still uses its own conservative budget for the actual prompt, so
 * a generous guess here can only under-report, never truncate a request.
 */
private const val FallbackWindow = 131_072
