package com.sirius.chat.feature.chat.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.domain.model.PowerMode

/**
 * Four rising bars that say how hard the model is being asked to work.
 *
 * ### Why bars and not the name alone
 * "MEDIUM" is a word that has to be read and compared against four other words
 * before it means anything. A filled-in ladder is ordinal at a glance: two of
 * four is visibly less than three of four, without reading at all. The name is
 * still shown next to it -- the bars are the fast answer, not the only one.
 *
 * ### Why CUSTOM is not a fifth step
 * A hand-made config has no place on the ladder: it can be lower than LOW or
 * higher than MAX, and guessing a rung would misreport it. So CUSTOM lights
 * every bar in the neutral ink instead of the accent, which reads as "set by
 * hand" rather than "stronger than MAX".
 */
@Composable
fun PowerLevelBars(
    mode: PowerMode,
    modifier: Modifier = Modifier,
    /** False greys the ladder out, for an endpoint with nothing to configure. */
    active: Boolean = true,
    /**
     * Whether a CUSTOM config has any fields at all.
     *
     * Four filled bars over a request that carries no power field is the one
     * thing this control must never show, and an unsaved CUSTOM is exactly that:
     * selected, ranked at the top of the ladder, sending nothing.
     */
    configured: Boolean = true,
    /** Height of the tallest bar; the rest are proportional. */
    height: Dp = 14.dp
) {
    val colors = SiriusTheme.colors
    val level = if (mode == PowerMode.CUSTOM && !configured) 0 else powerLevel(mode)
    val custom = mode == PowerMode.CUSTOM
    val tint = when {
        !active -> colors.textTertiary
        custom -> colors.textSecondary
        else -> colors.primary
    }
    val shape = RoundedCornerShape(2.dp)
    Row(
        // Decorative: every place this appears also prints the mode name, and a
        // screen reader announcing "two of four bars" next to "Medium" is noise.
        modifier = modifier.clearAndSetSemantics {},
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        repeat(BAR_COUNT) { index ->
            val step = (index + 1).toFloat() / BAR_COUNT
            val lit = index < level
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(height * (0.42f + 0.58f * step))
                    .clip(shape)
                    .then(
                        if (lit) {
                            Modifier.background(tint, shape)
                        } else {
                            // An unlit bar is drawn, not omitted: the empty rungs
                            // are what make "two of four" readable as a fraction.
                            Modifier.border(1.dp, colors.outline, shape)
                        }
                    )
            )
        }
    }
}

/**
 * The composer's power control: the ladder, the mode name, one tap to change it.
 *
 * Sits next to the model pill because the choice is stored against this exact
 * (endpoint, model) pair -- it changes when the model changes, so hiding it two
 * sheets deep would mean the number on screen and the number being sent could
 * differ with nothing on screen to say so.
 */
@Composable
fun PowerPill(
    mode: PowerMode,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = true
) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.pill)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = siriusSpring(),
        label = "powerPillPress"
    )
    Row(
        modifier = modifier
            // Click node above the press-scale, or the outer few pixels of the
            // pill stop responding while it is shrinking.
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClickLabel = stringResource(R.string.chat_power_title),
                onClick = onClick
            )
            .scale(scale)
            .clip(shape)
            .softSurface(shape)
            .heightIn(min = 40.dp)
            .padding(horizontal = SiriusSpacing.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
    ) {
        PowerLevelBars(mode = mode, active = active, height = 12.dp)
        Text(
            text = stringResource(powerLabelRes(mode)),
            style = MaterialTheme.typography.labelLarge,
            color = if (active) colors.textSecondary else colors.textTertiary,
            maxLines = 1
        )
    }
}

/** How many rungs are lit. CUSTOM lights them all in a different ink instead. */
private fun powerLevel(mode: PowerMode): Int = when (mode) {
    PowerMode.LOW -> 1
    PowerMode.MEDIUM -> 2
    PowerMode.HIGH -> 3
    PowerMode.MAX -> 4
    PowerMode.CUSTOM -> 4
}

private const val BAR_COUNT = 4
