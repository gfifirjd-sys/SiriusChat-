package com.sirius.chat.ai.provider

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.ProbeVerdict
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import com.sirius.chat.domain.model.VisionSupport
import com.sirius.chat.domain.model.requiresApiKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** What asking an endpoint for its catalogue produced. */
sealed interface ProbeResult {
    /**
     * The endpoint answered. [models] can still be empty: some gateways accept
     * the key and expose no listing, which is a working key all the same.
     */
    data class Ok(val models: List<AiModel>) : ProbeResult

    data class Failure(val error: AiError) : ProbeResult
}

/**
 * Asks an endpoint who it is and what it serves, without generating anything.
 *
 * `GET /models` is the cheapest question in both protocols: it is free, it
 * returns instantly, and it fails loudly on a bad key or a wrong base URL. That
 * is why the screen checks a connection this way instead of sending a throwaway
 * "hi" and burning tokens to learn the same thing.
 */
class ProviderProbe(private val client: OkHttpClient = HttpClientProvider.client) {

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun listModels(config: ProviderConfig, apiKey: String?): ProbeResult =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(config.baseUrl.trim().trimEnd('/') + "/models")
                .get()
                .apply {
                    header("Accept", "application/json")
                    if (!apiKey.isNullOrBlank()) {
                        // Anthropic authenticates on its own header and refuses a
                        // request without a version pin.
                        if (config.type == ProviderType.AnthropicCompatible) {
                            header("x-api-key", apiKey)
                            header("anthropic-version", ANTHROPIC_MODELS_VERSION)
                        } else {
                            header("Authorization", "Bearer $apiKey")
                        }
                    } else if (config.type == ProviderType.AnthropicCompatible) {
                        header("anthropic-version", ANTHROPIC_MODELS_VERSION)
                    }
                }
                .build()

            val response = runCatching { client.newCall(request).execute() }
                .getOrElse { return@withContext ProbeResult.Failure(it.toAiError()) }

            response.use { httpResponse ->
                val body = runCatching { httpResponse.body?.string() }.getOrNull().orEmpty()
                if (!httpResponse.isSuccessful) {
                    return@withContext ProbeResult.Failure(httpError(httpResponse.code, body))
                }
                val models = runCatching { parse(body) }.getOrElse {
                    return@withContext ProbeResult.Failure(
                        AiError(
                            AiError.Kind.Server,
                            AppStrings.get(
                                R.string.providers_probe_unreadable,
                                fallback = "The endpoint answered with a catalogue this app could not read."
                            )
                        )
                    )
                }
                ProbeResult.Ok(models)
            }
        }

    /**
     * Both protocols answer with `{ "data": [ { "id": ... } ] }`, and a few
     * OpenAI-compatible gateways answer with a bare array instead. Anything with
     * an id is kept; ids are what a request actually needs.
     */
    private fun parse(body: String): List<AiModel> {
        val root = json.parseToJsonElement(body)
        val array = when {
            root is kotlinx.serialization.json.JsonArray -> root
            else -> root.jsonObject["data"]?.jsonArray
                ?: root.jsonObject["models"]?.jsonArray
                ?: return emptyList()
        }
        return array.mapNotNull { element ->
            val entry = element.jsonObject
            val id = entry["id"]?.jsonPrimitive?.contentOrNull
                ?: entry["name"]?.jsonPrimitive?.contentOrNull
                ?: return@mapNotNull null
            if (id.isBlank()) return@mapNotNull null
            val label = entry["display_name"]?.jsonPrimitive?.contentOrNull
                ?: entry["name"]?.jsonPrimitive?.contentOrNull?.takeIf { it != id }
            val context = entry["context_length"]?.jsonPrimitive?.intOrNull
                ?: entry["max_context_length"]?.jsonPrimitive?.intOrNull
                ?: 0
            AiModel(id = id, label = label?.takeIf { it.isNotBlank() } ?: id, contextWindow = context)
        }
            .distinctBy { it.id }
            .sortedBy { it.id.lowercase() }
    }

    /**
     * Asks the model itself whether it can read an image, by sending it one.
     *
     * ### Why a request and not a name check
     * [com.sirius.chat.ai.capability.ModelCapabilities] infers vision from the
     * model id, and that inference is permanently behind: it knows the naming
     * conventions that existed when the build was cut, so a model released next
     * month reads as blind, and a user with a working vision model is told their
     * app cannot see. There is no list that fixes this -- the model catalogue is
     * not ours, users point providers at arbitrary gateways and rename them.
     *
     * One request settles it for good. The payload is a 1x1 transparent PNG (68
     * bytes) with `max_tokens = 1`, so the cost is a rounding error on any
     * provider that bills per token, and the answer is stored on the model rather
     * than asked again per chat.
     *
     * ### How the answer is read
     * A success means the endpoint accepted an image block, which is exactly the
     * thing we needed to know -- what the model *says* about a blank pixel is
     * irrelevant and is not looked at.
     *
     * A refusal only counts when the endpoint says it is about the image. A 400
     * can equally mean an unsupported `max_tokens`, a gateway rewriting the body,
     * or a model name that needs a prefix; treating all of those as "no vision"
     * would disable the switch for working models, which is the bug this is meant
     * to remove. Anything unrecognised, and every auth, rate-limit, timeout and
     * 5xx, returns [VisionSupport.Unknown] so the id heuristic stays in charge.
     *
     * @return what was learned, never a guess dressed as a fact.
     */
    suspend fun probeVision(
        config: ProviderConfig,
        apiKey: String?,
        modelId: String
    ): VisionSupport {
        // Saving a provider twice used to re-run every probe from scratch, and
        // each one may wait up to twenty seconds on a slow endpoint. What a probe
        // learns is a property of the endpoint, not of the moment it was asked,
        // so the answer is kept and the second Save returns it for free.
        val key = cacheKey(config, modelId, "vision")
        visionCache.fresh(key)?.let { return it }
        val verdict = measureVision(config, apiKey, modelId)
        visionCache.store(key, verdict, settled = verdict != VisionSupport.Unknown)
        return verdict
    }

    private suspend fun measureVision(
        config: ProviderConfig,
        apiKey: String?,
        modelId: String
    ): VisionSupport = withContext(Dispatchers.IO) {
        if (modelId.isBlank()) return@withContext VisionSupport.Unknown
        // No key, no probe: an unauthenticated 401 says nothing about vision, and
        // spending a request to learn nothing is worse than not asking. A local
        // server is the exception -- it never wanted a key, and it is exactly
        // where the id heuristic is most often wrong, because those model names
        // are whatever the person who quantised the file decided to type.
        if (apiKey.isNullOrBlank() && config.requiresApiKey) {
            return@withContext VisionSupport.Unknown
        }
        if (config.type == ProviderType.Custom) return@withContext VisionSupport.Unknown
        // A key that cannot be encoded as a header would throw while the probe
        // request is being built, where the caller expects a verdict.
        if (apiKey != null && !apiKey.isHeaderSafe()) return@withContext VisionSupport.Unknown

        val anthropic = config.type == ProviderType.AnthropicCompatible
        val base = config.baseUrl.trim().trimEnd('/')
        val url = base + if (anthropic) "/messages" else "/chat/completions"
        val request = Request.Builder()
            .url(url)
            .post(visionBody(anthropic, modelId).toRequestBody(JSON_MEDIA))
            .apply {
                header("Accept", "application/json")
                if (anthropic) {
                    header("anthropic-version", ANTHROPIC_MODELS_VERSION)
                    if (!apiKey.isNullOrBlank()) header("x-api-key", apiKey)
                } else if (!apiKey.isNullOrBlank()) {
                    // Never "Bearer null": a keyless local server answers a bare
                    // request, and a junk header is how you turn that into a 401.
                    header("Authorization", "Bearer " + apiKey)
                }
            }
            .build()

        val response = runCatching { probeClient.newCall(request).execute() }
            .getOrElse { return@withContext VisionSupport.Unknown }

        response.use { httpResponse ->
            if (httpResponse.isSuccessful) return@withContext VisionSupport.Supported
            val body = runCatching { httpResponse.body?.string() }
                .getOrNull().orEmpty().lowercase()
            val refusedTheImage = REJECTION_MARKERS.any { body.contains(it) }
            when {
                // 4xx that names the image is the endpoint telling us plainly.
                httpResponse.code in 400..422 && refusedTheImage -> VisionSupport.Unsupported
                else -> VisionSupport.Unknown
            }
        }
    }

    /**
     * Asks the endpoint whether it accepts tool definitions, by sending it one.
     *
     * The answer is recorded but weak by design, and the reason is in
     * [com.sirius.chat.ai.capability.ModelCapabilities.tools]: the agent speaks
     * in fenced text blocks, so `tools` being refused does not stop a single
     * Sirius tool from running. What this fixes is the opposite error -- a preset
     * or a heuristic claiming "no functions" for a model that plainly has them.
     */
    suspend fun probeTools(
        config: ProviderConfig,
        apiKey: String?,
        modelId: String
    ): ProbeVerdict =
        capabilityProbe(config, apiKey, modelId, tools = true, stream = false, markers = TOOL_MARKERS)

    /**
     * Asks the endpoint whether it can stream, by asking it to.
     *
     * ### Why a 200 is not the answer
     * A gateway that does not implement streaming has two ways to say so, and
     * only one of them is an error: it can 400, or it can quietly ignore the flag
     * and return one whole JSON object with a cheerful 200. Reading that 200 as
     * "streaming works" is the same false positive this whole mechanism exists to
     * remove, so the body has to actually look like server-sent events before the
     * answer counts as yes.
     */
    suspend fun probeStreaming(
        config: ProviderConfig,
        apiKey: String?,
        modelId: String
    ): ProbeVerdict =
        capabilityProbe(config, apiKey, modelId, tools = false, stream = true, markers = STREAM_MARKERS)

    /**
     * One request, one capability, same reading rules as [probeVision].
     *
     * A 4xx only counts as a refusal when the body names the thing we added to
     * the request; everything else -- auth, rate limits, timeouts, 5xx, a gateway
     * rewriting the body -- returns [ProbeVerdict.Unknown] so the declared
     * defaults stay in charge. Guessing wrong here disables a working feature,
     * which is worse than not knowing.
     */
    private suspend fun capabilityProbe(
        config: ProviderConfig,
        apiKey: String?,
        modelId: String,
        tools: Boolean,
        stream: Boolean,
        markers: List<String>
    ): ProbeVerdict {
        val key = cacheKey(config, modelId, if (tools) "tools" else "stream")
        capabilityCache.fresh(key)?.let { return it }
        val verdict = measureCapability(config, apiKey, modelId, tools, stream, markers)
        capabilityCache.store(key, verdict, settled = verdict != ProbeVerdict.Unknown)
        return verdict
    }

    private suspend fun measureCapability(
        config: ProviderConfig,
        apiKey: String?,
        modelId: String,
        tools: Boolean,
        stream: Boolean,
        markers: List<String>
    ): ProbeVerdict = withContext(Dispatchers.IO) {
        if (modelId.isBlank()) return@withContext ProbeVerdict.Unknown
        if (apiKey.isNullOrBlank() && config.requiresApiKey) return@withContext ProbeVerdict.Unknown
        if (config.type == ProviderType.Custom) return@withContext ProbeVerdict.Unknown
        if (apiKey != null && !apiKey.isHeaderSafe()) return@withContext ProbeVerdict.Unknown

        val anthropic = config.type == ProviderType.AnthropicCompatible
        val base = config.baseUrl.trim().trimEnd('/')
        val url = base + if (anthropic) "/messages" else "/chat/completions"
        val request = Request.Builder()
            .url(url)
            .post(capabilityBody(anthropic, modelId, tools, stream).toRequestBody(JSON_MEDIA))
            .apply {
                header("Accept", if (stream) "text/event-stream" else "application/json")
                if (anthropic) {
                    header("anthropic-version", ANTHROPIC_MODELS_VERSION)
                    if (!apiKey.isNullOrBlank()) header("x-api-key", apiKey)
                } else if (!apiKey.isNullOrBlank()) {
                    header("Authorization", "Bearer " + apiKey)
                }
            }
            .build()

        val response = runCatching { probeClient.newCall(request).execute() }
            .getOrElse { return@withContext ProbeVerdict.Unknown }

        response.use { httpResponse ->
            // Safe to read whole: max_tokens is 1, so even the streaming variant is
            // a few hundred bytes, and probeClient caps the wait at seconds.
            val body = runCatching { httpResponse.body?.string() }.getOrNull().orEmpty()
            if (httpResponse.isSuccessful) {
                return@withContext when {
                    !stream -> ProbeVerdict.Supported
                    looksLikeSse(httpResponse, body) -> ProbeVerdict.Supported
                    else -> ProbeVerdict.Unsupported
                }
            }
            val lowered = body.lowercase()
            when {
                httpResponse.code in 400..422 && markers.any { lowered.contains(it) } ->
                    ProbeVerdict.Unsupported
                else -> ProbeVerdict.Unknown
            }
        }
    }

    /**
     * Whether this response is really an event stream.
     *
     * The header is the honest signal; the body scan is there for the proxies
     * that stream correctly while labelling it `application/json`.
     */
    private fun looksLikeSse(response: Response, body: String): Boolean {
        val contentType = response.header("Content-Type").orEmpty().lowercase()
        if (contentType.contains("event-stream")) return true
        return body.lineSequence().any { it.startsWith("data:") }
    }

    /**
     * The probe body for tools and streaming.
     *
     * Built with the JSON DSL for the same reason as [visionBody]: the model id
     * is user-supplied, and a quote in it must not turn into a 400 that gets
     * filed as "this model cannot stream".
     */
    private fun capabilityBody(
        anthropic: Boolean,
        modelId: String,
        tools: Boolean,
        stream: Boolean
    ): String = buildJsonObject {
        put("model", modelId)
        put("max_tokens", 1)
        put("stream", stream)
        putJsonArray("messages") {
            addJsonObject {
                put("role", "user")
                put("content", PROBE_PROMPT)
            }
        }
        if (tools) {
            putJsonArray("tools") {
                addJsonObject {
                    if (anthropic) {
                        put("name", PROBE_TOOL_NAME)
                        put("description", PROBE_TOOL_DESCRIPTION)
                        putJsonObject("input_schema") {
                            put("type", "object")
                            putJsonObject("properties") {}
                        }
                    } else {
                        put("type", "function")
                        putJsonObject("function") {
                            put("name", PROBE_TOOL_NAME)
                            put("description", PROBE_TOOL_DESCRIPTION)
                            putJsonObject("parameters") {
                                put("type", "object")
                                putJsonObject("properties") {}
                            }
                        }
                    }
                }
            }
        }
    }.toString()

    /**
     * The probe request body, in whichever shape this protocol takes images.
     *
     * Built with the JSON DSL rather than a template string because the model id
     * is user-supplied: a gateway id containing a quote would otherwise produce a
     * malformed body, and the resulting 400 would be recorded as "this model
     * cannot see".
     */
    private fun visionBody(anthropic: Boolean, modelId: String): String = buildJsonObject {
        put("model", modelId)
        // One token. The content of the answer is never read; only whether the
        // endpoint accepted the request at all.
        put("max_tokens", 1)
        if (!anthropic) put("stream", false)
        putJsonArray("messages") {
            addJsonObject {
                put("role", "user")
                putJsonArray("content") {
                    addJsonObject {
                        put("type", "text")
                        put("text", PROBE_PROMPT)
                    }
                    if (anthropic) {
                        addJsonObject {
                            put("type", "image")
                            putJsonObject("source") {
                                put("type", "base64")
                                put("media_type", "image/png")
                                put("data", PIXEL_PNG_BASE64)
                            }
                        }
                    } else {
                        addJsonObject {
                            put("type", "image_url")
                            putJsonObject("image_url") {
                                put("url", "data:image/png;base64," + PIXEL_PNG_BASE64)
                            }
                        }
                    }
                }
            }
        }
    }.toString()

    /**
     * A short-fused clone of the shared client.
     *
     * The shared one is tuned for streaming answers and waits minutes for a slow
     * model. A capability probe runs while the user is looking at a Save button,
     * so it gets seconds and gives up as Unknown -- which costs nothing, because
     * the id heuristic is still there.
     */
    private val probeClient: OkHttpClient by lazy {
        client.newBuilder()
            .callTimeout(PROBE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .readTimeout(PROBE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .build()
    }

    private companion object {
        const val ANTHROPIC_MODELS_VERSION = "2023-06-01"

        /** One probe answer, and the moment it stops being trusted. */
        class Cached<T : Any>(val value: T, val expiresAt: Long)

        /**
         * Answers already paid for, keyed by endpoint, model and probe.
         *
         * Kept on the companion so every [ProviderProbe] shares them: the settings
         * screen builds a fresh one per check, and the whole point is not to ask
         * the same question twice.
         */
        val visionCache = ConcurrentHashMap<String, Cached<VisionSupport>>()

        val capabilityCache = ConcurrentHashMap<String, Cached<ProbeVerdict>>()

        /**
         * A settled answer describes the endpoint, so it keeps for a day.
         *
         * Unknown means the question never got through -- a timeout, a rate limit,
         * a gateway rewriting the body -- and that is worth re-asking in minutes.
         * Caching it for a day would freeze a temporary failure into a capability.
         */
        const val SETTLED_TTL_MS = 24L * 60 * 60 * 1000

        const val UNKNOWN_TTL_MS = 10L * 60 * 1000

        fun cacheKey(config: ProviderConfig, modelId: String, probe: String): String =
            "${config.type}|${config.baseUrl.trim().trimEnd('/').lowercase()}|$modelId|$probe"

        fun <T : Any> ConcurrentHashMap<String, Cached<T>>.fresh(key: String): T? {
            val hit = this[key] ?: return null
            if (System.currentTimeMillis() >= hit.expiresAt) {
                remove(key)
                return null
            }
            return hit.value
        }

        fun <T : Any> ConcurrentHashMap<String, Cached<T>>.store(
            key: String,
            value: T,
            settled: Boolean
        ) {
            val ttl = if (settled) SETTLED_TTL_MS else UNKNOWN_TTL_MS
            this[key] = Cached(value, System.currentTimeMillis() + ttl)
        }

        val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

        const val PROBE_TIMEOUT_SECONDS = 20L

        /**
         * Deliberately trivial: the point is that an image block was accepted,
         * not what the model thinks of it.
         */
        const val PROBE_PROMPT = "ok"

        /** Named so it is recognisable in a server log, not as a real tool. */
        const val PROBE_TOOL_NAME = "sirius_probe"

        const val PROBE_TOOL_DESCRIPTION = "Capability probe. Never called."

        /** A 1x1 fully transparent PNG. 68 bytes on the wire. */
        const val PIXEL_PNG_BASE64 =
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8" +
                "z8DwHwAE/AI/1ZY2WgAAAABJRU5ErkJggg=="

        /**
         * Fragments that mean "the image is the problem".
         *
         * Collected from what the endpoints actually answer: OpenAI-compatible
         * gateways say the model does not support image input or reject the
         * `image_url` content part outright, Anthropic names the `image` block,
         * and several proxies phrase it as a modality or multimodal error.
         */
        val REJECTION_MARKERS = listOf(
            "image",
            "vision",
            "multimodal",
            "modality",
            "image_url",
            "text-only",
            "text only"
        )

        /**
         * Fragments that mean "the tool definitions are the problem".
         *
         * Kept narrow on purpose. A broad marker like "not supported" also
         * matches an unknown *model* name, and that would record a refusal about
         * the wrong thing.
         */
        val TOOL_MARKERS = listOf("tool", "function")

        /** Fragments that mean "the stream flag is the problem". */
        val STREAM_MARKERS = listOf("stream", "sse")
    }
}
