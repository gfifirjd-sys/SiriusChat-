package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.int
import com.sirius.chat.ai.agent.string
import com.sirius.chat.ai.agent.stringOrEmpty
import com.sirius.chat.data.image.GeneratedImageStore
import com.sirius.chat.data.image.ImageEditUnsupportedException
import com.sirius.chat.data.image.ImageGenerationService
import com.sirius.chat.data.image.ImageModerationException
import com.sirius.chat.data.image.ImageRequest
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.JsonObject

/**
 * The tool behind the "Генерация изображений" switch.
 *
 * ### Why the result is markdown and not a structured field
 * The tool returns the image as a markdown link in its output, and the model is
 * told to repeat that link in its answer. The alternative — a dedicated
 * `imageUrl` field on the message that the bubble renders specially — was
 * rejected because it makes the picture invisible to everything that treats a
 * message as text: the transcript export, the clipboard, the prompt history sent
 * back on the next turn, and the model's own view of what it just did.
 *
 * With markdown, the model *knows* there is an image in the conversation, can
 * refer to it ("the second one, with the blue background"), and can place it
 * mid-sentence where it belongs rather than always at the end of the bubble.
 *
 * ### Why the tool does not silently retry
 * One call, one picture. A model asked for "some icons" will otherwise call this
 * four times in one step, and each call is a real generation the user may be
 * paying for. The per-run cap in the engine bounds the total, and the
 * instructions below tell the model to ask before producing a batch.
 */
private class GenerateImageTool(
    private val service: ImageGenerationService
) : AgentTool {

    override val name = "generate_image"
    override val description =
        "Generate one image from a text description and place it in the chat. Use " +
            "when the user asks for a picture, illustration, icon, logo, mockup or " +
            "diagram-as-art. Write the prompt in English and describe subject, " +
            "composition, lighting and style — the image model does not see the " +
            "conversation, only your prompt. Ask first before generating more than one."
    override val usage =
        """{"prompt": "a red fox sleeping on a mossy rock, soft morning light", """ +
            """"aspect": "square", "style": "photorealistic"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val prompt = args.string("prompt") ?: args.string("description")
            ?: args.string("text") ?: args.string("query")
            ?: return AgentToolResult(
                "Missing 'prompt'. Describe the picture in English.",
                success = false
            )

        val (width, height) = dimensions(args)

        val result = try {
            service.generate(
                providerId = context.providerId,
                request = ImageRequest(
                    prompt = prompt,
                    width = width,
                    height = height,
                    style = args.stringOrEmpty("style")
                )
            )
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (refusal: ImageModerationException) {
            // Reported as a failure but with no suggestion to rephrase and retry:
            // the engine refused the content, and coaching the model into finding
            // a wording that slips past is not this app's job.
            return AgentToolResult(
                "The image engine refused this prompt: ${refusal.message}. " +
                    "Tell the user it was declined and do not retry it.",
                success = false
            )
        } catch (error: Throwable) {
            return AgentToolResult(
                "Image generation failed: ${error.message ?: error::class.simpleName}. " +
                    "Tell the user, and suggest checking the provider key in Settings " +
                    "if the endpoint rejected the request.",
                success = false
            )
        }

        val alt = prompt.replace(']', ' ').replace('[', ' ').trim().take(ALT_CHARS)
        val markdown = "![$alt](${result.image.markdownUri})"

        return AgentToolResult(
            buildString {
                append("Image generated with ").append(result.engine)
                append(" at ").append(result.image.resolution).append(".\n\n")
                if (result.fellBack) {
                    append("Note: the provider's own image endpoint refused (")
                    append(result.fallbackReason.take(200))
                    append("), so the built-in engine drew it instead. ")
                    append("Mention this to the user.\n\n")
                }
                append("Include exactly this line in your answer so the picture is shown:\n")
                append(markdown)
                append("\n\nDo not describe the image in detail afterwards — the user can see it.")
            }
        )
    }

    /**
     * Pixel size from whatever the model expressed the shape as.
     *
     * Named aspects are accepted because that is what models emit — `"aspect":
     * "landscape"` far more often than `"width": 1344`. Explicit pixels win when
     * given, and everything is snapped to a multiple of 64: diffusion endpoints
     * reject or silently re-round odd sizes, and a silent re-round means the
     * resolution badge in the chat lies about what was produced.
     */
    private fun dimensions(args: JsonObject): Pair<Int, Int> {
        val explicitWidth = args.int("width", 0)
        val explicitHeight = args.int("height", 0)
        if (explicitWidth > 0 && explicitHeight > 0) {
            return snap(explicitWidth) to snap(explicitHeight)
        }

        val aspect = (args.string("aspect") ?: args.string("aspect_ratio") ?: args.string("size"))
            ?.lowercase()
            .orEmpty()

        return when {
            aspect.contains("land") || aspect.contains("wide") || aspect == "16:9" ->
                1344 to 768
            aspect.contains("port") || aspect.contains("tall") || aspect == "9:16" ->
                768 to 1344
            aspect == "4:3" -> 1152 to 896
            aspect == "3:4" -> 896 to 1152
            else -> 1024 to 1024
        }
    }

    private fun snap(value: Int): Int =
        (value.coerceIn(256, 1536) / 64) * 64

    private companion object {
        const val ALT_CHARS = 120
    }
}

/**
 * The tool behind the "Редактирование изображений" switch.
 *
 * ### Why editing is not a second call to [GenerateImageTool]
 * "Make the background blue" sent to a text-to-image model produces a new
 * picture that happens to have a blue background: different subject, different
 * pose, different everything the user was happy with. The composition only
 * survives if the source image is *in the request*, which is what this tool does
 * and what generation structurally cannot do.
 *
 * ### Why only images from this conversation can be edited
 * The reference must be a `sirius-image:` uri the app itself wrote. Accepting an
 * arbitrary URL would mean a model could name any address, and the app would
 * fetch it and upload it to a paid endpoint under the user's key -- a prompt
 * injection with a bill attached. Attachments the user picked are a separate
 * (and reasonable) future case; a model-supplied URL is not.
 *
 * ### Why an unsupported provider is a plain answer and not an error
 * Most endpoints sell text-to-image and no edit route. When that is the case the
 * switch is already greyed out with a reason, so this path is only reached when a
 * gateway looked capable and was not. The model is told to explain the choice --
 * switch provider, or generate a fresh picture -- rather than being handed a
 * failure it will try again with different words.
 */
private class EditImageTool(
    private val service: ImageGenerationService
) : AgentTool {

    override val name = "edit_image"
    override val description =
        "Change an image that is already in this conversation, keeping its " +
            "composition. Use when the user asks to alter a picture you generated " +
            "earlier (\"make the background blue\", \"remove the text\", \"same logo " +
            "but green\"). Pass the exact sirius-image: uri from the markdown link of " +
            "that image and describe the change in English. Only images from this " +
            "chat can be edited; there is no keyless fallback, so if the provider " +
            "cannot edit, say so instead of generating a replacement."
    override val usage =
        """{"image": "sirius-image:img-1a2b3c.png", "instruction": "make the background deep blue"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val reference = reference(args)
            ?: return AgentToolResult(
                "Missing 'image'. Pass the sirius-image: uri of the picture to change, " +
                    "exactly as it appears in the markdown link in this conversation.",
                success = false
            )

        val instruction = args.string("instruction") ?: args.string("prompt")
            ?: args.string("edit") ?: args.string("change") ?: args.string("text")
            ?: return AgentToolResult(
                "Missing 'instruction'. Describe the change in English.",
                success = false
            )

        val result = try {
            service.edit(
                providerId = context.providerId,
                reference = reference,
                instruction = instruction
            )
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (unsupported: ImageEditUnsupportedException) {
            // Not a failure to retry: nothing about this request was wrong.
            return AgentToolResult(
                buildString {
                    append("Image editing is unavailable here: ")
                    append(unsupported.message)
                    append(". Tell the user plainly, and offer the two things that ")
                    append("would work: switching this chat to OpenAI or Gemini with a ")
                    append("key, or generating a new picture from a fuller description. ")
                    append("Do not call generate_image as if it were an edit.")
                },
                success = false
            )
        } catch (refusal: ImageModerationException) {
            return AgentToolResult(
                "The image engine refused this edit: ${refusal.message}. " +
                    "Tell the user it was declined and do not retry it.",
                success = false
            )
        } catch (error: Throwable) {
            return AgentToolResult(
                "Image editing failed: ${error.message ?: error::class.simpleName}. " +
                    "Tell the user, and suggest checking the provider key in Settings " +
                    "if the endpoint rejected the request.",
                success = false
            )
        }

        val alt = instruction.replace(']', ' ').replace('[', ' ').trim().take(ALT_CHARS)
        val markdown = "![$alt](${result.image.markdownUri})"

        return AgentToolResult(
            buildString {
                append("Image edited with ").append(result.engine)
                append(" at ").append(result.image.resolution).append(".\n\n")
                append("The edit is a new picture; the original is still in the chat above. ")
                append("Include exactly this line in your answer so the result is shown:\n")
                append(markdown)
                append("\n\nDo not describe it in detail afterwards \u2014 the user can see it.")
            }
        )
    }

    /**
     * The source image's uri, however the model phrased it.
     *
     * Models copy the whole markdown link (`![fox](sirius-image:img-1.png)`) about
     * as often as they copy the uri, and sometimes only the file name. All three
     * are accepted because the alternative is a tool call that fails on a
     * formatting detail the user never sees, on a request that was perfectly
     * clear.
     */
    private fun reference(args: JsonObject): String? {
        val raw = args.string("image") ?: args.string("uri") ?: args.string("reference")
            ?: args.string("source") ?: args.string("url") ?: return null
        val trimmed = raw.trim()
        val inside = trimmed.substringAfter('(', "").substringBefore(')').trim()
        val candidate = inside.ifEmpty { trimmed }
        return when {
            candidate.startsWith(GeneratedImageStore.SCHEME) -> candidate
            // A bare file name is unambiguous: the store resolves names inside its
            // own directory and nothing else.
            candidate.isNotEmpty() && !candidate.contains("://") ->
                GeneratedImageStore.SCHEME + candidate.substringAfterLast('/')
            else -> null
        }
    }

    private companion object {
        const val ALT_CHARS = 120
    }
}

/** Registers the image tools. */
fun imageTools(service: ImageGenerationService): List<AgentTool> = listOf(
    GenerateImageTool(service),
    EditImageTool(service)
)

/** Names of the tools this switch controls, for the per-session tool filter. */
val IMAGE_TOOL_NAMES: Set<String> = setOf("generate_image")

/**
 * Names behind the editing switch, kept apart from [IMAGE_TOOL_NAMES].
 *
 * Two sets because the two features have genuinely different availability: a
 * keyless session can draw and cannot edit, so one switch would have to be wrong
 * about one of them.
 */
val IMAGE_EDIT_TOOL_NAMES: Set<String> = setOf("edit_image")
