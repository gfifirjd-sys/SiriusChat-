package com.sirius.chat.ai.capability

import com.sirius.chat.domain.model.EndpointCapabilities
import com.sirius.chat.domain.model.PowerConfig
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * The only place a power field becomes JSON.
 *
 * ### Why the providers do not do this themselves
 * Both payload builders would need the same three rules -- write only declared
 * paths, nest dotted paths, narrow `Any` to a JSON primitive -- and the one that
 * drifted would send a field the endpoint rejects. One converter also means the
 * "never send an undeclared field" guarantee is checkable in a single function
 * rather than trusted twice.
 */
object PowerWire {

    /**
     * Top-level fields to merge into a request body.
     *
     * Dotted paths in the capabilities become nested objects, which is what
     * `thinking.budget_tokens` and Gemini's `extra_body.google.thinking_config`
     * actually are on the wire. `max_tokens` is not here: the request already
     * carries it, so it goes through [maxTokens] instead of being added twice.
     */
    fun fields(power: PowerConfig?, capabilities: EndpointCapabilities): Map<String, JsonElement> {
        if (power == null || power.isNoOp) return emptyMap()
        val flat = LinkedHashMap<String, Any>()

        // A value being present is already a decision: the resolver sets one only
        // where the endpoint declares the knob, and manual mode only where the
        // user typed it. What this converter still enforces is the veto -- a field
        // this endpoint has refused is never written again, whoever asked.
        val effort = power.reasoningEffort
        if (effort != null &&
            !capabilities.refusedReasoningEffort &&
            capabilities.reasoningEffortKey.isNotBlank()
        ) {
            flat[capabilities.reasoningEffortKey] = effort
        }

        // Never both. OpenRouter answers a request that carries
        // `reasoning.effort` and `reasoning.max_tokens` together with
        // "Only one of ... can be specified", and it is the same story on every
        // gateway that exposes the pair: they are two spellings of one decision,
        // not two settings. The tier wins because it is the portable one -- a
        // budget means nothing on an endpoint that only grades effort.
        val budget = power.thinkingBudget
        val effortSent = capabilities.reasoningEffortKey.isNotBlank() &&
            flat.containsKey(capabilities.reasoningEffortKey)
        if (budget != null &&
            !effortSent &&
            !capabilities.refusedThinkingBudget &&
            capabilities.thinkingBudgetKey.isNotBlank()
        ) {
            flat[capabilities.thinkingBudgetKey] = budget
        }

        // Anything else is only allowed if this endpoint declared the path --
        // either as an extra parameter or as the switch a thinking control needs.
        power.extra.forEach { (path, value) ->
            val declared = path in capabilities.extraParams
            // A switch travels with the control it enables, never alone: by
            // itself it turns on a mode with no size, which is ignored at best
            // and a 400 at worst. Which control it rides on is no longer always
            // the budget -- GLM grades effort only while `thinking.type` is
            // enabled, DashScope wants `enable_thinking` beside either field,
            // DeepSeek V4 pairs its switch with a word, and Claude 4.7+ reads
            // `output_config.effort` only when `thinking.type` is adaptive. So
            // any thinking field being on the wire is enough.
            val thinkingSent = effortSent || flat.containsKey(capabilities.thinkingBudgetKey)
            val enabling = capabilities.thinkingEnableFlags.containsKey(path) && thinkingSent
            if (declared || enabling) {
                flat[path] = value
            }
        }
        return nest(flat)
    }

    /**
     * The length to send, or the caller's own value when power says nothing.
     *
     * Clamped to the model's real ceiling even when the caller picked the
     * number: the global default in Settings can exceed what a small model
     * accepts, and that used to be a 400 with the user's own setting as the
     * cause.
     */
    fun maxTokens(power: PowerConfig?, capabilities: EndpointCapabilities, fallback: Int): Int {
        val wanted = power?.maxTokens ?: fallback
        val limit = capabilities.maxTokensLimit
        val bounded = if (limit != null) minOf(wanted, limit) else wanted
        return bounded.coerceAtLeast(MIN_TOKENS)
    }

    private fun nest(flat: Map<String, Any>): Map<String, JsonElement> {
        val out = LinkedHashMap<String, JsonElement>()
        val groups = LinkedHashMap<String, LinkedHashMap<String, Any>>()
        flat.forEach { (path, value) ->
            val head = path.substringBefore('.')
            if (head == path) {
                out[path] = primitive(value)
            } else {
                groups.getOrPut(head) { LinkedHashMap() }[path.substringAfter('.')] = value
            }
        }
        groups.forEach { (head, children) -> out[head] = JsonObject(nest(children)) }
        return out
    }

    /**
     * `Any` narrowed by hand.
     *
     * `JsonPrimitive` has no overload for `Any`, and the fallback matters: an
     * unexpected type becomes its own text rather than crashing a request that
     * was otherwise fine.
     */
    private fun primitive(value: Any): JsonElement = when (value) {
        is String -> JsonPrimitive(value)
        is Int -> JsonPrimitive(value)
        is Long -> JsonPrimitive(value)
        is Double -> JsonPrimitive(value)
        is Float -> JsonPrimitive(value)
        is Boolean -> JsonPrimitive(value)
        else -> JsonPrimitive(value.toString())
    }

    private const val MIN_TOKENS = 256
}
