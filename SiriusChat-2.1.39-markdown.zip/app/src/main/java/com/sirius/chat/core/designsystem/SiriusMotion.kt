package com.sirius.chat.core.designsystem

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedContentScope
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntOffset

/**
 * One place that owns *how* Sirius moves.
 *
 * Before this existed every call site invented its own `tween(120)` or
 * `spring(0.6f)`, so nothing in the app felt like it belonged to the same
 * object. Four durations and three springs cover the whole product:
 *
 *  - [Instant] state flips the user already expects (press, tint swap)
 *  - [Quick]   small reveals that must not delay a tap
 *  - [Base]    the default for anything that changes layout
 *  - [Slow]    full-screen or hero transitions
 *
 * Easing is asymmetric on purpose: things enter with [Emphasized] (fast out of
 * the gate, long soft landing) and leave with [Exit] (slow start, quick away),
 * which is what makes a transition read as intentional rather than linear.
 */
object SiriusMotion {
    const val Instant = 90
    const val Quick = 150
    const val Base = 240
    const val Slow = 380

    /** Ambient loops (background flow, orbs, beams) run on their own clock. */
    const val AmbientSlow = 26_000
    const val AmbientBeam = 3_400
    const val AmbientBreath = 4_200

    /** Enter: leaves immediately, settles gently. */
    val Emphasized: Easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)

    /** Neutral both ways, for color and opacity. */
    val Standard: Easing = CubicBezierEasing(0.3f, 0f, 0.2f, 1f)

    /** Exit: hesitates, then gets out of the way. */
    val Exit: Easing = CubicBezierEasing(0.4f, 0f, 1f, 1f)

    /** No overshoot. Use when the element must land exactly where promised. */
    val SpringPrecise: SpringSpec<Float> =
        spring(dampingRatio = 1f, stiffness = Spring.StiffnessMediumLow)

    /** A single soft overshoot. The default for anything that appears. */
    val SpringGentle: SpringSpec<Float> =
        spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow)

    /** Visible bounce. Reserved for the send button and tab selection. */
    val SpringBouncy: SpringSpec<Float> =
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium)
}

/**
 * A tween that collapses to a single frame when the user asked for reduced
 * motion. Every animated value in the app should go through this or through
 * [SiriusTheme.reduceMotion] directly, so "Reduce motion" is a real promise and
 * not a suggestion.
 */
@Composable
fun <T> siriusTween(
    durationMillis: Int = SiriusMotion.Base,
    easing: Easing = SiriusMotion.Standard
): FiniteAnimationSpec<T> = tween(
    durationMillis = if (SiriusTheme.reduceMotion) 0 else durationMillis,
    easing = easing
)

@Composable
fun siriusSpring(base: SpringSpec<Float> = SiriusMotion.SpringGentle): FiniteAnimationSpec<Float> =
    if (SiriusTheme.reduceMotion) tween(0) else base

/**
 * Fade-through: the shared "one thing replaced another" transition. Reduced
 * motion keeps the cross-fade (it carries meaning) but drops the scale.
 */
@Composable
fun siriusFadeThrough(): Pair<EnterTransition, ExitTransition> {
    val reduce = SiriusTheme.reduceMotion
    val enter = fadeIn(siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)) +
        if (reduce) EnterTransition.None else scaleIn(
            initialScale = 0.94f,
            animationSpec = siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)
        )
    val exit = fadeOut(siriusTween(SiriusMotion.Quick, SiriusMotion.Exit)) +
        if (reduce) ExitTransition.None else scaleOut(
            targetScale = 0.96f,
            animationSpec = siriusTween(SiriusMotion.Quick, SiriusMotion.Exit)
        )
    return enter to exit
}

/** Content that arrives from below: banners, composer rows, new messages. */
@Composable
fun siriusRise(distancePx: Int = 24): Pair<EnterTransition, ExitTransition> {
    val reduce = SiriusTheme.reduceMotion
    val enter = fadeIn(siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)) +
        if (reduce) EnterTransition.None else slideInVertically(
            animationSpec = siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)
        ) { distancePx }
    val exit = fadeOut(siriusTween(SiriusMotion.Quick, SiriusMotion.Exit)) +
        if (reduce) ExitTransition.None else slideOutVertically(
            animationSpec = siriusTween(SiriusMotion.Quick, SiriusMotion.Exit)
        ) { distancePx / 2 }
    return enter to exit
}

/**
 * The four-plus-two transitions a `NavHost` needs, resolved once per theme.
 *
 * Navigation used to slide horizontally for *every* destination change, which
 * quietly lied about the shape of the app: moving from Home to Settings is a
 * step sideways between peers, not a step deeper, and sliding it like a push
 * implies a hierarchy the back stack does not have. So siblings fade through
 * each other and only real pushes and pops slide.
 *
 * The two slide distances are deliberately unequal. The arriving screen travels
 * a fifth of the width while the leaving screen drifts a tenth in the opposite
 * direction, so the pair reads as one connected gesture with a near layer and a
 * far layer instead of two unrelated screens crossing at the same speed.
 */
@Immutable
class SiriusNavMotion(
    val pushEnter: EnterTransition,
    val pushExit: ExitTransition,
    val popEnter: EnterTransition,
    val popExit: ExitTransition,
    val siblingEnter: EnterTransition,
    val siblingExit: ExitTransition
)

@Composable
fun rememberSiriusNavMotion(): SiriusNavMotion {
    val reduce = SiriusTheme.reduceMotion
    val fadeInSpec = siriusTween<Float>(SiriusMotion.Base, SiriusMotion.Emphasized)
    val fadeOutSpec = siriusTween<Float>(SiriusMotion.Quick, SiriusMotion.Exit)
    val slideInSpec = siriusTween<IntOffset>(SiriusMotion.Base, SiriusMotion.Emphasized)
    val slideOutSpec = siriusTween<IntOffset>(SiriusMotion.Quick, SiriusMotion.Exit)

    return remember(reduce) {
        val fadeEnter = fadeIn(animationSpec = fadeInSpec)
        val fadeExit = fadeOut(animationSpec = fadeOutSpec)

        if (reduce) {
            // The cross-fade stays: it carries the "this replaced that" meaning
            // rather than decorating it. siriusTween has already zeroed the
            // duration, so nothing actually travels or lingers.
            SiriusNavMotion(
                pushEnter = fadeEnter,
                pushExit = fadeExit,
                popEnter = fadeEnter,
                popExit = fadeExit,
                siblingEnter = fadeEnter,
                siblingExit = fadeExit
            )
        } else {
            SiriusNavMotion(
                pushEnter = fadeEnter +
                    slideInHorizontally(animationSpec = slideInSpec) { full -> full / 5 },
                pushExit = fadeExit +
                    slideOutHorizontally(animationSpec = slideOutSpec) { full -> -full / 10 },
                popEnter = fadeEnter +
                    slideInHorizontally(animationSpec = slideInSpec) { full -> -full / 10 },
                popExit = fadeExit +
                    slideOutHorizontally(animationSpec = slideOutSpec) { full -> full / 5 },
                // 2%, not the 6% siriusFadeThrough uses for chips and rows: at
                // full-screen size the same ratio stops reading as a hint and
                // starts reading as a zoom.
                siblingEnter = fadeEnter +
                    scaleIn(initialScale = 0.98f, animationSpec = fadeInSpec),
                siblingExit = fadeExit
            )
        }
    }
}

/**
 * The app-wide answer to "loading, then content, then maybe empty".
 *
 * Before this, screens swapped those three states by returning a different
 * subtree, so a list arriving after a 400ms fetch replaced its skeleton in a
 * single frame — the one moment the user is definitely watching, animated by
 * nothing at all. A fade-through costs one extra composition per swap and
 * removes the flicker.
 *
 * [contentKey] defaults to the state itself. Pass a coarser key (for example
 * `{ it::class }` over a sealed UI state) when the object changes on every
 * emission but the *kind* of content does not — otherwise the screen
 * cross-fades with itself on every tick.
 */
@Composable
fun <S> SiriusSwap(
    targetState: S,
    modifier: Modifier = Modifier,
    contentAlignment: Alignment = Alignment.TopStart,
    label: String = "siriusSwap",
    contentKey: (S) -> Any? = { it },
    content: @Composable AnimatedContentScope.(S) -> Unit
) {
    val (enter, exit) = siriusFadeThrough()
    val transform = ContentTransform(
        targetContentEnter = enter,
        initialContentExit = exit,
        // clip = false: most callers sit inside a scrolling column, where a
        // clipped size animation crops the taller state mid-transition.
        sizeTransform = SizeTransform(clip = false)
    )
    AnimatedContent(
        targetState = targetState,
        modifier = modifier,
        transitionSpec = { transform },
        contentAlignment = contentAlignment,
        label = label,
        contentKey = contentKey,
        content = content
    )
}

/**
 * `animateContentSize` with the app's easing, and genuinely off under reduced
 * motion. For any surface that grows or shrinks in place: expanding cards, an
 * error line appearing under a field, a toolbar gaining a second row of chips.
 */
@Composable
fun Modifier.siriusContentSize(durationMillis: Int = SiriusMotion.Base): Modifier =
    if (SiriusTheme.reduceMotion) {
        this
    } else {
        this.animateContentSize(
            animationSpec = tween(
                durationMillis = durationMillis,
                easing = SiriusMotion.Emphasized
            )
        )
    }
