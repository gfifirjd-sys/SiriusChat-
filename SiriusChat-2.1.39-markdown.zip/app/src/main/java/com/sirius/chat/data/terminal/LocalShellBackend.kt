package com.sirius.chat.data.terminal

import com.sirius.chat.R
import com.sirius.chat.core.locale.AppStrings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.SendChannel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Runs commands with the device shell inside the app sandbox.
 *
 * This is real execution, not a simulation: `ls`, `cat`, `grep`, `sh` scripts,
 * pipes and exit codes all behave normally. What it cannot do is escape the
 * sandbox, and no attempt is made to work around that.
 *
 * Concurrency model, which the previous implementation got wrong in a way that
 * hung every command:
 *
 *  - Each [execute] owns its own [Process]. The backend keeps a *set* of live
 *    processes rather than a single `current` field, because the backend is an
 *    application-wide singleton: with one field, a finishing command cleared the
 *    handle of a newer running one and the stop button became a no-op while the
 *    UI stayed stuck on "running".
 *  - stdout and stderr are drained on dedicated *threads*, not coroutines.
 *    `BufferedReader.readLine()` on a process pipe is uninterruptible, so a
 *    cancelled coroutine would leave the read parked forever and any `join()` on
 *    it would never return. Threads are drained to real EOF and the coroutine
 *    only waits on them with a timeout.
 *  - The terminal event for completion is emitted before the channel is closed,
 *    and the emission uses a suspending `send` on an unlimited buffer so it can
 *    never be silently dropped. Losing that one event is what left the UI
 *    showing "running" indefinitely.
 */
class LocalShellBackend : TerminalBackend {

    override val id: String = "local-shell"

    // Read on every access so the banner follows the in-app language switch.
    override val displayName: String
        get() = AppStrings.get(R.string.terminal_backend_local_name, fallback = "Device shell")

    override val description: String
        get() = AppStrings.get(
            R.string.terminal_backend_local_description,
            fallback = "Runs commands with /system/bin/sh inside the app sandbox. Real processes, real exit codes."
        )

    /**
     * Every process this backend has started and not yet reaped.
     *
     * A set rather than one field: [stop] has to be able to end whatever is
     * running even when several executions overlap, and an execution that
     * finishes must only ever remove *itself*.
     */
    private val live = CopyOnWriteArraySet<Process>()

    override fun isAvailable(): Boolean = File(SHELL).canExecute()

    override fun unavailableReason(): String? = if (isAvailable()) {
        null
    } else {
        AppStrings.format(
            R.string.terminal_no_shell,
            SHELL,
            fallback = "No shell available at $SHELL on this device."
        )
    }

    override fun execute(command: String, workingDirectory: File): Flow<TerminalEvent> = callbackFlow {
        val startedAt = System.currentTimeMillis()

        if (!isAvailable()) {
            send(TerminalEvent.Failed(noShellMessage()))
            close()
            return@callbackFlow
        }

        val process = runCatching { start(command, workingDirectory) }.getOrElse { error ->
            send(
                TerminalEvent.Failed(
                    error.message?.takeIf { it.isNotBlank() } ?: AppStrings.get(
                        R.string.terminal_process_start_failed,
                        fallback = "Cannot start process"
                    )
                )
            )
            close()
            return@callbackFlow
        }

        live += process
        send(TerminalEvent.Started(command, pidOf(process)))

        // ProcessBuilder silently ignores a working directory it cannot use, so
        // a command aimed at a project folder this process cannot see runs
        // somewhere else entirely and then fails with "no such file" about a
        // script that exists. Saying where it actually ran costs one line and
        // saves the model from debugging a phantom.
        if (!workingDirectory.isDirectory) {
            send(
                TerminalEvent.Notice(
                    AppStrings.format(
                        R.string.terminal_workdir_unreadable,
                        workingDirectory.absolutePath,
                        fallback = "Cannot enter " + workingDirectory.absolutePath +
                            "; the command runs in the app directory instead."
                    )
                )
            )
        }

        // Threads, not coroutines: readLine() on a process pipe cannot be
        // interrupted, so a coroutine parked in it would ignore cancellation and
        // deadlock every join() that waited for it.
        val drained = CountDownLatch(2)
        val stdout = drain(process.inputStream, drained) { line ->
            emitLine(TerminalEvent.Stdout(line))
        }
        val stderr = drain(process.errorStream, drained) { line ->
            emitLine(TerminalEvent.Stderr(line))
        }

        launch(Dispatchers.IO) {
            // waitFor() is blocking and uninterruptible, so it runs where
            // blocking is legal and cancellation is handled by awaitClose
            // destroying the process, which makes waitFor() return.
            val code = runCatching { process.waitFor() }.getOrDefault(EXIT_UNKNOWN)

            // The process is gone, so the pipes are at EOF and the readers are
            // finishing. Bounded so a wedged reader cannot hold the command
            // "running" forever - the exit code is already known.
            runCatching { drained.await(DRAIN_GRACE_MS, TimeUnit.MILLISECONDS) }

            live -= process

            // NonCancellable + suspending send: the completion event must reach
            // the collector even if the scope is being torn down, otherwise the
            // UI never leaves its running state.
            withContext(NonCancellable) {
                send(TerminalEvent.Exited(code, System.currentTimeMillis() - startedAt))
            }
            close()
        }

        awaitClose {
            // Cancelling the flow must kill the process, not leak it.
            runCatching { if (process.isAlive) process.destroyForcibly() }
            live -= process
            stdout.interrupt()
            stderr.interrupt()
        }
    }
        // UNLIMITED so a command that floods stdout can never block its own
        // reader thread against a slow collector, and no event is dropped.
        .buffer(Channel.UNLIMITED)
        // The producer does blocking work before its first event: canExecute()
        // stats the shell and ProcessBuilder.start() forks and execs. Left in
        // the collector's context those calls run on whatever dispatcher the
        // caller happened to be on, competing with everything else there, and a
        // saturated or confined caller context can delay the block past the
        // command's own timeout — which surfaces as a terminal that answers
        // nothing at all, not even to `echo`. The Termux backend already
        // isolated itself this way; this one had been left behind.
        .flowOn(Dispatchers.IO)

    /** Stops everything this backend started, used by the stop button. */
    override fun stop() {
        // Iterate a snapshot and remove per entry: an execution completing
        // concurrently must not have its own cleanup fight this loop.
        live.forEach { process ->
            runCatching { if (process.isAlive) process.destroyForcibly() }
            live -= process
        }
    }

    private fun start(command: String, workingDirectory: File): Process =
        ProcessBuilder(SHELL, "-c", command)
            .directory(workingDirectory.takeIf { it.isDirectory })
            .redirectErrorStream(false)
            .apply {
                environment().also { env ->
                    env["HOME"] = workingDirectory.absolutePath
                    // Without an explicit PATH the shell inherits a minimal one
                    // and ordinary tools resolve inconsistently across vendors.
                    env["PATH"] = DEFAULT_PATH
                    // Many tools buffer differently or emit escape codes when
                    // they believe they are on a smart terminal; the log view
                    // renders plain text.
                    env["TERM"] = "dumb"
                    env["LANG"] = "C.UTF-8"
                }
            }
            .start()

    /**
     * Reads [stream] to EOF on its own daemon thread, handing each line to [emit].
     *
     * Daemon so a wedged read can never keep the process alive, and the latch is
     * always counted down so the waiter cannot hang on an abnormal exit.
     */
    private fun drain(
        stream: InputStream,
        latch: CountDownLatch,
        emit: (String) -> Unit
    ): Thread = Thread {
        try {
            // Explicit UTF-8: without it the reader takes the platform default and
            // any non-ASCII byte from a command comes back as "?".
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    emit(line)
                }
            }
        } catch (_: Throwable) {
            // A destroyed process closes the pipe mid-read; that is the normal
            // way a stopped command ends, not an error worth surfacing.
        } finally {
            latch.countDown()
        }
    }.apply {
        isDaemon = true
        name = "sirius-shell-reader"
        start()
    }

    private fun noShellMessage(): String = AppStrings.format(
        R.string.terminal_no_shell,
        SHELL,
        fallback = "No shell available at $SHELL on this device."
    )

        /**
         * Best effort pid, read reflectively on purpose.
         *
         * `Process.pid()` is a Java 9 method that Android only exposes from API 33,
         * and on-device toolchains routinely compile against an older `android.jar`
         * than `compileSdk` claims — there it is not "requires API level", it fails
         * to resolve at all and takes the whole build down. The pid is nothing but a
         * label in the log, so it is looked up through the private `pid` field that
         * every Android `ProcessImpl` has carried since forever, and a miss simply
         * means the label is omitted.
         */
        private fun pidOf(process: Process): Int? = runCatching {
            var type: Class<*>? = process.javaClass
            while (type != null) {
                val field = type.declaredFields.firstOrNull { it.name == "pid" }
                if (field != null) {
                    field.isAccessible = true
                    return@runCatching (field.get(process) as? Number)?.toInt()
                }
                type = type.superclass
            }
            null
        }.getOrNull()

    private companion object {
        const val SHELL = "/system/bin/sh"
        const val DEFAULT_PATH = "/system/bin:/system/xbin:/vendor/bin"

        /** Exit code reported when the process outcome could not be read. */
        const val EXIT_UNKNOWN = -1

        /** How long to wait for readers once the process is already gone. */
        const val DRAIN_GRACE_MS = 2_000L
    }
}

/**
 * Send usable from a plain, non-coroutine thread.
 *
 * The reader threads cannot suspend. With an unlimited buffer this always
 * succeeds immediately, and a channel that is already closed discards the line
 * instead of throwing into the reader.
 */
private fun <T> SendChannel<T>.emitLine(element: T) {
    runCatching { trySend(element) }
}
