package com.sirius.chat.domain.usecase

import com.sirius.chat.R
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.repository.ChatRepository
import java.util.UUID

/** The placeholder title a conversation keeps until the first user message. */
internal fun untitledChatTitle(): String =
    AppStrings.get(R.string.chats_untitled, fallback = "New chat")

/** Creates a conversation with sensible defaults and stores it. */
class CreateSessionUseCase(private val chatRepository: ChatRepository) {
    suspend operator fun invoke(
        providerId: String,
        model: String,
        projectId: String? = null,
        title: String = untitledChatTitle()
    ): ChatSession {
        val now = System.currentTimeMillis()
        val session = ChatSession(
            id = UUID.randomUUID().toString(),
            title = title,
            projectId = projectId,
            providerId = providerId,
            model = model,
            agentMode = true,
            createdAt = now,
            updatedAt = now,
            // Only a chat that starts life as "New chat" may be renamed by the
            // model later. One created with a name was named by something that
            // knew what it was for, and that outranks a guess.
            titleAuto = title == untitledChatTitle()
        )
        return chatRepository.createSession(session)
    }
}

/**
 * Derives a short human title from the first user message so the history list
 * stays readable without an extra model round-trip.
 */
class DeriveSessionTitleUseCase {
    operator fun invoke(text: String): String {
        val cleaned = text.trim()
            .replace(Regex("\\s+"), " ")
            .removePrefix("#").trim()
            // A name never carries the punctuation the sentence ended on: a row
            // reading "Ты любишь мороженое?" is a quoted message, not a title.
            .trim('.', '!', '?', '\u2026', ',', ';', ':', '-', '\u2014', ' ')
        if (cleaned.isEmpty()) return untitledChatTitle()
        // Shorter than the old 48: this is one line in a list next to a time and
        // a model name, and a row cut mid-word reads as a broken string rather
        // than a short name. The model replaces it within a few seconds anyway.
        val cut = cleaned.take(MAX_CHARS)
        val trimmed = if (cleaned.length > MAX_CHARS) {
            cut.substringBeforeLast(' ', cut)
                .trim(',', ';', ':', '-', '\u2014', ' ')
                .plus("\u2026")
        } else {
            cut
        }
        // A row reading "нравится мороженое" is a sentence fragment; capitalised
        // it at least reads like a name until the model replaces it.
        return trimmed.replaceFirstChar { it.uppercaseChar() }
    }

    private companion object {
        /** One list row's worth of words, cut on a space and never mid-word. */
        private const val MAX_CHARS = 40
    }
}

/** Rolls the transcript back to just before [messageId] for edit / regenerate. */
class RewindConversationUseCase(private val chatRepository: ChatRepository) {
    suspend operator fun invoke(sessionId: String, messageId: String) {
        chatRepository.truncateFrom(sessionId, messageId)
    }
}

/** Builds the list handed to the provider, trimmed to a token-ish budget. */
class BuildPromptUseCase {
    operator fun invoke(history: List<ChatMessage>, maxChars: Int = 24_000): List<ChatMessage> {
        val usable = history.filter {
            it.role != MessageRole.System && it.content.isNotBlank()
        }
        var budget = maxChars
        val result = ArrayList<ChatMessage>(usable.size)
        for (message in usable.asReversed()) {
            budget -= message.content.length
            if (budget < 0 && result.isNotEmpty()) break
            result.add(message)
        }
        return result.asReversed()
    }
}
