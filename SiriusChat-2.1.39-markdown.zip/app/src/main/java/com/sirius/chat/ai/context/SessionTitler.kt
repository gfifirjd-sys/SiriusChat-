package com.sirius.chat.ai.context

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.provider.ProviderFactory
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.GenerationParams
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.repository.ChatRepository
import com.sirius.chat.domain.usecase.DeriveSessionTitleUseCase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Names a conversation after what it is about.
 *
 * ### Why the model and not the first message
 * The old title was the first 48 characters of whatever was typed, which is a
 * fine placeholder and a poor name. Real first messages are pasted stack traces,
 * "привет, смотри", or three paragraphs ending in the actual request, so the
 * history list ended up full of rows that all began identically and said nothing
 * about the task. Every other chat app asks the model for a short label, because
 * the model is the only thing in the loop that knows which sentence was the
 * point.
 *
 * ### Why it never blocks the answer
 * The heuristic title is written first and this runs beside the real generation.
 * If the request is slow, offline, out of quota, or comes back as a paragraph of
 * prose, the chat simply keeps the placeholder. A naming nicety must not cost a
 * turn, so every failure path here returns null and nothing else happens.
 *
 * ### Why the title is only replaced while it is still the app's guess
 * The user can rename a chat, and the run is asynchronous. Writing
 * unconditionally would let a title request issued seconds ago overwrite a name
 * the user has since typed by hand. So the write is conditional on
 * [com.sirius.chat.domain.model.ChatSession.titleAuto], which the first real
 * title clears for good.
 *
 * That flag is also what lets this be asked again on later turns. Keying off
 * the placeholder string meant one slow or failed request froze the chat under
 * the heuristic name forever: the moment the heuristic ran, the title was no
 * longer the placeholder and no later turn could ever qualify.
 */
class SessionTitler(
    private val chatRepository: ChatRepository,
    private val providerFactory: ProviderFactory,
    /**
     * Shortens a subject into a row-sized name, for the one case the model
     * cannot be reached at all. Never the first choice: a shortened message is
     * still the message.
     */
    private val deriveTitle: DeriveSessionTitleUseCase
) {

    /**
     * Asks the conversation's own model for a title and stores it.
     *
     * @param sessionId the conversation to rename.
     * @param firstMessage material to fall back on when nothing is stored yet;
     *   normally the message just sent, and empty when called after an answer.
     * @return the stored title, or null when nothing was changed.
     */
    suspend fun retitle(sessionId: String, firstMessage: String = ""): String? {
        val session = chatRepository.getSession(sessionId) ?: return null
        // The name is the user's own, or one this class already produced. Both
        // outrank anything a new request could say.
        if (!session.titleAuto) return null

        val opening = opening(sessionId, firstMessage)
        if (opening.turns == 0) return null

        // A chat that is nothing but "привет" already has a right name, and it
        // is not the message -- it is what the message was. That costs no
        // request and lands instantly, and it stays provisional (`titleAuto` is
        // left on), so the turn that finally says what the user wants renames
        // the chat over it.
        if (!hasTitleSubstance(opening.subject)) {
            return store(sessionId, greetingTitle(), locked = false)
        }

        val provider = providerFactory.create(session.providerId)
            ?: return store(sessionId, guess(opening), locked = false)

        val request = ChatRequest(
            model = session.model,
            messages = listOf(AiMessage(AiRole.User, PROMPT + opening.material)),
            systemPrompt = SYSTEM,
            // Deterministic, tiny, and non-streaming: this is a label, not a turn
            // in the conversation, and nothing is waiting to render it live.
            params = GenerationParams(
                temperature = 0f,
                topP = 1f,
                maxTokens = MAX_TOKENS
            ),
            stream = false
        )

        val raw = withTimeoutOrNull(TIMEOUT_MS) { ask(provider, request) }
        val named = raw?.let { sanitise(it) }

        // The model's answer is the real name and ends the naming. Anything else
        // is a stand-in a later turn may still improve on -- offline, out of
        // quota, or a model that replied with a paragraph.
        return if (named != null) {
            store(sessionId, named, locked = true)
        } else {
            store(sessionId, guess(opening), locked = false)
        }
    }

    /**
     * Writes a name, when the chat is still the app's to name.
     *
     * @param locked clears [com.sirius.chat.domain.model.ChatSession.titleAuto],
     *   which ends naming for good. Only the model's own answer does that: a
     *   stand-in has to stay replaceable, or a chat that opened with "привет"
     *   would be called "Приветствие" for the rest of its life.
     * @return the stored name, or null when nothing was written.
     */
    private suspend fun store(sessionId: String, title: String?, locked: Boolean): String? {
        if (title.isNullOrBlank()) return null
        // Re-read, because the whole request happened in between: the user may
        // have renamed the chat while the model was thinking.
        val current = chatRepository.getSession(sessionId) ?: return null
        if (!current.titleAuto) return null
        // Same name, different flag is still a write the list has to react to.
        if (current.title == title && current.titleAuto != locked) return null
        val renamed = current.copy(title = title, titleAuto = !locked)
        return try {
            chatRepository.updateSession(renamed)
            title
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            null
        }
    }

    /**
     * The name for a chat the model could not be asked about.
     *
     * This is the only path that still takes words from the message, and it is
     * deliberately late: not on the first turn, where the model is merely slow
     * and the next turn will name the chat properly, and never as a lock. A row
     * that quotes the opening message is the thing this class exists to avoid;
     * it is only better than "Новый чат" once it is clear no name is coming.
     */
    private fun guess(opening: Opening): String? {
        if (opening.turns < MIN_TURNS_FOR_THEME) return null
        val subject = titleSubject(opening.subject) ?: return null
        if (!hasTitleSubstance(subject)) return null
        return deriveTitle(subject)
    }

    /**
     * The start of the conversation, in the two shapes this needs it.
     *
     * Naming from the first message alone is what produced chats called
     * "привет": the request often lands in the second or third message, and by
     * then the name is already wrong and never looked at again. So the opening
     * turns are read from storage instead, and the answers are included too --
     * a reply often states the subject more plainly than the question did.
     *
     * [Opening.subject] holds only what the user wrote, because that is what
     * decides whether there is a task here at all. An assistant's "Привет! Чем
     * помочь?" is words, not a subject, and counting it would let a greeting
     * name the chat after all.
     */
    private suspend fun opening(sessionId: String, fallback: String): Opening {
        val stored = runCatching { chatRepository.messages(sessionId) }.getOrNull().orEmpty()
        val usable = stored
            .filter { it.role == MessageRole.User || it.role == MessageRole.Assistant }
            .filter { it.content.isNotBlank() }
            // A context summary is about the conversation, not its subject.
            .filterNot { it.content.contains(COMPACTION_MARKER) }
            .takeLast(MAX_MATERIAL_MESSAGES)

        // Newest first while the budget is spent, so a long opening never costs
        // the message that finally said what the user wants.
        val chosen = ArrayList<ChatMessage>(usable.size)
        var budget = MAX_MATERIAL_CHARS
        for (message in usable.asReversed()) {
            val body = message.content.trim().take(MAX_MESSAGE_CHARS)
            val cost = body.length + ASSISTANT_LABEL.length + 2
            if (chosen.isNotEmpty() && budget - cost < 0) break
            budget -= cost
            chosen += message
        }
        chosen.reverse()

        if (chosen.isEmpty()) {
            val text = fallback.trim().take(MAX_MATERIAL_CHARS)
            return Opening(material = text, subject = text, turns = if (text.isBlank()) 0 else 1)
        }

        val material = chosen.joinToString("\n\n") { message ->
            val label = if (message.role == MessageRole.Assistant) ASSISTANT_LABEL else USER_LABEL
            label + message.content.trim().take(MAX_MESSAGE_CHARS)
        }
        val subject = chosen
            .filter { it.role == MessageRole.User }
            .joinToString(" ") { it.content.trim().take(MAX_MESSAGE_CHARS) }

        return Opening(
            material = material,
            subject = subject.ifBlank { fallback.trim() },
            turns = chosen.size
        )
    }

    /** The name for a chat that is never going to be about anything else. */
    private fun greetingTitle(): String =
        AppStrings.get(R.string.chats_title_greeting, fallback = "Greeting")

    /**
     * The opening, labelled for the model and stripped for the substance test.
     *
     * [turns] counts the messages behind it, which is how naming tells "nothing
     * has been said yet" apart from "this chat really is just hello".
     */
    private data class Opening(val material: String, val subject: String, val turns: Int = 0)

    /** Collects one non-streaming answer, or null for anything that went wrong. */
    private suspend fun ask(
        provider: com.sirius.chat.ai.provider.AiProvider,
        request: ChatRequest
    ): String? {
        val text = StringBuilder()
        var failed = false
        try {
            provider.chat(request).collect { event ->
                when (event) {
                    is ChatStreamEvent.Delta -> text.append(event.text)
                    is ChatStreamEvent.Completed ->
                        if (event.fullText.isNotBlank()) {
                            // Authoritative: a provider answering a non-streaming
                            // request may send no deltas at all and still fill this.
                            text.setLength(0)
                            text.append(event.fullText)
                        }
                    is ChatStreamEvent.Failure -> failed = true
                    // A start marker, thinking text and keep-alives carry no
                    // title for this one-shot helper to collect.
                    ChatStreamEvent.Started,
                    ChatStreamEvent.Heartbeat,
                    is ChatStreamEvent.Reasoning -> Unit
                }
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            return null
        }
        return if (failed) null else text.toString().ifBlank { null }
    }

    /**
     * Turns whatever came back into something that fits a list row, or null.
     *
     * Models decorate: quotes, a leading `Title:`, a markdown heading, a trailing
     * full stop, and occasionally a whole explanatory paragraph. The first line is
     * taken because that is where the label is when the model over-answered, and
     * anything still too long afterwards is rejected rather than cut -- a
     * truncated sentence is a worse row than the placeholder it would replace.
     */
    private fun sanitise(raw: String): String? {
        var text = raw.trim()
            .lineSequence()
            .map { it.trim() }
            .firstOrNull { it.isNotBlank() }
            ?.trim()
            ?: return null

        // A reasoning model can prefix its thinking; drop it rather than title a
        // chat "<think>".
        if (text.startsWith("<")) return null

        text = text.removePrefix("#").removePrefix("#").removePrefix("#").trim()
        text = text.removePrefix("-").removePrefix("*").trim()
        for (prefix in listOf("title:", "название:", "заголовок:", "chat:")) {
            if (text.lowercase().startsWith(prefix)) {
                text = text.substring(prefix.length).trim()
            }
        }
        text = text.trim('"', '\u201C', '\u201D', '\u00AB', '\u00BB', '\'', '`', ' ')
        text = text.trimEnd('.', ',', ';', ':', '!').trim()
        // Markdown emphasis, which otherwise shows up literally in the list.
        text = text.replace("**", "").replace("__", "").trim()

        if (text.isEmpty()) return null
        // A whole paragraph is not a title and never becomes one.
        if (text.length > MAX_TITLE_PROSE_CHARS) return null
        if (text.length > MAX_TITLE_CHARS) {
            // A few words over the limit is a model that answered in a sentence,
            // and cutting it at the last whole word still names the chat.
            // Refusing outright is what left the heuristic guess -- the raw first
            // message -- standing as the name for good.
            val cut = text.take(MAX_TITLE_CHARS)
            text = cut.substringBeforeLast(' ', cut).trim(*SENTENCE_END).trim()
            if (text.length < MIN_TITLE_CHARS) return null
        }
        // The model is allowed to say there is no subject yet, and it sometimes
        // names the chat after the greeting anyway. Both answers are refused:
        // "Новый чат" is a better row than "Привет", because it does not look
        // like a name anyone chose.
        if (text.lowercase().trim { !it.isLetterOrDigit() } in DECLINED) return null
        if (isSmallTalk(text)) return null
        return text
    }

    private companion object {
        private const val SYSTEM =
            "You name chat conversations. Reply with nothing but the name.\n" +
                "Rules: 2 to 4 words. No quotes, no final punctuation, no emoji, no " +
                "markdown, no prefix such as \"Title:\". Write it in the language " +
                "the user writes in.\n" +
                "Name the subject, never the words. Do not copy, quote or shorten " +
                "the message: a name says what the conversation is about, it does " +
                "not repeat what was typed. Name the concrete task where there is " +
                "one -- \"Fix Gradle build failure\", not \"User request\" or \"Help " +
                "with code\" -- and where there is none, name what the exchange is.\n" +
                "Examples:\n" +
                "привет -> Приветствие\n" +
                "как дела? ты любишь мороженое? я да -> Разговор о мороженом\n" +
                "привет, у меня падает сборка gradle -> Ошибка сборки Gradle\n" +
                "hi -> Greeting\n" +
                "check my resume for a backend role -> Backend resume review\n" +
                "Reply with exactly NONE only when there is no text at all."

        private const val PROMPT =
            "Name this conversation. Reply with the name and nothing else:\n\n"

        /** Enough to know the subject; the rest is never the point. */
        private const val MAX_MATERIAL_CHARS = 2_000

        /** A six-word title cannot need more, and a cap keeps a rambling model cheap. */
        private const val MAX_TOKENS = 40

        /** Longer than this is cut back to the last whole word. */
        private const val MAX_TITLE_CHARS = 64

        /** Longer than this is prose, not a title, and is rejected outright. */
        private const val MAX_TITLE_PROSE_CHARS = 160

        /** Below this, whatever survived the cut is not a name. */
        private const val MIN_TITLE_CHARS = 6

        // Raised from twenty seconds: a reasoning model can still be thinking at
        // that point, and the cost of waiting is a title arriving late.
        private const val TIMEOUT_MS = 90_000L

        /**
         * Below this a chat is too new to be named after its small talk.
         *
         * A lone "привет" is usually followed by the actual request, so it
         * waits one turn. Once there is an answer under it, the theme is all
         * this conversation is ever going to be.
         */
        private const val MIN_TURNS_FOR_THEME = 2

        /** Both sides of the opening, which is where the subject usually is. */
        private const val MAX_MATERIAL_MESSAGES = 8

        /** Per message: naming needs the topic sentence, not the whole paste. */
        private const val MAX_MESSAGE_CHARS = 600

        private const val USER_LABEL = "User: "
        private const val ASSISTANT_LABEL = "Assistant: "

        /** Written by the context compactor; a summary is not a subject. */
        private const val COMPACTION_MARKER = "[sirius:context-compacted]"

        /** The model's ways of saying there is nothing to name yet. */
        private val DECLINED = setOf(
            "none", "n/a", "na", "unknown", "no title", "untitled",
            "нет", "без названия", "неизвестно"
        )
    }
}

/**
 * Whether there is anything here worth naming a conversation after.
 *
 * "привет", "тест" and "ок" describe no task, and a chat named after one of them
 * is worse than a chat still called "New chat": the placeholder says "not yet",
 * while "привет" looks like a name that was chosen. Both the instant heuristic
 * title and the model request are gated on this, so an opener leaves the
 * placeholder alone and the next message gets another chance.
 */
internal fun hasTitleSubstance(text: String): Boolean {
    val rest = withoutOpeners(text) ?: return false
    val letters = rest.count { it.isLetterOrDigit() }
    if (letters < MIN_SUBJECT_CHARS) return false
    val words = rest.split(' ').count { part -> part.any { it.isLetterOrDigit() } }
    // One long word can be a subject ("гидропоника"); one short word cannot.
    return words > 1 || letters >= MIN_SINGLE_WORD_CHARS
}

/** Whether the text is a greeting or an acknowledgement and nothing more. */
internal fun isSmallTalk(text: String): Boolean = withoutOpeners(text) == null

/**
 * The message with its greeting peeled off, in the case it was typed in.
 *
 * "привет тебе нравится мороженое" is a greeting followed by a subject, and
 * only the second half belongs in a title. [withoutOpeners] lowercases as it
 * matches, which is right for a test and wrong for a name, so the match is
 * mapped back onto the text the user actually typed.
 *
 * Returns null when the message is nothing but greeting.
 */
internal fun titleSubject(text: String): String? {
    val rest = withoutOpeners(text) ?: return null
    val flat = text.trim().replace(Regex("\\s+"), " ")
    val at = flat.lowercase().indexOf(rest)
    val tail = if (at < 0) flat else flat.substring(at).trim { !it.isLetterOrDigit() }.ifBlank { flat }
    return firstSubject(tail)
}

/**
 * The one sentence in [text] a name can come from.
 *
 * A message is usually several sentences and only one of them is the point:
 * "ты любишь мороженое? я да" is a subject followed by an aside, and a row
 * reading "Ты любишь мороженое? я да" is the raw message with a capital letter,
 * not a name. The first sentence that describes something is taken, and the
 * rest is left to the model, which sees the whole conversation anyway.
 */
private fun firstSubject(text: String): String {
    val whole = text.trim().trim(*SENTENCE_END).trim()
    val sentences = text
        .split(SENTENCE_SPLIT)
        .map { it.trim().trim(*SENTENCE_END).trim() }
        .filter { it.isNotBlank() }
    if (sentences.size <= 1) return whole.ifBlank { text.trim() }
    val chosen = sentences.firstOrNull { hasTitleSubstance(it) }
        ?: sentences.first()
    return chosen.ifBlank { whole.ifBlank { text.trim() } }
}

/** Sentence boundaries, kept simple: the end mark plus the space after it. */
private val SENTENCE_SPLIT = Regex("(?<=[.!?\u2026])\\s+|\\n+")

/** Punctuation a title never ends on. */
private val SENTENCE_END = charArrayOf(
    '.', '!', '?', '\u2026', ',', ';', ':', '-', '\u2014', ' '
)

/**
 * The text with leading greetings peeled off, or null when nothing is left.
 *
 * "привет, у меня падает сборка" is a request with a greeting in front of it, and
 * only what follows describes the task. "привет))" is the whole message.
 */
private fun withoutOpeners(text: String): String? {
    var rest = text.trim()
        .replace(Regex("\\s+"), " ")
        .lowercase()
        .trim { !it.isLetterOrDigit() }
    if (rest.isEmpty()) return null

    var peeling = true
    while (peeling) {
        peeling = false
        for (opener in SMALL_TALK) {
            if (rest == opener) return null
            if (!rest.startsWith(opener)) continue
            // A greeting ends wherever the writer stopped writing it, and that is
            // rarely a space: "привет," "как дела?" "хай!" "здарова..." are the
            // same word with punctuation behind it. Matching only the space and
            // comma forms is what left a chat named "Как дела? ты любишь м…" --
            // the question mark meant nothing was peeled and the whole message
            // became the name.
            val next = rest.getOrNull(opener.length) ?: return null
            if (next.isLetterOrDigit()) continue
            rest = rest.drop(opener.length).trim { !it.isLetterOrDigit() }
            if (rest.isEmpty()) return null
            peeling = true
            break
        }
    }
    return rest
}

/** Below this there is not enough text to name anything. */
private const val MIN_SUBJECT_CHARS = 10

/** A lone word has to be a real term to stand as a title. */
private const val MIN_SINGLE_WORD_CHARS = 12

/**
 * Openings that carry no subject. Deliberately short and literal: this gates
 * naming, not language detection, and anything it misses is simply named one
 * message later.
 */
private val SMALL_TALK = setOf(
    "привет", "приветик", "прив", "здравствуй", "здравствуйте", "хай", "ку",
    "добрый день", "доброе утро", "добрый вечер", "доброй ночи", "салам",
    "как дела", "что делаешь", "ты тут", "ты здесь", "тест", "проверка",
    "спасибо", "спс", "пожалуйста", "ок", "окей", "ага", "да", "нет", "ясно",
    "понятно", "давай", "продолжай",
    "hi", "hey", "hello", "yo", "sup", "good morning", "good evening",
    "how are you", "test", "testing", "ping", "thanks", "thank you", "ok",
    "okay", "yes", "no", "cool", "nice", "go on", "continue"
)
