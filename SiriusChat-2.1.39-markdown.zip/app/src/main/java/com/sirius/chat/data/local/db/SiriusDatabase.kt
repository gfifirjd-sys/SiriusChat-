package com.sirius.chat.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.sirius.chat.data.local.db.dao.ChatDao
import com.sirius.chat.data.local.db.dao.MemoryDao
import com.sirius.chat.data.local.db.dao.MemoryFileDao
import com.sirius.chat.data.local.db.dao.ProjectDao
import com.sirius.chat.data.local.db.entity.ChatMessageEntity
import com.sirius.chat.data.local.db.entity.ChatSessionEntity
import com.sirius.chat.data.local.db.entity.MemoryEntity
import com.sirius.chat.data.local.db.entity.MemoryFileEntity
import com.sirius.chat.data.local.db.entity.ProjectEntity
import com.sirius.chat.data.local.db.entity.RecentFileEntity

@Database(
    entities = [
        ProjectEntity::class,
        RecentFileEntity::class,
        ChatSessionEntity::class,
        ChatMessageEntity::class,
        MemoryEntity::class,
        MemoryFileEntity::class
    ],
    version = 8,
    exportSchema = false
)
abstract class SiriusDatabase : RoomDatabase() {

    abstract fun projectDao(): ProjectDao
    abstract fun chatDao(): ChatDao
    abstract fun memoryDao(): MemoryDao
    abstract fun memoryFileDao(): MemoryFileDao

    companion object {

        /**
         * Adds the per-chat feature switches.
         *
         * ### Why this is a real migration
         * The builder below still falls back to destroying the database, and for
         * v1 that was defensible: the schema was new and nobody had months of
         * conversations in it. It is not defensible now. Bumping to 2 without
         * this migration would silently delete every chat on the device the first
         * time the user opened the updated app -- to add a settings panel. That
         * is the single worst possible trade in this codebase.
         *
         * One `ALTER TABLE` is all it takes, which is precisely why the flags are
         * packed into one column rather than five.
         *
         * `DEFAULT -1` matches [ChatSessionEntity.INHERIT_FEATURES], so every
         * pre-existing conversation reads as "follow the user's defaults" instead
         * of "the user switched everything off".
         */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE chat_sessions ADD COLUMN featureFlags INTEGER NOT NULL DEFAULT -1"
                )
            }
        }

        /**
         * Adds the per-chat context meter and per-message token counts.
         *
         * Two columns, both with defaults that read as "unknown" rather than
         * "zero": -1 is the inherit sentinel the meter already uses, and an
         * empty usage string means nobody counted this turn. A `DEFAULT 0` on
         * the token columns would have quietly claimed every conversation in
         * the archive was free.
         */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE chat_sessions ADD COLUMN contextMeter INTEGER NOT NULL DEFAULT -1"
                )
                db.execSQL(
                    "ALTER TABLE chat_messages ADD COLUMN usageJson TEXT NOT NULL DEFAULT ''"
                )
            }
        }

        /**
         * Adds long-term memory: the facts table, and the per-chat switch.
         *
         * A real migration for the same reason as the two above -- this ships to
         * devices that already hold months of conversations, and adding a feature
         * is never a reason to delete them.
         *
         * The defaults here have to match the ones declared on
         * [com.sirius.chat.data.local.db.entity.MemoryEntity] exactly, or Room
         * refuses to open the database on the next launch: it compares the schema
         * it expects against the one it finds, down to each column default. The
         * new `memory` column reuses the same -1 inherit sentinel as
         * `contextMeter`, so every existing chat follows the global setting
         * rather than arriving with the feature silently switched off.
         */
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS memory_nodes (
                        id TEXT NOT NULL PRIMARY KEY,
                        content TEXT NOT NULL,
                        category TEXT NOT NULL,
                        links TEXT NOT NULL DEFAULT '',
                        source TEXT NOT NULL DEFAULT 'chat',
                        sessionId TEXT,
                        createdAt INTEGER NOT NULL,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "ALTER TABLE chat_sessions ADD COLUMN memory INTEGER NOT NULL DEFAULT -1"
                )
            }
        }

        /**
         * Files every fact under a subject: the `topic` column.
         *
         * `DEFAULT ''` has to be spelled the same way here and on the entity,
         * or Room's schema check fails on the next launch. Empty reads as "not
         * filed yet", which is exactly what every fact learned before this
         * build is -- they keep grouping by category until something new is
         * written about the same subject.
         */
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE memory_nodes ADD COLUMN topic TEXT NOT NULL DEFAULT ''"
                )
            }
        }

        /**
         * Gives memory files a version and a set of aliases.
         *
         * ### Why a second table rather than more columns
         * The version belongs to the file, not to any one fact in it, and the
         * facts are what `memory_nodes` holds. Hanging a version off every row
         * would mean six rows disagreeing about what version `/topics/food.md`
         * is at the moment one of them is edited.
         *
         * Nothing is backfilled on purpose: a file that only exists because
         * older facts point at it reads as version 1 in code, so the first write
         * to it inserts the row. Backfilling would touch every install to write
         * rows that say exactly what the default already says.
         *
         * The defaults below have to be spelled exactly as they are on
         * [com.sirius.chat.data.local.db.entity.MemoryFileEntity] or Room
         * refuses to open the database on the next launch.
         */
        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS memory_files (
                        path TEXT NOT NULL PRIMARY KEY,
                        aliases TEXT NOT NULL DEFAULT '',
                        version INTEGER NOT NULL DEFAULT 1,
                        updatedAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        /**
         * Adds the flag that says a chat is still named by the app.
         *
         * Existing rows get 0: they already have names, and the titler must
         * never rewrite one the user has been living with. The default is
         * spelled exactly as it is on
         * [com.sirius.chat.data.local.db.entity.ChatSessionEntity] or Room
         * refuses to open the database on the next launch.
         */
        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE chat_sessions ADD COLUMN titleAuto INTEGER NOT NULL DEFAULT 0"
                )
            }
        }

        /**
         * Adds the heading and the one-line description a memory file is shown
         * with.
         *
         * Existing rows get empty strings and are named from their path until
         * the model gives them a real heading. The defaults are spelled exactly
         * as they are on
         * [com.sirius.chat.data.local.db.entity.MemoryFileEntity] or Room
         * refuses to open the database on the next launch.
         */
        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE memory_files ADD COLUMN title TEXT NOT NULL DEFAULT ''"
                )
                db.execSQL(
                    "ALTER TABLE memory_files ADD COLUMN summary TEXT NOT NULL DEFAULT ''"
                )
            }
        }

        fun build(context: Context): SiriusDatabase = Room
            .databaseBuilder(context.applicationContext, SiriusDatabase::class.java, "sirius.db")
            .addMigrations(
                MIGRATION_1_2,
                MIGRATION_2_3,
                MIGRATION_3_4,
                MIGRATION_4_5,
                MIGRATION_5_6,
                MIGRATION_6_7,
                MIGRATION_7_8
            )
            // Kept as the last resort for a database from a build that never
            // shipped, but it is now unreachable for any released version --
            // every step from 1 has a migration above.
            .fallbackToDestructiveMigration()
            .build()
    }
}
