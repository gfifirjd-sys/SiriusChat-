package com.sirius.chat.core.designsystem.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.siriusTween

/**
 * Lightweight top bar. It deliberately avoids Material's TopAppBar so the metal
 * background of the screen shows through instead of an opaque container.
 *
 * Two details do an app bar's job without the box: when [scrolled] is true a
 * scrim fades in behind the row so the title stays legible over content, and a
 * hairline seam appears at the bottom edge. Both animate, so scrolling a list
 * never makes the chrome blink.
 */
@Composable
fun SiriusTopBar(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    scrolled: Boolean = false,
    onBack: (() -> Unit)? = null,
    /**
     * The glyph on the leading button. A full-screen scene is closed rather
     * than backed out of, and a cross is how that is said.
     */
    backIcon: ImageVector = Icons.AutoMirrored.Rounded.ArrowBack,
    backDescription: String? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    val colors = SiriusTheme.colors
    val scrim by animateFloatAsState(
        targetValue = if (scrolled) 1f else 0f,
        animationSpec = siriusTween(SiriusMotion.Base),
        label = "topBarScrim"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .drawBehind {
                if (scrim <= 0.01f) return@drawBehind
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to colors.background.copy(alpha = 0.94f * scrim),
                        0.7f to colors.background.copy(alpha = 0.8f * scrim),
                        1f to Color.Transparent
                    )
                )
                drawRect(
                    color = colors.outline.copy(alpha = colors.outline.alpha * scrim),
                    topLeft = Offset(0f, size.height - 1f),
                    size = Size(size.width, 1f)
                )
            }
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (onBack != null) {
            GlassIconButton(
                icon = backIcon,
                contentDescription = backDescription ?: stringResource(R.string.action_back),
                onClick = onBack
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.semantics { heading() }
            )
            // Subtitles carry live data (model, branch, file count), so they
            // cross-fade rather than pop the bar's height around.
            AnimatedVisibility(
                visible = subtitle != null,
                enter = fadeIn(siriusTween(SiriusMotion.Quick)),
                exit = fadeOut(siriusTween(SiriusMotion.Instant))
            ) {
                Text(
                    text = subtitle.orEmpty(),
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        actions()
    }
}

/**
 * Compact one-line header for nested surfaces (sheets, panels) that must not
 * claim the status bar.
 */
@Composable
fun SiriusPanelHeader(
    title: String,
    modifier: Modifier = Modifier,
    trailing: @Composable RowScope.() -> Unit = {}
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = colors.textSecondary,
            modifier = Modifier
                .weight(1f)
                .semantics { heading() },
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        trailing()
    }
}
