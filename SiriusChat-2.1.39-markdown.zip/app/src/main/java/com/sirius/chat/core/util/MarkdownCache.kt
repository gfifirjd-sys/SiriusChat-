package com.sirius.chat.core.util

/**
 * Parsed markdown that survives scrolling.
 *
 * ### The problem this solves
 * `MarkdownText` memoises its parse with `remember(markdown)`, which is correct
 * and is not enough. A `LazyColumn` destroys the composition of a message that
 * leaves the screen, so `remember` goes with it: scrolling up through fifty
 * answers re-parses all fifty, and scrolling back down parses them again. On a
 * slow phone that is the stutter the user feels while dragging.
 *
 * The parse depends on nothing but the text, so the result can outlive the
 * composition that produced it. Keyed by the text itself rather than a message
 * id because an edited message is a different document with the same id.
 *
 * ### Why streaming answers are not cached
 * A live answer changes every flush, so each version would be a distinct key
 * that is never asked for again -- a few hundred insertions per reply, evicting
 * every finished message on the way past. The streaming bubble therefore passes
 * `cacheable = false` and simply re-parses, which it has to do anyway.
 */
object MarkdownCache {

    private val entries = object : LinkedHashMap<String, List<MarkdownBlock>>(
        INITIAL_CAPACITY,
        LOAD_FACTOR,
        // Access order, so the cache keeps what is being read rather than what
        // happened to be inserted most recently.
        true
    ) {
        override fun removeEldestEntry(
            eldest: MutableMap.MutableEntry<String, List<MarkdownBlock>>
        ): Boolean = size > MAX_ENTRIES
    }

    /**
     * The blocks for [markdown], parsing only if this exact text is unknown.
     *
     * Synchronised because the background parse in `MarkdownText` runs off the
     * main thread while other messages are being composed on it.
     */
    @Synchronized
    fun blocks(markdown: String): List<MarkdownBlock> {
        // A very long document is cheap to parse relative to how much of the
        // cache it would occupy, so it is parsed and forgotten.
        if (markdown.length > MAX_CACHED_CHARS) return MarkdownParser.parse(markdown)
        entries[markdown]?.let { return it }
        val parsed = MarkdownParser.parse(markdown)
        entries[markdown] = parsed
        return parsed
    }

    @Synchronized
    fun clear() {
        entries.clear()
    }

    private const val INITIAL_CAPACITY = 24
    private const val LOAD_FACTOR = 0.75f

    /** Roughly two screens of history in each direction. */
    private const val MAX_ENTRIES = 40

    private const val MAX_CACHED_CHARS = 20_000
}
