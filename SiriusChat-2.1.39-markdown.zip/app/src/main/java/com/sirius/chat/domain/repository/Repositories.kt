package com.sirius.chat.domain.repository

import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.FileNode
import com.sirius.chat.domain.model.MessageHit
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.ProjectSnapshot
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.RecentFile
import com.sirius.chat.domain.model.TextMatch
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    val settings: Flow<AppSettings>
    suspend fun current(): AppSettings
    suspend fun update(transform: (AppSettings) -> AppSettings)
}

interface ProjectRepository {
    fun observeProjects(): Flow<List<Project>>
    fun observeProject(id: String): Flow<Project?>
    fun observeRecentFiles(projectId: String, limit: Int = 12): Flow<List<RecentFile>>
    suspend fun get(id: String): Project?
    suspend fun upsert(project: Project)
    suspend fun delete(id: String)
    suspend fun touch(id: String)
    suspend fun setFavorite(id: String, favorite: Boolean)
    suspend fun rememberFile(file: RecentFile)
    suspend fun updateFilePosition(documentId: String, caretOffset: Int, scrollLine: Int)
}

interface ChatRepository {
    fun observeSessions(projectId: String? = null): Flow<List<ChatSession>>
    fun observeMessages(sessionId: String): Flow<List<ChatMessage>>
    suspend fun getSession(id: String): ChatSession?
    suspend fun createSession(session: ChatSession): ChatSession
    suspend fun updateSession(session: ChatSession)
    suspend fun deleteSession(id: String)
    suspend fun setPinned(id: String, pinned: Boolean)
    suspend fun messages(sessionId: String): List<ChatMessage>
    suspend fun addMessage(message: ChatMessage)
    suspend fun updateMessage(message: ChatMessage)
    suspend fun deleteMessage(id: String)
    /** Removes [messageId] and everything created after it, used by edit/regenerate. */
    suspend fun truncateFrom(sessionId: String, messageId: String)
    suspend fun saveDraft(sessionId: String, draft: String)
    suspend fun draft(sessionId: String): String

    /**
     * Searches message text across every chat, newest first.
     *
     * Returns empty for anything shorter than two characters: a one-letter query
     * matches most of the history, which is the same as matching nothing.
     */
    suspend fun searchMessages(query: String, limit: Int = 40): List<MessageHit>
}

interface ProviderRepository {
    /** Providers the user kept. Removed shipped templates are excluded. */
    fun observeProviders(): Flow<List<ProviderConfig>>

    /** Everything on disk, hidden templates included; only the providers screen needs this. */
    fun observeAllProviders(): Flow<List<ProviderConfig>>

    suspend fun providers(): List<ProviderConfig>
    suspend fun get(id: String): ProviderConfig?
    suspend fun upsert(config: ProviderConfig)

    /**
     * Removes a custom provider. Shipped templates cannot be removed from disk,
     * so they are disabled and hidden from the list instead.
     */
    suspend fun delete(id: String)

    /** Brings a hidden shipped template back into the list. */
    suspend fun setEnabled(id: String, enabled: Boolean)
    suspend fun setApiKey(providerId: String, key: String)
    suspend fun apiKey(providerId: String): String?
    suspend fun clearApiKey(providerId: String)
}

/**
 * Storage Access Framework backed workspace. Every operation is suspending and
 * runs off the main thread; nothing traverses the whole tree eagerly.
 */
interface WorkspaceRepository {
    fun persistAccess(treeUri: String)
    fun hasAccess(treeUri: String): Boolean
    fun releaseAccess(treeUri: String)
    suspend fun rootNode(treeUri: String): FileNode?
    suspend fun listChildren(treeUri: String, documentId: String, parentPath: String): List<FileNode>
    suspend fun readText(treeUri: String, documentId: String, maxBytes: Long = 2L * 1024 * 1024): String
    suspend fun writeText(treeUri: String, documentId: String, content: String): Boolean
    suspend fun createFile(treeUri: String, parentDocumentId: String, name: String): FileNode?
    suspend fun createDirectory(treeUri: String, parentDocumentId: String, name: String): FileNode?
    suspend fun rename(treeUri: String, documentId: String, newName: String): String?
    suspend fun delete(treeUri: String, documentId: String): Boolean
    suspend fun copy(treeUri: String, documentId: String, targetParentId: String): FileNode?
    suspend fun move(treeUri: String, documentId: String, sourceParentId: String, targetParentId: String): FileNode?
    suspend fun findByPath(treeUri: String, path: String): FileNode?
    suspend fun searchFiles(treeUri: String, query: String, limit: Int = 200): List<FileNode>
    suspend fun searchText(treeUri: String, query: String, limit: Int = 200): List<TextMatch>
    suspend fun snapshot(treeUri: String, maxEntries: Int = 400): ProjectSnapshot
    suspend fun exists(treeUri: String, path: String): Boolean
}

/**
 * Facts about the user that outlive any single conversation.
 *
 * Small on purpose: the graph is read whole by the prompt builder on every
 * request and by the memory screen while it is open, so there is no paging, no
 * search and no partial load to design around.
 */
interface MemoryRepository {
    fun observeNodes(): Flow<List<com.sirius.chat.domain.model.MemoryNode>>

    /** The most recently touched facts, already capped for prompt use. */
    suspend fun nodes(): List<com.sirius.chat.domain.model.MemoryNode>

    /** Inserts new facts and replaces existing ones by id. */
    suspend fun save(nodes: List<com.sirius.chat.domain.model.MemoryNode>)

    /** Every known file with its version and aliases; files implied by facts are not in here. */
    suspend fun files(): List<com.sirius.chat.domain.model.MemoryFile>

    /** The same files, for the screen that lists them while they change. */
    fun observeFiles(): Flow<List<com.sirius.chat.domain.model.MemoryFile>>

    /** Records the new version of the files a write touched. */
    suspend fun saveFiles(files: List<com.sirius.chat.domain.model.MemoryFile>)

    suspend fun delete(id: String)

    /** Deletes one file: its row, and every fact filed in it. */
    suspend fun deleteFile(path: String)

    suspend fun clear()
}
