package com.sirius.chat.core.designsystem.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.effects.metalBevelBrush
import com.sirius.chat.core.designsystem.revealIn

/**
 * Stops a drag that began inside a sheet's scroll area from being handed to the
 * sheet itself.
 *
 * `ModalBottomSheet` wires a nested-scroll connection into its own body: any
 * scroll a child does not use is fed to the sheet, so a list that is already at
 * the top turns the next downward flick into a dismissal. That is the "I was
 * only scrolling and it closed" bug. This connection sits *between* the list and
 * the sheet and swallows the leftovers, which leaves exactly three deliberate
 * ways out -- the handle, the scrim and Back.
 *
 * Upward drags are left alone: the sheet only steals those while it still has
 * room to expand, and with `skipPartiallyExpanded` it never does.
 */
@Composable
fun rememberSheetDragGuard(): NestedScrollConnection = remember {
    object : NestedScrollConnection {
        override fun onPostScroll(
            consumed: Offset,
            available: Offset,
            source: androidx.compose.ui.input.nestedscroll.NestedScrollSource
        ): Offset = Offset(0f, available.y)

        override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity =
            available
    }
}

/**
 * Apply to a scroll container that lives inside a [SiriusBottomSheet] and does
 * its own scrolling (a `LazyColumn`, a `verticalScroll` column). Sheets that let
 * [SiriusBottomSheet] scroll for them get this for free.
 */
@Composable
fun Modifier.sheetDragGuard(): Modifier = nestedScroll(rememberSheetDragGuard())

/**
 * Swallows a vertical drag that no scrollable child claimed.
 *
 * ### Why the nested-scroll guard is not enough on its own
 * [rememberSheetDragGuard] can only see gestures a scrollable child *dispatched*.
 * A drag that starts on the sheet's title, on a search field, on the gap beside
 * a list or on a footer button is never dispatched as a scroll at all: it goes
 * straight to the sheet's own drag handling, and the sheet closes. On a picker
 * where the list is a bounded box in the middle of the body, that is most of the
 * sheet's surface -- which is exactly how "I flicked upwards and it closed"
 * happens even with the guard in place.
 *
 * This runs in the Main pass, where children are dispatched to first, so a list
 * that took the drag has already consumed it and this handler cancels itself.
 * Only the leftovers -- drags on non-scrollable furniture -- are eaten here.
 *
 * Opt-in per sheet ([SiriusBottomSheet]'s `lockBodyDrag`) because for a short,
 * fully visible sheet, swiping the body down *is* the expected way to close it.
 * It is the long, list-driven sheets that need the body to stop being a dismiss
 * surface.
 */
fun Modifier.sheetBodyDragLock(): Modifier = this.pointerInput(Unit) {
    detectVerticalDragGestures { _, _ -> }
}

/**
 * Shared sheet styling so every modal in Sirius looks like the same object.
 *
 * The container is the elevated background rather than a metal plate -- a sheet
 * is the room, not a control -- but it gets the same lit top edge as every plate
 * in the app, so it still belongs to the family.
 *
 * Two rules keep tall sheets usable. The body is capped short of the status bar,
 * so the title and the handle are always on screen instead of sliding under the
 * clock; and whatever does not fit scrolls, instead of being quietly clipped at
 * the bottom edge. Pass `scrollable = false` when the content already contains
 * its own scroll container -- nesting two of them is what makes a sheet feel like
 * it randomly refuses to scroll.
 *
 * @param lockBodyDrag stops the body from acting as a drag-to-dismiss surface.
 *   Set it on sheets whose body is mostly a scrolling list, where a stray flick
 *   on the furniture around the list should not close the sheet.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SiriusBottomSheet(
    title: String,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    scrollable: Boolean = true,
    lockBodyDrag: Boolean = false,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = SiriusTheme.colors
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val shape = RoundedCornerShape(topStart = SiriusRadius.xl, topEnd = SiriusRadius.xl)
    val scrollState = rememberScrollState()
    val dragGuard = rememberSheetDragGuard()

    // 88dp is the status bar plus a thumb's worth of scrim: enough that the sheet
    // always reads as a sheet and never as a second screen pasted over the app.
    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    val maxSheetHeight = (screenHeight - 88.dp).coerceAtLeast(240.dp)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.backgroundElevated,
        contentColor = colors.textPrimary,
        scrimColor = Color.Black.copy(alpha = 0.55f),
        shape = shape,
        dragHandle = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    // The lit rim of the sheet, matching every metal plate.
                    .drawBehind {
                        drawRect(
                            brush = metalBevelBrush(colors, 0.9f),
                            size = Size(size.width, 1.2f)
                        )
                    }
                    .padding(top = 12.dp, bottom = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 40.dp, height = 4.dp)
                        .clip(RoundedCornerShape(SiriusRadius.pill))
                        // Flat handle: a shaded one only made sense while
                        // every surface was a lit plate.
                        .background(colors.metalRimLight)
                )
            }
        }
    ) {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .heightIn(max = maxSheetHeight)
        ) {
            // The header stays put while the body scrolls under it: on a long
            // sheet the title is the only thing telling you what you are in.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .revealIn(index = 0)
                    .padding(horizontal = SiriusSpacing.md),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        color = colors.textPrimary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.semantics { heading() }
                    )
                    if (subtitle != null) {
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textTertiary
                        )
                    }
                }
                actions()
            }
            VSpace(SiriusSpacing.sm)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    // The keyboard is an inset, not a window resize: the app is
                    // edge-to-edge, so without this the field being typed into
                    // and the buttons under it sit behind the keyboard, and the
                    // first tap lands on the keyboard instead of the control.
                    .imePadding()
                    // No entrance animation on the body, deliberately. A node
                    // that is still translating slides out from under a
                    // stationary finger, and Compose reads that as "the press
                    // left the control": the tap is cancelled instead of
                    // firing, and a flick spends its slop on the animation
                    // rather than on the list. That is the first tap and the
                    // first swipe on a freshly opened sheet doing nothing. The
                    // sheet window already animates in; the body does not need
                    // to arrive a second time, and the header still does.
                    // Ordered outermost-first: the lock is above the scroll, so a
                    // scrolling child still wins the gesture and only what it
                    // refuses is swallowed here.
                    .let { base -> if (lockBodyDrag) base.sheetBodyDragLock() else base }
                    .let { base ->
                        if (scrollable) {
                            base.nestedScroll(dragGuard).verticalScroll(scrollState)
                        } else {
                            base
                        }
                    }
                    .padding(horizontal = SiriusSpacing.md)
            ) {
                content()
                VSpace(SiriusSpacing.lg)
            }
        }
    }
}
