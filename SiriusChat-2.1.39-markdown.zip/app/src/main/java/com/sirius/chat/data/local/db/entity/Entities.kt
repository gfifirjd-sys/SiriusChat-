package com.sirius.chat.data.local.db.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val treeUri: String?,
    val workspaceLabel: String,
    val providerId: String?,
    val model: String?,
    val accentIndex: Int,
    val favorite: Boolean,
    val createdAt: Long,
    val lastOpenedAt: Long
)

@Entity(
    tableName = "recent_files",
    primaryKeys = ["documentId", "projectId"],
    indices = [Index("projectId"), Index("openedAt")]
)
data class RecentFileEntity(
    val documentId: String,
    val projectId: String,
    val name: String,
    val path: String,
    val openedAt: Long,
    val caretOffset: Int,
    val scrollLine: Int
)

@Entity(
    tableName = "chat_sessions",
    indices = [Index("projectId"), Index("updatedAt")]
)
data class ChatSessionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val projectId: String?,
    val providerId: String,
    val model: String,
    val agentMode: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean,
    val draft: String = "",
    /**
     * The chat's feature switches, packed into one integer.
     *
     * ### Why a bitmask and not five columns
     * Five booleans would be more readable in a `SELECT`, and that is genuinely
     * the only thing they would be better at. Against it: five `ALTER TABLE`
     * statements in the migration instead of one, five more parameters threaded
     * through `toEntity`/`toDomain`, and — the deciding factor — a schema change
     * every single time a switch is added to the settings panel. A sixth feature
     * is a new bit here and nothing else; as a column it is another migration and
     * another version bump for every user.
     *
     * The packing is confined to [com.sirius.chat.data.repository.ChatFeatureFlags],
     * so nothing outside that object ever sees an integer.
     *
     * ### Why the default is declared twice
     * `@ColumnInfo(defaultValue = "-1")` is not redundant with the Kotlin default.
     * Room ignores Kotlin defaults when it builds the schema it expects to find,
     * and it *does* compare column defaults during validation. The migration adds
     * this column with `DEFAULT -1`, so without the annotation a fresh install
     * (no default in `CREATE TABLE`) and an upgraded install (default present)
     * would have different schemas -- and only the upgraded one would crash, on
     * the user's device, well after this code was reviewed. Declaring it here
     * makes both paths produce the same table.
     *
     * ### Why the default is negative
     * `-1` is not a set of flags, it is the absence of one: this session has never
     * had its switches touched, so it should follow the user's defaults from
     * [com.sirius.chat.domain.model.AppSettings]. A `0` default would be
     * indistinguishable from "the user deliberately turned everything off", which
     * would silently disable streaming for every conversation that existed before
     * this column did.
     */
    @ColumnInfo(defaultValue = "-1")
    val featureFlags: Int = INHERIT_FEATURES,
    /** Context meter: -1 follows the global default, 0 off, 1 on. */
    val contextMeter: Int = -1,
    /**
     * Long-term memory in this chat: -1 follows the global default, 0 off, 1 on.
     *
     * Off means the model is not *told* what is known about the user; facts are
     * still learned from the conversation, because the switch is about this
     * chat's answers, not about forgetting the person.
     */
    @ColumnInfo(defaultValue = "-1")
    val memory: Int = -1,
    /**
     * 1 while the title is still the app's guess and the model may replace it.
     *
     * Rows that existed before this column get 0 on purpose: those chats have
     * had their names for a while, and silently renaming them on the next
     * message would read as data loss. New sessions are inserted with 1.
     *
     * The default has to be spelled the same here and in the migration or Room
     * refuses to open the database on the next launch.
     */
    @ColumnInfo(defaultValue = "0")
    val titleAuto: Boolean = false
) {
    companion object {
        /** Sentinel for "no explicit choice stored". */
        const val INHERIT_FEATURES = -1
    }
}

@Entity(
    tableName = "chat_messages",
    indices = [Index("sessionId"), Index("createdAt")],
    foreignKeys = [
        ForeignKey(
            entity = ChatSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val role: String,
    val content: String,
    val createdAt: Long,
    val model: String?,
    val providerId: String?,
    val status: String,
    val error: String?,
    /** JSON encoded attachments; small and read together with the message. */
    val attachmentsJson: String = "[]",
    val toolRunsJson: String = "[]",
    /** JSON token counts; empty for a turn that never reported any. */
    val usageJson: String = ""
)

/** Denormalised counters used by the sessions list. */
/**
 * One message that matched a search, with the chat it belongs to.
 *
 * A projection rather than the entity: a hit list needs a title and a fragment,
 * and loading whole message rows -- attachments, tool runs, usage JSON -- to show
 * one line of text would read megabytes to display kilobytes.
 */
data class MessageHitRow(
    val messageId: String,
    val sessionId: String,
    val sessionTitle: String,
    val content: String,
    val createdAt: Long
)

data class SessionWithStats(
    val id: String,
    val title: String,
    val projectId: String?,
    val providerId: String,
    val model: String,
    val agentMode: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean,
    val messageCount: Int,
    val lastMessagePreview: String?
)

/**
 * One durable fact about the user, stored outside any conversation.
 *
 * Deliberately not tied to a session by foreign key: a fact learned in a chat
 * outlives that chat, and deleting the conversation must not delete what was
 * learned in it. [sessionId] is provenance only and may point at a row that is
 * long gone.
 *
 * [links] holds newline separated node ids rather than a join table -- the graph
 * is always read whole, so there is no query a second table would speed up, and
 * ids are UUIDs, so the separator can never appear inside one.
 */
@Entity(tableName = "memory_nodes")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val content: String,
    /** [com.sirius.chat.domain.model.MemoryCategory] wire name. */
    val category: String,
    /**
     * The file this fact is filed under, as a slug: "food", "sirius-chat".
     *
     * Empty means "not filed", which is how every row written before this
     * column existed reads -- they group by category instead, so nothing that
     * was already learned loses its place in the graph.
     */
    @ColumnInfo(defaultValue = "") val topic: String = "",
    @ColumnInfo(defaultValue = "") val links: String = "",
    @ColumnInfo(defaultValue = "chat") val source: String = "chat",
    val sessionId: String? = null,
    val createdAt: Long,
    val updatedAt: Long
)

/**
 * One memory file: the version its lines were last written at, and the other
 * names the same subject arrives under.
 *
 * ### Why the lines are not in here
 * The facts stay in `memory_nodes`, one row each, because that is what the
 * graph draws and what the prompt builder groups. This table holds only what a
 * row cannot: the version an edit has to match, and the aliases that stop the
 * same subject opening a second file. A file with no row here still exists --
 * every path implied by an older fact reads as version 1 -- so the feature
 * degrades to exactly its previous behaviour instead of losing anything.
 *
 * [aliases] is newline separated for the same reason [MemoryEntity.links] is:
 * the parse cannot fail, and there is no query that would be faster as a table.
 */
@Entity(tableName = "memory_files")
data class MemoryFileEntity(
    @PrimaryKey val path: String,
    @ColumnInfo(defaultValue = "") val aliases: String = "",
    @ColumnInfo(defaultValue = "1") val version: Int = 1,
    val updatedAt: Long,
    /** The heading shown above the file's lines; empty until something names it. */
    @ColumnInfo(defaultValue = "") val title: String = "",
    /** One line describing the file, shown under the heading. */
    @ColumnInfo(defaultValue = "") val summary: String = ""
)
