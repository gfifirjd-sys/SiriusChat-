package com.sirius.chat.data.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.sirius.chat.core.common.AppDispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Where generated pictures live on disk.
 *
 * ### Why files and not base64 in the message
 * A generated image is roughly 1–3 MB of PNG. Inlining that as base64 into the
 * message body would put it in the Room row, in every `Flow` emission of the
 * transcript, in the prompt history sent back to the model on the next turn, and
 * in the session export. The first of those is merely wasteful; the third is
 * fatal, because a 4 MB data URI in the context window costs more than the whole
 * conversation around it and would be re-sent on every subsequent message.
 *
 * So the message carries a path and the bytes stay here. The transcript renders
 * `![prompt](sirius-image:name.png)`, which is ordinary markdown — it survives
 * copy-paste, export and re-parsing, and a build that cannot render it degrades
 * to showing the prompt as alt text rather than to a crash.
 *
 * ### Lifetime
 * `filesDir`, not the cache: the user expects a picture that is visible in a
 * three-week-old conversation to still be there. Android may delete the cache
 * under pressure, which would leave every old chat full of broken images.
 * [prune] keeps that from growing without bound.
 */
class GeneratedImageStore(
    context: Context,
    private val dispatchers: AppDispatchers
) {

    private val root: File = File(context.filesDir, "generated-images").apply { mkdirs() }

    /**
     * Writes [bytes] and returns the markdown-safe reference for the transcript.
     *
     * The name is derived from the current time rather than from the prompt: a
     * prompt is user text, and user text in a filename means path traversal,
     * length limits and encoding bugs. Time plus a counter is unique enough for
     * a single device and sorts chronologically in a file listing.
     */
    suspend fun save(bytes: ByteArray): StoredImage? = withContext(dispatchers.io) {
        if (bytes.isEmpty()) return@withContext null
        // Decode bounds only: this both validates that what the endpoint sent is
        // actually an image (a JSON error page with a 200 is common) and gives
        // the real dimensions for the badge, without allocating the bitmap.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            Log.w(TAG, "endpoint returned ${bytes.size} bytes that are not an image")
            return@withContext null
        }

        val name = "img-${System.currentTimeMillis()}-${bytes.size % 100_000}.png"
        val file = File(root, name)
        runCatching { file.writeBytes(bytes) }
            .onFailure { Log.w(TAG, "could not write $name", it); return@withContext null }

        prune()
        StoredImage(
            name = name,
            path = file.absolutePath,
            width = bounds.outWidth,
            height = bounds.outHeight,
            sizeBytes = bytes.size.toLong()
        )
    }

    /** Absolute path for a reference produced by [StoredImage.markdownUri]. */
    fun resolve(reference: String): File? {
        val name = fileName(reference) ?: return null
        val direct = File(root, name)
        if (direct.exists()) return direct
        // A model that retypes a name instead of copying the line it was given
        // usually gets the case or the extension wrong and nothing else. One
        // directory listing turns that into the picture the user was shown
        // instead of a placeholder telling them it is gone.
        val stem = name.substringBeforeLast('.')
        return root.listFiles()?.firstOrNull { file ->
            file.name.equals(name, ignoreCase = true) ||
                file.name.substringBeforeLast('.').equals(stem, ignoreCase = true)
        }
    }

    /**
     * The bare file name inside a reference, or null when the reference cannot
     * be one of ours.
     *
     * Trailing punctuation is trimmed because a model writing prose around a
     * link puts a full stop after it about as often as not.
     */
    private fun fileName(reference: String): String? {
        val trimmed = reference.trim()
            .trim('<', '>', '"', '\'', '`')
            .removeSuffix(")")
            .trimEnd('.', ',', '!', ';', ':')
        val name = trimmed.removePrefix(SCHEME).trim().trimStart('/')
        // Anything with a separator is not one of ours. A model can write any
        // string into an image link, and this is the only place that string is
        // turned into a path, so it is the only place the check belongs.
        if (name.isEmpty() || name.contains('/') || name.contains('\\') || name.contains("..")) {
            return null
        }
        return name
    }

    /**
     * Decode for display, downsampled to roughly [maxDimension].
     *
     * A chat bubble is at most ~1000px wide on a phone; decoding a 1536×1536 PNG
     * at full size to draw it at a third of that is four times the memory for no
     * visible difference, and it is a real out-of-memory risk when a transcript
     * holds a dozen of them.
     */
    suspend fun decode(file: File, maxDimension: Int = 1280): Bitmap? =
        withContext(dispatchers.io) {
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                var sample = 1
                while (
                    bounds.outWidth / sample > maxDimension ||
                    bounds.outHeight / sample > maxDimension
                ) {
                    sample *= 2
                }
                BitmapFactory.decodeFile(
                    file.absolutePath,
                    BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                    }
                )
            }.onFailure { Log.w(TAG, "decode failed for ${file.name}", it) }.getOrNull()
        }

    /**
     * Width and height of a stored file, without decoding its pixels.
     *
     * The transcript needs the shape before it has the bitmap: an item that
     * reserves the wrong height and corrects it when the picture arrives moves
     * every message under it, and in a list being scrolled that shift is read as
     * the chat jumping on its own.
     */
    suspend fun dimensions(file: File): Pair<Int, Int>? = withContext(dispatchers.io) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        runCatching { BitmapFactory.decodeFile(file.absolutePath, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) null
        else bounds.outWidth to bounds.outHeight
    }

    /**
     * Rewrites the image links of a finished answer so the transcript only
     * promises pictures that exist.
     *
     * Models retype `sirius-image:` names from memory instead of copying the
     * line they were handed, and a name that is one character off used to render
     * as a grey block claiming the file was deleted -- which reads as the app
     * losing data it never had. [candidates] are the references this turn's
     * tools really produced: when the answer points at nothing and the turn made
     * exactly one picture, that picture is what the answer meant. With nothing
     * to point at, the link degrades to its alt text, because a sentence the
     * user can read beats a placeholder they cannot.
     */
    suspend fun repair(text: String, candidates: List<String>): String =
        withContext(dispatchers.io) {
            if (!text.contains(SCHEME)) return@withContext text
            val real = candidates
                .flatMap { output -> REFERENCE.findAll(output).map { it.value }.toList() }
                .distinct()
                .filter { resolve(it) != null }
            LINK.replace(text) { match ->
                val uri = match.groupValues[2].trim()
                if (!uri.startsWith(SCHEME) || resolve(uri) != null) {
                    match.value
                } else {
                    val alt = match.groupValues[1].trim()
                    val only = real.singleOrNull()
                    if (only != null) "![" + alt + "](" + only + ")" else alt
                }
            }
        }

    /**
     * Drops the oldest files once the folder passes the budget.
     *
     * By total bytes rather than by count, because that is the resource the user
     * actually notices in the system storage screen. The budget is generous
     * enough that pruning is rare and only ever removes images from
     * conversations far out of reach of the scroll position.
     */
    private fun prune() {
        val files = root.listFiles()?.sortedBy { it.lastModified() } ?: return
        var total = files.sumOf { it.length() }
        for (file in files) {
            if (total <= MAX_TOTAL_BYTES) break
            total -= file.length()
            file.delete()
        }
    }

    companion object {
        private const val TAG = "GeneratedImages"

        /** Custom scheme so the renderer can tell our images from remote ones. */
        const val SCHEME = "sirius-image:"

        /** `![alt](uri)`, matched the way the transcript's own parser does. */
        private val LINK = Regex("""!\[([^\]]*)\]\(([^)\s]+)\)""")

        /** A bare reference, for lifting the real ones out of a tool's output. */
        private val REFERENCE = Regex("""sirius-image:[A-Za-z0-9._-]+""")

        private const val MAX_TOTAL_BYTES = 256L * 1024 * 1024
    }
}

/** A picture on disk, plus what the transcript and the model each need to know. */
data class StoredImage(
    val name: String,
    val path: String,
    val width: Int,
    val height: Int,
    val sizeBytes: Long
) {
    /** What goes inside `![alt](...)`. */
    val markdownUri: String get() = "${GeneratedImageStore.SCHEME}$name"

    val resolution: String get() = "${width}×${height}"
}
