package com.sirius.chat.ai.discovery

import com.sirius.chat.ai.provider.HttpClientProvider
import com.sirius.chat.domain.model.AiModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.concurrent.TimeUnit

/** A model server answering on the local network. */
data class LocalServer(
    /** What the endpoint turned out to be, e.g. `Ollama`. Not localised: it is a product name. */
    val engine: String,
    /** Ready to paste into a provider: already includes the OpenAI-compatible suffix. */
    val baseUrl: String,
    val host: String,
    val port: Int,
    /** Round trip of the request that identified it, in milliseconds. */
    val latencyMs: Long,
    val models: List<AiModel>
) {
    val displayHost: String get() = host + ":" + port
}

/**
 * Finds Ollama, LM Studio and llama.cpp on the same Wi-Fi as the phone.
 *
 * ### Why this exists
 * Someone running models on their own machine currently has to read their
 * router's client list, guess the port, and type `http://192.168.1.37:11434/v1`
 * into a form -- on a phone keyboard, with no feedback until the first request
 * fails. The information needed to skip all of that is already on the device.
 *
 * ### Why it scans instead of asking the network
 * mDNS would be the polite way, and neither Ollama nor LM Studio advertises
 * itself over it, so there is nothing to ask. A /24 sweep of four known ports is
 * the method that actually finds them.
 *
 * ### Why a TCP knock comes first
 * An HTTP request to a dead address waits out the connect timeout and allocates
 * a full client call to learn nothing. A raw socket with a [KNOCK_TIMEOUT_MS]
 * budget answers the same question for the cost of one SYN, so the expensive
 * part only runs for the handful of addresses that have something listening.
 * A sweep is therefore seconds, not minutes, and it never touches the internet.
 */
class LocalServerScanner(private val client: OkHttpClient = HttpClientProvider.client) {

    private val json = Json { ignoreUnknownKeys = true }

    /**
     * Sweeps the phone's own subnet plus loopback.
     *
     * @return what answered, fastest first. Empty is a normal answer: it means
     * mobile data, a guest network with client isolation, or nothing running.
     */
    suspend fun scan(): List<LocalServer> = coroutineScope {
        val prefixes = subnetPrefixes()
        val gate = Semaphore(MAX_PARALLEL)
        val targets = buildList {
            // Loopback first: a server hosted on the phone itself (Termux) is a
            // real setup and costs four checks to cover.
            PORTS.forEach { port -> add("127.0.0.1" to port) }
            prefixes.forEach { prefix ->
                (1..254).forEach { last ->
                    PORTS.forEach { port -> add((prefix + last) to port) }
                }
            }
        }

        targets.map { (host, port) ->
            async(Dispatchers.IO) {
                gate.withPermit {
                    if (!knock(host, port)) null else identify(host, port)
                }
            }
        }
            .awaitAll()
            .filterNotNull()
            .distinctBy { it.baseUrl }
            .sortedBy { it.latencyMs }
    }

    /** IPv4 /24 prefixes this device sits on, as `192.168.1.` strings. */
    private fun subnetPrefixes(): List<String> = runCatching {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { runCatching { it.isUp && !it.isLoopback }.getOrDefault(false) }
            .flatMap { iface -> iface.interfaceAddresses }
            .mapNotNull { entry ->
                val address = entry.address
                if (address !is Inet4Address) return@mapNotNull null
                // Only private ranges. Sweeping a public /24 the carrier handed
                // out would be scanning strangers, which this must never do.
                if (!address.isSiteLocalAddress) return@mapNotNull null
                address.hostAddress?.substringBeforeLast('.')?.plus(".")
            }
            .distinct()
            .take(MAX_SUBNETS)
    }.getOrDefault(emptyList())

    /** Is anything listening at all. */
    private fun knock(host: String, port: Int): Boolean = runCatching {
        Socket().use { socket ->
            socket.connect(InetSocketAddress(host, port), KNOCK_TIMEOUT_MS)
            true
        }
    }.getOrDefault(false)

    /**
     * Asks an open port what it is.
     *
     * Tries the OpenAI-compatible catalogue first because that is what the app
     * will talk to afterwards, then Ollama's native listing. A port that is open
     * but answers neither is someone else's service and is dropped rather than
     * offered as a provider.
     */
    private suspend fun identify(host: String, port: Int): LocalServer? =
        withContext(Dispatchers.IO) {
            openAiStyle(host, port) ?: ollamaStyle(host, port)
        }

    private fun openAiStyle(host: String, port: Int): LocalServer? {
        val base = "http://" + host + ":" + port + "/v1"
        val (body, latency) = get(base + "/models") ?: return null
        val models = runCatching { parseOpenAi(body) }.getOrNull() ?: return null
        return LocalServer(
            engine = engineName(port, body),
            baseUrl = base,
            host = host,
            port = port,
            latencyMs = latency,
            models = models
        )
    }

    /**
     * Ollama's own endpoint.
     *
     * Reached only when `/v1/models` did not answer, which happens on builds
     * older than the OpenAI compatibility layer. The provider is still pointed at
     * `/v1`, because that is the surface this app speaks -- what is being
     * detected here is the machine, not the dialect.
     */
    private fun ollamaStyle(host: String, port: Int): LocalServer? {
        val (body, latency) = get("http://" + host + ":" + port + "/api/tags") ?: return null
        val models = runCatching { parseOllama(body) }.getOrNull()?.takeIf { it.isNotEmpty() }
            ?: return null
        return LocalServer(
            engine = "Ollama",
            baseUrl = "http://" + host + ":" + port + "/v1",
            host = host,
            port = port,
            latencyMs = latency,
            models = models
        )
    }

    /** Body and round trip, or null for anything that is not a readable 200. */
    private fun get(url: String): Pair<String, Long>? {
        val request = Request.Builder().url(url).get().header("Accept", "application/json").build()
        val started = System.nanoTime()
        return runCatching {
            probeClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string().orEmpty()
                val elapsed = (System.nanoTime() - started) / 1_000_000
                if (body.isBlank()) null else body to elapsed
            }
        }.getOrNull()
    }

    private fun parseOpenAi(body: String): List<AiModel> {
        val root = json.parseToJsonElement(body)
        val array = if (root is JsonArray) root else root.jsonObject["data"]?.jsonArray ?: return emptyList()
        return array.mapNotNull { element ->
            val entry = element.jsonObject
            val id = entry["id"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
                ?: return@mapNotNull null
            AiModel(
                id = id,
                label = id,
                contextWindow = entry["context_length"]?.jsonPrimitive?.intOrNull ?: 0
            )
        }.distinctBy { it.id }.sortedBy { it.id.lowercase() }
    }

    private fun parseOllama(body: String): List<AiModel> {
        val array = json.parseToJsonElement(body).jsonObject["models"]?.jsonArray ?: return emptyList()
        return array.mapNotNull { element ->
            val name = element.jsonObject["name"]?.jsonPrimitive?.contentOrNull?.takeIf { it.isNotBlank() }
                ?: return@mapNotNull null
            AiModel(id = name, label = name)
        }.distinctBy { it.id }.sortedBy { it.id.lowercase() }
    }

    /**
     * The product name to show.
     *
     * The port is the strongest signal available -- these servers do not identify
     * themselves in a catalogue response -- so it decides, and an unrecognised
     * port is described by what it demonstrably is rather than guessed at.
     */
    private fun engineName(port: Int, body: String): String = when {
        port == 11434 -> "Ollama"
        port == 1234 -> "LM Studio"
        body.contains("llama", ignoreCase = true) && port == 8080 -> "llama.cpp"
        port == 8000 -> "vLLM"
        else -> "OpenAI-compatible"
    }

    /**
     * A LAN client with a short fuse.
     *
     * The shared client waits ten minutes for a streaming answer, which is the
     * right setting for a model and a terrible one for a sweep.
     */
    private val probeClient: OkHttpClient by lazy {
        client.newBuilder()
            .connectTimeout(IDENTIFY_TIMEOUT_MS, TimeUnit.MILLISECONDS)
            .callTimeout(IDENTIFY_TIMEOUT_MS, TimeUnit.MILLISECONDS)
            .readTimeout(IDENTIFY_TIMEOUT_MS, TimeUnit.MILLISECONDS)
            .retryOnConnectionFailure(false)
            .build()
    }

    private companion object {
        /** Ollama, LM Studio, llama.cpp server, vLLM. */
        val PORTS = listOf(11434, 1234, 8080, 8000)

        /**
         * Wide enough to finish a /24 in seconds, narrow enough not to trip the
         * per-app socket ceiling or make a cheap router drop frames.
         */
        const val MAX_PARALLEL = 64

        const val KNOCK_TIMEOUT_MS = 260

        const val IDENTIFY_TIMEOUT_MS = 1_500L

        /** A phone on Wi-Fi plus a VPN can present several; two is already generous. */
        const val MAX_SUBNETS = 2
    }
}
