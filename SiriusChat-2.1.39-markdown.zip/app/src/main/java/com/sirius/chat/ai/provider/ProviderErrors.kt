package com.sirius.chat.ai.provider

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.core.locale.AppStrings
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.Locale

private val errorJson = Json { ignoreUnknownKeys = true }

/**
 * Whether this value can be sent as an HTTP header at all.
 *
 * OkHttp throws on a header value outside printable ASCII, and an API key
 * copied from a web page routinely arrives with a trailing newline or a
 * non-breaking space in it. Unchecked, that surfaced as a crash-shaped
 * "unexpected error" that said nothing about the one thing that was wrong.
 */
internal fun String.isHeaderSafe(): Boolean = all { it.code in 0x20..0x7E }

/** Shown for a key that cannot go on the wire, with the fix in the message. */
internal fun invalidKeyError(): AiError = AiError(
    AiError.Kind.Unauthorized,
    AppStrings.get(
        R.string.error_invalid_key,
        fallback = "This API key contains characters that cannot be sent in a request " +
            "header. Copy it again without spaces or line breaks."
    )
)

/**
 * True when the provider's complaint is "this prompt is too big".
 *
 * There is no status code for it -- every endpoint returns a plain 400 -- so the
 * text is all there is to go on. The markers are the phrasings the major
 * gateways actually use, kept specific enough that an unrelated 400 is not read
 * as an overflow and answered by deleting half the conversation.
 */
internal fun AiError.isContextOverflow(): Boolean {
    val text = message.lowercase(Locale.US)
    return OVERFLOW_MARKERS.any { text.contains(it) }
}

private val OVERFLOW_MARKERS = listOf(
    "context length",
    "context_length",
    "context window",
    "maximum context",
    "too many tokens",
    "prompt is too long",
    "input is too long",
    "reduce the length",
    "exceeds the maximum"
)

/** Maps transport exceptions to a stable, user-presentable error. */
internal fun Throwable.toAiError(): AiError = when (this) {
    is UnknownHostException -> AiError(
        AiError.Kind.Network,
        AppStrings.get(
            R.string.error_unreachable,
            fallback = "Cannot reach the provider. Check the base URL and your connection."
        )
    )
    is SocketTimeoutException -> AiError(
        AiError.Kind.Network,
        AppStrings.get(R.string.error_timeout, fallback = "The provider timed out.")
    )
    is java.util.concurrent.CancellationException -> AiError(
        AiError.Kind.Cancelled,
        AppStrings.get(R.string.error_cancelled, fallback = "Generation stopped.")
    )
    is IOException -> AiError(
        AiError.Kind.Network,
        message ?: AppStrings.get(R.string.error_network, fallback = "Network error")
    )
    else -> AiError(
        AiError.Kind.Unknown,
        message ?: AppStrings.get(R.string.error_unexpected, fallback = "Unexpected error")
    )
}

/**
 * Maps an HTTP failure, extracting the provider's own message when present.
 *
 * [retryAfterMillis] carries the wait the response asked for, when it carried
 * one, so the retry decision can prefer it over a guessed backoff.
 */
internal fun httpError(code: Int, body: String, retryAfterMillis: Long? = null): AiError {
    val detail = runCatching {
        val root = errorJson.parseToJsonElement(body).jsonObject
        val error = root["error"]
        when {
            error != null -> error.jsonObject["message"]?.jsonPrimitive?.contentOrNull
            else -> root["message"]?.jsonPrimitive?.contentOrNull
        }
    }.getOrNull()

    val kind = when (code) {
        401, 403 -> AiError.Kind.Unauthorized
        429 -> AiError.Kind.RateLimited
        in 400..499 -> AiError.Kind.BadRequest
        in 500..599 -> AiError.Kind.Server
        else -> AiError.Kind.Unknown
    }

    val fallback = when (kind) {
        AiError.Kind.Unauthorized -> AppStrings.get(
            R.string.error_unauthorized,
            fallback = "Invalid or missing API key for this provider."
        )
        AiError.Kind.RateLimited -> AppStrings.get(
            R.string.error_rate_limited,
            fallback = "Rate limited by the provider. Try again shortly."
        )
        AiError.Kind.BadRequest -> AppStrings.format(
            R.string.error_bad_request,
            code,
            fallback = "The provider rejected the request (HTTP $code)."
        )
        AiError.Kind.Server -> AppStrings.format(
            R.string.error_server,
            code,
            fallback = "The provider is having trouble (HTTP $code)."
        )
        else -> AppStrings.format(
            R.string.error_request_failed,
            code,
            fallback = "Request failed (HTTP $code)."
        )
    }

    return AiError(kind, detail?.takeIf { it.isNotBlank() } ?: fallback, code, retryAfterMillis)
}
