package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.string
import com.sirius.chat.ai.agent.stringOrEmpty
import com.sirius.chat.data.files.FileExporter
import com.sirius.chat.data.image.GeneratedImageStore
import com.sirius.chat.data.web.WebCaptureService
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.JsonObject

/**
 * Photographs a page instead of reading it.
 *
 * ### Why this is not covered by open_url
 * `open_url` returns text, which is the right answer for a changelog and no
 * answer at all for a chart, a rendered design, a map, or any of the sites that
 * are a JavaScript application and ship almost no HTML text. Those come back
 * empty today and the model tells the user the page could not be read. A picture
 * is the honest fallback, and on a phone it is often what was wanted anyway.
 *
 * The result is returned as a markdown image line for the same reason
 * `generate_image` does it: a picture that is part of the message text stays
 * visible to the transcript, the clipboard, and the model's own memory of what it
 * just did.
 */
private class ScreenshotUrlTool(
    private val capture: WebCaptureService,
    private val images: GeneratedImageStore
) : AgentTool {

    override val name = "screenshot_url"
    override val description =
        "Render a web page and put the picture in the chat. Use when the page is " +
            "visual (a design, a chart, a map, a rendered demo), when open_url " +
            "returned no readable text because the site is JavaScript-only, or when " +
            "the user asks what a page looks like. Set full_page false for just the " +
            "first screen."
    override val usage = """{"url": "https://kotlinlang.org", "full_page": true}"""
    override val requiredArgs = listOf("url")

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val url = args.string("url") ?: args.string("link") ?: args.string("page")
            ?: return AgentToolResult("Missing 'url'.", success = false)
        val fullPage = !args.stringOrEmpty("full_page").equals("false", ignoreCase = true)

        val bytes = try {
            capture.screenshot(url, fullPage)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (error: Throwable) {
            return AgentToolResult(
                "Could not render $url: ${error.message ?: error::class.simpleName}. " +
                    "Try open_url instead, or tell the user the page did not load.",
                success = false
            )
        }

        if (bytes == null) {
            return AgentToolResult(
                "$url did not finish loading, so there is nothing to photograph. The " +
                    "page may need a login or be blocked. Try open_url or another source.",
                success = false
            )
        }

        val stored = images.save(bytes)
            ?: return AgentToolResult(
                "The screenshot was taken but could not be stored. Tell the user and " +
                    "do not retry.",
                success = false
            )

        return AgentToolResult(
            buildString {
                append("Screenshot of ").append(url)
                append(" at ").append(stored.resolution).append(".\n\n")
                append("Include exactly this line in your answer so it is shown:\n")
                append("![screenshot of ").append(url.take(ALT_CHARS)).append("](")
                append(stored.markdownUri).append(")")
                append("\n\nThe user can see it; do not describe it pixel by pixel.")
            }
        )
    }

    private companion object {
        const val ALT_CHARS = 80
    }
}

/**
 * Pulls whatever a link points at into the conversation.
 *
 * Three outcomes, because there are three genuinely different things a URL can
 * be. A picture becomes a picture. A text file becomes a file card the user can
 * open, download or share — which is why the instruction tells the model to echo
 * it as a named fence rather than as a wall of code. Anything else is reported
 * with its size and left alone: pasting 8 MB of binary into a prompt helps nobody
 * and costs the user real money.
 */
private class DownloadFileTool(
    private val capture: WebCaptureService,
    private val images: GeneratedImageStore
) : AgentTool {

    override val name = "download_file"
    override val description =
        "Fetch the file behind a link: an image, a script, a JSON or CSV file, a " +
            "config. Images are placed in the chat, text files come back as content " +
            "you show as a named file, anything else is reported by size. Use " +
            "open_url for reading an article instead."
    override val usage = """{"url": "https://example.com/data/report.json"}"""
    override val requiredArgs = listOf("url")

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val url = args.string("url") ?: args.string("link") ?: args.string("file")
            ?: return AgentToolResult("Missing 'url'.", success = false)

        val remote = try {
            capture.download(url)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (error: Throwable) {
            return AgentToolResult(
                "Could not download $url: ${error.message ?: error::class.simpleName}. " +
                    "The link may be dead, need a login, or be too large.",
                success = false
            )
        }

        val size = FileExporter.readableSize(remote.bytes.size.toLong())

        if (remote.isImage) {
            val stored = images.save(remote.bytes)
                ?: return AgentToolResult(
                    "Downloaded ${remote.name} ($size) but it could not be decoded as " +
                        "an image. Give the user the link instead.",
                    success = false
                )
            return AgentToolResult(
                buildString {
                    append("Downloaded ").append(remote.name).append(" (").append(size)
                    append(", ").append(stored.resolution).append(").\n\n")
                    append("Include exactly this line in your answer so it is shown:\n")
                    append("![").append(remote.name).append("](")
                    append(stored.markdownUri).append(")")
                }
            )
        }

        if (!remote.isText || remote.bytes.size > MAX_TEXT_BYTES) {
            return AgentToolResult(
                "${remote.name} is ${remote.mime}, $size. It is not text, so there is " +
                    "nothing to read out. Tell the user what it is and give them the " +
                    "link so they can download it themselves."
            )
        }

        val text = String(remote.bytes, Charsets.UTF_8)
        if (text.contains('\u0000')) {
            return AgentToolResult(
                "${remote.name} claims to be ${remote.mime} but is binary, $size. Give " +
                    "the user the link instead of the contents."
            )
        }
        val body = text.take(MAX_TEXT_CHARS)

        return AgentToolResult(
            buildString {
                append(remote.name).append(" — ").append(remote.mime).append(", ").append(size)
                if (text.length > MAX_TEXT_CHARS) {
                    append(" (showing the first ").append(MAX_TEXT_CHARS).append(" characters)")
                }
                append("\n\n")
                append(body)
                append("\n\nTo hand this to the user as a file they can open, download or ")
                append("share, put it in a fenced block whose info line ends with the file ")
                append("name, for example ```json ").append(remote.name).append(" — do not ")
                append("paste it as plain prose.")
            }
        )
    }

    private companion object {
        const val MAX_TEXT_BYTES = 512 * 1024
        const val MAX_TEXT_CHARS = 12_000
    }
}

/**
 * Registers the link tools.
 *
 * A factory, like [webTools] and [imageTools], because both of these need
 * services that only the container can build.
 */
fun linkTools(
    capture: WebCaptureService,
    images: GeneratedImageStore
): List<AgentTool> = listOf(
    ScreenshotUrlTool(capture, images),
    DownloadFileTool(capture, images)
)

/**
 * Names of the tools the "Интернет" switch controls, beyond the search pair.
 *
 * Grouped with web search rather than with image generation even though one of
 * them produces a picture: what they need is the network, and a user who turned
 * the internet off does not expect a tool to reach a URL anyway.
 */
val LINK_TOOL_NAMES: Set<String> = setOf("screenshot_url", "download_file")
