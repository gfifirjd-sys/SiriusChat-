package com.sirius.chat.core.designsystem.components

import android.view.View
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.effects.ambientGlow
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.designsystem.siriusRise
import com.sirius.chat.core.designsystem.siriusSpring
import kotlinx.coroutines.delay

/**
 * The shared "there is nothing here yet" view.
 *
 * The icon sits in a milled well with a faint bloom behind it, which is enough
 * to make an empty screen look designed rather than unfinished. Everything rises
 * into place on a spring so arriving at an empty list still feels like arriving
 * somewhere. Pass [orb] when the emptiness is about the assistant itself — that
 * is the one case where the signature element earns its place.
 */
@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    orb: Boolean = false,
    onAction: (() -> Unit)? = null
) {
    val colors = SiriusTheme.colors
    var appeared by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appeared = true }
    val scale by animateFloatAsState(
        targetValue = if (appeared) 1f else 0.9f,
        animationSpec = siriusSpring(),
        label = "emptyScale"
    )
    val fade by animateFloatAsState(
        targetValue = if (appeared) 1f else 0f,
        animationSpec = siriusSpring(),
        label = "emptyFade"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(SiriusSpacing.xl)
            .alpha(fade),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.sm)
    ) {
        if (orb) {
            SiriusOrb(size = 72.dp, modifier = Modifier.scale(scale))
        } else {
            Box(
                modifier = Modifier
                    .scale(scale)
                    .ambientGlow(color = colors.primary, shape = CircleShape, radius = 22.dp, alpha = 0.28f)
                    .size(64.dp)
                    .clip(CircleShape)
                    .softSurface(CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = colors.primary, modifier = Modifier.size(28.dp))
            }
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = colors.textPrimary,
            textAlign = TextAlign.Center
        )
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = colors.textTertiary,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(max = 320.dp)
        )
        if (actionLabel != null && onAction != null) {
            SiriusActionRow(visible = appeared) {
                SiriusPrimaryButton(
                    text = actionLabel,
                    onClick = onAction,
                    modifier = Modifier.padding(top = SiriusSpacing.xs)
                )
            }
        }
    }
}

@Composable
fun ErrorState(
    message: String,
    modifier: Modifier = Modifier,
    onRetry: (() -> Unit)? = null
) = EmptyState(
    icon = Icons.Rounded.ErrorOutline,
    title = stringResource(R.string.state_error_title),
    message = message,
    modifier = modifier,
    actionLabel = if (onRetry != null) stringResource(R.string.action_retry) else null,
    onAction = onRetry
)

@Composable
fun OfflineState(modifier: Modifier = Modifier, onRetry: (() -> Unit)? = null) = EmptyState(
    icon = Icons.Rounded.CloudOff,
    title = stringResource(R.string.state_offline_title),
    message = stringResource(R.string.state_offline_message),
    modifier = modifier,
    actionLabel = if (onRetry != null) stringResource(R.string.action_retry) else null,
    onAction = onRetry
)

/** Tone of a [MessageToast]; picks the icon and the accent. */
enum class ToastTone { Error, Success }

/**
 * Floating status message rendered in an overlay window, so it can be called
 * from anywhere in a screen (even as a sibling of a full-size Column) and still
 * float above the content.
 *
 * It rises in, holds, and leaves on its own — a status message that requires a
 * dismissal is a dialog, not a toast. It is also announced as a polite live
 * region, so the message reaches a screen reader even though it is transient.
 */
@Composable
fun MessageToast(
    message: String?,
    bottomPadding: Dp = SiriusSpacing.xxl,
    tone: ToastTone = ToastTone.Error,
    durationMillis: Long = 4_000
) {
    val colors = SiriusTheme.colors
    var visible by remember(message) { mutableStateOf(false) }
    // Whether the overlay window exists at all, tracked apart from visibility:
    // once the message has faded there is no reason to keep a window hanging
    // over the screen, and keeping one is half of why the bottom of the screen
    // stopped responding after every toast.
    var mounted by remember(message) { mutableStateOf(false) }

    LaunchedEffect(message) {
        if (message.isNullOrBlank()) {
            visible = false
            mounted = false
            return@LaunchedEffect
        }
        mounted = true
        visible = true
        delay(durationMillis)
        visible = false
        delay(EXIT_GRACE_MILLIS)
        mounted = false
    }
    if (message.isNullOrBlank() || !mounted) return

    val accent = when (tone) {
        ToastTone.Error -> colors.error
        ToastTone.Success -> colors.success
    }
    val icon = when (tone) {
        ToastTone.Error -> Icons.Rounded.ErrorOutline
        ToastTone.Success -> Icons.Rounded.CheckCircle
    }
    val (enter, exit) = siriusRise(distancePx = 16)

    Popup(
        alignment = Alignment.BottomCenter,
        properties = PopupProperties(focusable = false, clippingEnabled = false)
    ) {
        // A popup is a real window, and a window swallows every touch inside its
        // bounds even when nothing in it is clickable. That is how a note about a
        // deleted chat left the composer and the navigation bar dead for the
        // seconds it was on screen. Nothing here is meant to be tapped, so the
        // window is told to hand touches to the app underneath.
        val popupView = LocalView.current
        SideEffect { popupView.passTouchesThrough() }

        AnimatedVisibility(visible = visible, enter = enter, exit = exit) {
            Row(
                modifier = Modifier
                    .padding(horizontal = SiriusSpacing.md)
                    .padding(bottom = bottomPadding)
                    .ambientGlow(
                        color = accent,
                        shape = RoundedCornerShape(SiriusRadius.md),
                        radius = 16.dp,
                        alpha = 0.3f
                    )
                    .clip(RoundedCornerShape(SiriusRadius.md))
                    .softSurface(RoundedCornerShape(SiriusRadius.md))
                    .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
                    .semantics {
                        liveRegion = LiveRegionMode.Polite
                        contentDescription = message
                    },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textPrimary,
                    maxLines = 3
                )
            }
        }
    }
}

/** Long enough for the exit animation to finish before the window is dropped. */
private const val EXIT_GRACE_MILLIS = 400L

/**
 * Gives touches back to the app by flagging the window that owns this view, so a
 * status message can never intercept a tap meant for the screen behind it.
 *
 * Compose exposes no property for this on [Popup], and the alternative -- laying
 * the toast out inside each screen instead of in an overlay -- would put it back
 * underneath sheets and bottom bars, which is what the overlay was for.
 */
private fun View.passTouchesThrough() {
    var owner: View? = this
    while (owner != null && owner.layoutParams !is WindowManager.LayoutParams) {
        owner = owner.parent as? View
    }
    val window = owner ?: return
    val params = window.layoutParams as? WindowManager.LayoutParams ?: return
    val flags = params.flags or
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    if (flags == params.flags) return
    params.flags = flags
    // The window can already be gone by the time this runs, and a failure here is
    // cosmetic -- never worth taking the screen down for.
    runCatching {
        window.context.getSystemService(WindowManager::class.java)
            ?.updateViewLayout(window, params)
    }
}

/**
 * Full-screen loading. Prefer [ListSkeleton] whenever the shape of the incoming
 * content is known — a skeleton holds the layout still, a spinner does not.
 */
@Composable
fun LoadingState(modifier: Modifier = Modifier, label: String = stringResource(R.string.state_loading)) {
    val colors = SiriusTheme.colors
    Column(
        modifier = modifier
            .fillMaxSize()
            .semantics {
                liveRegion = LiveRegionMode.Polite
                contentDescription = label
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        SiriusOrb(size = 44.dp)
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = colors.textTertiary,
            modifier = Modifier.padding(top = SiriusSpacing.sm)
        )
    }
}

/**
 * Placeholder list used while real rows load. Each row fades a little further
 * back than the one above it, which reads as depth instead of a stack of
 * identical grey bars.
 */
@Composable
fun ListSkeleton(
    modifier: Modifier = Modifier,
    rows: Int = 5,
    showLeading: Boolean = true,
    lines: Int = 2
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .semantics {
                liveRegion = LiveRegionMode.Polite
                contentDescription = ""
            },
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
    ) {
        repeat(rows) { index ->
            SkeletonRow(
                modifier = Modifier.alpha(1f - index * (0.6f / rows.coerceAtLeast(1))),
                showLeading = showLeading,
                lines = lines
            )
        }
    }
}

/**
 * Inline progress strip for work that happens *inside* an already-populated
 * screen (saving a file, applying a diff). It never covers the content.
 */
@Composable
fun InlineBusyRow(
    label: String,
    modifier: Modifier = Modifier,
    tint: Color? = null
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.sm))
            .softSurface(RoundedCornerShape(SiriusRadius.sm))
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
            .semantics { liveRegion = LiveRegionMode.Polite },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
    ) {
        SiriusTypingDots(color = tint ?: colors.primary)
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
            maxLines = 1
        )
    }
}
