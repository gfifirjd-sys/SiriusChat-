package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentQuestion
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.string
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.util.UUID

/**
 * Lets the agent ask a question mid-run instead of guessing.
 *
 * Without this the only way to answer a model's question is to let the run finish
 * on a wrong assumption and correct it afterwards, which throws away every step
 * that followed the guess. A build that has already written six files against the
 * wrong package name is not cheaper to fix than one that paused to ask.
 *
 * The tool is read-only in the sense that matters: it proposes no change and
 * touches no file. It only suspends.
 *
 * ### Who decides how many answers
 *
 * The model does, per question, with `multi_select`. That is deliberate: whether
 * several answers can hold at once is a fact about the question, not about the
 * app. "Which features should I add?" takes three answers; "which folder do I
 * build in?" takes one, and offering checkboxes there invites an answer the run
 * cannot act on. The flag is described in [description] rather than inferred,
 * and the inference below only covers the case where the model sent no flag at
 * all.
 *
 * ### Bounds
 * Options are capped and truncated because they are rendered as buttons -- a
 * model that offers twelve paragraph-long choices produces a sheet nobody can
 * use. The cap is enforced here rather than in the UI so the limit is part of the
 * contract the model is held to, not a layout accident.
 */
class AskUserTool : AgentTool {
    override val name = "ask_user"
    override val description =
        "Ask the user a question and wait for their answer. Use it when a choice " +
            "would change what you build and you cannot infer it. Do not use it " +
            "to confirm work you have already described.\n" +
            "You choose the shape of the answer. Set multi_select to true when " +
            "several of the options can be true at the same time (which features " +
            "to include, which files to touch), and false when the options are " +
            "alternatives and only one can win (which folder to build in, which " +
            "language). If you are unsure, use false.\n" +
            "Give 2 to 5 short options, written in the user's language. The user " +
            "can always type an answer of their own instead of picking one."
    override val usage =
        """{"question": "Which features should I add?", "options": ["auth", "sync", "offline"], "multi_select": true} """ +
            """or {"question": "Where should I build it?", "options": ["this folder", "a new folder"], "multi_select": false}"""

    /**
     * Nothing, on purpose.
     *
     * The engine's gate knows exactly one spelling of "question", so a model
     * that sent `prompt` -- or sent everything under a different key -- lost a
     * whole step to "Missing required argument(s): question" before it could be
     * told what to fix. The same check still happens, one level down, where the
     * aliases are known.
     */
    override val requiredArgs = emptyList<String>()

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val question = args.firstString(*QUESTION_KEYS)
            ?: return AgentToolResult(
                "Missing the question itself. Send it as \"question\", written in " +
                    "the user's language, together with the answers you can " +
                    "already think of. Usage: $usage",
                success = false
            )

        val ask = context.askUser
            ?: return AgentToolResult(
                "Cannot ask the user in this run. Continue with your best " +
                    "judgement and state the assumption you made.",
                success = false
            )

        val options = optionsOf(args)

        // The flag the model sent wins, including an explicit false. The reading
        // of the question is only a fallback for the model that sent no flag at
        // all, and it reads the words the model itself wrote -- "which ones",
        // "выберите несколько" -- rather than guessing from the option count,
        // which says nothing: three mutually exclusive folders are still three.
        val multi = multiFlag(args) ?: asksForSeveral(question)

        val answer = ask(
            AgentQuestion(
                id = UUID.randomUUID().toString(),
                question = question.take(MAX_QUESTION_CHARS),
                options = options,
                // Multi select without options would render a confirm button
                // over an empty list, so it is ignored unless there is something
                // to select.
                multiSelect = multi && options.isNotEmpty()
            )
        )

        // A dismissed sheet is a real answer, not an error: the user chose not to
        // steer. Reporting it as a failure would make the model apologise and ask
        // again, which is the loop this branch exists to avoid.
        return if (answer.isBlank()) {
            AgentToolResult(
                "The user skipped the question. Proceed with your best judgement " +
                    "and say which assumption you made."
            )
        } else {
            AgentToolResult("The user answered: $answer")
        }
    }

    /** The first of [keys] carrying a non-empty string, or null. */
    private fun JsonObject.firstString(vararg keys: String): String? {
        for (key in keys) {
            val value = string(key)?.trim()
            if (!value.isNullOrEmpty()) return value
        }
        return null
    }

    /**
     * The options, in every shape models actually send them.
     *
     * A list of strings is the documented one. The rest are what arrives anyway:
     * a list of `{label, value}` objects, or one string with the choices on
     * separate lines. Rejecting those would be technically correct and would
     * cost the user a visible failed step to fix something the app can read.
     */
    private fun optionsOf(args: JsonObject): List<String> {
        val raw = OPTION_KEYS.firstNotNullOfOrNull { key -> args[key] }
        val labels = when {
            raw is JsonArray -> raw.mapNotNull { element ->
                when (element) {
                    is JsonObject -> element.firstString(*OPTION_LABEL_KEYS)
                    is JsonNull -> null
                    is JsonPrimitive -> element.content
                    else -> null
                }
            }
            raw is JsonPrimitive && raw !is JsonNull -> splitInline(raw.content)
            else -> emptyList()
        }
        return labels
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .take(MAX_OPTIONS)
            .map { it.take(MAX_OPTION_CHARS) }
    }

    /** Choices sent as one string: newlines first, then the usual separators. */
    private fun splitInline(text: String): List<String> {
        val lines = text.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size > 1) return lines
        val marked = text.split(';', '|').map { it.trim() }.filter { it.isNotEmpty() }
        if (marked.size > 1) return marked
        return text.split(',').map { it.trim() }.filter { it.isNotEmpty() }
    }

    /**
     * The model's own answer to "one or several", or null if it did not say.
     *
     * Strings are accepted next to booleans because a model writing JSON by hand
     * writes `"multi_select": "true"` often enough that treating it as "not set"
     * would silently turn a multi-answer question into a single-answer one --
     * the exact bug the flag exists to prevent.
     */
    private fun multiFlag(args: JsonObject): Boolean? {
        val raw = MULTI_KEYS.firstNotNullOfOrNull { key -> args[key] }
        val primitive = raw as? JsonPrimitive ?: return null
        if (primitive is JsonNull) return null
        return when (primitive.content.trim().lowercase()) {
            "true", "yes", "y", "1", "да" -> true
            "false", "no", "n", "0", "нет" -> false
            else -> null
        }
    }

    /** Whether the question itself asks for more than one answer. */
    private fun asksForSeveral(question: String): Boolean {
        val text = question.lowercase()
        return MULTI_HINTS.any { text.contains(it) }
    }

    private companion object {
        val QUESTION_KEYS = arrayOf("question", "prompt", "text", "message", "title", "ask", "q")
        val OPTION_KEYS = arrayOf("options", "choices", "suggestions", "answers", "variants")
        val OPTION_LABEL_KEYS = arrayOf("label", "value", "text", "name", "title", "option")
        val MULTI_KEYS = arrayOf(
            "multi_select",
            "multiSelect",
            "multiple",
            "allow_multiple",
            "allowMultiple",
            "multi"
        )

        /**
         * Phrases that only appear in a question expecting several answers.
         *
         * Kept narrow on purpose: a false positive here shows checkboxes for a
         * question with one right answer, and the user then picks two things
         * that cannot both happen.
         */
        val MULTI_HINTS = listOf(
            "select all",
            "choose all",
            "that apply",
            "which ones",
            "one or more",
            "as many as",
            "несколько",
            "все подходящ",
            "какие из",
            "что именно включ",
            "отметьте",
            "выберите все"
        )

        const val MAX_OPTIONS = 5
        const val MAX_OPTION_CHARS = 80
        const val MAX_QUESTION_CHARS = 400
    }
}
