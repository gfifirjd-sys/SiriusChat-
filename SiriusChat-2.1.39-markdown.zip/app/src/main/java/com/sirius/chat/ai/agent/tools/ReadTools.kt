package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.int
import com.sirius.chat.ai.agent.string
import com.sirius.chat.ai.agent.stringOrEmpty
import com.sirius.chat.core.util.Formatters
import kotlinx.serialization.json.JsonObject

/**
 * Reads a file, in pages.
 *
 * The old version read up to 200 KB and returned the whole thing as one string,
 * which looked correct and was not: [com.sirius.chat.ai.agent.AgentEngine] clips
 * every tool result before it reaches the model, so a file longer than that clip
 * arrived cut off *without saying so*. The model then rewrote the file from the
 * fragment it had and silently deleted the tail — the worst possible failure for
 * a coding tool.
 *
 * So the tool now owns its own limit instead of being cut by someone else:
 *
 *  - a page is bounded by both lines ([limit]) and characters ([MAX_PAGE_CHARS]),
 *    and always ends on a line boundary, so the model never sees half a line;
 *  - the header states which lines came back out of how many, so "is this all of
 *    it" is answerable without counting;
 *  - when lines remain, the footer is a ready-to-send call with the next
 *    `offset`, because a model that is told *how* to continue does, and a model
 *    that is merely told it was truncated guesses.
 */
class ReadFileTool : AgentTool {
    override val name = "read_file"
    override val description =
        "Read a text file from the workspace as numbered lines. Long files are returned in " +
            "pages: if the footer reports remaining lines, call this again with the offset it " +
            "gives you and keep going until the whole file has been read."
    override val usage =
        """{"path": "app/src/main/java/Main.kt", "offset": 1, "limit": 800}"""
    override val requiredArgs = listOf("path")

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val path = args.string("path") ?: return AgentToolResult("Missing 'path'.", success = false)
        val node = context.workspace.findByPath(tree, path)
            ?: return AgentToolResult("File not found: $path", success = false)
        if (node.isDirectory) return AgentToolResult("$path is a directory.", success = false)

        val content = context.workspace.readText(tree, node.documentId, maxBytes = MAX_FILE_BYTES)
        val lines = content.lines()
        val total = lines.size

        // Both are accepted as strings too: models emit "offset": "278" often
        // enough that rejecting it would just cost a round trip. `int` handles it.
        val offset = args.int("offset", 1).coerceIn(1, maxOf(total, 1))
        val limit = args.int("limit", DEFAULT_LINE_LIMIT).coerceIn(1, MAX_LINE_LIMIT)

        val page = StringBuilder()
        var lastLine = offset - 1
        var budget = 0
        val end = minOf(total, offset - 1 + limit)
        for (index in (offset - 1) until end) {
            val rendered = "${index + 1}\t${lines[index]}"
            // Always emit at least one line, however long it is: a single
            // minified line that exceeds the whole budget still has to come back
            // rather than producing an empty page the model cannot advance past.
            if (budget + rendered.length + 1 > MAX_PAGE_CHARS && lastLine >= offset) break
            page.append(rendered).append('\n')
            budget += rendered.length + 1
            lastLine = index + 1
        }

        val remaining = total - lastLine
        return AgentToolResult(
            buildString {
                append("File: $path (${Formatters.fileSize(node.sizeBytes)}, $total lines)")
                appendLine(" — showing lines $offset-$lastLine")
                append(page)
                if (remaining > 0) {
                    appendLine(
                        "\u2026 $remaining more lines. This is NOT the end of the file. Continue with:"
                    )
                    append("""{"tool": "read_file", "args": {"path": "$path", "offset": ${lastLine + 1}}}""")
                } else {
                    append("(end of file)")
                }
            }
        )
    }

    private companion object {
        /**
         * Characters per page. Sized to sit under the engine's own clip so a page
         * is never cut a second time on its way to the model.
         */
        const val MAX_PAGE_CHARS = 20_000

        const val DEFAULT_LINE_LIMIT = 800
        const val MAX_LINE_LIMIT = 4_000

        /**
         * How much of the file is read from storage before paging.
         *
         * Generous on purpose: the byte cap is a guard against opening a
         * multi-megabyte binary, not a reading limit, and the previous 200 KB was
         * small enough to clip real source files.
         */
        const val MAX_FILE_BYTES = 4L * 1024 * 1024
    }
}

class ListDirectoryTool : AgentTool {
    override val name = "list_directory"
    override val description = "List files and folders of a directory."
    override val usage = """{"path": "app/src/main"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val path = args.stringOrEmpty("path")
        val node = if (path.isBlank() || path == "." || path == "/") {
            context.workspace.rootNode(tree)
        } else {
            context.workspace.findByPath(tree, path)
        } ?: return AgentToolResult("Directory not found: $path", success = false)

        val children = context.workspace.listChildren(tree, node.documentId, node.path)
        if (children.isEmpty()) return AgentToolResult("$path is empty.")
        val listing = children.joinToString("\n") { child ->
            if (child.isDirectory) "dir   ${child.name}/"
            else "file  ${child.name}  ${Formatters.fileSize(child.sizeBytes)}"
        }
        return AgentToolResult("Contents of ${node.path.ifBlank { "/" }}:\n$listing")
    }
}

class SearchFilesTool : AgentTool {
    override val name = "search_files"
    override val description = "Find files whose name contains a substring."
    override val usage = """{"query": "ViewModel", "limit": 40}"""
    override val requiredArgs = listOf("query")

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val query = args.string("query") ?: return AgentToolResult("Missing 'query'.", success = false)
        val limit = args.int("limit", 40).coerceIn(1, 200)
        val results = context.workspace.searchFiles(tree, query, limit)
        if (results.isEmpty()) return AgentToolResult("No files match '$query'.")
        return AgentToolResult(results.joinToString("\n") { it.path })
    }
}

class SearchTextTool : AgentTool {
    override val name = "search_text"
    override val description = "Search the workspace for a text fragment and return matching lines."
    override val usage = """{"query": "fun onCreate", "limit": 40}"""
    override val requiredArgs = listOf("query")

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val query = args.string("query") ?: return AgentToolResult("Missing 'query'.", success = false)
        val limit = args.int("limit", 40).coerceIn(1, 200)
        val matches = context.workspace.searchText(tree, query, limit)
        if (matches.isEmpty()) return AgentToolResult("No matches for '$query'.")
        return AgentToolResult(matches.joinToString("\n") { "${it.path}:${it.lineNumber}: ${it.line}" })
    }
}

class AnalyzeProjectTool : AgentTool {
    override val name = "analyze_project"
    override val description = "Summarise the project: size, languages and directory tree."
    override val usage = """{}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val snapshot = context.workspace.snapshot(tree)
        val languages = snapshot.languages.entries.joinToString(", ") { "${it.key} \u00D7 ${it.value}" }
        return AgentToolResult(
            buildString {
                appendLine("Project: ${snapshot.rootName}")
                appendLine("Files: ${snapshot.fileCount}, folders: ${snapshot.directoryCount}, size: ${Formatters.fileSize(snapshot.totalBytes)}")
                appendLine("Languages: $languages")
                appendLine()
                appendLine("Tree:")
                append(snapshot.tree)
                if (snapshot.truncated) appendLine("\u2026 tree truncated \u2026")
            }
        )
    }
}
