package com.sirius.chat.ai.capability

import com.sirius.chat.ai.provider.ModelQuirks
import com.sirius.chat.ai.provider.ParamQuirks
import com.sirius.chat.domain.model.EndpointCapabilities
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import java.util.Locale

/**
 * One capabilities object per endpoint family, keyed by preset id and model.
 *
 * ### Why a table and not a probe
 * Power fields cannot be probed cheaply the way vision and tools are: a wrong
 * guess is a 400 that costs a real turn, and "does this model accept a thinking
 * budget" has no free question that answers it. So the known families are
 * listed, the numbers are the published output ceilings rather than round
 * numbers, and anything unknown falls back to the one field every
 * `/chat/completions` server accepts.
 *
 * ### Adding an endpoint
 * Add a branch here. Nothing else changes -- the resolver reads only this type,
 * so a new provider cannot require new resolver logic.
 */
object EndpointCapabilityTable {

    /** What this endpoint+model declares, before experience narrows it. */
    fun of(config: ProviderConfig?, modelId: String): EndpointCapabilities {
        // No endpoint, no claims. A missing config means the request is already
        // broken for a different reason, and guessing knobs for it would only add
        // fields to a call that cannot be made.
        if (config == null || modelId.isBlank()) return EndpointCapabilities.None
        val id = modelId.lowercase(Locale.US).substringAfterLast('/')
        val window = config.models.firstOrNull { it.id == modelId }?.contextWindow ?: 0
        val declared = when (config.id) {
            "openai" -> openai(id)
            "anthropic" -> anthropic(id)
            "google-gemini" -> gemini(id)
            "xai" -> xai(id)
            "deepseek" -> deepseek(id)
            "zai" -> zai(id)
            "groq" -> groq(id)
            "openrouter" -> openrouter(window)
            "perplexity" -> perplexity(id)
            "qwen" -> qwen(id)
            "moonshot" -> moonshot(id)
            "minimax" -> tokens(8_192)
            "mistral" -> tokens(8_192)
            "cohere" -> tokens(4_096)
            "together" -> tokens(8_192)
            "fireworks" -> tokens(8_192)
            "deepinfra" -> tokens(8_192)
            "sambanova" -> tokens(8_192)
            "nebius" -> tokens(8_192)
            "novita" -> tokens(8_192)
            "nvidia-nim" -> tokens(8_192)
            "huggingface" -> tokens(4_096)
            "cerebras" -> cerebras(id)
            "ollama", "lmstudio" -> local(window)
            else -> fallback(window)
        }
        // Every branch above is an endpoint somebody added by hand, which is why
        // a gateway nobody listed came out length-only even while it served a
        // thinking model. The model's own name and the dialect it speaks are true
        // no matter who hosts it, so they get the last word.
        return upgrade(declared, id, config.type)
    }

    /**
     * The same thing, minus whatever this model has already refused.
     *
     * A learned rejection outranks the table: the endpoint itself said no, and
     * repeating the field would repeat the 400. This is also what makes the UI
     * honest -- a gateway that turns out to ignore every knob ends up reporting
     * "not adjustable" instead of pretending.
     */
    fun effective(config: ProviderConfig?, modelId: String): EndpointCapabilities {
        val declared = of(config, modelId)
        val providerId = config?.id ?: return declared
        return narrow(declared, ModelQuirks.of(providerId, modelId))
    }

    fun narrow(caps: EndpointCapabilities, quirks: ParamQuirks): EndpointCapabilities = caps.copy(
        supportsReasoningEffort = caps.supportsReasoningEffort && quirks.sendReasoningEffort,
        supportsThinkingBudget = caps.supportsThinkingBudget && quirks.sendThinking,
        supportsMaxTokens = caps.supportsMaxTokens && quirks.sendMaxTokens,
        // A refusal is recorded apart from a declaration, because manual mode may
        // send a field the table never declared -- but never one this endpoint
        // has already rejected.
        refusedReasoningEffort = caps.refusedReasoningEffort || !quirks.sendReasoningEffort,
        refusedThinkingBudget = caps.refusedThinkingBudget || !quirks.sendThinking
    )

    /**
     * Fills in what a table of endpoint ids cannot know: the model and dialect.
     *
     * Only ever widens, and only where nothing was declared -- a listed endpoint
     * is a fact and outranks a name. Two steps:
     *
     * 1. An Anthropic-dialect endpoint gets the budget's wire path even for an
     *    unrecognised model, because `thinking.budget_tokens` belongs to the
     *    protocol rather than to any one model. Presets stay off; manual mode can
     *    reach it.
     * 2. A name that reads as a thinking model gets the knob its dialect uses.
     *    `reasoning_effort` is the one spelling every OpenAI-shaped gateway
     *    agrees on, which is what makes trying it safe: an endpoint that does not
     *    know the field answers with a 400 that names it, `ModelQuirks` records
     *    the refusal, the step is retried without it, and the sheet stops
     *    offering it. One hidden retry, once per model, is the whole price.
     */
    private fun upgrade(
        base: EndpointCapabilities,
        id: String,
        type: ProviderType
    ): EndpointCapabilities {
        if (base.supportsReasoningEffort || base.supportsThinkingBudget) return base
        val anthropicDialect = type == ProviderType.AnthropicCompatible
        val withPath = if (anthropicDialect && base.thinkingBudgetKey.isBlank()) {
            base.copy(
                thinkingBudgetKey = "thinking.budget_tokens",
                thinkingBudgetMin = 1_024,
                thinkingBudgetMax = 32_000,
                thinkingEnableFlags = mapOf("thinking.type" to "enabled")
            )
        } else {
            base
        }
        if (!looksLikeThinking(id)) return withPath
        // A Claude id that reads as 4.7 or later must not be offered a budget on
        // its own protocol: the fixed budget is gone there and
        // `thinking.type: enabled` answers 400, so the guess has to be the
        // adaptive word instead. Behind an OpenAI-shaped proxy the same model
        // takes `reasoning_effort` like everything else, which is the branch
        // below.
        if (anthropicDialect && adaptiveOnly(id)) {
            return adaptive(ANTHROPIC_EFFORT_TIERS, anthropicOutput(id)).copy(inferred = true)
        }
        return if (anthropicDialect) {
            withPath.copy(
                supportsThinkingBudget = true,
                maxTokensLimit = withPath.maxTokensLimit ?: 64_000,
                inferred = true
            )
        } else {
            withPath.copy(
                supportsReasoningEffort = true,
                reasoningTiers = STANDARD_TIERS,
                inferred = true
            )
        }
    }

    /**
     * Whether a model id reads as one that thinks.
     *
     * A list of families rather than one rule, because the honest names are the
     * minority: `deepseek-r1`, `qwq`, `magistral` and `gpt-oss` say nothing about
     * reasoning and are exactly the models people run on their own gateways. A
     * wrong guess costs one retry and is then forgotten, so this leans towards
     * trying rather than towards silence.
     */
    private fun looksLikeThinking(id: String): Boolean = when {
        REASONING_PREFIXES.any { id.startsWith(it) } -> !id.contains("chat")
        OPENAI_REASONING.containsMatchIn(id) -> !id.contains("chat")
        thinks(id) -> true
        id.startsWith("grok-3-mini") -> true
        id.startsWith("gemini-2.5") || id.startsWith("gemini-3") -> true
        else -> THINKING_MARKERS.any { id.contains(it) }
    }

    // --- families ---------------------------------------------------------

    /**
     * Effort on the o-series and gpt-5, length on everything else.
     *
     * The reasoning families also rename the length field, but that is
     * `ModelQuirks`' job; here it only matters that they have a real tier.
     */
    private fun openai(id: String): EndpointCapabilities = when {
        // `gpt-5-chat` is the non-reasoning sibling and refuses the field, so a
        // family prefix on its own is not enough to claim a tier.
        id.contains("chat") -> tokens(16_384)
        // The two models that shipped before the field existed. They answer
        // "Unknown parameter: 'reasoning_effort'", so they stay length-only
        // even though they are reasoning models.
        id.startsWith("o1-preview") || id.startsWith("o1-mini") -> tokens(65_536)
        id.startsWith("gpt-5") -> effort(gptTiers(id), limit = 128_000)
        REASONING_PREFIXES.any { id.startsWith(it) } -> effort(STANDARD_TIERS, limit = 100_000)
        // A line this table has never met -- gpt-6, o5 -- still gets a tier, but
        // the three words every OpenAI reasoning model has taken since o1 rather
        // than the newest ladder. An unknown *value* is rejected in the same
        // breath as an unknown *field*, and that rejection would cost the
        // endpoint its knob entirely instead of one step of it.
        OPENAI_REASONING.containsMatchIn(id) -> effort(STANDARD_TIERS, limit = 128_000)
        id.startsWith("gpt-4.1") -> tokens(32_768)
        else -> tokens(16_384)
    }

    /**
     * The gpt-5 ladder grew with the line, and a word this model does not know
     * is a 400 rather than a weaker answer.
     *
     * `none` arrives with 5.1, `xhigh` with the codex-max models and 5.2, `max`
     * with 5.6. Only the version is read, so the suffixed siblings --
     * `gpt-5.6-sol`, `-terra`, `-luna`, `-mini`, `-codex`, dated snapshots --
     * land on the right ladder without being listed one by one. An id whose
     * version cannot be read keeps the three words every reasoning endpoint has
     * always taken.
     */
    private fun gptTiers(id: String): List<String> {
        val minor = GPT5_MINOR.find(id)?.groupValues?.lastOrNull()?.toIntOrNull() ?: 0
        return when {
            minor >= 6 -> listOf("none", "low", "medium", "high", "xhigh", "max")
            minor >= 2 || id.contains("codex-max") ->
                listOf("none", "low", "medium", "high", "xhigh")
            minor >= 1 -> listOf("none", "low", "medium", "high")
            else -> STANDARD_TIERS
        }
    }

    /**
     * Anthropic takes a budget, and the budget has to fit inside `max_tokens`.
     *
     * `max_tokens` is required on every request here, so it is always declared;
     * the resolver is what keeps the two numbers consistent.
     */
    private fun anthropic(id: String): EndpointCapabilities = when {
        // 4.7 and later dropped the fixed budget: `thinking.type: enabled` is a
        // 400 there and adaptive effort is the only dial left. That is exactly
        // the model this app was sending a budget to. 4.6 accepts both shapes
        // but not the word `xhigh`, which is why its ladder is one shorter.
        adaptiveOnly(id) -> adaptive(ANTHROPIC_EFFORT_TIERS, anthropicOutput(id))
        adaptiveAlso(id) -> adaptive(listOf("low", "medium", "high", "max"), anthropicOutput(id))
        thinks(id) -> EndpointCapabilities(
            supportsThinkingBudget = true,
            thinkingBudgetKey = "thinking.budget_tokens",
            thinkingBudgetMin = 1_024,
            thinkingBudgetMax = 32_000,
            thinkingEnableFlags = mapOf("thinking.type" to "enabled"),
            maxTokensLimit = anthropicOutput(id)
        )
        else -> tokens(8_192)
    }

    /**
     * Adaptive thinking: the effort word travels in `output_config`, and the
     * `thinking` object carries a mode instead of a size.
     *
     * No budget is declared on purpose -- not "unknown" but rejected, and the
     * resolver must never fall back to one here.
     */
    private fun adaptive(tiers: List<String>, limit: Int) = EndpointCapabilities(
        supportsReasoningEffort = true,
        reasoningTiers = tiers,
        reasoningEffortKey = "output_config.effort",
        thinkingEnableFlags = mapOf("thinking.type" to "adaptive"),
        maxTokensLimit = limit
    )

    /** 4.7 and later, Opus 5 and Sonnet 5 included: adaptive or nothing. */
    private fun adaptiveOnly(id: String): Boolean {
        val (major, minor) = claudeVersion(id)
        return major >= 5 || (major == 4 && minor >= 7)
    }

    /** 4.6: adaptive works, `xhigh` does not, the old budget still passes. */
    private fun adaptiveAlso(id: String): Boolean {
        val (major, minor) = claudeVersion(id)
        return major == 4 && minor == 6
    }

    /**
     * The version pair out of a Claude id, in whichever order the words come:
     * `claude-opus-4-6`, `claude-sonnet-5`, `claude-opus-5-thinking`,
     * `claude-4.7-opus`. Missing minor reads as zero, so `claude-sonnet-5` is
     * 5.0 and still lands on the adaptive branch.
     */
    private fun claudeVersion(id: String): Pair<Int, Int> {
        val match = CLAUDE_VERSION.find(id) ?: return 0 to 0
        val major = match.groupValues.getOrNull(1)?.toIntOrNull() ?: 0
        val minor = match.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
        return major to minor
    }

    /**
     * Whether this Claude has extended thinking, read off its version.
     *
     * A list of exact prefixes is what broke: `claude-opus-4-1` was covered and
     * `claude-opus-5-thinking` -- the same API one number later -- fell into the
     * length-only branch, where a thinking model got no budget at all and an 8k
     * cap that also clamped the user's own setting. HIGH and MAX then resolved
     * to the same number, so two of the five modes did nothing. A comparison
     * keeps working when the next model ships.
     */
    private fun thinks(id: String): Boolean = when {
        // Spelled out in the id. Nothing left to infer.
        id.contains("thinking") -> true
        // The oldest model with a budget, and the only one whose version sits in
        // front of the family word.
        id.startsWith("claude-3-7") || id.startsWith("claude-3.7") -> true
        // Everything else in the 2.x/3.x era predates extended thinking.
        id.startsWith("claude-2") || id.startsWith("claude-3") -> false
        else -> (CLAUDE_MAJOR.find(id)?.groupValues?.lastOrNull()?.toIntOrNull() ?: 0) >= 4
    }

    /**
     * The published output ceiling, which is not one number across a single
     * line: Opus 4 tops out at 32k where Sonnet and Haiku take 64k.
     *
     * Worth being exact about, because too high a ceiling is a 400 whose wording
     * is about a number rather than a field -- and that kind of rejection
     * teaches `ModelQuirks` nothing, so it would cost the turn every time.
     */
    private fun anthropicOutput(id: String): Int {
        val (major, minor) = claudeVersion(id)
        return when {
            // Opus 5 publishes 128k of output where Opus 4 was the lowest of the
            // thinking models at 32k.
            major >= 5 -> if (id.contains("opus")) 128_000 else 64_000
            major == 4 && minor >= 6 -> 64_000
            id.contains("opus-4") || id.startsWith("claude-3-7") -> 32_000
            else -> 64_000
        }
    }

    /**
     * Gemini 2.5 accepts both an effort word and an exact budget.
     *
     * The budget travels in `extra_body`, which is how the OpenAI-compatible
     * surface passes native Google fields through. 2.0 has no thinking at all.
     */
    private fun gemini(id: String): EndpointCapabilities = when {
        // Image, speech and embedding endpoints reject a thinking config
        // outright, whatever generation they belong to.
        id.contains("image") || id.contains("tts") || id.contains("embedding") ->
            tokens(8_192)
        // 3 and later replaced the token budget with a word, in the same nested
        // object. The two are mutually exclusive -- sending the old field to a 3
        // is an error -- so only one of them is ever declared.
        GEMINI_3_PLUS.containsMatchIn(id) -> EndpointCapabilities(
            supportsReasoningEffort = true,
            // Pro takes only the two ends of the ladder: `medium` is an error
            // there. Flash and Lite take all four.
            reasoningTiers = if (id.contains("pro")) {
                listOf("low", "high")
            } else {
                listOf("minimal", "low", "medium", "high")
            },
            reasoningEffortKey = GEMINI_LEVEL_KEY,
            maxTokensLimit = 65_536
        )
        id.startsWith("gemini-2.5-pro") -> EndpointCapabilities(
            supportsReasoningEffort = true,
            reasoningTiers = STANDARD_TIERS,
            supportsThinkingBudget = true,
            thinkingBudgetKey = GEMINI_BUDGET_KEY,
            thinkingBudgetMin = 128,
            thinkingBudgetMax = 32_768,
            maxTokensLimit = 65_536
        )
        id.startsWith("gemini-2.5") -> EndpointCapabilities(
            supportsReasoningEffort = true,
            reasoningTiers = STANDARD_TIERS,
            supportsThinkingBudget = true,
            thinkingBudgetKey = GEMINI_BUDGET_KEY,
            // Zero is legal and means "do not think", which is what LOW wants.
            thinkingBudgetMin = 0,
            thinkingBudgetMax = 24_576,
            maxTokensLimit = 65_536
        )
        else -> tokens(8_192)
    }

    /**
     * grok-3-mini has two tiers and no middle one; grok-4 always reasons and
     * rejects the field outright, so it is declared as length-only.
     */
    private fun xai(id: String): EndpointCapabilities = when {
        id.startsWith("grok-3-mini") -> effort(listOf("low", "high"), limit = 32_768)
        // 4.6 added `xhigh`; on 4.5 that word is silently treated as `high`, and
        // 4.3 is the only one of the four that can switch thinking off.
        grokAtLeast(id, 4, 6) -> effort(listOf("low", "medium", "high", "xhigh"), limit = 65_536)
        grokAtLeast(id, 4, 5) -> effort(STANDARD_TIERS, limit = 65_536)
        grokAtLeast(id, 4, 3) -> effort(listOf("none", "low", "medium", "high"), limit = 65_536)
        // grok-4, grok-4.1-fast and the code models reason on their own and
        // reject the field outright.
        else -> tokens(32_768)
    }

    /** Whether a Grok id is at least this version, `grok-4.5-fast` included. */
    private fun grokAtLeast(id: String, major: Int, minor: Int): Boolean {
        val match = GROK_VERSION.find(id) ?: return false
        val gotMajor = match.groupValues.getOrNull(1)?.toIntOrNull() ?: return false
        val gotMinor = match.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
        return gotMajor > major || (gotMajor == major && gotMinor >= minor)
    }

    /**
     * GLM 5 grades effort with the OpenAI word, but only while thinking is on.
     *
     * 5.3 removed `disabled` altogether -- a request that asks for it fails --
     * and takes three words; 5.0 to 5.2 take the full six. On 4.x there is no
     * grading at all: the nested type is the whole control, so its own two words
     * are the tiers.
     */
    private fun zai(id: String): EndpointCapabilities = when {
        glmAtLeast(id, 5, 3) -> glm(listOf("low", "high", "max"))
        glmAtLeast(id, 5, 0) ->
            glm(listOf("minimal", "low", "medium", "high", "xhigh", "max"))
        id.startsWith("glm-4") -> EndpointCapabilities(
            supportsReasoningEffort = true,
            // "enabled" twice on purpose: MEDIUM lands on the second slot, and
            // this endpoint has nothing between off and on.
            reasoningTiers = listOf("disabled", "enabled", "enabled"),
            reasoningEffortKey = "thinking.type",
            maxTokensLimit = 16_384
        )
        else -> tokens(8_192)
    }

    private fun glm(tiers: List<String>) = EndpointCapabilities(
        supportsReasoningEffort = true,
        reasoningTiers = tiers,
        thinkingEnableFlags = mapOf("thinking.type" to "enabled"),
        maxTokensLimit = 32_768
    )

    private fun glmAtLeast(id: String, major: Int, minor: Int): Boolean {
        val match = GLM_VERSION.find(id) ?: return false
        val gotMajor = match.groupValues.getOrNull(1)?.toIntOrNull() ?: return false
        val gotMinor = match.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
        return gotMajor > major || (gotMajor == major && gotMinor >= minor)
    }

    private fun groq(id: String): EndpointCapabilities = when {
        id.startsWith("gpt-oss") -> effort(STANDARD_TIERS, limit = 32_768)
        id.startsWith("qwen3") -> effort(listOf("none", "default"), limit = 32_768)
        else -> tokens(8_192)
    }

    /**
     * OpenRouter normalises everyone else's knobs into one object, so both a
     * tier and a budget are available whatever the underlying model is.
     */
    private fun openrouter(window: Int): EndpointCapabilities = EndpointCapabilities(
        supportsReasoningEffort = true,
        // The gateway's own enum, wider than any single model behind it: it
        // translates the word into whatever the target family actually wants.
        reasoningTiers = listOf("minimal", "low", "medium", "high", "xhigh"),
        reasoningEffortKey = "reasoning.effort",
        supportsThinkingBudget = true,
        thinkingBudgetKey = "reasoning.max_tokens",
        thinkingBudgetMin = 1_024,
        thinkingBudgetMax = 32_000,
        maxTokensLimit = if (window > 0) minOf(window, 32_768) else 32_768
    )

    private fun perplexity(id: String): EndpointCapabilities =
        if (id.contains("reasoning")) effort(STANDARD_TIERS, limit = 8_192) else tokens(8_192)

    /**
     * DashScope gates both fields behind its own boolean, and rejects the pair
     * when they arrive together -- which the wire converter already prevents.
     *
     * The budget stops well short of the published 38 912: it is spent from the
     * same allowance as the reply, so a budget above the output ceiling is
     * thinking that never becomes text.
     */
    private fun qwen(id: String): EndpointCapabilities = when {
        id.startsWith("qwen3") || id.startsWith("qwen-plus") || id.startsWith("qwen-max") ->
            EndpointCapabilities(
                supportsReasoningEffort = true,
                reasoningTiers = listOf("low", "medium", "xhigh"),
                supportsThinkingBudget = true,
                thinkingBudgetKey = "thinking_budget",
                thinkingBudgetMin = 0,
                thinkingBudgetMax = 8_192,
                thinkingEnableFlags = mapOf("enable_thinking" to true),
                maxTokensLimit = 16_384
            )
        else -> tokens(8_192)
    }

    /**
     * V4 split the old chat/reasoner pair into a switch and a word.
     *
     * No `medium` and no `xhigh` in the ladder: the server folds them onto
     * `high` and `max`, which would make two of the four modes identical.
     */
    private fun deepseek(id: String): EndpointCapabilities = when {
        id.contains("chat") && !id.contains("v4") -> tokens(8_192)
        else -> EndpointCapabilities(
            supportsReasoningEffort = true,
            reasoningTiers = listOf("low", "high", "max"),
            thinkingEnableFlags = mapOf("thinking.type" to "enabled"),
            maxTokensLimit = 65_536
        )
    }

    /**
     * K3 takes the OpenAI word at the top level. K2.5 and K2.6 carry their own
     * `thinking` block and reject the word beside it, so they stay length-only.
     */
    private fun moonshot(id: String): EndpointCapabilities = when {
        kimiAtLeast(id, 3) -> effort(listOf("low", "high", "max"), limit = 32_768)
        else -> tokens(16_384)
    }

    private fun kimiAtLeast(id: String, major: Int): Boolean {
        val match = KIMI_VERSION.find(id) ?: return false
        return (match.groupValues.getOrNull(1)?.toIntOrNull() ?: 0) >= major
    }

    /** Cerebras hosts gpt-oss, the one model there that grades effort. */
    private fun cerebras(id: String): EndpointCapabilities =
        if (id.startsWith("gpt-oss")) effort(STANDARD_TIERS, limit = 32_768) else tokens(8_192)

    /**
     * A local server's only honest ceiling is the window it declares.
     *
     * LM Studio's placeholder model reports 8k, and asking it for more output
     * than its whole window is how a local run ends in a stall rather than an
     * error.
     */
    private fun local(window: Int): EndpointCapabilities =
        tokens(if (window > 0) window else 4_096)

    /**
     * An endpoint nobody has described: a user-added gateway, or a model this
     * table has never seen.
     *
     * Length only, capped by whatever window the preset declared. A model whose
     * name says "reasoning" still gets no reasoning field here: the name is not
     * the API, and the field is only safe when the endpoint is known to take it.
     */
    private fun fallback(window: Int): EndpointCapabilities =
        tokens(if (window > 0) minOf(window, 16_384) else 4_096)

    // --- builders ---------------------------------------------------------

    private fun tokens(limit: Int) =
        EndpointCapabilities(supportsMaxTokens = true, maxTokensLimit = limit)

    private fun effort(tiers: List<String>, limit: Int) = EndpointCapabilities(
        supportsReasoningEffort = true,
        reasoningTiers = tiers,
        supportsMaxTokens = true,
        maxTokensLimit = limit
    )

    private val STANDARD_TIERS = listOf("low", "medium", "high")

    /**
     * The major version in a Claude id, with or without the family word:
     * `claude-sonnet-4-5`, `claude-opus-5-thinking`, `claude-4-opus`.
     */
    private val CLAUDE_MAJOR = Regex("""claude-(?:opus-|sonnet-|haiku-)?(\d+)""")

    /**
     * Families that think without saying so in their name.
     *
     * These are the models that actually turn up on self-hosted and third-party
     * gateways, where the endpoint id says nothing at all.
     */
    private val THINKING_MARKERS = listOf(
        "thinking",
        "reasoner",
        "reasoning",
        "deepseek-r",
        "qwq",
        "qwen3",
        "gpt-oss",
        "glm-4.5",
        "glm-4.6",
        "glm-z1",
        "magistral",
        "minimax-m",
        "nemotron",
        "ernie-x1",
        "hunyuan-t1",
        // 2026 lines whose names say nothing about reasoning at all
        "deepseek-v4",
        "glm-5",
        "kimi-k3",
        "seed-thinking",
        "ring-1t"
    )

    private const val GEMINI_BUDGET_KEY =
        "extra_body.google.thinking_config.thinking_budget"

    /** Gemini 3 replaced the budget with a word, in the same nested object. */
    private const val GEMINI_LEVEL_KEY =
        "extra_body.google.thinking_config.thinking_level"

    private val GEMINI_3_PLUS = Regex("""gemini-([3-9]|\d{2,})""")

    /** Claude's ladder from 4.7 on. */
    private val ANTHROPIC_EFFORT_TIERS =
        listOf("low", "medium", "high", "xhigh", "max")

    /**
     * Major and minor together: `claude-opus-4-6`, `claude-sonnet-5`,
     * `claude-4.7-opus`. [CLAUDE_MAJOR] stays for the older question of whether
     * a model thinks at all.
     */
    private val CLAUDE_VERSION =
        Regex("""claude-(?:opus-|sonnet-|haiku-)?(\d+)(?:[.-](\d+))?""")

    private val GPT5_MINOR = Regex("""gpt-5[.-](\d+)""")

    private val GROK_VERSION = Regex("""grok-(\d+)(?:[.-](\d+))?""")

    private val GLM_VERSION = Regex("""glm-(\d+)(?:[.-](\d+))?""")

    private val KIMI_VERSION = Regex("""kimi-k(\d+)""")

    private val REASONING_PREFIXES = listOf("o1", "o3", "o4", "gpt-5")

    /**
     * The shape of an OpenAI reasoning id for lines that do not exist yet: any
     * `o` followed by a digit, and any `gpt-` from 6 upwards.
     *
     * A list of prefixes is what would go stale here -- the same failure the
     * Claude version comparison already replaced.
     */
    private val OPENAI_REASONING = Regex("""^(o\d|gpt-([6-9]|\d{2,}))""")
}
