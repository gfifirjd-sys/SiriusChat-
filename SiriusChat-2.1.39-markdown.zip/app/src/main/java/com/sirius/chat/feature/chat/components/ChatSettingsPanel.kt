package com.sirius.chat.feature.chat.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DataUsage
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.SheetActionRow
import com.sirius.chat.core.designsystem.components.SiriusCheckToggle
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.domain.model.ChatFeature
import com.sirius.chat.domain.model.DefaultPowerMode
import com.sirius.chat.domain.model.PowerMode
import com.sirius.chat.domain.model.ChatFeatures
import com.sirius.chat.domain.model.FeatureSupport
import com.sirius.chat.domain.model.FeatureTier

/**
 * The chat's own settings, on the right edge.
 *
 * ### Why a right-edge panel and not a bottom sheet
 * The app already has `SiriusBottomSheet` and the model picker uses it, so a
 * sheet would have been less code. It is the wrong container here for one
 * concrete reason: a bottom sheet covers the composer and the last few messages,
 * and these switches are things the user flips *while looking at a reply* — "this
 * answer is stale, turn the internet on and ask again". Losing sight of the
 * transcript is losing the reason you opened the panel.
 *
 * A right-edge panel keeps the conversation visible beside it, and it matches
 * where the trigger lives (the top bar's trailing action), so the panel appears
 * to come out of the button that opened it.
 *
 * ### Why the scrim is not a Dialog
 * A `Dialog` would place this in its own window, which on Android means its own
 * animation clock and its own insets. The panel is drawn in the chat's own
 * hierarchy instead, so it shares the transcript's frame timing and cannot
 * flicker out of sync with the scrim behind it.
 */
@Composable
fun ChatSettingsPanel(
    visible: Boolean,
    features: ChatFeatures,
    support: FeatureSupport,
    /** Feature whose switch is mid-write, so the toggle can show its spinner. */
    busyFeature: ChatFeature?,
    modelLabel: String,
    onToggle: (ChatFeature, Boolean) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    /** Whether this chat shows the context meter. */
    contextMeter: Boolean = true,
    onToggleContextMeter: (Boolean) -> Unit = {},
    /** Whether this chat is told what is already known about the user. */
    memory: Boolean = true,
    onToggleMemory: (Boolean) -> Unit = {},
    /** Opens the memory graph -- everything the app has learned, as a whole. */
    onOpenMemory: () -> Unit = {},
    /** The power mode stored for this chat's endpoint and model. */
    powerMode: PowerMode = DefaultPowerMode,
    /** Whether that pair has anything to configure. */
    powerSupported: Boolean = true,
    onOpenPower: () -> Unit = {}
) {
    val colors = SiriusTheme.colors

    // The scrim and the panel are animated together but not identically: the
    // scrim fades over the full duration while the panel slides with the
    // emphasised curve, so the background dims slightly ahead of the panel
    // arriving. Matching them exactly makes the panel feel like it is dragging
    // the scrim with it.
    val scrimAlpha by animateFloatAsState(
        targetValue = if (visible) ScrimAlpha else 0f,
        animationSpec = siriusTween(SiriusMotion.Base, SiriusMotion.Standard),
        label = "settingsScrim"
    )

    Box(modifier = modifier.fillMaxSize()) {
        if (scrimAlpha > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(scrimAlpha)
                    .background(colors.background)
                    // No ripple and no role: this is a dismiss surface, not a
                    // button, and a ripple spreading across the whole transcript
                    // reads as the app registering a tap on the message behind it.
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onDismiss
                    )
            )
        }

        AnimatedVisibility(
            visible = visible,
            modifier = Modifier.align(Alignment.CenterEnd),
            enter = slideInHorizontally(
                animationSpec = siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)
            ) { it } + fadeIn(siriusTween(SiriusMotion.Quick)),
            exit = slideOutHorizontally(
                animationSpec = siriusTween(SiriusMotion.Quick, SiriusMotion.Exit)
            ) { it } + fadeOut(siriusTween(SiriusMotion.Quick))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .widthIn(max = PanelMaxWidth)
                    .fillMaxWidth(PanelWidthFraction)
                    .padding(SiriusSpacing.xs)
                    .clip(RoundedCornerShape(SiriusRadius.lg))
                    .glassSurface(RoundedCornerShape(SiriusRadius.lg))
                    .padding(SiriusSpacing.sm)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.chat_settings_title),
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary
                        )
                        Text(
                            // The model is named here because every disabled
                            // switch below is disabled *because of it*. Without
                            // this line the panel says "unsupported" and the user
                            // has no idea what to change to fix it.
                            text = modelLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textTertiary,
                            maxLines = 1
                        )
                    }
                    GlassIconButton(
                        icon = Icons.Rounded.Close,
                        contentDescription = stringResource(R.string.action_close),
                        onClick = onDismiss
                    )
                }

                Spacer(Modifier.height(SiriusSpacing.sm))

                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
                ) {
                    FeatureRows.forEach { row ->
                        FeatureToggleRow(
                            row = row,
                            enabled = features[row.feature],
                            state = support[row.feature],
                            busy = busyFeature == row.feature,
                            onToggle = { onToggle(row.feature, it) }
                        )
                    }

                    Spacer(Modifier.height(SiriusSpacing.xxs))
                    DisplayToggleRow(
                        title = stringResource(R.string.chat_settings_context_meter),
                        subtitle = stringResource(R.string.chat_settings_context_meter_hint),
                        icon = Icons.Rounded.DataUsage,
                        checked = contextMeter,
                        onToggle = onToggleContextMeter
                    )
                    DisplayToggleRow(
                        title = stringResource(R.string.chat_memory),
                        subtitle = stringResource(R.string.chat_memory_hint),
                        icon = Icons.Rounded.Psychology,
                        checked = memory,
                        onToggle = onToggleMemory,
                        onInspect = onOpenMemory,
                        inspectDescription = stringResource(R.string.settings_memory_open)
                    )
                    // Here as well as in the model picker, because this is the
                    // panel people already open mid-conversation to change how
                    // the next answer comes out -- and power is exactly that,
                    // not a capability of the model.
                    SheetActionRow(
                        icon = Icons.Rounded.Bolt,
                        label = stringResource(R.string.chat_power_title),
                        supporting = if (powerSupported) {
                            stringResource(powerLabelRes(powerMode))
                        } else {
                            stringResource(R.string.chat_power_unsupported_short)
                        },
                        onClick = onOpenPower,
                        trailing = {
                            PowerLevelBars(mode = powerMode, active = powerSupported)
                        }
                    )
                }
            }
        }
    }
}

/**
 * One switch.
 *
 * ### Why the whole row is the target and the toggle is not clickable
 * A 22dp badge is below the 48dp minimum touch target, and growing it to 48dp
 * would wreck the proportions the reference transition depends on. Making the row
 * the target solves both: the badge stays 22dp, the tap area is the full row, and
 * there is exactly one clickable thing per row rather than two overlapping ones
 * that fight over the same gesture.
 */
@Composable
private fun FeatureToggleRow(
    row: FeatureRow,
    enabled: Boolean,
    state: com.sirius.chat.domain.model.FeatureState,
    busy: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val colors = SiriusTheme.colors
    val usable = state.usable

    // The subtitle answers a different question depending on the tier, and that
    // is deliberate. Available: *what will run this*, because native and keyless
    // differ in cost and privacy. Unavailable: *why not*, because a greyed switch
    // with no reason is how a working app gets reported as broken.
    val subtitle = when (state.tier) {
        FeatureTier.Native -> state.engine
        FeatureTier.Builtin -> stringResource(R.string.chat_settings_engine_builtin, state.engine)
        FeatureTier.Unsupported -> stringResource(reasonRes(state.reasonKey))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.md))
            .then(if (enabled && usable) Modifier.softSurface(RoundedCornerShape(SiriusRadius.md)) else Modifier)
            .clickable(
                enabled = usable,
                role = Role.Switch,
                onClick = { onToggle(!enabled) }
            )
            .padding(SiriusSpacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = row.icon,
            contentDescription = null,
            tint = if (usable) colors.textSecondary else colors.textTertiary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(SiriusSpacing.xs))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(row.title),
                style = MaterialTheme.typography.bodyMedium,
                color = if (usable) colors.textPrimary else colors.textTertiary
            )
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary,
                    maxLines = 2
                )
            }
        }
        Spacer(Modifier.width(SiriusSpacing.xs))
        SiriusCheckToggle(
            // A stored `true` on an unsupported model shows as off, matching what
            // will actually happen on the next request -- `ChatFeatures.clampTo`
            // suppresses it. The preference is still on disk and comes back when
            // the model does; showing it as on here would promise a capability
            // the turn will not have.
            checked = enabled && usable,
            busy = busy,
            modifier = Modifier.alpha(if (usable) 1f else DisabledAlpha)
        )
    }
}

/** A row's static presentation. */
private data class FeatureRow(
    val feature: ChatFeature,
    val title: Int,
    val icon: ImageVector
)

/**
 * The panel's contents, in order.
 *
 * Ordered by how often it is touched, not by importance: internet and images are
 * the two the user came here for, so they are first and reachable without
 * reading. Vision, tools and streaming are set once and forgotten.
 */
private val FeatureRows = listOf(
    FeatureRow(ChatFeature.WebSearch, R.string.chat_settings_internet, Icons.Rounded.Language),
    FeatureRow(ChatFeature.ImageGeneration, R.string.chat_settings_images, Icons.Rounded.Image),
    // Directly under generation, because it is the same subject and because that
    // adjacency is what explains the greyed-out state: the user sees one image
    // switch they can turn on and one they cannot, with the reason underneath.
    FeatureRow(ChatFeature.ImageEditing, R.string.chat_settings_image_edit, Icons.Rounded.AutoFixHigh),
    FeatureRow(ChatFeature.Vision, R.string.chat_settings_vision, Icons.Outlined.Visibility),
    FeatureRow(ChatFeature.Tools, R.string.chat_settings_tools, Icons.Rounded.Build),
    FeatureRow(ChatFeature.Streaming, R.string.chat_settings_streaming, Icons.Rounded.Bolt)
)

/**
 * Maps a reason key from the capability layer to a sentence.
 *
 * Every key gets its own sentence rather than sharing a generic one, because a
 * disabled switch is only acceptable if it says what would enable it. "Editing
 * needs a key" is a two-tap fix; "unavailable" is a support ticket.
 */
private fun reasonRes(key: String): Int = when (key) {
    "vision" -> R.string.chat_settings_reason_vision
    // Measured, not guessed: this model was sent an image and refused it.
    "vision_probed" -> R.string.chat_settings_reason_vision_probed
    "tools" -> R.string.chat_settings_reason_tools
    "streaming" -> R.string.chat_settings_reason_streaming
    "image_edit" -> R.string.chat_settings_reason_image_edit
    "image_edit_key" -> R.string.chat_settings_reason_image_edit_key
    else -> R.string.chat_settings_reason_provider
}

private val PanelMaxWidth = 360.dp

/**
 * Not full width even on a narrow phone.
 *
 * The visible strip of transcript on the left is what makes this a panel over the
 * conversation rather than a second screen, and it is what tells the user a
 * single tap outside returns them.
 */
private const val PanelWidthFraction = 0.88f

private const val ScrimAlpha = 0.5f
private const val DisabledAlpha = 0.4f

/**
 * A row that changes what the panel *shows*, not what the model can do.
 *
 * ### Why this is not a FeatureRow
 * Every switch above it is a model capability: it has a tier, an engine, and a
 * reason it may be greyed out. A display preference has none of those, and
 * pushing it through the same type would have meant inventing a FeatureState
 * for it -- "natively supported" is a meaningless thing to say about a progress
 * bar, and it would then need clamping against a provider that has no opinion.
 * Separate row, no tier subtitle, never disabled.
 */
@Composable
private fun DisplayToggleRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    onToggle: (Boolean) -> Unit,
    /**
     * Adds an eye before the toggle that opens what the row controls, the same
     * way the memory row in Settings does. It takes its own taps, so looking at
     * memory never switches it off by accident.
     */
    onInspect: (() -> Unit)? = null,
    inspectDescription: String? = null
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(SiriusRadius.md))
            .softSurface(RoundedCornerShape(SiriusRadius.md))
            .clickable(role = Role.Switch, onClick = { onToggle(!checked) })
            .padding(SiriusSpacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = colors.textSecondary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(SiriusSpacing.xs))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textPrimary,
                maxLines = 1
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary,
                maxLines = 1
            )
        }
        if (onInspect != null) {
            GlassIconButton(
                icon = Icons.Outlined.Visibility,
                contentDescription = inspectDescription,
                onClick = onInspect,
                tint = colors.textSecondary,
                size = 32.dp,
                iconSize = 20.dp
            )
            Spacer(Modifier.width(SiriusSpacing.xs))
        }
        SiriusCheckToggle(checked = checked, busy = false)
    }
}
