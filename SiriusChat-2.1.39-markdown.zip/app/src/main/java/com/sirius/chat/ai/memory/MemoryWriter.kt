package com.sirius.chat.ai.memory

import com.sirius.chat.domain.model.MemoryFile
import com.sirius.chat.domain.model.MemoryNode
import com.sirius.chat.domain.model.MemoryWrite
import com.sirius.chat.domain.model.memoryNormalisePath
import com.sirius.chat.domain.model.memoryPath
import com.sirius.chat.domain.model.memoryPathCategory
import com.sirius.chat.domain.model.memoryPathFolder
import com.sirius.chat.domain.model.memoryPathSlug
import com.sirius.chat.domain.model.memoryTopicSlug
import com.sirius.chat.domain.repository.MemoryRepository
import kotlinx.coroutines.CancellationException
import java.util.Locale
import java.util.UUID

/** One file exactly as the model is shown it: version, aliases, and its lines. */
data class MemoryFileView(
    val path: String,
    val aliases: List<String> = emptyList(),
    val version: Int = MemoryFile.DERIVED_VERSION,
    val lines: List<MemoryNode> = emptyList(),
    /** The heading the file is shown with, empty until something names it. */
    val title: String = "",
    /** One line describing the file, empty until something describes it. */
    val summary: String = ""
)

/**
 * Memory arranged as files -- the listing the model reads and the state a write
 * is checked against.
 *
 * A file exists here if anything points at it: a row in the files table, or a
 * fact whose path resolves to it. That second case is what keeps every fact
 * learned before versions existed reachable; those files simply read as version
 * 1 until something writes to them.
 */
class MemoryIndex(val files: List<MemoryFileView>) {

    val isEmpty: Boolean get() = files.all { it.lines.isEmpty() }

    /** The version [path] is at, or [MemoryFile.NEW_FILE] when it does not exist. */
    fun version(path: String): Int =
        files.firstOrNull { it.path == path }?.version ?: MemoryFile.NEW_FILE

    /**
     * The path a model meant, matched against the files that already exist.
     *
     * ### Why this is not just a string clean-up
     * The whole point of the listing is that the second fact about food joins
     * the first one. A model that writes `/topics/еда.md` today and
     * `/topics/food.md` tomorrow defeats that silently -- two files, one
     * subject, neither complete. So a name is matched first exactly, then by
     * slug, then against the aliases each file records, and only an actual miss
     * opens a new file.
     *
     * Matching is confined to one folder. `/areas/food.md` and `/topics/food.md`
     * are not the same file and never should be: one is something the user is
     * building, the other is something they like.
     */
    fun resolve(raw: String?, hints: List<String> = emptyList()): String {
        val direct = memoryNormalisePath(raw)
        if (direct.isEmpty()) return ""
        files.firstOrNull { it.path == direct }?.let { return it.path }

        val folder = memoryPathFolder(direct)
        val slug = memoryPathSlug(direct)
        val wanted = HashSet<String>()
        wanted += slug
        hints.forEach { hint -> memoryTopicSlug(hint).takeIf { it.isNotEmpty() }?.let { wanted += it } }

        for (file in files) {
            if (memoryPathFolder(file.path) != folder) continue
            val fileSlug = memoryPathSlug(file.path)
            if (fileSlug in wanted) return file.path
            if (file.aliases.any { memoryTopicSlug(it) in wanted }) return file.path
        }
        return direct
    }
}

/**
 * Applies the model's file edits, one line at a time, with a version check.
 *
 * ### Why writes are line-sized
 * The alternative -- letting the model restate a file -- loses facts the moment
 * it paraphrases, and it does paraphrase. An append can only add, a replace can
 * only touch a line it correctly quoted back, and neither can drop the rest of
 * the file. The worst a bad answer can do here is add one wrong line, which the
 * user can delete in the memory screen.
 *
 * ### Why a version and not a lock
 * The listing is read, then a network round trip happens, then the write lands.
 * In between, the user can delete a fact or another turn can add one. Comparing
 * the version the edit was planned against with the version on disk turns that
 * race into a clean rejection instead of a silent overwrite -- and a rejection
 * is recoverable, because the caller can re-read and ask again.
 */
class MemoryWriter(private val repository: MemoryRepository) {

    /** How a batch of edits went: what landed, and what was refused and why. */
    data class Outcome(val applied: Int, val conflicts: List<String>)

    /** The current state of memory, as files. */
    suspend fun index(): MemoryIndex = build(
        nodes = runCatching { repository.nodes() }.getOrNull().orEmpty(),
        stored = runCatching { repository.files() }.getOrNull().orEmpty()
    )

    /**
     * Applies [writes] against a freshly read index.
     *
     * Read again rather than trusting the index the caller planned with: that is
     * exactly the window the version guards, and re-reading a local table costs
     * nothing next to the request that produced these edits.
     */
    suspend fun apply(writes: List<MemoryWrite>, sessionId: String): Outcome {
        if (writes.isEmpty()) return Outcome(0, emptyList())
        val index = index()

        val lines = LinkedHashMap<String, MutableList<MemoryNode>>()
        val versions = LinkedHashMap<String, Int>()
        val aliases = LinkedHashMap<String, MutableList<String>>()
        val titles = LinkedHashMap<String, String>()
        val summaries = LinkedHashMap<String, String>()
        for (file in index.files) {
            lines[file.path] = ArrayList(file.lines)
            versions[file.path] = file.version
            aliases[file.path] = ArrayList(file.aliases)
            titles[file.path] = file.title
            summaries[file.path] = file.summary
        }

        val touched = LinkedHashMap<String, MemoryNode>()
        val changed = LinkedHashSet<String>()
        val removed = LinkedHashSet<String>()
        val conflicts = ArrayList<String>()
        val now = System.currentTimeMillis()

        for (write in writes) {
            val path = write.path
            if (path.isEmpty()) continue
            val current = versions[path] ?: MemoryFile.NEW_FILE
            if (write.ifVersion != current) {
                conflicts += rejected(path, current, write.ifVersion)
                continue
            }
            when (write) {
                is MemoryWrite.Append -> {
                    if (forbidden(write.content)) continue
                    val group = lines.getOrPut(path) { ArrayList() }
                    // Already on file. Not a conflict and not a write -- the
                    // model simply re-heard something it had already stored.
                    if (group.any { same(it.content, write.content) }) continue
                    val node = MemoryNode(
                        id = UUID.randomUUID().toString(),
                        content = write.content,
                        category = memoryPathCategory(path, write.category),
                        topic = memoryPathSlug(path),
                        links = write.links,
                        source = MemoryNode.SOURCE_CHAT,
                        sessionId = sessionId,
                        createdAt = now,
                        updatedAt = now
                    )
                    group += node
                    touched[node.id] = node
                    aliases.getOrPut(path) { ArrayList() } += write.aliases
                    // A heading is set once, by whoever opened the file. Letting
                    // every later append rewrite it would rename "Food
                    // preferences" to whatever the newest line happened to be
                    // about.
                    if (titles[path].isNullOrBlank() && write.title.isNotBlank()) {
                        titles[path] = write.title.trim().take(MAX_TITLE_CHARS)
                    }
                    if (summaries[path].isNullOrBlank() && write.summary.isNotBlank()) {
                        summaries[path] = write.summary.trim().take(MAX_SUMMARY_CHARS)
                    }
                    versions[path] = current + 1
                    changed += path
                }

                is MemoryWrite.Replace -> {
                    if (forbidden(write.newLine)) continue
                    val group = lines[path]
                    val target = group?.firstOrNull { same(it.content, write.oldLine) }
                        ?: group?.firstOrNull { overlaps(it.content, write.oldLine) }
                    // Both, even though a target implies a group: the compiler
                    // cannot infer that, and the guard is what smart-casts the
                    // list for the in-place swap below.
                    if (group == null || target == null) {
                        conflicts += unmatched(path, write.oldLine)
                        continue
                    }
                    val updated = target.copy(content = write.newLine, updatedAt = now)
                    group[group.indexOf(target)] = updated
                    touched[updated.id] = updated
                    versions[path] = current + 1
                    changed += path
                }

                is MemoryWrite.Rewrite -> {
                    val kept = write.lines
                        .map { it.trim() }
                        .filter { it.isNotEmpty() && !forbidden(it) }
                        .distinct()
                        .take(MAX_REWRITE_LINES)
                    // A rewrite down to nothing is a deletion asked for
                    // sideways, and deleting is the user's to ask for.
                    if (kept.isEmpty()) {
                        conflicts += emptied(path)
                        continue
                    }
                    val group = lines.getOrPut(path) { ArrayList() }
                    val spare = ArrayList(group)
                    val rebuilt = ArrayList<MemoryNode>(kept.size)
                    for (line in kept) {
                        // A line that survived the rewrite keeps its node, so
                        // its links, its date and its place in the graph survive
                        // with it. Only what is genuinely gone is deleted.
                        val match = spare.firstOrNull { same(it.content, line) }
                        if (match != null) {
                            spare -= match
                            rebuilt += match.copy(content = line, updatedAt = now)
                        } else {
                            rebuilt += MemoryNode(
                                id = UUID.randomUUID().toString(),
                                content = line,
                                category = memoryPathCategory(path, write.category),
                                topic = memoryPathSlug(path),
                                links = emptyList(),
                                source = MemoryNode.SOURCE_CHAT,
                                sessionId = sessionId,
                                createdAt = now,
                                updatedAt = now
                            )
                        }
                    }
                    removed += spare.map { it.id }
                    group.clear()
                    group += rebuilt
                    rebuilt.forEach { touched[it.id] = it }
                    versions[path] = current + 1
                    changed += path
                }
            }
        }

        if (touched.isEmpty()) return Outcome(0, conflicts)

        return try {
            repository.save(touched.values.toList())
            // Only a rewrite can leave a line behind, and its node has to go
            // with it: the file is rebuilt from the facts filed under it, so a
            // node left in place would put the dropped line straight back.
            removed.forEach { repository.delete(it) }
            repository.saveFiles(
                changed.map { path ->
                    MemoryFile(
                        path = path,
                        aliases = tidy(path, aliases[path].orEmpty()),
                        version = versions[path] ?: MemoryFile.DERIVED_VERSION,
                        updatedAt = now,
                        title = titles[path].orEmpty(),
                        summary = summaries[path].orEmpty()
                    )
                }
            )
            Outcome(touched.size, conflicts)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            // Memory is best effort by design: a failed write is a fact not
            // learned, never a failed turn.
            Outcome(0, conflicts)
        }
    }

    private fun build(nodes: List<MemoryNode>, stored: List<MemoryFile>): MemoryIndex {
        val grouped = LinkedHashMap<String, MutableList<MemoryNode>>()
        for (node in nodes.sortedBy { it.createdAt }) {
            grouped.getOrPut(node.memoryPath()) { ArrayList() } += node
        }
        val byPath = stored.associateBy { it.path }
        val views = ArrayList<MemoryFileView>(grouped.size + stored.size)
        for ((path, group) in grouped) {
            val file = byPath[path]
            views += MemoryFileView(
                path = path,
                aliases = file?.aliases.orEmpty(),
                version = file?.version ?: MemoryFile.DERIVED_VERSION,
                lines = group,
                title = file?.title.orEmpty(),
                summary = file?.summary.orEmpty()
            )
        }
        // A file whose every line was forgotten still exists, and still has a
        // version: writing to it again must not look like creating it.
        for (file in stored) {
            if (grouped.containsKey(file.path)) continue
            views += MemoryFileView(
                path = file.path,
                aliases = file.aliases,
                version = file.version,
                lines = emptyList(),
                title = file.title,
                summary = file.summary
            )
        }
        return MemoryIndex(views)
    }

    /** Aliases worth keeping: slugged, unique, never the file's own name. */
    private fun tidy(path: String, raw: List<String>): List<String> {
        val own = memoryPathSlug(path)
        return raw
            .map { memoryTopicSlug(it) }
            .filter { it.isNotEmpty() && it != own }
            .distinct()
            .take(MAX_ALIASES)
    }

    private fun same(first: String, second: String): Boolean =
        key(first) == key(second)

    /** Loose match for a quoted line: models re-type the fact, rarely byte for byte. */
    private fun overlaps(stored: String, quoted: String): Boolean {
        val left = key(stored)
        val right = key(quoted)
        if (left.isEmpty() || right.length < MIN_QUOTE_CHARS) return false
        return left.contains(right) || right.contains(left)
    }

    private fun key(text: String): String = text
        .lowercase(Locale.getDefault())
        .filter { it.isLetterOrDigit() || it.isWhitespace() }
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun rejected(path: String, current: Int, sent: Int): String = when {
        sent == MemoryWrite.UNVERSIONED ->
            "$path rejected: no if_version was sent. It is at v$current."
        current == MemoryFile.NEW_FILE ->
            "$path rejected: it does not exist yet, so if_version must be \"new\"."
        sent == MemoryFile.NEW_FILE ->
            "$path rejected: it already exists at v$current, so if_version must be $current."
        else ->
            "$path rejected: if_version was $sent but the file is at v$current."
    }

    private fun unmatched(path: String, quoted: String): String =
        "$path rejected: no line matching \"" + quoted.take(MAX_QUOTE_SHOWN) + "\" to replace."

    /**
     * Whether a line must never be stored, whoever said it.
     *
     * The model is told the same list and mostly keeps to it, but "mostly" is
     * not a guarantee to hang someone's diagnosis or card number on. This is
     * the copy that decides, and it fails closed: a matching line is dropped
     * without a word back, because reporting that a line was refused on content
     * is an invitation to rephrase it until it lands.
     */
    private fun forbidden(line: String): Boolean {
        val text = line.lowercase()
        if (FORBIDDEN.any { text.contains(it) }) return true
        if (MONEY.containsMatchIn(text) || DOCUMENT.containsMatchIn(text)) return true
        return minor(text)
    }

    /** Whether the line states an age below [ADULT_AGE]. */
    private fun minor(text: String): Boolean {
        val stated = AGE_STATED.find(text)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (stated != null && stated in 1 until ADULT_AGE) return true
        // "3 years of Kotlin" is not an age, and in a coding app it is the far
        // commoner shape of a small number sitting next to "years".
        if (AGE_EXPERIENCE.containsMatchIn(text)) return false
        val years = AGE_YEARS.find(text)?.groupValues?.getOrNull(1)?.toIntOrNull()
        return years != null && years in 1 until ADULT_AGE
    }

    /** Why a rewrite that would empty a file was refused. */
    private fun emptied(path: String): String =
        "$path rejected: a rewrite has to leave at least one line."

    private companion object {
        /** Enough for the subject in two languages plus one synonym. */
        private const val MAX_ALIASES = 4

        /** Below this, a quoted fragment matches half the file by accident. */
        private const val MIN_QUOTE_CHARS = 6

        /** A heading, not a sentence: "Food preferences", "Sirius Chat App". */
        private const val MAX_TITLE_CHARS = 60

        /** One line under the heading, not a paragraph. */
        private const val MAX_SUMMARY_CHARS = 140

        private const val MAX_QUOTE_SHOWN = 60

        /** A whole file at once is still a small file; past this it is a log. */
        private const val MAX_REWRITE_LINES = 12

        /** Under this an age belongs to a child, and no child's age is stored. */
        private const val ADULT_AGE = 18

        /**
         * Subjects that are never written down, in either language.
         *
         * Substrings rather than words, because Russian inflects and "диагноз"
         * has to catch "диагнозом" too. Fragments that would collide with
         * ordinary sentences are spelled out in full instead: "трансгендер"
         * rather than "транс", "гей " with the space.
         */
        private val FORBIDDEN = listOf(
            "диагноз", "болезн", "болею", "лечени", "терапи", "психиатр",
            "антидепресс", "депресси", "тревожност", "аутизм", "сдвг",
            "diagnos", "illness", "disease", "therapy", "antidepress", "medication",
            "depression", "anxiety", "mental health", "adhd", "autism",
            "религи", "верующ", "мусульман", "христиан", "иудей", "атеист",
            "ориентация ", "гей ", "лесбия", "бисексуал", "трансгендер",
            "гендерн", "раса ", "иммиграц", "гражданств", "вид на жительство",
            "religion", "muslim", "christian", "jewish", "atheist", "orientation",
            "gay ", "lesbian", "bisexual", "transgender", "gender identity",
            "immigration", "visa status",
            "политик", "политическ", "голосовал", "партия", "выборы",
            "politics", "political", "voted for", "election",
            "зарплат", "доходы", "мой доход", "накоплени", "паспорт",
            "номер карты", "salary", "income", "savings", "passport",
            "card number", "iban", "cvv",
            "я сейчас в", "сейчас нахожусь", "currently at", "right now at",
            "суицид", "самоубийств", "самоповрежд", "селфхарм", "насили",
            "избива", "тюрьм", "судимост", "suicide", "self-harm", "self harm",
            "abuse", "assault", "prison", "criminal record"
        )

        /** A sum with a currency: the exact amount is the part that is private. */
        private val MONEY = Regex(
            "\\d[\\d\\s.,]*\\s*(?:руб|тенге|доллар|евро|тыс|млн|usd|eur|kzt|" +
                "[\\u0024\\u20ac\\u20bd\\u20b8])"
        )

        /** Card, passport and account numbers: four digits, three times over. */
        private val DOCUMENT = Regex("\\d{4}[\\s-]?\\d{4}[\\s-]?\\d{4}")

        /** "мне 16", "age: 16", "i am 16" -- an age given outright. */
        private val AGE_STATED = Regex("(?:мне|возраст|\\bage\\b|i am|i'm)\\D{0,4}(\\d{1,2})")

        /** "16 лет", "16 years old" -- an age given as a count of years. */
        private val AGE_YEARS = Regex("(\\d{1,2})\\s*(?:лет|года|год|years old)")

        /** What turns those years into a career instead of a birthday. */
        private val AGE_EXPERIENCE = Regex("опыт|стаж|experience")
    }
}
