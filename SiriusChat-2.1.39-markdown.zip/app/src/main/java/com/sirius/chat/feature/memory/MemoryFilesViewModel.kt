package com.sirius.chat.feature.memory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.MEMORY_PREFERENCES_PATH
import com.sirius.chat.domain.model.MEMORY_PROFILE_PATH
import com.sirius.chat.domain.model.MemoryFile
import com.sirius.chat.domain.model.MemoryNode
import com.sirius.chat.domain.model.memoryFileTitle
import com.sirius.chat.domain.model.memoryPath
import com.sirius.chat.domain.model.memoryPathFolder
import com.sirius.chat.domain.model.memoryPathSlug
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** The heading a file is listed under, in the order they are shown. */
enum class MemoryFileGroup { You, Topics, Areas, People }

/**
 * One memory file as the list shows it.
 *
 * The lines are plain strings on purpose: this screen shows what is written and
 * lets a whole file go, while forgetting one fact at a time stays where it
 * already works -- tapping the node in the graph.
 */
data class MemoryFileCard(
    val path: String,
    val title: String,
    val summary: String,
    val aliases: List<String>,
    val updatedAt: Long,
    val lines: List<String>,
    val group: MemoryFileGroup
) {
    /** `/topics/food.md` -> `food`: the name the file is addressed by. */
    val name: String
        get() = memoryPathSlug(path)
}

data class MemoryFilesUiState(
    val files: List<MemoryFileCard> = emptyList(),
    val openPath: String? = null,
    val loaded: Boolean = false
) {
    val open: MemoryFileCard?
        get() = files.firstOrNull { it.path == openPath }

    fun inGroup(group: MemoryFileGroup): List<MemoryFileCard> =
        files.filter { it.group == group }
}

/**
 * Backing state for the list of memory files.
 *
 * ### Why files are rebuilt from facts and not just read
 * A file row records a version, aliases and a heading -- not its contents. The
 * lines live with the facts, and facts written before the file protocol existed
 * have no row at all. Grouping the facts by the same path the rest of the app
 * derives, then merging the stored rows over the top, is what makes those older
 * facts visible here instead of silently missing.
 *
 * ### Why the open file is a path and not a card
 * Held as a card, an open file would freeze at the moment it was tapped: a fact
 * learned while it is on screen would not appear, and deleting it elsewhere
 * would leave a page showing something that no longer exists. Held as a path,
 * the card is looked up from the current list on every emission, and a path that
 * is gone closes the page by itself.
 */
class MemoryFilesViewModel(private val container: AppContainer) : ViewModel() {

    private val _open = MutableStateFlow<String?>(null)

    val state: StateFlow<MemoryFilesUiState> = combine(
        container.memoryRepository.observeNodes(),
        container.memoryRepository.observeFiles(),
        _open
    ) { nodes, stored, open ->
        val files = cards(nodes, stored)
        MemoryFilesUiState(
            files = files,
            openPath = open?.takeIf { path -> files.any { it.path == path } },
            loaded = true
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MemoryFilesUiState())

    fun open(path: String) {
        _open.value = path
    }

    fun close() {
        _open.value = null
    }

    /** Deletes the file and everything filed in it. */
    fun forget(path: String) {
        viewModelScope.launch {
            container.memoryRepository.deleteFile(path)
            if (_open.value == path) _open.value = null
        }
    }

    private fun cards(
        nodes: List<MemoryNode>,
        stored: List<MemoryFile>
    ): List<MemoryFileCard> {
        val grouped = LinkedHashMap<String, MutableList<MemoryNode>>()
        for (node in nodes.sortedBy { it.createdAt }) {
            grouped.getOrPut(node.memoryPath()) { ArrayList() } += node
        }
        val byPath = stored.associateBy { it.path }
        val paths = LinkedHashSet<String>()
        paths += grouped.keys
        paths += stored.map { it.path }

        return paths
            .map { path ->
                val file = byPath[path]
                val lines = grouped[path].orEmpty()
                MemoryFileCard(
                    path = path,
                    title = memoryFileTitle(path, file?.title.orEmpty()),
                    summary = file?.summary.orEmpty(),
                    aliases = file?.aliases.orEmpty(),
                    // A file row is only touched when a write goes through, so
                    // for a file that predates the protocol the newest fact in
                    // it is the only date there is.
                    updatedAt = maxOf(
                        file?.updatedAt ?: 0L,
                        lines.maxOfOrNull { maxOf(it.updatedAt, it.createdAt) } ?: 0L
                    ),
                    lines = lines.map { it.content },
                    group = groupOf(path)
                )
            }
            .sortedByDescending { it.updatedAt }
    }

    private fun groupOf(path: String): MemoryFileGroup = when {
        path == MEMORY_PROFILE_PATH || path == MEMORY_PREFERENCES_PATH -> MemoryFileGroup.You
        memoryPathFolder(path) == "/areas" -> MemoryFileGroup.Areas
        memoryPathFolder(path) == "/people" -> MemoryFileGroup.People
        else -> MemoryFileGroup.Topics
    }
}
