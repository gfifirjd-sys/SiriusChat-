package com.sirius.chat.core.util

import com.sirius.chat.domain.model.DiffHunk
import com.sirius.chat.domain.model.DiffLine
import com.sirius.chat.domain.model.DiffLineType
import com.sirius.chat.domain.model.FileDiff

/**
 * Line based diff.
 *
 * Common prefix/suffix are stripped first, which makes the usual "agent edited
 * a few lines of a large file" case almost free. The quadratic LCS is only run
 * on the remaining window and is bounded, so a huge rewrite degrades to a
 * block replace instead of freezing the device.
 */
object DiffEngine {

    private const val LCS_LIMIT = 900
    private const val CONTEXT = 3

    fun diff(path: String, oldText: String?, newText: String?, contextLines: Int = CONTEXT): FileDiff {
        val oldLines = oldText?.lines() ?: emptyList()
        val newLines = newText?.lines() ?: emptyList()
        val lines = buildDiffLines(oldLines, newLines)
        val hunks = groupIntoHunks(lines, contextLines)
        return FileDiff(
            path = path,
            hunks = hunks,
            added = lines.count { it.type == DiffLineType.Added },
            removed = lines.count { it.type == DiffLineType.Removed }
        )
    }

    fun buildDiffLines(oldLines: List<String>, newLines: List<String>): List<DiffLine> {
        var prefix = 0
        val maxPrefix = minOf(oldLines.size, newLines.size)
        while (prefix < maxPrefix && oldLines[prefix] == newLines[prefix]) prefix++

        var suffix = 0
        while (suffix < (maxPrefix - prefix) &&
            oldLines[oldLines.size - 1 - suffix] == newLines[newLines.size - 1 - suffix]
        ) suffix++

        val result = ArrayList<DiffLine>(oldLines.size + newLines.size)
        for (i in 0 until prefix) {
            result += DiffLine(DiffLineType.Context, i + 1, i + 1, oldLines[i])
        }

        val oldMid = oldLines.subList(prefix, oldLines.size - suffix)
        val newMid = newLines.subList(prefix, newLines.size - suffix)

        val midLines = if (oldMid.size <= LCS_LIMIT && newMid.size <= LCS_LIMIT) {
            lcsDiff(oldMid, newMid, prefix)
        } else {
            blockReplace(oldMid, newMid, prefix)
        }
        result += midLines

        val oldTailStart = oldLines.size - suffix
        val newTailStart = newLines.size - suffix
        for (i in 0 until suffix) {
            result += DiffLine(
                DiffLineType.Context,
                oldTailStart + i + 1,
                newTailStart + i + 1,
                oldLines[oldTailStart + i]
            )
        }
        return result
    }

    private fun blockReplace(oldMid: List<String>, newMid: List<String>, offset: Int): List<DiffLine> {
        val out = ArrayList<DiffLine>(oldMid.size + newMid.size)
        oldMid.forEachIndexed { i, line ->
            out += DiffLine(DiffLineType.Removed, offset + i + 1, null, line)
        }
        newMid.forEachIndexed { i, line ->
            out += DiffLine(DiffLineType.Added, null, offset + i + 1, line)
        }
        return out
    }

    private fun lcsDiff(oldMid: List<String>, newMid: List<String>, offset: Int): List<DiffLine> {
        val n = oldMid.size
        val m = newMid.size
        if (n == 0 || m == 0) return blockReplace(oldMid, newMid, offset)

        // table[i][j] = LCS length of oldMid[i..] and newMid[j..]
        val width = m + 1
        val table = IntArray((n + 1) * width)
        for (i in n - 1 downTo 0) {
            for (j in m - 1 downTo 0) {
                table[i * width + j] = if (oldMid[i] == newMid[j]) {
                    table[(i + 1) * width + (j + 1)] + 1
                } else {
                    maxOf(table[(i + 1) * width + j], table[i * width + (j + 1)])
                }
            }
        }

        val out = ArrayList<DiffLine>(n + m)
        var i = 0
        var j = 0
        while (i < n && j < m) {
            when {
                oldMid[i] == newMid[j] -> {
                    out += DiffLine(DiffLineType.Context, offset + i + 1, offset + j + 1, oldMid[i])
                    i++
                    j++
                }
                table[(i + 1) * width + j] >= table[i * width + (j + 1)] -> {
                    out += DiffLine(DiffLineType.Removed, offset + i + 1, null, oldMid[i])
                    i++
                }
                else -> {
                    out += DiffLine(DiffLineType.Added, null, offset + j + 1, newMid[j])
                    j++
                }
            }
        }
        while (i < n) {
            out += DiffLine(DiffLineType.Removed, offset + i + 1, null, oldMid[i])
            i++
        }
        while (j < m) {
            out += DiffLine(DiffLineType.Added, null, offset + j + 1, newMid[j])
            j++
        }
        return out
    }

    private fun groupIntoHunks(lines: List<DiffLine>, context: Int): List<DiffHunk> {
        if (lines.none { it.type != DiffLineType.Context }) return emptyList()

        val changedIndices = lines.indices.filter { lines[it].type != DiffLineType.Context }
        val hunks = ArrayList<DiffHunk>()
        var start = maxOf(0, changedIndices.first() - context)
        var end = minOf(lines.lastIndex, changedIndices.first() + context)
        var hunkId = 0

        for (index in changedIndices.drop(1)) {
            if (index - context <= end + 1) {
                end = minOf(lines.lastIndex, index + context)
            } else {
                hunks += buildHunk(hunkId++, lines.subList(start, end + 1))
                start = maxOf(0, index - context)
                end = minOf(lines.lastIndex, index + context)
            }
        }
        hunks += buildHunk(hunkId, lines.subList(start, end + 1))
        return hunks
    }

    private fun buildHunk(id: Int, slice: List<DiffLine>): DiffHunk = DiffHunk(
        id = id,
        oldStart = slice.firstNotNullOfOrNull { it.oldLineNumber } ?: 0,
        newStart = slice.firstNotNullOfOrNull { it.newLineNumber } ?: 0,
        lines = slice.toList()
    )

    /**
     * Rebuilds file content applying only the accepted hunks, which is what
     * makes partial approval possible.
     *
     * ### Line endings
     * The rebuild goes through [String.lines], which splits on CRLF as readily as
     * on LF and keeps neither. Joining with a bare newline therefore used to
     * convert a CRLF file to LF on every partial apply -- a whole-file apply
     * writes the agent text verbatim and never did this, so accepting two hunks
     * out of three silently rewrote every line ending in the file and turned a
     * small review into a whole-file diff in git. The separator is now taken from
     * the original text.
     */
    fun applyHunks(oldText: String, diff: FileDiff, acceptedHunkIds: Set<Int>): String {
        if (acceptedHunkIds.isEmpty()) return oldText
        // The file decides, not the platform: a CRLF file stays CRLF even when the
        // accepted hunk text arrived with LF endings.
        val separator = if (oldText.contains("\r\n")) "\r\n" else "\n"
        val oldLines = oldText.lines()
        val result = ArrayList<String>(oldLines.size + 32)
        var cursor = 0 // index into oldLines

        for (hunk in diff.hunks) {
            val hunkOldLines = hunk.lines.mapNotNull { it.oldLineNumber }
            val firstOld = hunkOldLines.minOrNull()
            val lastOld = hunkOldLines.maxOrNull()

            val insertAt = (firstOld?.minus(1)) ?: cursor
            while (cursor < insertAt && cursor < oldLines.size) {
                result += oldLines[cursor]
                cursor++
            }

            if (hunk.id in acceptedHunkIds) {
                hunk.lines.forEach { line ->
                    when (line.type) {
                        DiffLineType.Added -> result += line.text
                        DiffLineType.Context -> result += line.text
                        DiffLineType.Removed -> Unit
                    }
                }
            } else {
                hunk.lines.forEach { line ->
                    when (line.type) {
                        DiffLineType.Removed -> result += line.text
                        DiffLineType.Context -> result += line.text
                        DiffLineType.Added -> Unit
                    }
                }
            }
            cursor = (lastOld ?: cursor)
        }
        while (cursor < oldLines.size) {
            result += oldLines[cursor]
            cursor++
        }
        return result.joinToString(separator)
    }
}
