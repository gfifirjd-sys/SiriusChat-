package com.sirius.chat.feature.chat.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.sirius.chat.R
import com.sirius.chat.ai.pricing.ModelPricing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.domain.model.TokenUsage
import java.util.Locale

/**
 * What one answer cost, in tokens and -- when it can be known -- in money.
 *
 * ### Why cost is sometimes missing
 * Three things have to be true to show a price: the endpoint reported real token
 * counts, the model id matches the price table, and the counts are not an
 * estimate. Any one of them failing drops the money and keeps the tokens, which
 * is the honest degradation: an approximate token count is still useful, while
 * an approximate price is a number people will repeat as fact.
 *
 * ### Why it is this quiet
 * `labelSmall` in the tertiary colour, one line, no icon, no chip. It is
 * reference information under an answer, and anything louder competes with the
 * answer for attention every single turn.
 */
@Composable
fun MessageUsage(usage: TokenUsage, model: String?, modifier: Modifier = Modifier) {
    val colors = SiriusTheme.colors
    val tokens = if (usage.promptTokens > 0) {
        stringResource(
            R.string.chat_usage_tokens,
            grouped(usage.promptTokens),
            grouped(usage.completionTokens)
        )
    } else {
        // Output only: the estimate path cannot see the prompt, and inventing an
        // input number to make the row look symmetrical would be a lie.
        stringResource(R.string.chat_usage_tokens_out, grouped(usage.completionTokens))
    }
    val cost = remember(model, usage) {
        ModelPricing.cost(model, usage)?.let(ModelPricing::format)
    }
    val line = if (cost != null) tokens + " \u00b7 " + cost else tokens
    Text(
        text = if (usage.estimated) stringResource(R.string.chat_usage_estimated, line) else line,
        style = MaterialTheme.typography.labelSmall,
        color = colors.textTertiary,
        maxLines = 1,
        modifier = modifier
    )
}

/** Thin spaces, not commas: 1240 reads as an id, 1\u2009240 reads as a quantity. */
private fun grouped(value: Int): String =
    String.format(Locale.US, "%,d", value).replace(',', '\u2009')
