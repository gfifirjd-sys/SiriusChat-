package com.sirius.chat.feature.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.MessageHit
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.isUsable
import com.sirius.chat.domain.model.resolveModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatListUiState(
    val sessions: List<ChatSession> = emptyList(),
    val projects: List<Project> = emptyList(),
    val query: String = "",
    val projectFilter: String? = null,
    /** One-shot text for the toast; consumed by the screen. */
    val message: String? = null,
    /** Sessions the model is answering in right now, including closed ones. */
    val generating: Set<String> = emptySet(),
    /**
     * Matches inside message text, for the current [query].
     *
     * Kept apart from [filtered]: that narrows the visible list by title and last
     * message and is instant, while this reaches into the whole history and lands
     * a moment later. Merging them would make rows jump under the finger.
     */
    val hits: List<MessageHit> = emptyList()
) {
    val filtered: List<ChatSession>
        get() = sessions.filter { session ->
            (projectFilter == null || session.projectId == projectFilter) &&
                (query.isBlank() ||
                    session.title.contains(query, true) ||
                    session.lastMessagePreview.contains(query, true))
        }
}

class ChatListViewModel(private val container: AppContainer) : ViewModel() {

    private val _query = MutableStateFlow("")
    private val _projectFilter = MutableStateFlow<String?>(null)
    private val _message = MutableStateFlow<String?>(null)
    private val _hits = MutableStateFlow<List<MessageHit>>(emptyList())

    /** The in-flight search, so typing replaces it instead of racing it. */
    private var searchJob: Job? = null

    val state: StateFlow<ChatListUiState> = combine(
        container.chatRepository.observeSessions(),
        container.projectRepository.observeProjects(),
        _query,
        _projectFilter,
        _message,
        container.generations.activeSessions,
        _hits
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        ChatListUiState(
            sessions = values[0] as List<ChatSession>,
            projects = values[1] as List<Project>,
            query = values[2] as String,
            projectFilter = values[3] as String?,
            message = values[4] as String?,
            generating = values[5] as Set<String>,
            hits = values[6] as List<MessageHit>
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ChatListUiState())

    /** Stops a background run from the list, without opening the chat. */
    fun stopGeneration(sessionId: String) = container.generations.stop(sessionId)

    fun consumeMessage() {
        _message.value = null
    }

    /**
     * Filters the list immediately and searches message bodies shortly after.
     *
     * ### Why the pause
     * Without it every keystroke is its own scan of the entire history: four
     * letters means four scans, three of them already obsolete when they return.
     * A short silence means the search runs once, when the person stopped typing,
     * and the title filter above keeps the list responsive in the meantime.
     */
    fun onQueryChange(value: String) {
        _query.value = value
        searchJob?.cancel()
        val needle = value.trim()
        if (needle.length < 2) {
            _hits.value = emptyList()
            return
        }
        searchJob = viewModelScope.launch {
            delay(SEARCH_DEBOUNCE_MS)
            _hits.value = container.chatRepository.searchMessages(needle)
        }
    }

    fun onProjectFilter(projectId: String?) {
        _projectFilter.value = projectId
    }

    fun togglePin(session: ChatSession) {
        viewModelScope.launch { container.chatRepository.setPinned(session.id, !session.pinned) }
    }

    fun delete(session: ChatSession) {
        viewModelScope.launch { container.chatRepository.deleteSession(session.id) }
    }

    /**
     * Creates a session and hands its id back.
     *
     * [onNeedsProvider] exists because the provider list starts empty: the old
     * `?: return@launch` made this button do nothing at all on a fresh install,
     * with no message and no navigation. A tap has to end in either a chat or an
     * explanation, never in silence.
     */
    fun newChat(onReady: (String) -> Unit, onNeedsProvider: () -> Unit = {}) {
        viewModelScope.launch {
            val settings = container.settingsRepository.current()
            val providers = container.providerRepository.providers()
            val provider = providers.firstOrNull { it.id == settings.activeProviderId }
                ?: providers.firstOrNull { it.isUsable }
                ?: providers.firstOrNull()
            if (provider == null) {
                _message.value = container.strings.get(R.string.chats_needs_provider)
                onNeedsProvider()
                return@launch
            }
            val session = container.createSession(
                providerId = provider.id,
                model = provider.resolveModel(settings.activeModel),
                projectId = _projectFilter.value ?: settings.activeProjectId.takeIf { it.isNotBlank() },
                title = container.strings.get(R.string.chats_untitled_agent)
            )
            onReady(session.id)
        }
    }
}

/** Long enough to skip the keystrokes in between, short enough to feel instant. */
private const val SEARCH_DEBOUNCE_MS = 220L
