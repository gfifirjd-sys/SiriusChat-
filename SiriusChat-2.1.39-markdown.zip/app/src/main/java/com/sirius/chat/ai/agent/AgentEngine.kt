package com.sirius.chat.ai.agent

import com.sirius.chat.R
import com.sirius.chat.ai.agent.tools.AnalyzeProjectTool
import com.sirius.chat.ai.agent.tools.AskUserTool
import com.sirius.chat.ai.agent.tools.CreateFileTool
import com.sirius.chat.ai.agent.tools.DeleteFileTool
import com.sirius.chat.ai.agent.tools.IMAGE_EDIT_TOOL_NAMES
import com.sirius.chat.ai.agent.tools.IMAGE_TOOL_NAMES
import com.sirius.chat.ai.agent.tools.LINK_TOOL_NAMES
import com.sirius.chat.ai.agent.tools.ListDirectoryTool
import com.sirius.chat.ai.agent.tools.MoveFileTool
import com.sirius.chat.ai.agent.tools.ReadFileTool
import com.sirius.chat.ai.agent.tools.RenameFileTool
import com.sirius.chat.ai.agent.tools.RunCommandTool
import com.sirius.chat.ai.agent.tools.SearchFilesTool
import com.sirius.chat.ai.agent.tools.SearchTextTool
import com.sirius.chat.ai.agent.tools.WEB_TOOL_NAMES
import com.sirius.chat.ai.agent.tools.WriteFileTool
import com.sirius.chat.ai.context.SystemPrompts
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.AiToolCall
import com.sirius.chat.ai.model.AiToolSpec
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.pricing.TokenCalibration
import com.sirius.chat.ai.provider.AiProvider
import com.sirius.chat.ai.provider.ModelQuirks
import com.sirius.chat.ai.provider.isContextOverflow
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.ChatFeature
import com.sirius.chat.domain.model.ChatFeatures
import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.model.ProbeVerdict
import com.sirius.chat.domain.model.TokenUsage
import com.sirius.chat.domain.model.ToolRun
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.put
import java.util.UUID
import java.util.Locale

/** Events the chat layer renders while the agent works. */
sealed interface AgentEvent {
    data class StepStarted(val step: Int) : AgentEvent
    data class Delta(val text: String) : AgentEvent
    data class ToolStarted(val toolName: String, val preview: String) : AgentEvent
    data class ToolFinished(val run: ToolRun) : AgentEvent
    data class Proposals(val changes: List<PendingChange>) : AgentEvent
    data class Completed(val text: String, val usage: TokenUsage? = null) : AgentEvent
    data class Failure(val error: AiError) : AgentEvent
}

/** Lenient on purpose: this text came from a model, not from a schema. */
private val toolArgumentJson = Json { ignoreUnknownKeys = true; isLenient = true }

/** A schema that accepts whatever the tool's own description asked for. */
private const val OPEN_TOOL_SCHEMA = """{"type":"object","properties":{},"additionalProperties":true}"""

/**
 * A vendor tool call as the engine's own call type, or `null` when it is unusable.
 *
 * Arguments are text on the wire and are not always the object they should be.
 * Nothing at all means "no arguments" and is fine. A truncated stream leaves a
 * fragment that parses as nothing, and running a tool on silently empty
 * arguments is better than running it on half of them -- the tool reports what
 * it needed and the model retries. And a gateway that re-serializes the field
 * sends a *string* containing the object, which has to be decoded twice. Each
 * case is settled here so a half-formed call never reaches a tool.
 */
private fun AiToolCall.toParsedCall(): ParsedToolCall? {
    if (name.isBlank()) return null
    val raw = argumentsJson.trim()
    val decoded = if (raw.isEmpty()) {
        null
    } else {
        runCatching { toolArgumentJson.parseToJsonElement(raw) }.getOrNull()
    }
    val args = when (decoded) {
        is JsonObject -> decoded
        is JsonPrimitive -> decoded.reparsedObject()
        else -> JsonObject(emptyMap())
    }
    return ParsedToolCall(tool = name, args = args, rawBlock = raw)
}

/** Double-encoded arguments: a JSON object inside a JSON string. */
private fun JsonPrimitive.reparsedObject(): JsonObject {
    val inner = contentOrNull?.trim().orEmpty()
    if (inner.isEmpty()) return JsonObject(emptyMap())
    val element = runCatching { toolArgumentJson.parseToJsonElement(inner) }.getOrNull()
    return element as? JsonObject ?: JsonObject(emptyMap())
}

/**
 * The assistant turn to store for a step that called tools.
 *
 * A native call is rewritten into the fenced form the system prompt already
 * documents. That keeps one history format whichever channel produced the call,
 * keeps it readable to a model that never saw a `tools` array, and -- the part
 * that actually breaks things otherwise -- keeps the turn from being empty,
 * which several gateways reject with a 400.
 */
private fun replayOf(answer: String, calls: List<ParsedToolCall>, native: Boolean): String {
    if (!native) return answer
    return buildString {
        val prose = answer.trim()
        if (prose.isNotEmpty()) {
            append(prose)
            append("\n\n")
        }
        calls.forEach { call ->
            append("```sirius-tool\n")
            append(
                buildJsonObject {
                    put("tool", call.tool)
                    put("args", call.args)
                }.toString()
            )
            append("\n```\n")
        }
    }.trim().ifBlank { answer }
}

/**
 * The agent loop: ask the model, run the tools it requested, feed the results
 * back, repeat until it stops asking for tools or the step budget runs out.
 *
 * Mutating tools do not write anything; their proposals are collected and
 * emitted so the UI can show a diff and ask for approval.
 */
class AgentEngine(
    private val tools: List<AgentTool> = defaultTools()
) {

    fun toolList(): List<AgentTool> = tools

    fun run(
        provider: AiProvider,
        model: String,
        history: List<AiMessage>,
        context: AgentContext,
        projectContext: String?,
        params: com.sirius.chat.domain.model.GenerationParams,
        maxSteps: Int,
        /** Mirrors the user setting, purely so the system prompt can be honest. */
        autoApply: Boolean = false,
        /**
         * Whether the shell tool is in the registry at all.
         *
         * Separate from [features] because it is a global setting rather than a
         * per-conversation switch: `run_command` is the only tool that can act
         * outside the project folder, so a user who turns it off means "not from
         * this app", not "not in this chat".
         */
        allowTerminal: Boolean = true,
        /**
         * The switches from the chat's settings panel.
         *
         * Passed in rather than read from a repository here because the engine is
         * a single long-lived instance shared by every conversation: a session
         * with the internet switch off and one with it on run concurrently in the
         * same process, and each has to see its own answer.
         */
        features: ChatFeatures = ChatFeatures(),
        /**
         * Long-term facts about the user, already formatted for the prompt, or
         * null when this chat has memory switched off.
         *
         * Passed in for the same reason [features] is: one engine serves every
         * conversation at once, and a chat with memory off must not be able to
         * see what a chat with memory on was told.
         */
        memory: String? = null
    ): Flow<AgentEvent> = channelFlow {
        // The registry is narrowed *before* the prompt is built, which is the
        // whole point of doing this here rather than refusing inside each tool.
        //
        // A disabled tool that still appears in the system prompt is worse than
        // useless: the model calls it, gets "this is switched off", apologises,
        // and burns a step -- and on a weaker model it will try twice more before
        // giving up. A tool the model was never told about is simply not part of
        // its world, so it plans around the absence from the first token.
        val tools = activeTools(features, allowTerminal)
        val systemPrompt = SystemPrompts.agent(tools, projectContext, autoApply, memory)
        val known = tools.mapTo(HashSet()) { it.name }

        // Vendor function calling, offered only where a real request has already
        // proved the endpoint takes the field.
        //
        // The fenced-block contract stays in the system prompt either way, and
        // that is deliberate: it is the fallback for every model that ignores the
        // field, and it is the format calls are replayed in, so the history stays
        // readable to a model that never saw a `tools` array.
        //
        // The gate is the *probe* verdict rather than the preset flag, because
        // the preset flag means something else. `supportsTools` describes writing
        // a fenced block -- it is true for almost every model -- so trusting it
        // here would start sending `tools` to local gateways that 400 on unknown
        // request keys, and lose the turn for a channel the app does not need.
        val nativeSpecs = tools.map { tool ->
            AiToolSpec(
                name = tool.name,
                // The argument documentation the prompt already carries. The
                // schema is left open rather than reconstructed from that prose:
                // a wrong schema makes the endpoint reject correct calls, while
                // an open one only means the model leans on a description it was
                // given anyway.
                description = listOf(tool.description, tool.usage)
                    .filter { it.isNotBlank() }
                    .joinToString("\n"),
                parametersJson = OPEN_TOOL_SCHEMA
            )
        }
        var nativeTools = nativeSpecs.isNotEmpty() &&
            provider.models.firstOrNull { it.id == model }?.toolsProbe == ProbeVerdict.Supported
        val conversation = history.toMutableList()
        val proposals = ArrayList<PendingChange>()
        // Prose from *every* step, in order. The chat bubble shows the whole run
        // as it streams, so the stored message has to be the whole run too --
        // keeping only the last step silently dropped everything the model said
        // before its first tool call.
        val transcript = StringBuilder()
        var nudges = 0

        // `params` is re-read every step because a blank turn caused by an
        // exhausted token budget is fixed by raising the budget, not by asking
        // again with the same one.
        var activeParams = params
        var tokenBumps = 0

        // Bounded on purpose: a prompt still too long after two cuts is not
        // going to fit, and repeating the cut would erase the conversation.
        var overflowTrims = 0

        // Why the last blank turn was blank, so the final message can say
        // something the user can act on instead of "empty response".
        var blankFinish: String? = null
        var blankReasoning = 0

        // The budget extends itself instead of stopping. `maxSteps` used to be a
        // wall: the run ended mid-task and left "ask me to continue if more work
        // is needed", so the user had to type "продолжай" to get work they had
        // already asked for. Worse with `run_command` in the registry, where one
        // Gradle build is a single step and a six-step budget cannot finish
        // anything real.
        //
        // So the budget grows in `maxSteps`-sized increments for as long as the
        // agent is still calling tools, up to [hardCap]. Reaching the end of the
        // loop body already proves it is working — a step with no tool calls
        // breaks out above — so no extra "is it done" guess is needed.
        var step = 0
        // Summed across the whole run, not per step. One user turn can make
        // several provider calls when the agent uses tools, and the user is
        // billed for every one of them -- keeping only the last step's numbers
        // would make a six-tool run look as cheap as a one-liner.
        var spent: TokenUsage? = null
        var toolsRun = 0
        var budget = maxSteps
        val hardCap = (maxSteps.toLong() * BUDGET_EXTENSIONS)
            .coerceAtMost(ABSOLUTE_MAX_STEPS.toLong()).toInt()

        while (step < budget) {
            step++
            send(AgentEvent.StepStarted(step))

            val builder = StringBuilder()
            var failed: AiError? = null
            var finishReason: String? = null
            var reasoningChars = 0
            // Counted from the stream too, because only some endpoints report a
            // reasoning total in their final frame.
            var reasoningStreamed = 0
            var nativeCalls: List<AiToolCall> = emptyList()

            // Measured before the call so it can be compared with the token count
            // the endpoint reports for this exact prompt.
            val promptChars = conversation.sumOf { it.content.length } + systemPrompt.length

            // A step that goes completely quiet is indistinguishable from a
            // frozen app, and the HTTP read timeout is deliberately long enough
            // for a slow first token on a large prompt -- which means a dead
            // connection can hold the chat for minutes with nothing on screen.
            // The wait is bounded here instead, and the clock is reset by every
            // event rather than started once: an answer may take as long as it
            // likes while it is still arriving, but silence has a limit.
            var lastEventAt = System.currentTimeMillis()
            var stalled = false

            coroutineScope {
                val stream = launch {
                    provider.chat(
                        ChatRequest(
                            model = model,
                            messages = conversation.toList(),
                            systemPrompt = systemPrompt,
                            params = activeParams,
                            // Previously hard-coded to true, which quietly made the
                            // "Streaming" switch in Settings do nothing at all. It is now
                            // the session's own flag, already clamped to what the model
                            // supports -- a model with no streaming endpoint would
                            // otherwise fail the whole request rather than degrade.
                            stream = features.streaming,
                            tools = if (nativeTools) nativeSpecs else emptyList()
                        )
                    ).collect { event ->
                        lastEventAt = System.currentTimeMillis()
                        when (event) {
                            is ChatStreamEvent.Delta -> {
                                builder.append(event.text)
                                send(AgentEvent.Delta(event.text))
                            }
                            // Thinking text: never shown and never appended to
                            // the answer, but it resets the silence clock above,
                            // which is what lets a model think for as long as it
                            // needs to without the turn being abandoned.
                            is ChatStreamEvent.Reasoning ->
                                reasoningStreamed += event.text.length
                            is ChatStreamEvent.Failure -> failed = event.error
                            // Completed used to be swallowed by `else`, which threw away
                            // the finish reason -- the single most diagnostic field in
                            // the response -- and left every blank turn looking the same.
                            is ChatStreamEvent.Completed -> {
                                finishReason = event.finishReason
                                reasoningChars = event.reasoningChars
                                spent = addUsage(spent, event.usage)
                                // The endpoint just counted this prompt, so the
                                // estimator can stop guessing for this model. The
                                // shared 3.5 characters per token is an English
                                // average that undercounts Cyrillic and code by
                                // roughly half -- which is how a meter reading
                                // "70% full" walks straight into an overflow.
                                event.usage?.takeIf { !it.estimated }?.let { measured ->
                                    TokenCalibration.record(
                                        modelId = model,
                                        promptChars = promptChars,
                                        promptTokens = measured.promptTokens
                                    )
                                }
                                nativeCalls = event.toolCalls
                            }
                            else -> Unit
                        }
                    }
                }

                // Not started at all unless a limit is configured. See
                // [STALL_TIMEOUT_MS]: there is no limit by default.
                val watchdog = if (STALL_TIMEOUT_MS <= 0L) null else launch {
                    while (stream.isActive) {
                        delay(STALL_CHECK_MS)
                        if (System.currentTimeMillis() - lastEventAt >= STALL_TIMEOUT_MS) {
                            stalled = true
                            // Cancelling one child does not disturb the other or
                            // this scope, so the loop below still owns the outcome.
                            stream.cancel()
                            break
                        }
                    }
                }

                stream.join()
                watchdog?.cancel()
            }

            // Whichever count is larger is the real one: an endpoint that reports
            // no total still streamed its thinking, and one that reports a total
            // may have streamed none of it.
            reasoningChars = maxOf(reasoningChars, reasoningStreamed)

            if (stalled && failed == null) {
                // Reported as a timeout rather than as an empty answer, and
                // whatever text did arrive is still handed to the caller, which
                // stores it instead of throwing half a reply away.
                failed = AiError(
                    kind = AiError.Kind.Network,
                    message = AppStrings.get(
                        R.string.error_timeout,
                        fallback = "The provider timed out."
                    )
                )
            }

            val error = failed
            if (error != null) {
                // A rejected `tools` field must not cost the user their turn.
                // The endpoint accepted one when it was probed, but gateways
                // change, and one that dislikes a schema says so with a plain 400
                // that looks like any other bad request. So the vendor channel is
                // dropped for the rest of the run and the step is retried on the
                // prompt contract, which asks nothing of the endpoint. This can
                // only happen once -- `nativeTools` is false afterwards -- so it
                // cannot loop.
                if (nativeTools && error.kind == AiError.Kind.BadRequest) {
                    nativeTools = false
                    step--
                    continue
                }

                // A rejected generation parameter is the other 400 worth
                // surviving. When the endpoint names one -- "use
                // max_completion_tokens", "temperature is not supported" -- the
                // answer is recorded against this model and the step is retried
                // with the spelling it asked for. `learn` returns false when the
                // message taught nothing, so an unrelated 400 still surfaces and
                // an unchanged request is never sent twice.
                if (error.kind == AiError.Kind.BadRequest &&
                    ModelQuirks.learn(provider.id, model, error.message)
                ) {
                    step--
                    continue
                }

                // "Your prompt is too long" is the one error the app can answer
                // by itself: nothing the user types will make the next attempt
                // smaller, but dropping the oldest half of the conversation
                // will. The estimator that let it get this big is corrected from
                // the same turn's usage, so this is a floor under a bad guess,
                // not the routine path.
                if (error.kind == AiError.Kind.BadRequest &&
                    error.isContextOverflow() &&
                    overflowTrims < MAX_OVERFLOW_TRIMS &&
                    conversation.size > MIN_KEPT_TURNS
                ) {
                    overflowTrims++
                    val keep = (conversation.size / 2).coerceAtLeast(MIN_KEPT_TURNS)
                    while (conversation.size > keep) conversation.removeAt(0)
                    // Left in place of what went, so the model knows there is a
                    // gap instead of answering as if the task began mid-sentence.
                    conversation.add(0, AiMessage(AiRole.User, OVERFLOW_NOTE))
                    step--
                    continue
                }

                send(AgentEvent.Failure(error))
                return@channelFlow
            }

            val answer = builder.toString()

            // A blank turn is handled before anything else because it is the one
            // failure the user always reads as the app being broken.
            //
            // `finish_reason == "length"` means the model hit `max_tokens`. On a
            // reasoning model that happens *inside the thinking phase*, so not a
            // character of the answer is ever emitted -- asking again with the
            // same budget produces the same nothing, which is exactly what the
            // two nudges below were doing before this existed. Doubling the
            // budget and retrying the step fixes it without the user having to
            // know what a token is.
            // A native tool call carries no text of its own, so a turn that made
            // one is not blank -- it is the most productive kind of turn there is.
            // Testing the text alone would send it down the token-bump-and-nudge
            // path below and never run the tool.
            if (answer.isBlank() && nativeCalls.isEmpty()) {
                blankFinish = finishReason
                blankReasoning = reasoningChars
                val truncated = finishReason == "length"
                // A power mode may legitimately have asked for more than the
                // Settings slider allows, and bumping down to a smaller number
                // than the user already chose would be a bump that shrinks the
                // budget. The power cap travels with it, because it is the value
                // the request actually uses when one is set.
                val room = maxOf(MAX_TOKENS_CEILING, activeParams.power?.maxTokens ?: 0)
                // Never past what the endpoint accepts. The wire converter clamps
                // to that limit anyway, so a bump above it re-sent the identical
                // request and bought one more empty turn.
                val ceiling = activeParams.maxTokensLimit?.let { minOf(room, it) } ?: room
                val budget = activeParams.power?.maxTokens ?: activeParams.maxTokens
                if (truncated && tokenBumps < MAX_TOKEN_BUMPS && budget < ceiling) {
                    tokenBumps++
                    val bumped = (budget * 2).coerceAtMost(ceiling)
                    activeParams = activeParams.copy(
                        maxTokens = bumped,
                        power = activeParams.power?.let { current ->
                            // Only where a cap was already part of the mode: adding
                            // one to an effort-only config would send a field the
                            // endpoint never declared.
                            if (current.maxTokens != null) current.copy(maxTokens = bumped) else current
                        }
                    )
                    // Deliberately not appended to the conversation: the model
                    // said nothing, and an empty assistant turn is rejected
                    // outright by some gateways.
                    continue
                }
                if (truncated) break
            } else {
                // Keep the diagnosis about the *last* turn: a run that recovers
                // must not end with a message blaming a token limit it already
                // worked around.
                blankFinish = null
                blankReasoning = 0
            }

            // The vendor channel wins whenever it was used: those arguments
            // arrived as structured JSON and cannot have been mangled by a
            // missing fence, a stray backtick, or prose wrapped around them,
            // which is the entire class of failure it exists to remove. Anything
            // else -- every model that ignored the field, every endpoint that
            // never received it -- falls through to the fenced block unchanged.
            val calls = nativeCalls.mapNotNull { it.toParsedCall() }
                .ifEmpty { ToolCallParser.parse(answer, known) }
                // The same call twice in one turn is a stutter, not a plan.
                // Models repeat a block when they restate it after prose, and
                // gateways occasionally replay a fragment; either way running it
                // twice means two commits, two files, two identical builds.
                .distinctBy { ToolCallParser.canonicalName(it.tool) to it.args.toString() }

            // Append this step's prose instead of replacing the total. A step whose
            // entire output was a tool call contributes nothing and must not erase
            // what came before it.
            val prose = ToolCallParser.stripToolBlocks(answer, known)
            if (prose.isNotBlank()) {
                if (transcript.isNotEmpty()) transcript.append("\n\n")
                transcript.append(prose)
            }

            if (calls.isEmpty()) {
                // A step with no tool call used to end the entire run, which is
                // how "I forgot to call the tools. Let me check now." became a
                // dead turn the user had to poke with "you stopped".
                //
                // A turn that ends in prose is usually correct — it is how the
                // agent answers a question — so this does not retry blindly. It
                // retries only when the prose *promised* something, and only
                // twice, after which the original break stands and the run ends
                // rather than looping.
                // A blank turn is included: an endpoint that returned nothing at
                // all -- no content, no finish reason, no reasoning -- used to
                // fall straight through to the break below and end the run with
                // "the model returned an empty response", even though asking once
                // more is what fixes it in practice. Gateways drop a chunk, and a
                // reasoning model occasionally closes the stream after its
                // thinking phase. One retry costs a second; a dead turn costs the
                // user the question they just typed.
                if (nudges < MAX_NUDGES && (answer.isBlank() || announcesAction(prose))) {
                    nudges++
                    // An empty assistant message is not merely useless context:
                    // several OpenAI-compatible gateways reject
                    // {"role":"assistant","content":""} with a 400, turning a
                    // recoverable blank turn into a failed request.
                    if (answer.isNotBlank()) conversation += AiMessage(AiRole.Assistant, answer)
                    conversation += AiMessage(
                        AiRole.User,
                        if (answer.isBlank()) BLANK_PROMPT else NUDGE_PROMPT
                    )
                    continue
                }
                break
            }

            conversation += AiMessage(
                AiRole.Assistant,
                replayOf(answer, calls, nativeCalls.isNotEmpty())
            )
            val results = StringBuilder("Tool results:\n")

            for (call in calls) {
                val tool = tools.firstOrNull { it.name == call.tool }
                    // A name the registry does not have verbatim is usually the
                    // right tool in the wrong spelling: `functions.read_file`
                    // from a model trained on OpenAI's namespacing, `Read-File`
                    // from one writing prose. Matching canonically costs nothing
                    // and saves a step spent on an apology.
                    ?: tools.firstOrNull {
                        ToolCallParser.canonicalName(it.name) ==
                            ToolCallParser.canonicalName(call.tool)
                    }
                val preview = call.args.toString().take(160)
                send(AgentEvent.ToolStarted(call.tool, preview))

                val startedAt = System.currentTimeMillis()
                val missing = tool?.let { call.args.missingArgs(it.requiredArgs) }.orEmpty()
                val result = when {
                    tool == null -> AgentToolResult(
                        // The list is the fix, not the complaint: a model told
                        // only "unknown tool" guesses again, usually at the same
                        // name. Told what exists, it picks the right one next
                        // step instead of ending the run.
                        "Unknown tool '${call.tool}'. Available tools: " +
                            tools.joinToString(", ") { it.name },
                        success = false
                    )
                    // Checked before the call instead of inside every tool. A model
                    // that dropped an argument gets the name of what is missing and
                    // the tool's own usage line, which is enough to fix the call on
                    // the next step; the same mistake used to come back as "Tool
                    // failed: null", or as a write resolved against an empty path.
                    missing.isNotEmpty() -> AgentToolResult(
                        "Missing required argument(s): ${missing.joinToString(", ")}. " +
                            "Usage: ${tool.usage}",
                        success = false
                    )
                    // `runCatching` also catches CancellationException, which
                    // turned pressing Stop mid-tool into a fake tool failure and
                    // let the loop start another step. Cancellation has to win.
                    else -> try {
                        tool.execute(call.args, context)
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (t: Throwable) {
                        AgentToolResult("Tool failed: ${t.message}", success = false)
                    }
                }
                val duration = System.currentTimeMillis() - startedAt

                result.proposal?.let { proposals += it }

                val run = ToolRun(
                    id = UUID.randomUUID().toString(),
                    toolName = call.tool,
                    argumentsPreview = preview,
                    // What the user can expand under the tool row. Larger than it
                    // was: a 4000-char cap hid the tail of exactly the reads that
                    // needed checking, and the transcript is where a user
                    // verifies what the model actually saw.
                    output = result.output.take(MAX_STORED_OUTPUT_CHARS),
                    success = result.success,
                    durationMs = duration
                )
                send(AgentEvent.ToolFinished(run))
                toolsRun++

                results.appendLine("[${call.tool}] ${if (result.success) "ok" else "error"}")
                results.appendLine(clipForModel(result.output))
                results.appendLine()
            }

            conversation += AiMessage(AiRole.User, results.toString())

            if (step >= budget) {
                if (budget < hardCap) {
                    budget = (budget + maxSteps).coerceAtMost(hardCap)
                    // Telling the model its budget grew keeps it from padding the
                    // remaining steps: without this it tends to rush a summary at
                    // what it believes is the last step.
                    conversation += AiMessage(
                        AiRole.User,
                        "Continue. You have more steps available. Keep working " +
                            "until the task is done, then give your final answer."
                    )
                } else if (transcript.isBlank()) {
                    // The hard cap is the one place the old message still belongs:
                    // stopping here is a real limit, not a mid-task pause.
                    transcript.append(
                        "Stopped after $hardCap steps without finishing. " +
                            "Tell me how to narrow this down, or raise the step " +
                            "limit in Settings."
                    )
                }
            }
        }

        if (proposals.isNotEmpty()) send(AgentEvent.Proposals(proposals))

        // A run that called tools and produced no prose used to complete with an
        // empty string, which the chat rendered as nothing at all: the user saw a
        // tool card, no message, and an agent that had apparently given up
        // without a word. It is the most confusing possible failure because there
        // is nothing on screen to react to.
        //
        // Empty is only reported as empty when nothing happened either.
        val finalText = transcript.toString().trim().ifBlank {
            when {
                blankFinish == "length" -> AppStrings.format(
                    R.string.error_model_truncated,
                    activeParams.maxTokens,
                    fallback = "The model used its entire ${activeParams.maxTokens}-token " +
                        "budget before writing an answer. Raise \"Max tokens\" in Settings, " +
                        "or use a model that does not spend the budget on reasoning."
                )
                blankReasoning > 0 -> AppStrings.format(
                    R.string.error_model_reasoning_only,
                    blankReasoning,
                    fallback = "The model produced $blankReasoning characters of reasoning " +
                        "and no answer. Try again, or switch model."
                )
                toolsRun == 0 -> AppStrings.get(
                    R.string.error_model_empty,
                    fallback = "The model returned an empty response. Try again, or switch model."
                )
                else -> AppStrings.format(
                    R.string.error_agent_no_answer,
                    toolsRun,
                    fallback = "Ran $toolsRun tool call(s) but produced no answer. " +
                        "This usually means the model stopped early."
                )
            }
        }
        send(AgentEvent.Completed(finalText, spent))
    }

    /** Adds one step's counts to the run's total. */
    private fun addUsage(current: TokenUsage?, incoming: TokenUsage?): TokenUsage? {
        if (incoming == null) return current
        if (current == null) return incoming
        return TokenUsage(
            promptTokens = current.promptTokens + incoming.promptTokens,
            completionTokens = current.completionTokens + incoming.completionTokens,
            estimated = current.estimated || incoming.estimated
        )
    }

    /**
     * Did this prose promise an action it then failed to take?
     *
     * The strongest signal is language independent: prose that ends in a colon
     * is introducing something. Every stuck turn in the reported transcript
     * ended exactly that way — "Начну с файлов:", "Создам их через временные
     * файлы:" — with nothing after the colon.
     *
     * The phrase list is a second net for announcements that end in a full stop,
     * and covers both interface languages. It is matched case-insensitively
     * against the tail of the message, because an opening "Let me check the
     * repository first" followed by a *completed* answer is not stuck; it is only
     * the last thing said that indicates an unfulfilled promise.
     *
     * False positives cost one wasted round trip. False negatives cost the user
     * a dead turn, so this errs toward retrying.
     *
     * Folded with an explicit [Locale.ROOT]. Kotlin's `lowercase()` is already
     * invariant, so this only guards against someone swapping in Java's
     * locale-sensitive `toLowerCase()`, under which the English markers starting
     * with `i` would fold to a dotless `ı` on a Turkish device and never match.
     */
    private fun announcesAction(prose: String): Boolean {
        val text = prose.trim()
        if (text.isEmpty()) return true
        if (text.endsWith(":") || text.endsWith("—") || text.endsWith("...")) return true
        val tail = text.takeLast(160).lowercase(Locale.ROOT)
        return INTENT_MARKERS.any { it in tail }
    }

    /**
     * Bounds one tool result before it is handed back to the model.
     *
     * The cut itself is unavoidable — a tool can return more than a context
     * window holds — but a *silent* cut is a correctness bug, not a limit: this
     * is what made `read_file` stop at line 277 of a longer file while looking
     * like a complete read, after which the model rewrote the file from the part
     * it had. So the clip now ends on a line boundary and says, in the output the
     * model reads, that data is missing and how to ask for the rest.
     *
     * Tools that page their own output (read_file, github_read_file) stay well
     * under this cap and are never touched here.
     */
    private fun clipForModel(output: String): String {
        if (output.length <= MAX_TOOL_OUTPUT_CHARS) return output
        val head = output.take(MAX_TOOL_OUTPUT_CHARS)
        // Prefer the last newline so a truncated line never reads as a real one.
        val boundary = head.lastIndexOf('\n').takeIf { it > MAX_TOOL_OUTPUT_CHARS / 2 }
            ?: head.length
        val kept = head.substring(0, boundary)
        val dropped = output.length - kept.length
        return buildString {
            append(kept)
            appendLine()
            append(
                "\u2026 [Sirius cut this tool result after ${kept.length} characters; " +
                    "$dropped characters were NOT shown. The data above is incomplete. " +
                    "Re-run the tool with a narrower request, or with pagination arguments " +
                    "(read_file and github_read_file accept \"offset\" and \"limit\") " +
                    "until you have read everything. Do not rewrite a file you have only " +
                    "partially read.]"
            )
        }
    }

    /**
     * The registry this run is allowed to use.
     *
     * ### Why the mapping lives here and not on AgentTool
     * A `feature` property on [AgentTool] was the obvious alternative and is
     * wrong: it would make every workspace tool declare
     * `override val feature = null`, and it would let a third-party-shaped tool
     * claim a switch that has no UI. The set of switches is a product decision
     * with five rows in a settings panel, so it is stated once, here, where the
     * panel's contract is visible.
     *
     * ### Why "tools off" leaves ask_user alive
     * With the tools switch off the model is a plain chat model -- but a plain
     * chat model that has been asked to build something still needs a way to say
     * "which framework?". `ask_user` writes nothing, reads nothing and touches no
     * file; removing it would not make the run safer, only more likely to guess.
     */
    private fun activeTools(features: ChatFeatures, allowTerminal: Boolean): List<AgentTool> {
        val blocked = HashSet<String>()
        for (feature in ChatFeature.entries) {
            if (!features[feature]) blocked += toolsFor(feature)
        }
        // Dropped from the registry for the same reason as the feature switches
        // above, rather than refused inside the tool: the model never hears about
        // it and plans around the absence, instead of calling it and spending a
        // step on an apology.
        if (!allowTerminal) blocked += RUN_COMMAND
        return tools.filterNot { it.name in blocked }
    }

    private fun toolsFor(feature: ChatFeature): Set<String> = when (feature) {
        // The link tools ride with search: what they need is the network, and a
        // user who switched the internet off does not expect one of them to
        // quietly reach a URL anyway.
        ChatFeature.WebSearch -> WEB_TOOL_NAMES + LINK_TOOL_NAMES
        ChatFeature.ImageGeneration -> IMAGE_TOOL_NAMES
        ChatFeature.ImageEditing -> IMAGE_EDIT_TOOL_NAMES
        // Vision gates the *request body*, not the registry: an attached image is
        // downgraded to a filename by the prompt builder. Streaming gates
        // transport. Neither removes a tool.
        ChatFeature.Vision, ChatFeature.Streaming -> emptySet()
        // Everything except the question tool, for the reason in the doc above.
        ChatFeature.Tools -> tools.mapTo(HashSet()) { it.name } - "ask_user"
    }

    companion object {
        /**
         * Characters of one tool result that reach the model.
         *
         * Raised from 8000, which was under a single page of a real source file:
         * a 300-line HTML file with line numbers already exceeded it. Kept finite
         * because several results accumulate in one conversation turn.
         */
        private const val MAX_TOOL_OUTPUT_CHARS = 24_000

        /** Characters of one tool result kept in the transcript for the user. */
        private const val MAX_STORED_OUTPUT_CHARS = 16_000

        /** Retries per run for a turn that promised work and did none. */
        private const val MAX_NUDGES = 2

        /** The one tool the global terminal switch removes. */
        private const val RUN_COMMAND = "run_command"

        /**
         * How many times the step budget may refill. Four is enough for a build,
         * a fix and a rebuild; unbounded would let one bad prompt spend the
         * user's API credit until the app is killed.
         */
        private const val BUDGET_EXTENSIONS = 4

        /** Ceiling regardless of the configured limit, for the same reason. */
        private const val ABSOLUTE_MAX_STEPS = 40

        /**
         * How many times one run may double `max_tokens` after a truncated,
         * answerless turn. Two takes 4096 to 16000, which is the top of the
         * settings slider, so a third would be a promise the UI cannot keep.
         */
        private const val MAX_TOKEN_BUMPS = 2

        /** Matches the ceiling of the Max tokens slider in Settings. */
        private const val MAX_TOKENS_CEILING = 16_000

        /**
         * How long a step may produce nothing at all before it is abandoned, or
         * `0` for no limit -- which is what ships.
         *
         * Ninety seconds used to live here, and it was wrong for the models this
         * app is actually used with. Extended thinking routinely runs for several
         * minutes, and none of that traffic used to reach this loop: thinking
         * deltas were dropped by the providers and keep-alive frames by the SSE
         * reader, so a model deep in a hard problem looked exactly like a dead
         * socket and the turn ended with "the provider timed out" mid-thought.
         *
         * Thinking text and keep-alives are now forwarded as events, so this
         * clock would be reset by a healthy stream -- but a client-side stopwatch
         * should not be deciding how long a model is allowed to think at all, so
         * the watchdog is off.
         *
         * What still bounds a genuinely dead connection: the read timeout in
         * [com.sirius.chat.ai.provider.HttpClientProvider], which fires only when
         * not one byte has arrived, and the Stop button, which the user can
         * always reach. Set a positive value here to bring the watchdog back.
         */
        private const val STALL_TIMEOUT_MS = 0L

        /** Watchdog granularity. Coarse enough to cost nothing while streaming. */
        private const val STALL_CHECK_MS = 2_000L

        /** How many times one run may cut its own history to make it fit. */
        private const val MAX_OVERFLOW_TRIMS = 2

        /** A prompt has to keep enough turns to still contain the task. */
        private const val MIN_KEPT_TURNS = 4

        /** Stands in for the turns an overflow cut away. */
        private const val OVERFLOW_NOTE =
            "[Earlier turns were removed because the provider reported the prompt was " +
                "too long. Ask the user to repeat anything you need from them.]"

        private val NUDGE_PROMPT = """
            You described an action but issued no tool call, so nothing ran.
            Emit the tool call now as a ```sirius-tool fenced JSON block, or, if
            no tool is needed, give your final answer directly.
        """.trimIndent()

        /**
         * Sent after a turn that returned nothing at all.
         *
         * Different from [NUDGE_PROMPT] on purpose: there is no prose to refer
         * back to, and the usual cause on a reasoning model is a thinking phase
         * that never converged, so the instruction is to be brief rather than to
         * finish a sentence it never started.
         */
        private val BLANK_PROMPT = """
            Your previous reply arrived empty. Do not think at length: answer
            directly, or issue one tool call as a ```sirius-tool fenced JSON
            block. Keep it short.
        """.trimIndent()

        private val INTENT_MARKERS = listOf(
            // Russian
            "сейчас", "проверю", "посмотрю", "создам", "создаю", "начну",
            "сделаю", "прочитаю", "исправлю", "добавлю", "запущу", "вызову",
            // English
            "let me", "i'll ", "i will ", "i am going to", "i'm going to",
            "now i", "checking", "creating", "reading", "next step"
        )

        fun defaultTools(): List<AgentTool> = listOf(
            ReadFileTool(),
            ListDirectoryTool(),
            SearchFilesTool(),
            SearchTextTool(),
            AnalyzeProjectTool(),
            AskUserTool(),
            RunCommandTool(),
            CreateFileTool(),
            WriteFileTool(),
            DeleteFileTool(),
            RenameFileTool(),
            MoveFileTool()
        )
    }
}
