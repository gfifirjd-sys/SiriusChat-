package com.sirius.chat.ai.provider

import com.sirius.chat.ai.capability.EndpointCapabilityTable
import com.sirius.chat.ai.capability.PowerWire

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiContentPart
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.AiToolCall
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.streaming.SseParser
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.TokenUsage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.job
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Speaks the `/chat/completions` protocol, which covers OpenAI itself plus
 * OpenRouter, Groq, Together, vLLM, LM Studio, Ollama and most self-hosted
 * gateways.
 */
class OpenAiCompatibleProvider(
    private val config: ProviderConfig,
    private val apiKey: String?,
    private val client: OkHttpClient = HttpClientProvider.client
) : AiProvider {

    override val id: String = config.id
    override val label: String = config.label
    override val models: List<AiModel> = config.models

    private val json = Json { ignoreUnknownKeys = true }

    override fun chat(request: ChatRequest): Flow<ChatStreamEvent> = flow {
        emit(ChatStreamEvent.Started)

        // Reasoning models rename one of these fields and refuse the other:
        // `max_tokens` is `max_completion_tokens` on the o-series and gpt-5, and
        // any temperature but the default is a flat 400 there. Sending both to
        // everything meant choosing one of the strongest models available turned
        // every message into a rejection the user could not act on.
        val quirks = ModelQuirks.of(config.id, request.model)

        // Power fields come from the capability table, narrowed by whatever this
        // model has already refused. Nothing is written that the endpoint has not
        // declared: an unknown key is a 400 on a strict gateway, and that costs
        // the user the entire turn.
        val capabilities = EndpointCapabilityTable.narrow(
            EndpointCapabilityTable.of(config, request.model),
            quirks
        )
        val powerFields = PowerWire.fields(request.params.power, capabilities)

        val payload = buildJsonObject {
            put("model", request.model)
            if (quirks.sendTemperature) put("temperature", request.params.temperature)
            if (quirks.sendMaxTokens) {
                put(
                    quirks.maxTokensKey,
                    PowerWire.maxTokens(
                        request.params.power,
                        capabilities,
                        request.params.maxTokens
                    )
                )
            }
            powerFields.forEach { (key, value) -> put(key, value) }
            put("stream", request.stream)
            putJsonArray("messages") {
                request.systemPrompt?.takeIf { it.isNotBlank() }?.let { system ->
                    add(buildJsonObject {
                        put("role", "system")
                        put("content", system)
                    })
                }
                request.messages.forEach { message ->
                    add(buildJsonObject {
                        put("role", message.role.wireName())
                        if (message.parts.isEmpty()) {
                            // String content, exactly as before: some
                            // OpenAI-compatible servers reject the array form
                            // outright, so it is only used when there is something
                            // that needs it.
                            put("content", message.content)
                        } else {
                            putJsonArray("content") {
                                message.parts.forEach { part -> add(contentBlock(part)) }
                            }
                        }
                    })
                }
            }
            // Sent only when the caller has tools to offer, which upstream means
            // only when a real request has already proved this model accepts the
            // field. Some llama.cpp builds and older vLLM releases reject unknown
            // request keys outright, and losing the whole turn to a capability the
            // app does not need is the wrong trade -- the fenced-block contract in
            // the system prompt works without any of this.
            if (request.tools.isNotEmpty()) {
                putJsonArray("tools") {
                    request.tools.forEach { spec ->
                        add(buildJsonObject {
                            put("type", "function")
                            putJsonObject("function") {
                                put("name", spec.name)
                                put("description", spec.description)
                                put("parameters", schemaOf(spec.parametersJson, json))
                            }
                        })
                    }
                }
                // "auto", never "required": the last step of an agent run is
                // prose, and forcing a call there makes the model invent one.
                put("tool_choice", "auto")
            }
        }

        // A key pasted from a website arrives with a trailing newline more often
        // than not, and building a header out of it throws before the request is
        // ever sent. Trimmed here, and refused with an explanation when it still
        // cannot be encoded -- an error naming the key beats a stack trace.
        val key = apiKey?.trim().orEmpty()
        if (key.isNotEmpty() && !key.isHeaderSafe()) {
            emit(ChatStreamEvent.Failure(invalidKeyError()))
            return@flow
        }

        val httpRequest = Request.Builder()
            .url(config.baseUrl.trimEnd('/') + "/chat/completions")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .apply {
                header("Content-Type", "application/json")
                if (key.isNotEmpty()) header("Authorization", "Bearer $key")
                if (request.stream) header("Accept", "text/event-stream")
            }
            .build()

        val call = client.newCall(httpRequest)
        // OkHttp reads block; cancelling the coroutine must abort the socket.
        currentCoroutineContext().job.invokeOnCompletion { if (!call.isCanceled()) call.cancel() }

        val response = runCatching { call.execute() }.getOrElse { error ->
            emit(ChatStreamEvent.Failure(error.toAiError()))
            return@flow
        }

        response.use { httpResponse ->
            if (!httpResponse.isSuccessful) {
                val body = runCatching { httpResponse.body?.string() }.getOrNull().orEmpty()
                emit(
                    ChatStreamEvent.Failure(
                        httpError(httpResponse.code, body, httpResponse.retryHintMillis())
                    )
                )
                return@flow
            }
            val source = httpResponse.body?.source()
            if (source == null) {
                emit(
                    ChatStreamEvent.Failure(
                        AiError(
                            AiError.Kind.Server,
                            AppStrings.get(R.string.error_empty_body, fallback = "Empty response body")
                        )
                    )
                )
                return@flow
            }

            val builder = StringBuilder()
            var finishReason: String? = null
            var reasoningChars = 0
            var usage: TokenUsage? = null
            var streamError: String? = null
            var toolCalls: List<AiToolCall> = emptyList()
            // Keyed by the stream's own `index`, which is the only thing tying a
            // name fragment to the argument fragments that follow it.
            val toolBuffer = LinkedHashMap<Int, ToolCallBuilder>()

            if (!request.stream) {
                val text = source.readUtf8()
                val root = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
                streamError = root?.errorMessage()
                val choice = root?.get("choices")?.jsonArray?.firstOrNull()?.jsonObject
                val message = choice?.get("message")?.jsonObject
                val content = (message?.get("content") as? JsonPrimitive)?.contentOrNull
                reasoningChars = message?.reasoningText()?.length ?: 0
                finishReason = (choice?.get("finish_reason") as? JsonPrimitive)?.contentOrNull
                usage = root?.usageOrNull()
                toolCalls = message?.completedToolCalls().orEmpty()
                if (content != null) {
                    builder.append(content)
                    emit(ChatStreamEvent.Delta(content))
                }
            } else {
                // SseParser.read is inline, so tokens are emitted downstream the
                // moment they arrive instead of being buffered.
                SseParser.read(
                    source,
                    // Gateways send `: comment` frames while a reasoning model
                    // thinks. That is liveness, not silence.
                    onKeepAlive = { emit(ChatStreamEvent.Heartbeat) }
                ) { event ->
                    if (event.data == SseParser.DONE) return@read false
                    // Any frame at all means the endpoint is still working, even
                    // when this one carries no visible token.
                    emit(ChatStreamEvent.Heartbeat)
                    val chunk = extractDelta(event.data)
                    if (chunk.error != null) {
                        streamError = chunk.error
                        return@read false
                    }
                    if (chunk.finish != null) finishReason = chunk.finish
                    chunk.usage?.let { usage = it }
                    // Counted and forwarded, never appended to the answer. The
                    // forwarding is what lets the agent tell a model that is
                    // thinking apart from a stream that has died.
                    chunk.reasoning?.takeIf { it.isNotEmpty() }?.let { thinking ->
                        reasoningChars += thinking.length
                        emit(ChatStreamEvent.Reasoning(thinking))
                    }
                    chunk.toolCalls.forEach { fragment ->
                        val slot = toolBuffer.getOrPut(fragment.index) { ToolCallBuilder() }
                        fragment.id?.let { slot.id = it }
                        fragment.name?.let { slot.name = it }
                        fragment.arguments?.let { slot.arguments.append(it) }
                    }
                    val text = chunk.content
                    if (!text.isNullOrEmpty()) {
                        builder.append(text)
                        emit(ChatStreamEvent.Delta(text))
                    }
                    true
                }
                toolCalls = toolBuffer.reassemble()
            }

            val problem = streamError
            if (problem != null) {
                emit(ChatStreamEvent.Failure(AiError(AiError.Kind.Server, problem)))
                return@use
            }

            emit(
                ChatStreamEvent.Completed(
                    finishReason,
                    builder.toString(),
                    reasoningChars,
                    usage,
                    toolCalls
                )
            )
        }
    }.flowOn(Dispatchers.IO)

    /**
     * One SSE payload, split into what belongs in the answer and what does not.
     *
     * Reasoning models return their thinking in a field of its own --
     * `reasoning_content` on DeepSeek, `reasoning` on OpenRouter -- and it must
     * never be concatenated into the answer: it is a draft, often in another
     * language, and the tool-call parser would try to read it.
     *
     * It cannot be discarded either. A turn that spends its whole `max_tokens`
     * budget thinking arrives here with an empty `content`, and only the
     * reasoning tells the difference between "this model thought and ran out of
     * room" and "this endpoint sent nothing".
     *
     * Fields are read through `as? JsonPrimitive` rather than `.jsonPrimitive`,
     * which throws: a gateway that returns `content` as an array of parts used
     * to take down the whole stream with an exception instead of dropping one
     * chunk.
     */
    private data class Chunk(
        val content: String?,
        val reasoning: String?,
        val finish: String?,
        /**
         * Gateway error delivered inside a 200 response.
         *
         * Rate limits and upstream provider failures routinely arrive as
         * `data: {"error":{...}}` *after* the headers are already on the wire,
         * so the HTTP status is 200 and the old parser, which only looked at
         * `choices`, dropped the message on the floor and reported an empty
         * answer. The one thing the user needed to see was in that payload.
         */
        val error: String? = null,
        val usage: TokenUsage? = null,
        /** Tool-call fragments in this chunk, in the order they arrived. */
        val toolCalls: List<ToolCallFragment> = emptyList()
    )

    /**
     * One slice of a streamed tool call.
     *
     * The first chunk of a call carries its id and function name; every chunk
     * after it carries a piece of the argument string, which is only valid JSON
     * once all of them are concatenated. `index` is what says which call a piece
     * belongs to, and it is read rather than assumed because a model calling two
     * tools in one turn interleaves their fragments.
     */
    private data class ToolCallFragment(
        val index: Int,
        val id: String?,
        val name: String?,
        val arguments: String?
    )

    private fun extractDelta(data: String): Chunk {
        val root = runCatching { json.parseToJsonElement(data).jsonObject }.getOrNull()
            ?: return EMPTY_CHUNK
        root.errorMessage()?.let { return EMPTY_CHUNK.copy(error = it) }
        // Read before the `choices` guard below: the chunk that carries usage
        // is usually the one with an empty choices array, so the old early
        // return would have dropped exactly the payload being looked for.
        val usage = root.usageOrNull()
        val choice = (root["choices"] as? JsonArray)?.firstOrNull()?.jsonObject
            ?: return EMPTY_CHUNK.copy(usage = usage)
        val delta = choice["delta"] as? JsonObject
        return Chunk(
            content = (delta?.get("content") as? JsonPrimitive)?.contentOrNull,
            reasoning = delta?.reasoningText(),
            finish = (choice["finish_reason"] as? JsonPrimitive)?.contentOrNull,
            usage = usage,
            toolCalls = delta?.toolCallFragments().orEmpty()
        )
    }

    /**
     * Tool-call fragments in one streamed delta.
     *
     * Every field is read through `as?` rather than `.jsonPrimitive`, which
     * throws: a gateway that sends `index` as a string or omits `function` on a
     * continuation chunk would otherwise take down the whole stream instead of
     * contributing nothing to one call.
     */
    private fun JsonObject.toolCallFragments(): List<ToolCallFragment> {
        val array = this["tool_calls"] as? JsonArray ?: return emptyList()
        return array.mapIndexedNotNull { position, element ->
            val obj = element as? JsonObject ?: return@mapIndexedNotNull null
            val function = obj["function"] as? JsonObject
            ToolCallFragment(
                index = (obj["index"] as? JsonPrimitive)?.contentOrNull?.toIntOrNull() ?: position,
                id = (obj["id"] as? JsonPrimitive)?.contentOrNull,
                name = (function?.get("name") as? JsonPrimitive)?.contentOrNull,
                arguments = argumentsText(function?.get("arguments"))
            )
        }
    }

    /**
     * Complete tool calls from a non-streamed message.
     *
     * A call with no name is dropped: there is nothing to run, and passing an
     * empty name through would surface as "unknown tool ''" a step later.
     */
    private fun JsonObject.completedToolCalls(): List<AiToolCall> {
        val array = this["tool_calls"] as? JsonArray ?: return emptyList()
        return array.mapIndexedNotNull { position, element ->
            val obj = element as? JsonObject ?: return@mapIndexedNotNull null
            val function = obj["function"] as? JsonObject ?: return@mapIndexedNotNull null
            val name = (function["name"] as? JsonPrimitive)?.contentOrNull
                ?.takeIf { it.isNotBlank() } ?: return@mapIndexedNotNull null
            AiToolCall(
                id = (obj["id"] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }
                    ?: "call_$position",
                name = name,
                argumentsJson = argumentsText(function["arguments"]).orEmpty()
            )
        }
    }

    /**
     * The arguments field as text, whether it arrived as text or as an object.
     *
     * The protocol says this is a string containing JSON and most endpoints
     * agree. Several gateways -- and every local server that re-serialises the
     * model's own output -- send the object itself instead. Reading only the
     * string case dropped those arguments on the floor, so the tool ran on
     * nothing and answered "missing required argument" for a call that was
     * complete on the wire.
     */
    private fun argumentsText(value: JsonElement?): String? = when (value) {
        null -> null
        is JsonPrimitive -> value.contentOrNull
        else -> value.toString()
    }

    /** Token counts, when the endpoint volunteers them. */
    private fun JsonObject.usageOrNull(): TokenUsage? {
        val block = this["usage"] as? JsonObject ?: return null
        fun field(name: String) =
            (block[name] as? JsonPrimitive)?.contentOrNull?.toIntOrNull() ?: 0
        val prompt = field("prompt_tokens")
        val completion = field("completion_tokens")
        if (prompt <= 0 && completion <= 0) return null
        return TokenUsage(prompt, completion)
    }

    /** Thinking text under either of the two field names in use. */
    private fun JsonObject.reasoningText(): String? =
        (this["reasoning_content"] as? JsonPrimitive)?.contentOrNull
            ?: (this["reasoning"] as? JsonPrimitive)?.contentOrNull

    /**
     * Error text from an `error` field, whether it is an object or a bare string.
     *
     * Blank is treated as absent so an `"error": ""` field, which some gateways
     * send on every chunk, cannot abort a healthy stream.
     */
    private fun JsonObject.errorMessage(): String? {
        val node = this["error"] ?: return null
        val text = when (node) {
            is JsonObject -> (node["message"] as? JsonPrimitive)?.contentOrNull
            is JsonPrimitive -> node.contentOrNull
            else -> null
        }
        return text?.takeIf { it.isNotBlank() }
    }

    private fun AiRole.wireName(): String = when (this) {
        AiRole.System -> "system"
        AiRole.User -> "user"
        AiRole.Assistant -> "assistant"
    }

    private companion object {
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        val EMPTY_CHUNK = Chunk(null, null, null)
    }

    /**
     * One content block in the OpenAI chat-completions format.
     *
     * Images travel as `image_url` with a data uri. PDFs have no equivalent here,
     * so instead of sending something the endpoint would reject, the model is told
     * the document exists and cannot be read — which is recoverable, unlike a
     * failed request.
     */
    private fun contentBlock(part: AiContentPart): JsonObject = when (part) {
        is AiContentPart.Text -> buildJsonObject {
            put("type", "text")
            put("text", part.text)
        }
        is AiContentPart.Image -> buildJsonObject {
            put("type", "image_url")
            putJsonObject("image_url") {
                put("url", "data:${part.mediaType};base64,${part.base64}")
            }
        }
        is AiContentPart.Document -> buildJsonObject {
            put("type", "text")
            put(
                "text",
                "[Attached document \"${part.name}\" — this provider cannot receive PDF " +
                    "documents. Ask the user for the relevant text, or to switch to a provider " +
                    "that supports documents.]"
            )
        }
    }

}
