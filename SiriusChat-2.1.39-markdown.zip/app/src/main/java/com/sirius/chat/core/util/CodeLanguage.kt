package com.sirius.chat.core.util

import androidx.annotation.StringRes
import com.sirius.chat.R

/**
 * Languages Sirius can highlight and reason about.
 *
 * [displayName] is the stable identifier used for markdown fences and never
 * translated: language names are proper nouns. Only the "plain text" bucket is
 * a real UI word, so it carries a string resource for [labelRes].
 */
enum class CodeLanguage(val displayName: String) {
    Kotlin("Kotlin"),
    Java("Java"),
    Xml("XML"),
    Json("JSON"),
    Gradle("Gradle"),
    Markdown("Markdown"),
    Python("Python"),
    JavaScript("JavaScript"),
    TypeScript("TypeScript"),
    Shell("Shell"),
    Yaml("YAML"),
    Sql("SQL"),
    C("C/C++"),
    Properties("Properties"),
    Diff("Diff"),
    PlainText("Text");

    val isBraceLanguage: Boolean
        get() = this in setOf(Kotlin, Java, JavaScript, TypeScript, C, Sql)

    /** Set only where the name is a translatable word rather than a proper noun. */
    @get:StringRes
    val labelRes: Int?
        get() = if (this == PlainText) R.string.language_plain_text else null
}

object CodeLanguages {

    private val byExtension = mapOf(
        "kt" to CodeLanguage.Kotlin,
        "kts" to CodeLanguage.Gradle,
        "java" to CodeLanguage.Java,
        "xml" to CodeLanguage.Xml,
        "html" to CodeLanguage.Xml,
        "htm" to CodeLanguage.Xml,
        "svg" to CodeLanguage.Xml,
        "json" to CodeLanguage.Json,
        "md" to CodeLanguage.Markdown,
        "markdown" to CodeLanguage.Markdown,
        "py" to CodeLanguage.Python,
        "js" to CodeLanguage.JavaScript,
        "mjs" to CodeLanguage.JavaScript,
        "jsx" to CodeLanguage.JavaScript,
        "ts" to CodeLanguage.TypeScript,
        "tsx" to CodeLanguage.TypeScript,
        "sh" to CodeLanguage.Shell,
        "bash" to CodeLanguage.Shell,
        "zsh" to CodeLanguage.Shell,
        "yml" to CodeLanguage.Yaml,
        "yaml" to CodeLanguage.Yaml,
        "sql" to CodeLanguage.Sql,
        "c" to CodeLanguage.C,
        "h" to CodeLanguage.C,
        "cpp" to CodeLanguage.C,
        "hpp" to CodeLanguage.C,
        "cc" to CodeLanguage.C,
        "properties" to CodeLanguage.Properties,
        "pro" to CodeLanguage.Properties,
        "gitignore" to CodeLanguage.Properties,
        "diff" to CodeLanguage.Diff,
        "patch" to CodeLanguage.Diff,
        "txt" to CodeLanguage.PlainText
    )

    private val byMarkdownTag = mapOf(
        "kotlin" to CodeLanguage.Kotlin,
        "kt" to CodeLanguage.Kotlin,
        "java" to CodeLanguage.Java,
        "xml" to CodeLanguage.Xml,
        "html" to CodeLanguage.Xml,
        "json" to CodeLanguage.Json,
        "gradle" to CodeLanguage.Gradle,
        "kts" to CodeLanguage.Gradle,
        "groovy" to CodeLanguage.Gradle,
        "md" to CodeLanguage.Markdown,
        "python" to CodeLanguage.Python,
        "py" to CodeLanguage.Python,
        "javascript" to CodeLanguage.JavaScript,
        "js" to CodeLanguage.JavaScript,
        "typescript" to CodeLanguage.TypeScript,
        "ts" to CodeLanguage.TypeScript,
        "tsx" to CodeLanguage.TypeScript,
        "bash" to CodeLanguage.Shell,
        "sh" to CodeLanguage.Shell,
        "shell" to CodeLanguage.Shell,
        "console" to CodeLanguage.Shell,
        "yaml" to CodeLanguage.Yaml,
        "yml" to CodeLanguage.Yaml,
        "sql" to CodeLanguage.Sql,
        "c" to CodeLanguage.C,
        "cpp" to CodeLanguage.C,
        "properties" to CodeLanguage.Properties,
        // A patch is the clearest way to show an edit, and it is the one fence
        // tag whose meaning is carried by the first character of every line.
        "diff" to CodeLanguage.Diff,
        "patch" to CodeLanguage.Diff
    )

    fun fromFileName(name: String): CodeLanguage {
        val lower = name.lowercase()
        if (lower.endsWith(".gradle.kts") || lower == "build.gradle") return CodeLanguage.Gradle
        if (lower == "dockerfile") return CodeLanguage.Shell
        val ext = lower.substringAfterLast('.', "")
        return byExtension[ext] ?: CodeLanguage.PlainText
    }

    fun fromTag(tag: String?): CodeLanguage {
        if (tag.isNullOrBlank()) return CodeLanguage.PlainText
        return byMarkdownTag[tag.trim().lowercase()] ?: CodeLanguage.PlainText
    }

    /** Rough binary sniffing so the editor never tries to render a PNG. */
    fun isProbablyText(name: String, mimeType: String): Boolean {
        if (mimeType.startsWith("text/")) return true
        if (mimeType in setOf("application/json", "application/xml", "application/javascript")) return true
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext.isEmpty()) return true
        return ext in byExtension.keys || ext in setOf(
            "gradle", "toml", "cfg", "ini", "csv", "log", "env", "lock", "editorconfig", "pro"
        )
    }
}
