package com.sirius.chat.core.util

import android.app.ActivityManager
import android.content.Context
import android.os.Build

/**
 * Whether this phone should be given the cheap version of the chat.
 *
 * ### Why the app asks at all
 * Every expensive thing in this UI -- the glass blur, the entry animation on
 * each bubble, re-parsing markdown on every streamed token -- is affordable on
 * a 2023 flagship and is not affordable on a four-core phone from 2018. The
 * choice is not "pretty or fast": it is which of the two the *device* can
 * actually deliver, and only the device knows that.
 *
 * ### Why these four signals
 * `isLowRamDevice` is the manufacturer's own answer and is trusted first.
 * `memoryClass` is the per-app heap Android is willing to hand out, which
 * tracks the device tier closely. Core count catches the cheap chips that ship
 * with plenty of RAM, and the API level catches the phones too old to have been
 * fast when they were new. Any one of them is enough: this decides whether to
 * skip a blur, not whether to refuse to run.
 *
 * ### Why the answer is cached
 * None of these change while the process is alive, and the call sites are in
 * composition and in the streaming loop -- the two places that must not do
 * system-service lookups per frame.
 */
object DevicePerformance {

    @Volatile
    private var cached: Boolean? = null

    /** True when this device should run the reduced-cost chat. */
    fun isWeak(context: Context): Boolean =
        cached ?: measure(context).also { cached = it }

    private fun measure(context: Context): Boolean {
        val manager = runCatching {
            context.applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        }.getOrNull()

        if (manager?.isLowRamDevice == true) return true

        // 0 would mean the lookup failed, which is not evidence of a slow phone.
        val memoryClass = manager?.memoryClass ?: 0
        if (memoryClass in 1 until MIN_MEMORY_CLASS_MB) return true

        if (Runtime.getRuntime().availableProcessors() <= WEAK_CORE_COUNT) return true

        return Build.VERSION.SDK_INT <= WEAK_SDK
    }

    /** Below this per-app heap the device is entry level whatever else it reports. */
    private const val MIN_MEMORY_CLASS_MB = 192

    /** Four slow cores is the common shape of a budget phone. */
    private const val WEAK_CORE_COUNT = 4

    /** Android 8.1 and older: nothing shipping today is on it by choice. */
    private const val WEAK_SDK = 27
}
