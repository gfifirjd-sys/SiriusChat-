package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.ProviderAvatar
import com.sirius.chat.core.designsystem.components.SheetActionRow
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.components.sheetDragGuard
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.locale.displayLabel
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.DefaultPowerMode
import com.sirius.chat.domain.model.PowerMode
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.requiresApiKey

/** Above this many models across all providers, the sheet shows a search field. */
private const val SEARCH_THRESHOLD = 12

/**
 * How much of the screen the model list may take.
 *
 * A fraction rather than the old flat 420dp. The list is one of five things in
 * this sheet (title, search, list, warning, footer button) and the sheet itself
 * is capped at the screen minus 88dp. On a short phone 420dp of list pushed the
 * footer -- and the last rows of the list -- past the bottom of the window, where
 * they are drawn but cannot be touched: the sheet looked like it "stopped
 * reacting". Sizing off the screen keeps every row inside the sheet on every
 * device.
 */
private const val LIST_HEIGHT_FRACTION = 0.46f

/**
 * One line of the picker.
 *
 * ### Why the list is flattened
 * The previous version nested `items(provider.models.size)` inside a `forEach`
 * over providers, with keys built from the provider it closed over. That works
 * until the list is filtered while a scroll is in flight: the item lambdas are
 * rebuilt against a *new* provider list, and `LazyColumn` is left resolving keys
 * against captured state that no longer matches its own item count. The visible
 * symptom is a list that stalls mid-drag or ignores the first touch after a
 * filter change.
 *
 * A single flat list with one stable key per row has no captured collection to
 * fall out of sync, so scrolling stays continuous across filtering.
 */
private sealed interface PickerRow {

    /** Stable across filtering, so recycling never reuses the wrong row. */
    val key: String

    data class Group(val provider: ProviderConfig) : PickerRow {
        override val key: String get() = "group:" + provider.id
    }

    data class Entry(val provider: ProviderConfig, val model: AiModel) : PickerRow {
        override val key: String get() = "model:" + provider.id + ":" + model.id
    }
}

/** Provider + model selection in one compact sheet. */
@Composable
fun ModelPickerSheet(
    providers: List<ProviderConfig>,
    activeProviderId: String?,
    activeModel: String?,
    onSelect: (String, String) -> Unit,
    onManageProviders: () -> Unit,
    /** The mode stored for the pair that is currently selected. */
    powerMode: PowerMode = DefaultPowerMode,
    /** Whether that pair has anything to configure at all. */
    powerSupported: Boolean = false,
    /**
     * Opens the power picker, or null to hide the row entirely.
     *
     * Null is how the fork picker reuses this sheet: choosing which model to
     * branch onto is not the moment to change how hard the current chat thinks.
     */
    onOpenPower: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors

    SiriusBottomSheet(
        title = stringResource(R.string.chat_model_title),
        subtitle = stringResource(R.string.chat_model_subtitle),
        onDismiss = onDismiss,
        scrollable = false,
        // The body is a list plus furniture; a flick on the furniture must not be
        // read as "close this".
        lockBodyDrag = true
    ) {
        val enabled = providers.filter { it.enabled }
        // With nothing configured the sheet was a title above a lone button; say
        // why the list is empty before pointing at the fix.
        if (enabled.isEmpty()) {
            Text(
                text = stringResource(R.string.home_no_provider),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary,
                modifier = Modifier.padding(vertical = SiriusSpacing.sm)
            )
        }

        // Adding a gateway's whole catalogue can leave hundreds of rows here, so
        // past a screenful the sheet gets a filter instead of an endless scroll.
        var query by remember { mutableStateOf("") }
        val searchable = enabled.sumOf { it.models.size } > SEARCH_THRESHOLD
        val shown = remember(enabled, query, searchable) {
            val needle = query.trim()
            if (!searchable || needle.isEmpty()) enabled
            else enabled.mapNotNull { provider ->
                // Typing a provider's name keeps everything it serves; typing a
                // model name narrows each provider to its matches.
                if (provider.label.contains(needle, ignoreCase = true)) provider
                else {
                    val models = provider.models.filter {
                        it.id.contains(needle, ignoreCase = true) ||
                            it.label.contains(needle, ignoreCase = true)
                    }
                    if (models.isEmpty()) null else provider.copy(models = models)
                }
            }
        }
        val rows = remember(shown) {
            buildList {
                shown.forEach { provider ->
                    add(PickerRow.Group(provider))
                    provider.models.forEach { model -> add(PickerRow.Entry(provider, model)) }
                }
            }
        }

        if (searchable) {
            VSpace(SiriusSpacing.xs)
            SiriusTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = stringResource(R.string.providers_model_search),
                leadingIcon = Icons.Rounded.Search,
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (shown.isEmpty() && enabled.isNotEmpty()) {
            VSpace(SiriusSpacing.xs)
            Text(
                text = stringResource(R.string.providers_model_no_match, query.trim()),
                style = MaterialTheme.typography.bodySmall,
                color = colors.warning
            )
        }

        val listState = rememberLazyListState()
        val screenHeight = LocalConfiguration.current.screenHeightDp.dp
        val listMaxHeight = (screenHeight * LIST_HEIGHT_FRACTION).coerceIn(200.dp, 440.dp)

        // Opening the picker on a gateway with 200 models used to land at the top
        // of the alphabet, several screens away from the model actually in use.
        // Only on first composition and only when unfiltered, so it never fights
        // the user's own scrolling or a search.
        LaunchedEffect(rows.size) {
            if (query.isNotEmpty()) return@LaunchedEffect
            val index = rows.indexOfFirst {
                it is PickerRow.Entry && it.provider.id == activeProviderId && it.model.id == activeModel
            }
            // Leave the first screenful alone: scrolling by two rows to "reveal"
            // something already visible only looks like a glitch.
            if (index > 3) listState.scrollToItem(index - 2)
        }

        if (rows.isNotEmpty()) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = listMaxHeight)
                    .sheetDragGuard(),
                contentPadding = PaddingValues(vertical = SiriusSpacing.xxs),
                verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
            ) {
                items(
                    count = rows.size,
                    key = { index -> rows[index].key },
                    contentType = { index -> rows[index] is PickerRow.Group }
                ) { index ->
                    when (val row = rows[index]) {
                        is PickerRow.Group -> ProviderGroupHeader(provider = row.provider)
                        is PickerRow.Entry -> ModelChoiceRow(
                            model = row.model,
                            selected = row.provider.id == activeProviderId &&
                                row.model.id == activeModel,
                            onClick = { onSelect(row.provider.id, row.model.id) }
                        )
                    }
                }
            }
        }
        if (onOpenPower != null) {
            Spacer(Modifier.size(SiriusSpacing.xs))
            // Directly under the model list because the two belong together: the
            // mode is stored against this exact pair, and the row shows what the
            // pair is on without opening anything.
            SheetActionRow(
                icon = Icons.Rounded.Bolt,
                label = stringResource(R.string.chat_power_title),
                supporting = if (powerSupported) {
                    stringResource(powerLabelRes(powerMode))
                } else {
                    stringResource(R.string.chat_power_unsupported_short)
                },
                onClick = onOpenPower,
                trailing = { PowerLevelBars(mode = powerMode, active = powerSupported) }
            )
        }
        Spacer(Modifier.size(SiriusSpacing.sm))
        SiriusGhostButton(
            text = stringResource(R.string.chat_manage_providers),
            onClick = onManageProviders,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun ProviderGroupHeader(provider: ProviderConfig) {
    val colors = SiriusTheme.colors
    Row(
        modifier = Modifier.padding(top = SiriusSpacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Same mark as the providers screen, so the two lists read as the same
        // set of endpoints.
        ProviderAvatar(provider = provider, size = 24.dp)
        Spacer(Modifier.width(SiriusSpacing.xs))
        Text(
            text = provider.displayLabel(),
            style = MaterialTheme.typography.labelLarge,
            color = colors.textSecondary
        )
        Spacer(Modifier.width(6.dp))
        // A loopback or LAN endpoint needs no key at all, so warning about a
        // missing one would be a badge the user can never clear.
        if (provider.requiresApiKey && !provider.hasKey) {
            Icon(
                Icons.Rounded.Key,
                contentDescription = stringResource(R.string.chat_no_api_key),
                tint = colors.warning,
                modifier = Modifier.size(13.dp)
            )
        }
    }
}

@Composable
private fun ModelChoiceRow(
    model: AiModel,
    selected: Boolean,
    onClick: () -> Unit
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .softSurface(RoundedCornerShape(SiriusRadius.md))
            // This is a single-choice list, so the rows have to say so: the tick
            // alone left the current model unannounced.
            .clickable(role = Role.RadioButton, onClick = onClick)
            .semantics(mergeDescendants = true) { this.selected = selected }
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = model.label,
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary
            )
            if (model.contextWindow > 0) {
                Text(
                    text = stringResource(
                        R.string.chat_context_window,
                        model.contextWindow / 1000
                    ),
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary
                )
            }
        }
        if (selected) {
            Icon(
                Icons.Rounded.CheckCircle,
                contentDescription = null,
                tint = colors.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
