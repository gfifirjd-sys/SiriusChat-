package com.sirius.chat.feature.chat.components

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.domain.model.ToolRun

/**
 * One page the answer above was built from.
 *
 * @property opened whether the page was actually fetched and read, as opposed to
 *   merely appearing in a result list. This is the distinction the whole feature
 *   exists for -- a search hit is a claim, a fetched page is evidence -- so it is
 *   part of the model rather than a rendering detail.
 */
data class MessageSource(
    val url: String,
    val title: String,
    val opened: Boolean
) {
    /**
     * The bare domain, for when a result has no usable title.
     *
     * `www.` is dropped because it is never the information the reader wants and
     * it costs four characters in a row that is already tight on a phone.
     */
    val host: String
        get() = url
            .substringAfter("://", url)
            .substringBefore('/')
            .removePrefix("www.")
            .ifBlank { url }
}

/**
 * Reconstructs the source list from the tool runs already stored on a message.
 *
 * ### Why this parses text instead of reading structured data
 * The alternative is a schema change: give `ToolRun` a typed `sources` field,
 * migrate the messages table, and write it from the web tools. That is the right
 * design if this were being built from scratch, and it is the wrong one to reach
 * for here -- every conversation already on the user's phone would show no
 * sources, because the data was never captured. Parsing the output means the
 * button works on history from builds that predate it, with no migration and no
 * risk to the transcript.
 *
 * The formats are produced by [com.sirius.chat.ai.agent.tools.WebSearchTool] and
 * `OpenUrlTool` in this same codebase, so this is not screen-scraping a third
 * party: if those change, this changes with them, and the failure mode is an
 * absent button rather than a wrong one.
 *
 * ### Why opened pages sort first
 * They are the strongest evidence the answer is grounded. A model that searched
 * and then read two pages did the work; a model that searched and read nothing
 * produced an answer from titles and snippets, and the ordering makes that
 * visible without a word of explanation.
 */
fun sourcesFrom(runs: List<ToolRun>): List<MessageSource> {
    if (runs.isEmpty()) return emptyList()

    // Insertion-ordered so the list reads in the order the model worked, and
    // keyed by a normalised url so the same page found twice is one row.
    val collected = LinkedHashMap<String, MessageSource>()

    runs.forEach { run ->
        // A failed run's output is an error message, not a result list.
        if (!run.success) return@forEach
        when (run.toolName) {
            "web_search" -> parseSearchResults(run.output).forEach { collect(collected, it) }
            "open_url" -> parseOpenedPage(run.output)?.let { collect(collected, it) }
        }
    }

    // Stable sort: opened first, discovery order preserved inside each group.
    return collected.values.sortedByDescending { it.opened }
}

/**
 * The button, and the list it opens.
 *
 * ### Why it is collapsed by default
 * The answer is the content. Six links between the answer and whatever the user
 * scrolls to next would make every searched reply twice as long to get past, and
 * most of the time the user believes the answer and moves on. Collapsed, it costs
 * one line and still does the important half of its job: it says a search
 * happened and how much was found, which is exactly what a user who suspects the
 * model ignored the internet wants to know.
 *
 * ### Why not just trust the links in the prose
 * The model cites what it chooses to cite, from memory of what it read, and it
 * can cite a page it never opened. This list is assembled from what the tools
 * actually did. When the two disagree, that disagreement is the useful signal.
 */
@Composable
fun MessageSources(
    sources: List<MessageSource>,
    modifier: Modifier = Modifier
) {
    if (sources.isEmpty()) return

    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    // Keyed on the list so a recycled bubble in the transcript does not inherit
    // the expanded state of whatever message was in that slot before.
    var expanded by remember(sources) { mutableStateOf(false) }
    val chevron by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = siriusTween(SiriusMotion.Quick, SiriusMotion.Standard),
        label = "sourcesChevron"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
    ) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(SiriusRadius.pill))
                .softSurface(RoundedCornerShape(SiriusRadius.pill))
                .clickable(role = Role.Button) {
                    haptics.light()
                    expanded = !expanded
                }
                .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xxs),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
        ) {
            Icon(
                imageVector = Icons.Rounded.Link,
                contentDescription = null,
                tint = colors.textSecondary,
                modifier = Modifier.size(IconSize)
            )
            Text(
                text = stringResource(R.string.chat_sources, sources.size),
                style = MaterialTheme.typography.labelMedium,
                color = colors.textSecondary
            )
            Icon(
                imageVector = Icons.Rounded.ExpandMore,
                contentDescription = null,
                tint = colors.textTertiary,
                modifier = Modifier
                    .size(IconSize)
                    .graphicsLayer { rotationZ = chevron }
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(siriusTween(SiriusMotion.Quick, SiriusMotion.Standard)) +
                expandVertically(siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)),
            exit = fadeOut(siriusTween(SiriusMotion.Instant, SiriusMotion.Exit)) +
                shrinkVertically(siriusTween(SiriusMotion.Quick, SiriusMotion.Exit))
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)) {
                sources.forEach { source ->
                    SourceRow(source)
                }
            }
        }
    }
}

/**
 * One tappable source.
 *
 * Opens in the system browser rather than an in-app view: the point of the list
 * is that the user can check the claim themselves, and that means their own
 * browser, with their own session, extensions and reading tools.
 */
@Composable
private fun SourceRow(source: MessageSource) {
    val colors = SiriusTheme.colors
    val context = LocalContext.current
    val haptics = rememberHaptics()
    val failedText = stringResource(R.string.chat_sources_open_failed)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.sm))
            .softSurface(RoundedCornerShape(SiriusRadius.sm), alpha = 0.7f)
            .clickable(role = Role.Button, onClickLabel = source.url) {
                haptics.light()
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(source.url))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                // A device with no browser is unusual and not impossible; an
                // unhandled ActivityNotFoundException here would take the whole
                // conversation down with it.
                runCatching { context.startActivity(intent) }.onFailure {
                    Toast.makeText(context, failedText, Toast.LENGTH_SHORT).show()
                }
            }
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
    ) {
        Column(
            modifier = Modifier.widthIn(max = RowTextWidth),
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            Text(
                // A search hit without a title is rare; falling back to the host
                // keeps the row identifiable instead of showing an empty line.
                text = source.title.ifBlank { source.host },
                style = MaterialTheme.typography.bodySmall,
                color = colors.textPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
            ) {
                Text(
                    text = source.host,
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (source.opened) {
                    // The badge is the verifiable part: this page was fetched and
                    // its text went into the prompt.
                    Text(
                        text = stringResource(R.string.chat_sources_opened),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.success,
                        maxLines = 1
                    )
                }
            }
        }
        Icon(
            imageVector = Icons.Rounded.OpenInNew,
            contentDescription = null,
            tint = colors.textTertiary,
            modifier = Modifier.size(IconSize)
        )
    }
}

/**
 * Pulls `N. title` / `   url` pairs out of a search result block.
 *
 * The url line is indented by exactly the three spaces the tool writes, which is
 * what separates it from a url that happens to appear inside a snippet -- those
 * are the model's business, not a source we can claim was consulted.
 */
private fun parseSearchResults(output: String): List<MessageSource> {
    val found = mutableListOf<MessageSource>()
    var pendingTitle = ""
    output.lineSequence().forEach { line ->
        val trimmed = line.trim()
        when {
            TITLE_LINE.matches(trimmed) -> pendingTitle = trimmed.substringAfter(". ").trim()
            line.startsWith(URL_INDENT) && trimmed.startsWith("http") -> {
                found += MessageSource(
                    url = tidy(trimmed),
                    title = pendingTitle,
                    opened = false
                )
                // Consumed: the snippet lines that follow belong to no new title.
                pendingTitle = ""
            }
        }
    }
    return found
}

/**
 * Reads the header line a page fetch writes: `url` optionally followed by
 * ` — title`.
 */
private fun parseOpenedPage(output: String): MessageSource? {
    val header = output.lineSequence().firstOrNull()?.trim().orEmpty()
    if (!header.startsWith("http")) return null
    val url = header.substringBefore(TITLE_SEPARATOR).trim()
    val title = header.substringAfter(TITLE_SEPARATOR, "").trim()
    if (url.isEmpty()) return null
    return MessageSource(url = tidy(url), title = title, opened = true)
}

/**
 * Merges a find into the collected set.
 *
 * Deduplication is by url without its trailing slash, because a page found in a
 * result list and then opened arrives twice in two spellings, and showing it
 * twice would undercount nothing and overstate the work done. The merged row
 * keeps [MessageSource.opened] if either copy had it, and the first non-blank
 * title -- a search result's title is usually better written than the `<title>`
 * tag a fetch reports.
 */
private fun collect(into: LinkedHashMap<String, MessageSource>, source: MessageSource) {
    val key = source.url.trimEnd('/')
    val existing = into[key]
    into[key] = if (existing == null) {
        source
    } else {
        existing.copy(
            title = existing.title.ifBlank { source.title },
            opened = existing.opened || source.opened
        )
    }
}

/** Drops sentence punctuation a url picked up from the surrounding text. */
private fun tidy(url: String): String = url.trimEnd('.', ',', ';', ')', ']', '"')

private val TITLE_LINE = Regex("""^\d{1,3}\. .+""")
private const val URL_INDENT = "   "
private const val TITLE_SEPARATOR = " \u2014 "
private val IconSize = 14.dp
private val RowTextWidth = 240.dp
