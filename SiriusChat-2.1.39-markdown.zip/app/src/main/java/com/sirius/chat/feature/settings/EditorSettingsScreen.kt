package com.sirius.chat.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.WrapText
import androidx.compose.material.icons.rounded.FormatListNumbered
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.revealIn
import com.sirius.chat.core.designsystem.siriusContentSize
import com.sirius.chat.core.ui.siriusViewModel

@Composable
fun EditorSettingsScreen(
    onBack: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: SettingsViewModel = siriusViewModel { SettingsViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val settings = state.settings
    val colors = SiriusTheme.colors

    val scroll = rememberScrollState()
    // The bar only earns its seam once there is content hidden behind it.
    val scrolled by remember { derivedStateOf { scroll.value > 4 } }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.editor_title),
            subtitle = stringResource(R.string.editor_settings_subtitle),
            scrolled = scrolled,
            onBack = onBack
        )
        Column(
            modifier = Modifier
                .verticalScroll(scroll)
                .padding(
                    start = SiriusSpacing.sm,
                    end = SiriusSpacing.sm,
                    top = SiriusSpacing.xs,
                    bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
                )
        ) {
            GlassCard(modifier = Modifier.revealIn(index = 0)) {
                SliderRow(
                    label = stringResource(R.string.editor_font_size),
                    value = settings.editorFontSize.toFloat(),
                    valueLabel = stringResource(
                        R.string.editor_font_size_value,
                        settings.editorFontSize
                    ),
                    range = 10f..24f,
                    // Both values are whole numbers, so the handle stops on them
                    // instead of sliding between stops that round to the same size.
                    steps = FONT_SIZE_STEPS,
                    onChange = { viewModel.setEditorFontSize(it.toInt()) }
                )
                SliderRow(
                    label = stringResource(R.string.editor_tab_size),
                    value = settings.editorTabSize.toFloat(),
                    valueLabel = settings.editorTabSize.toString(),
                    range = 2f..8f,
                    steps = TAB_SIZE_STEPS,
                    onChange = { viewModel.setEditorTabSize(it.toInt()) }
                )
                SettingToggle(
                    icon = Icons.AutoMirrored.Rounded.WrapText,
                    title = stringResource(R.string.editor_word_wrap),
                    subtitle = stringResource(R.string.editor_word_wrap_subtitle),
                    checked = settings.editorWordWrap,
                    onCheckedChange = viewModel::setWordWrap
                )
                SettingToggle(
                    icon = Icons.Rounded.FormatListNumbered,
                    title = stringResource(R.string.editor_line_numbers),
                    subtitle = stringResource(R.string.editor_line_numbers_subtitle),
                    checked = settings.editorLineNumbers,
                    onCheckedChange = viewModel::setLineNumbers
                )
                SettingToggle(
                    icon = Icons.Rounded.Save,
                    title = stringResource(R.string.editor_auto_save),
                    subtitle = stringResource(R.string.editor_auto_save_subtitle),
                    checked = settings.editorAutoSave,
                    onCheckedChange = viewModel::setAutoSave
                )
            }
            VSpace(SiriusSpacing.sm)
            GlassCard(modifier = Modifier.revealIn(index = 1)) {
                Text(
                    text = stringResource(R.string.editor_preview),
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textPrimary
                )
                VSpace(SiriusSpacing.xs)
                CodePreview(
                    fontSize = settings.editorFontSize,
                    tabSize = settings.editorTabSize,
                    wordWrap = settings.editorWordWrap,
                    lineNumbers = settings.editorLineNumbers
                )
            }
        }
    }
}

/**
 * The sample the sliders and toggles are judged against.
 *
 * Every control on this screen changes something here — indentation width, wrap
 * behaviour, the gutter — so the card is a real editor viewport in miniature
 * rather than a fixed snippet that only reacted to font size. The sample line is
 * deliberately long enough to wrap on a narrow phone.
 */
@Composable
private fun CodePreview(
    fontSize: Int,
    tabSize: Int,
    wordWrap: Boolean,
    lineNumbers: Boolean
) {
    val colors = SiriusTheme.colors
    val style = codeTextStyle(fontSize)
    val code = remember(tabSize) {
        val indent = " ".repeat(tabSize)
        listOf(
            "fun main() {",
            "${indent}val greeting = \"Sirius\" // long enough to show how wrapping behaves",
            "${indent}println(greeting)",
            "}"
        )
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            // Dragging the font-size slider changes this box's height on almost
            // every step. Without this the card snaps to a new height per tick
            // and the whole screen below it stutters; with it the preview grows
            // under your thumb, which is also what makes the slider feel
            // connected to the thing it edits.
            .siriusContentSize()
            .clip(RoundedCornerShape(SiriusRadius.sm))
            .background(colors.codeBackground)
            .padding(SiriusSpacing.xs)
    ) {
        code.forEachIndexed { index, line ->
            // The gutter is per logical line rather than a separate column, so a
            // wrapped line keeps its number next to its first row.
            Row(verticalAlignment = Alignment.Top) {
                if (lineNumbers) {
                    Text(
                        text = (index + 1).toString(),
                        style = style,
                        color = colors.codeComment,
                        maxLines = 1
                    )
                    Spacer(Modifier.width(SiriusSpacing.xs))
                }
                Text(
                    text = line,
                    style = style,
                    color = colors.codePlain,
                    softWrap = wordWrap,
                    // With wrap off the editor clips instead of reflowing, so the
                    // preview clips too.
                    maxLines = if (wordWrap) Int.MAX_VALUE else 1,
                    overflow = TextOverflow.Clip,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/** 10sp…24sp in whole steps. */
private const val FONT_SIZE_STEPS = 13

/** 2…8 spaces in whole steps. */
private const val TAB_SIZE_STEPS = 5
