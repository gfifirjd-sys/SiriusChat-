package com.sirius.chat.data.web

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.view.View
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.sirius.chat.core.common.AppDispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Bytes that arrived from a link, with the name and type they arrived as.
 *
 * A plain class rather than a `data class`: the payload is a [ByteArray], and
 * generated `equals`/`hashCode` over an array compare identities while looking
 * like they compare contents.
 */
class RemoteFile(
    val name: String,
    val mime: String,
    val bytes: ByteArray
) {
    val isImage: Boolean get() = mime.startsWith("image/") && !mime.contains("svg")

    /** True when the bytes can be shown as text instead of only downloaded. */
    val isText: Boolean
        get() = mime.startsWith("text/") || TEXTUAL.any { mime.contains(it) }

    private companion object {
        val TEXTUAL = listOf(
            "json", "javascript", "xml", "csv", "yaml", "x-sh", "markdown", "svg"
        )
    }
}

/**
 * The two things the app can do with a URL beyond reading its text: fetch what
 * it points at, and photograph it.
 *
 * ### Why a screenshot at all
 * `open_url` already returns a page as text, and for a changelog that is the
 * right answer. It is the wrong answer for "does this look right", for a chart,
 * for a rendered design, or for any page that is a JavaScript app and has almost
 * no text in the HTML at all — those come back empty today. A picture answers all
 * of them, and it is the one thing a phone can do that a text fetch cannot.
 *
 * ### Why WebView and not a service
 * Rendering elsewhere means shipping the URL, and often the user's cookies for
 * it, to somebody else's server. The engine that draws the page here is the one
 * already installed on the device, the request comes from the user's own IP, and
 * nothing leaves the phone. It costs a main-thread render and roughly a second,
 * which is a fair price for that.
 *
 * ### Why the download is capped
 * A link can point at a 4 GB disk image. The cap is checked while reading rather
 * than trusted from `Content-Length`, because the header is optional and a server
 * that lies about it would otherwise fill the heap before anyone noticed.
 */
class WebCaptureService(
    private val context: Context,
    private val dispatchers: AppDispatchers
) {

    /**
     * Fetches whatever a link points at.
     *
     * @throws IOException on a non-2xx status, a broken host, or a body larger
     * than [maxBytes]. Callers are UI click handlers and tools, both of which
     * turn the message into one line for the user.
     */
    suspend fun download(url: String, maxBytes: Int = MAX_DOWNLOAD_BYTES): RemoteFile =
        withContext(dispatchers.io) {
            val address = normalise(url)
            val connection = (URL(address).openConnection() as HttpURLConnection).apply {
                connectTimeout = CONNECT_MS
                readTimeout = READ_MS
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", USER_AGENT)
                setRequestProperty("Accept", "*/*")
            }
            try {
                val status = connection.responseCode
                if (status !in 200..299) throw IOException("HTTP $status")
                val mime = connection.contentType.orEmpty()
                    .substringBefore(';')
                    .trim()
                    .lowercase(Locale.ROOT)
                val bytes = connection.inputStream.use { stream -> read(stream, maxBytes) }
                RemoteFile(
                    name = nameFor(address, connection.getHeaderField("Content-Disposition"), mime),
                    mime = mime.ifBlank { "application/octet-stream" },
                    bytes = bytes
                )
            } finally {
                connection.disconnect()
            }
        }

    /**
     * Renders a page and returns it as PNG bytes, or null if it never loaded.
     *
     * Runs on the main thread because a [WebView] cannot be created anywhere
     * else, and is destroyed in a `finally` because a leaked one keeps a whole
     * rendering process alive.
     */
    @SuppressLint("SetJavaScriptEnabled")
    suspend fun screenshot(url: String, fullPage: Boolean = true): ByteArray? =
        withContext(dispatchers.main) {
            val address = normalise(url)
            val web = WebView(context)
            try {
                web.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    blockNetworkImage = false
                    userAgentString = USER_AGENT
                }
                web.setBackgroundColor(Color.WHITE)
                // Laid out before loading so the page sees a phone-width viewport
                // and picks its mobile layout, instead of rendering desktop-wide
                // and being photographed at 20% scale.
                layoutAt(web, VIEWPORT_HEIGHT_PX)

                val loaded = withTimeoutOrNull(LOAD_TIMEOUT_MS) {
                    suspendCancellableCoroutine { continuation ->
                        web.webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView, finishedUrl: String) {
                                // Fires again for in-page navigations; only the
                                // first one may resume a continuation.
                                if (continuation.isActive) continuation.resumeWith(Result.success(true))
                            }

                            override fun onReceivedError(
                                view: WebView,
                                request: WebResourceRequest,
                                error: WebResourceError
                            ) {
                                // Sub-resource failures are normal on a real page
                                // — a missing font is not a failed screenshot.
                                if (request.isForMainFrame && continuation.isActive) {
                                    continuation.resumeWith(Result.success(false))
                                }
                            }
                        }
                        web.loadUrl(address)
                        continuation.invokeOnCancellation { web.stopLoading() }
                    }
                } ?: false

                if (!loaded) return@withContext null
                // Layout finishes after onPageFinished, and web fonts land after
                // that. Photographing immediately catches a blank white page.
                delay(SETTLE_MS)

                @Suppress("DEPRECATION")
                val contentPx = (web.contentHeight * web.scale).toInt()
                val height = if (fullPage) {
                    contentPx.coerceIn(VIEWPORT_HEIGHT_PX, MAX_HEIGHT_PX)
                } else {
                    VIEWPORT_HEIGHT_PX
                }
                layoutAt(web, height)

                val bitmap = Bitmap.createBitmap(WIDTH_PX, height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                // Pages with a transparent body would otherwise come out black.
                canvas.drawColor(Color.WHITE)
                web.draw(canvas)
                val out = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.PNG, PNG_QUALITY, out)
                bitmap.recycle()
                out.toByteArray()
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Throwable) {
                null
            } finally {
                web.stopLoading()
                web.destroy()
            }
        }

    private fun layoutAt(web: WebView, height: Int) {
        web.measure(
            View.MeasureSpec.makeMeasureSpec(WIDTH_PX, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY)
        )
        web.layout(0, 0, WIDTH_PX, height)
    }

    private fun read(stream: InputStream, cap: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(BUFFER_BYTES)
        while (true) {
            val count = stream.read(buffer)
            if (count < 0) break
            out.write(buffer, 0, count)
            if (out.size() > cap) {
                throw IOException("file is larger than ${cap / (1024 * 1024)} MB")
            }
        }
        return out.toByteArray()
    }

    /** A model writes `example.com/logo.png` as often as it writes the scheme. */
    private fun normalise(url: String): String {
        val trimmed = url.trim()
        return if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            trimmed
        } else {
            "https://" + trimmed.removePrefix("//")
        }
    }

    private fun nameFor(url: String, disposition: String?, mime: String): String {
        val fromHeader = disposition
            ?.substringAfter("filename=", "")
            ?.trim('"', ' ', ';')
            ?.takeIf { it.isNotBlank() && !it.startsWith("UTF-8") }
        if (fromHeader != null) return fromHeader
        val path = runCatching { URL(url).path }.getOrNull().orEmpty()
        val tail = path.substringAfterLast('/').substringBefore('?')
        if (tail.isNotBlank() && tail.contains('.')) return tail
        val host = runCatching { URL(url).host }.getOrNull().orEmpty().ifBlank { "page" }
        return host.replace('.', '-') + extensionFor(mime)
    }

    private fun extensionFor(mime: String): String = when {
        mime.contains("html") -> ".html"
        mime.contains("json") -> ".json"
        mime.contains("png") -> ".png"
        mime.contains("jpeg") -> ".jpg"
        mime.contains("webp") -> ".webp"
        mime.contains("gif") -> ".gif"
        mime.contains("pdf") -> ".pdf"
        mime.contains("zip") -> ".zip"
        mime.startsWith("text/") -> ".txt"
        else -> ".bin"
    }

    private companion object {
        const val MAX_DOWNLOAD_BYTES = 24 * 1024 * 1024
        const val BUFFER_BYTES = 16 * 1024
        const val CONNECT_MS = 15_000
        const val READ_MS = 30_000
        const val LOAD_TIMEOUT_MS = 25_000L
        const val SETTLE_MS = 700L
        const val WIDTH_PX = 1080
        const val VIEWPORT_HEIGHT_PX = 1920

        /**
         * Roughly 12 phone screens. A long article renders to a strip nobody can
         * read anyway, and an uncapped height is an OutOfMemoryError waiting for
         * the first infinite-scroll feed.
         */
        const val MAX_HEIGHT_PX = 24_000
        const val PNG_QUALITY = 100
        const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/120.0 Mobile Safari/537.36"
    }
}
