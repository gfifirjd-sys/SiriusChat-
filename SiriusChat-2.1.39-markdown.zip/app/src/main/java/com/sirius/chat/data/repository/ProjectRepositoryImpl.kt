package com.sirius.chat.data.repository

import com.sirius.chat.core.common.AppDispatchers
import com.sirius.chat.core.util.WorkspaceNames
import com.sirius.chat.data.local.db.dao.ProjectDao
import com.sirius.chat.data.local.db.entity.ProjectEntity
import com.sirius.chat.data.local.db.entity.RecentFileEntity
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.RecentFile
import com.sirius.chat.domain.repository.ProjectRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ProjectRepositoryImpl(
    private val dao: ProjectDao,
    private val dispatchers: AppDispatchers
) : ProjectRepository {

    override fun observeProjects(): Flow<List<Project>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun observeProject(id: String): Flow<Project?> =
        dao.observeById(id).map { it?.toDomain() }

    override fun observeRecentFiles(projectId: String, limit: Int): Flow<List<RecentFile>> =
        dao.observeRecentFiles(projectId, limit).map { list -> list.map { it.toDomain() } }

    override suspend fun get(id: String): Project? = withContext(dispatchers.io) {
        dao.getById(id)?.toDomain()
    }

    override suspend fun upsert(project: Project) = withContext(dispatchers.io) {
        dao.upsert(project.toEntity())
    }

    override suspend fun delete(id: String) = withContext(dispatchers.io) {
        dao.clearRecentFiles(id)
        dao.delete(id)
    }

    override suspend fun touch(id: String) = withContext(dispatchers.io) {
        repairEncodedName(id)
        dao.touch(id, System.currentTimeMillis())
    }

    /**
     * Rewrites a project name that is still percent-encoded from an older build.
     *
     * Opening the project is the only moment where the name is known to be wrong
     * and the row is being written anyway, so this costs one extra read on a
     * path that already touches the database. A project the user renamed by hand
     * is untouched, because a hand-typed name does not contain `%XX`.
     */
    private suspend fun repairEncodedName(id: String) {
        val project = dao.getById(id) ?: return
        if (!WorkspaceNames.looksEncoded(project.name)) return
        val repaired = project.workspaceLabel.ifBlank { WorkspaceNames.folderName(project.treeUri) }
        if (repaired.isBlank() || repaired == project.name) return
        dao.upsert(project.copy(name = repaired))
    }

    override suspend fun setFavorite(id: String, favorite: Boolean) = withContext(dispatchers.io) {
        dao.setFavorite(id, favorite)
    }

    override suspend fun rememberFile(file: RecentFile) = withContext(dispatchers.io) {
        dao.upsertRecentFile(file.toEntity())
    }

    override suspend fun updateFilePosition(documentId: String, caretOffset: Int, scrollLine: Int) =
        withContext(dispatchers.io) { dao.updateFilePosition(documentId, caretOffset, scrollLine) }
}

/**
 * Display name for a row, with the percent-encoding repair applied.
 *
 * A hand-typed name never contains `%XX`, so a project the user genuinely
 * called "100% done" is left alone.
 */
private fun ProjectEntity.displayName(): String {
    if (!WorkspaceNames.looksEncoded(name)) return name
    return workspaceLabel
        .ifBlank { WorkspaceNames.folderName(treeUri) }
        .ifBlank { name }
}

private fun ProjectEntity.toDomain() = Project(
    id = id,
    // A row written by an older build can still hold a percent-encoded folder
    // name: picking `тест` stored `%D1%82%D0%B5%D1%81%D1%82`. repairEncodedName
    // rewrites the row, but it only runs from touch(), i.e. when the project is
    // opened -- so every other read (chat header, agent session subtitle,
    // project list) kept showing the ruined name until then. Resolving it here
    // fixes every read path at once; the row is still repaired on open.
    name = displayName(),
    description = description,
    treeUri = treeUri,
    workspaceLabel = workspaceLabel,
    providerId = providerId,
    model = model,
    accentIndex = accentIndex,
    favorite = favorite,
    createdAt = createdAt,
    lastOpenedAt = lastOpenedAt
)

private fun Project.toEntity() = ProjectEntity(
    id = id,
    name = name,
    description = description,
    treeUri = treeUri,
    workspaceLabel = workspaceLabel,
    providerId = providerId,
    model = model,
    accentIndex = accentIndex,
    favorite = favorite,
    createdAt = createdAt,
    lastOpenedAt = lastOpenedAt
)

private fun RecentFileEntity.toDomain() = RecentFile(
    documentId = documentId,
    projectId = projectId,
    name = name,
    path = path,
    openedAt = openedAt,
    caretOffset = caretOffset,
    scrollLine = scrollLine
)

private fun RecentFile.toEntity() = RecentFileEntity(
    documentId = documentId,
    projectId = projectId,
    name = name,
    path = path,
    openedAt = openedAt,
    caretOffset = caretOffset,
    scrollLine = scrollLine
)
