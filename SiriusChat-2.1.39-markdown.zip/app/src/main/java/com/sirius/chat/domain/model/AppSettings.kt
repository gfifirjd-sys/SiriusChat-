package com.sirius.chat.domain.model

enum class ThemeMode { System, Light, Dark }

/** How aggressive the liquid-glass layer is; lowest tier is the fastest. */
enum class GlassLevel { Off, Subtle, Full }

/**
 * UI language. [System] follows the device locale, the rest force one language
 * regardless of system settings. [tag] is a BCP-47 tag matching a `values-*`
 * resource folder; it is empty for [System].
 */
enum class AppLanguage(val tag: String) {
    System(""),
    English("en"),
    Russian("ru");

    companion object {
        fun ofTag(tag: String): AppLanguage =
            entries.firstOrNull { it.tag == tag } ?: System
    }
}

/**
 * Which engine the terminal runs commands with.
 *
 * [DeviceShell] always works but is confined to the app sandbox; [Termux] gives
 * up streaming output and process control in exchange for a real toolchain.
 */
enum class TerminalEngine { DeviceShell, Termux }

data class AppSettings(
    val language: AppLanguage = AppLanguage.System,
    val themeMode: ThemeMode = ThemeMode.System,
    /**
     * Interface accent as an ARGB int, or 0 for the monochrome default.
     *
     * This replaced the Material You switch. A wallpaper scheme could only ever
     * reach four palette slots, and which four was unpredictable; an explicit
     * colour lands on the same four, visibly and reproducibly.
     */
    val accentColor: Int = 0,
    val glassLevel: GlassLevel = GlassLevel.Full,
    val reduceMotion: Boolean = false,
    val hapticsEnabled: Boolean = true,
    val streamingEnabled: Boolean = true,
    val activeProviderId: String = "",
    val activeModel: String = "",
    val temperature: Float = 0.3f,
    val maxTokens: Int = 4096,
    val agentAutoApproveReads: Boolean = true,
    /**
     * Write agent proposals straight to disk instead of queueing them for review.
     *
     * Defaults to off, and stays off after an update, because it removes the only
     * checkpoint between a model's mistake and the user's files. Deletion is the
     * part that has no undo: SAF has no trash, so an auto-applied `delete_file`
     * is gone unless the folder happens to be a Git repository.
     */
    val agentAutoApplyChanges: Boolean = false,
    val agentMaxSteps: Int = 6,
    /**
     * Whether the agent is offered the shell tool at all.
     *
     * Global rather than per-chat, unlike the switches in [ChatFeatures]:
     * `run_command` is the only tool that can act outside the project folder, so
     * a user turning it off means "not from this app", not "not in this
     * conversation".
     *
     * On by default because without it the agent cannot check its own work -- it
     * writes a build file and never learns whether it compiles, which is how a
     * run ends with confident success the agent never observed. Off is the right
     * choice for someone who wants edits proposed and nothing executed.
     */
    val agentTerminalEnabled: Boolean = true,
    /**
     * What a *new* chat's internet switch starts as.
     *
     * Off by default, and that is a deliberate choice against convenience. A
     * search runs before the model answers, so it adds latency to every reply,
     * and it sends a query derived from the user's message to a third party. Both
     * are fine when asked for and both are surprising when they arrive by
     * default -- particularly on the local-model setups where users pick Ollama
     * precisely so nothing leaves the device.
     *
     * The switch is one tap away in the chat's own panel, which is the right cost
     * for something with those two properties.
     */
    val defaultWebSearch: Boolean = false,
    /**
     * What a new chat's image switch starts as.
     *
     * Off, because when the provider sells images this spends real money per
     * call, and a model that sees the tool available will reach for it on a
     * borderline request ("show me how this looks") that the user meant
     * rhetorically.
     */
    val defaultImageGeneration: Boolean = false,
    val editorFontSize: Int = 14,
    val editorTabSize: Int = 4,
    val editorWordWrap: Boolean = false,
    val editorLineNumbers: Boolean = true,
    val editorAutoSave: Boolean = false,
    val terminalFontSize: Int = 13,
    val terminalEngine: TerminalEngine = TerminalEngine.DeviceShell,
    /**
     * Whether the one-off Termux background-mode explanation has been read.
     *
     * Termux is a separate app: once Android stops it, RUN_COMMAND silently
     * stops producing results and the terminal looks broken rather than
     * throttled. The explanation is therefore shown once, the first time the
     * user picks the Termux engine, and never again.
     */
    val termuxBackgroundNoticeShown: Boolean = false,
    val activeProjectId: String = "",
    /** `owner/name` of the repository the GitHub screen is pointed at. */
    val githubRepo: String = "",
    val onboardingDone: Boolean = false,
    /**
     * Whether context management starts on in a newly created chat.
     *
     * A default, not a retroactive override: a conversation that has made its
     * own choice keeps it, so changing this cannot silently alter a chat the
     * user is reading. The chat's own switch is the one that turns the feature
     * off -- meter and folding together.
     */
    val showContextMeter: Boolean = true,
    /**
     * Whether new chats start with long-term memory switched on.
     *
     * A default for new conversations, exactly like [showContextMeter]: a chat
     * that has made its own choice keeps it. On by default because a memory
     * nobody knows about is a memory nobody benefits from -- and because the
     * chat's own switch, plus the memory screen, are both one tap away.
     */
    val memoryEnabled: Boolean = true,
    /**
     * Categories left switched on in the memory graph.
     *
     * Empty means "no filter", which is the same picture as every category
     * ticked -- and the only one that also colours a category that turns up
     * later. Stored here rather than in the screen because a filter the user set
     * is a decision, and a decision that dies when the panel closes is a bug.
     */
    val memoryFilters: Set<MemoryCategory> = emptySet(),
    /**
     * Whether the graph draws a label on every node.
     *
     * Null means "never chosen", which is what lets the default follow the
     * device: a label costs a text layout per visible node, so an undecided weak
     * phone starts without them and an undecided fast one starts with them. A
     * plain boolean would have to freeze that decision at first launch.
     */
    val memoryLabels: Boolean? = null,
    /** Whether the scene turns on its own until the viewer takes it over. */
    val memorySpin: Boolean = true,
    /** Whether stated links between two facts are drawn. */
    val memoryLinks: Boolean = true,
    /** Whether the fainter lines that group a file's facts are drawn. */
    val memoryTopics: Boolean = true,
    /**
     * Whether the app may post a notification when an answer is finished, when
     * the agent needs a decision, or when a run fails.
     *
     * Separate from the silent "working" status, which is a foreground-service
     * requirement rather than a choice: this switch covers the notifications
     * that actually arrive with a sound.
     */
    val notificationsEnabled: Boolean = true,
    /**
     * How much work the chat UI is allowed to do per frame.
     *
     * [PerformanceMode.Auto] asks the device, which is the right answer for
     * almost everyone. The manual options exist because detection is a
     * heuristic: a fast phone with a huge conversation open can want the cheap
     * path, and a user on a modest device may prefer the blur and keep the
     * stutter.
     */
    val performanceMode: PerformanceMode = PerformanceMode.Auto,
    /**
     * Answer power, stored per (endpoint, model) pair.
     *
     * Not one global value, because the same mode means different things on
     * different endpoints: HIGH is an effort tier on OpenAI, a 16k thinking
     * budget on Anthropic and a longer answer on a local model. A single global
     * setting would silently change meaning every time the model changed, and
     * the user would see a choice they never made.
     */
    val powerModes: Map<Pair<String, String>, PowerMode> = emptyMap(),
    /**
     * Hand-tuned power fields for the same pairs.
     *
     * Kept even while a preset mode is active, so stepping through the presets
     * and back does not throw away numbers the user typed.
     */
    val powerCustom: Map<Pair<String, String>, PowerConfig> = emptyMap()
)

/**
 * The three answers to "should this build cost less to draw".
 *
 * Kept as an enum rather than a boolean so that [Auto] is a real, stored state.
 * A boolean would have to be seeded from device detection at first launch, and
 * would then be indistinguishable from a choice the user made -- so a phone that
 * was correctly detected as slow could never be told "no, use the full UI", and
 * a later improvement to detection could never reach anyone.
 */
enum class PerformanceMode {
    /** Decide from the device: low RAM, small heap, few cores, or an old OS. */
    Auto,

    /** Always cheap: no entry animations, fewer redraws, plainer code blocks. */
    On,

    /** Always full quality, whatever the device reports. */
    Off;

    /**
     * The one question the rest of the app asks: should this run cheap?
     *
     * [weakDevice] is the detector's answer and is only consulted for [Auto], so
     * an explicit choice always wins over the heuristic.
     */
    fun economical(weakDevice: Boolean): Boolean = when (this) {
        Auto -> weakDevice
        On -> true
        Off -> false
    }
}
