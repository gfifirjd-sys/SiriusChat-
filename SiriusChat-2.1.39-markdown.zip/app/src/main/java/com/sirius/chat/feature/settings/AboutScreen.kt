package com.sirius.chat.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.HSpace
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.components.decorative
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.designsystem.revealIn

@Composable
fun AboutScreen(onBack: () -> Unit, contentPadding: PaddingValues) {
    val colors = SiriusTheme.colors
    val scroll = rememberScrollState()
    // The bar only earns its seam once there is content hidden behind it.
    val scrolled by remember { derivedStateOf { scroll.value > 4 } }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.about_title),
            subtitle = stringResource(R.string.settings_about_subtitle),
            scrolled = scrolled,
            onBack = onBack
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scroll)
                .padding(
                    start = SiriusSpacing.sm,
                    end = SiriusSpacing.sm,
                    top = SiriusSpacing.xs,
                    bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
                )
        ) {
            GlassCard(
                modifier = Modifier.revealIn(index = 0),
                contentPadding = SiriusSpacing.lg
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .softSurface(CircleShape)
                            .decorative(),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = colors.primary,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    HSpace(SiriusSpacing.sm)
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.headlineSmall,
                            color = colors.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            // The build, not a number typed into strings.xml that
                            // drifts the moment versionName changes.
                            text = stringResource(R.string.about_version, rememberVersionName()),
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textTertiary
                        )
                    }
                }
                VSpace(SiriusSpacing.md)
                Text(
                    text = stringResource(R.string.about_intro),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
            }

            VSpace(SiriusSpacing.sm)
            GlassCard(modifier = Modifier.revealIn(index = 1)) {
                AboutSectionTitle(stringResource(R.string.about_built_with))
                VSpace(SiriusSpacing.xs)
                TechChips()
            }

            VSpace(SiriusSpacing.sm)
            GlassCard(modifier = Modifier.revealIn(index = 2)) {
                AboutSectionTitle(stringResource(R.string.about_architecture))
                VSpace(SiriusSpacing.xs)
                AboutSectionBody(stringResource(R.string.about_architecture_body))
            }

            VSpace(SiriusSpacing.sm)
            GlassCard(modifier = Modifier.revealIn(index = 3)) {
                AboutSectionTitle(stringResource(R.string.about_terminal))
                VSpace(SiriusSpacing.xs)
                AboutSectionBody(stringResource(R.string.about_terminal_body))
            }
        }
    }
}

@Composable
private fun AboutSectionTitle(text: String) = Text(
    text = text,
    style = MaterialTheme.typography.titleSmall,
    color = SiriusTheme.colors.textPrimary
)

@Composable
private fun AboutSectionBody(text: String) = Text(
    text = text,
    style = MaterialTheme.typography.bodySmall,
    color = SiriusTheme.colors.textSecondary
)

/**
 * The stack, as chips that wrap.
 *
 * Two fixed rows clipped their last chip on a 360dp phone, so this is one
 * FlowRow that reflows instead of guessing how many labels fit per line.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TechChips() {
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        TECH_STACK.forEach { SiriusChip(text = it) }
    }
}

private val TECH_STACK = listOf(
    "Kotlin",
    "Compose",
    "Material 3",
    "JDK 17",
    "Room",
    "DataStore",
    "OkHttp",
    "SAF"
)

/**
 * Installed versionName, so debug builds show their `-debug` suffix honestly.
 *
 * `internal` rather than private because the settings header shows the same
 * value: a hardcoded string there had already drifted to "1.0" while the app
 * shipped 2.0.
 */
@Composable
internal fun rememberVersionName(): String {
    val context = LocalContext.current
    return remember(context) {
        runCatching {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull()?.takeIf { it.isNotBlank() } ?: "\u2014"
    }
}
