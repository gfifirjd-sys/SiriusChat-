package com.sirius.chat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.locale.ProvideAppLanguage
import com.sirius.chat.core.notify.AgentNotifier
import com.sirius.chat.core.ui.LocalAppContainer
import com.sirius.chat.feature.chat.components.LinkActionsHost
import com.sirius.chat.feature.chat.components.LocalGeneratedImageStore
import com.sirius.chat.domain.model.AppSettings

class MainActivity : ComponentActivity() {

    private val container by lazy { (application as SiriusApplication).container }

    /**
     * Chat asked for by a tapped notification, cleared as soon as it is opened.
     *
     * Snapshot state rather than a plain field: the value arrives from
     * `onNewIntent`, which runs outside composition, and the navigation that
     * acts on it lives inside it.
     */
    private val pendingSession = mutableStateOf<String?>(null)

    /**
     * Registered here rather than at the call site because a result launcher has
     * to exist before the activity is STARTED; creating one lazily throws.
     * The result is ignored on purpose -- a refusal is a valid answer, and every
     * notification path already checks the permission before posting.
     */
    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        pendingSession.value = intent?.getStringExtra(AgentNotifier.EXTRA_SESSION_ID)
        requestNotifications()

        // Keep the splash up only until the first settings emission is ready,
        // which avoids a theme flash without adding a fixed artificial delay.
        var settingsLoaded = false
        splash.setKeepOnScreenCondition { !settingsLoaded }

        setContent {
            val settings: AppSettings? by container.settingsRepository.settings
                .collectAsStateWithLifecycle(initialValue = null)
            val loaded = settings
            val openSession by pendingSession

            if (loaded != null) {
                SideEffect { settingsLoaded = true }
                CompositionLocalProvider(
                    LocalAppContainer provides container,
                    // Needed by the markdown renderer deep inside the transcript.
                    // See LocalGeneratedImageStore for why it is ambient rather
                    // than threaded through four layers of composable.
                    LocalGeneratedImageStore provides container.generatedImages
                ) {
                    // Language wraps the theme so every screen below, including
                    // dialogs and sheets, reads strings in the chosen locale.
                    ProvideAppLanguage(language = loaded.language) {
                        // One decision, taken once, for the whole UI: is this
                        // device (or this user) asking for the cheap path?
                        //
                        // Applied here rather than screen by screen because both
                        // of the expensive things are already theme-wide. Glass is
                        // a blur behind every card, which is the single most
                        // costly effect on an old GPU, and reduceMotion is what
                        // every animation in the app already checks. Setting them
                        // at the root is a two-line change that reaches code that
                        // has not been written yet.
                        val economical = loaded.performanceMode.economical(container.weakDevice)
                        SiriusTheme(
                            themeMode = loaded.themeMode,
                            accentColor = loaded.accentColor,
                            glassLevel = if (economical) {
                                com.sirius.chat.domain.model.GlassLevel.Off
                            } else {
                                loaded.glassLevel
                            },
                            reduceMotion = loaded.reduceMotion || economical
                        ) {
                            // Above every screen rather than inside the chat: a
                            // link is a link whether it is in an answer, a note
                            // or a preview, and the sheet has to outlive the
                            // composable that was tapped so a download it starts
                            // is not cancelled by its own dismissal.
                            LinkActionsHost {
                                SiriusApp(
                                    startWithOnboarding = !loaded.onboardingDone,
                                    openSessionId = openSession,
                                    onSessionOpened = { pendingSession.value = null }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * A notification tapped while this activity is already on top arrives here
     * instead of through [onCreate], so both paths have to read the extra or
     * half the taps would open the app on whatever screen it was left on.
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingSession.value = intent.getStringExtra(AgentNotifier.EXTRA_SESSION_ID)
    }

    override fun onStart() {
        super.onStart()
        // Nothing is posted while the app is on screen: the chat already shows
        // the answer and the question sheet.
        container.notifier.appVisible = true
    }

    override fun onStop() {
        container.notifier.appVisible = false
        super.onStop()
    }

    /**
     * Android 13 made notifications a runtime permission, and without it every
     * post is a silent no-op -- including the foreground-service status that
     * keeps a long answer alive. Asked once at startup; Android itself stops
     * showing the dialog after the user has refused twice, so there is no need
     * to remember the answer here.
     */
    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        val granted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) return
        runCatching { askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS) }
    }
}
