package com.sirius.chat.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.ai.discovery.LocalServer
import com.sirius.chat.ai.discovery.LocalServerScanner
import com.sirius.chat.ai.provider.ModelQuirks
import com.sirius.chat.ai.provider.ProbeResult
import com.sirius.chat.ai.provider.ProviderProbe
import com.sirius.chat.core.designsystem.components.deleteProviderIcon
import com.sirius.chat.core.locale.displayLabel
import com.sirius.chat.data.local.preferences.ProviderPreset
import com.sirius.chat.data.local.preferences.ProviderPresets
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.ProbeVerdict
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import com.sirius.chat.domain.model.VisionSupport
import com.sirius.chat.domain.model.requiresApiKey
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class ProviderEditor(
    val id: String? = null,
    val label: String = "",
    /** Set for shipped templates whose name is a string resource. */
    val labelKey: String? = null,
    val baseUrl: String = "",
    val type: ProviderType = ProviderType.OpenAiCompatible,
    val models: String = "",
    val apiKey: String = "",
    val builtIn: Boolean = false,
    /** Key of a built-in mark; ignored while [iconImagePath] is set. */
    val iconKey: String? = null,
    /** Path to an image copied out of the gallery, or `null` for a built-in mark. */
    val iconImagePath: String? = null,
    /**
     * The image the provider already had when the sheet opened. Kept so a
     * cancelled edit never deletes a file the saved provider still points at.
     */
    val savedIconImagePath: String? = null
) {
    /**
     * The models field parsed into ids.
     *
     * The field stays free text so anyone can paste an id no endpoint advertises,
     * while the picker needs the same list as a set to mark what is already in.
     */
    fun modelIds(): List<String> = models
        .split(',', '\n')
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()
}

/**
 * Outcome of the last connection check, shown inside the editor sheet.
 *
 * Kept separate from [ProviderEditor] because it is not something the user typed
 * and must never be written back to the provider on save.
 */
sealed interface ProbeState {
    data object Idle : ProbeState
    data object Running : ProbeState

    /**
     * The endpoint answered. [models] is its own catalogue, which the user picks
     * from; an empty list still means the key and URL work.
     */
    data class Success(val models: List<AiModel>, val message: String) : ProbeState

    data class Failure(val message: String) : ProbeState
}

/**
 * Where the local-network sweep is up to.
 *
 * [Done] with an empty list is a real, common outcome -- mobile data, or a guest
 * network that isolates clients -- and has to be distinguishable from [Idle], or
 * the screen cannot tell "nothing found" from "never looked".
 */
sealed interface DiscoveryState {
    data object Idle : DiscoveryState
    data object Scanning : DiscoveryState
    data class Done(val servers: List<LocalServer>) : DiscoveryState
}

data class ProvidersUiState(
    /** Exactly what the user added; nothing is here that they did not choose. */
    val providers: List<ProviderConfig> = emptyList(),
    /** Presets not yet added, offered in the catalogue sheet. */
    val catalog: List<ProviderPreset> = emptyList(),
    /** `true` while the catalogue sheet is open. */
    val catalogOpen: Boolean = false,
    val settings: AppSettings = AppSettings(),
    val editor: ProviderEditor? = null,
    /** Result of the editor's connection check; resets whenever the sheet opens. */
    val probe: ProbeState = ProbeState.Idle,
    /** Free text filtering the discovered model list. */
    val modelQuery: String = "",
    val discovery: DiscoveryState = DiscoveryState.Idle,
    val message: String? = null
)

class ProvidersViewModel(private val container: AppContainer) : ViewModel() {

    private val _editor = MutableStateFlow<ProviderEditor?>(null)
    private val _message = MutableStateFlow<String?>(null)
    private val _catalogOpen = MutableStateFlow(false)
    private val _probe = MutableStateFlow<ProbeState>(ProbeState.Idle)
    private val _modelQuery = MutableStateFlow("")
    private val _discovery = MutableStateFlow<DiscoveryState>(DiscoveryState.Idle)
    private val probe = ProviderProbe()
    private val scanner = LocalServerScanner()

    /** The in-flight check, kept so a second tap replaces it instead of racing it. */
    private var probeJob: Job? = null

    /** The in-flight capability measurement, so saving twice does not double-probe. */
    private var capabilityJob: Job? = null

    /** The in-flight LAN sweep, so a second tap replaces it instead of racing it. */
    private var discoveryJob: Job? = null

    /**
     * Everything the editor sheet owns, folded into one flow to stay inside
     * combine's arity. Discovery rides along for the same reason -- the outer
     * combine is already at five sources, which is its limit.
     */
    private data class SheetBundle(
        val editor: ProviderEditor?,
        val probe: ProbeState,
        val modelQuery: String,
        val discovery: DiscoveryState
    )

    private val editorState = combine(
        _editor,
        _probe,
        _modelQuery,
        _discovery
    ) { editor, probeState, query, discovery -> SheetBundle(editor, probeState, query, discovery) }

    val state: StateFlow<ProvidersUiState> = combine(
        container.providerRepository.observeProviders(),
        container.settingsRepository.settings,
        editorState,
        _message,
        _catalogOpen
    ) { providers, settings, editorBundle, message, catalogOpen ->
        val kept = providers.filter { it.enabled }
        val editor = editorBundle.editor
        val probeState = editorBundle.probe
        val modelQuery = editorBundle.modelQuery
        ProvidersUiState(
            providers = kept,
            // A preset already in the list is not offered again; adding it twice
            // would just collide on its id.
            catalog = ProviderPresets.all.filter { preset ->
                kept.none { it.id == preset.config.id }
            },
            catalogOpen = catalogOpen,
            settings = settings,
            editor = editor,
            probe = probeState,
            modelQuery = modelQuery,
            discovery = editorBundle.discovery,
            message = message
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ProvidersUiState())

    fun startEdit(config: ProviderConfig) {
        // A result from the previous provider would be read as this one's.
        resetProbe()
        _editor.value = ProviderEditor(
            id = config.id,
            label = config.label,
            labelKey = config.labelKey,
            baseUrl = config.baseUrl,
            type = config.type,
            models = config.models.joinToString(", ") { it.id },
            builtIn = config.builtIn,
            iconKey = config.iconKey,
            iconImagePath = config.iconImagePath,
            savedIconImagePath = config.iconImagePath
        )
    }

    fun startCreate() {
        resetProbe()
        _editor.value = ProviderEditor(
            label = container.strings.get(R.string.providers_default_label),
            baseUrl = "https://",
            type = ProviderType.OpenAiCompatible,
            iconKey = "robot"
        )
    }

    /** Picking a built-in mark drops the custom image; the two cannot both win. */
    fun selectIcon(key: String) {
        _editor.value = _editor.value?.let { editor ->
            editor.discardDraftImage()
            editor.copy(iconKey = key, iconImagePath = null)
        }
    }

    /** [path] is a copy already inside app storage, produced by `saveProviderIcon`. */
    fun selectIconImage(path: String) {
        _editor.value = _editor.value?.let { editor ->
            if (editor.iconImagePath != path) editor.discardDraftImage()
            editor.copy(iconImagePath = path)
        }
    }

    fun clearIconImage() {
        _editor.value = _editor.value?.let { editor ->
            editor.discardDraftImage()
            editor.copy(iconImagePath = null)
        }
    }

    fun updateEditor(transform: (ProviderEditor) -> ProviderEditor) {
        val before = _editor.value ?: return
        val after = transform(before)
        _editor.value = after
        // A "Connected" badge next to a URL or key the user has since changed is a
        // lie, so the result dies with the thing it was about.
        if (after.baseUrl != before.baseUrl ||
            after.apiKey != before.apiKey ||
            after.type != before.type
        ) {
            resetProbe()
        }
        // What a model refused is a fact about the server that refused it, so a
        // new URL or protocol invalidates every lesson learned from the old one.
        // Nothing cleared them before: one bad 400 kept a parameter switched off
        // for the rest of the process, and the power sheet went on reporting
        // knobs as unavailable on an endpoint that had never refused them.
        if (after.baseUrl != before.baseUrl || after.type != before.type) {
            before.id?.let { ModelQuirks.forget(it) }
        }
    }

    /**
     * Asks the endpoint for its model list.
     *
     * This is both the connection check and the model finder: one free `GET` says
     * whether the URL resolves, whether the key is accepted, and what can be run.
     * Nothing is generated, so nothing is billed.
     */
    fun checkConnection() {
        val editor = _editor.value ?: return
        val url = editor.baseUrl.trim()
        if (!url.startsWith("http")) return

        probeJob?.cancel()
        _probe.value = ProbeState.Running
        probeJob = viewModelScope.launch {
            // An empty field means "keep the stored key", so the check has to use
            // the saved one or it would report a false 401.
            val key = editor.apiKey.trim().ifBlank {
                editor.id?.let { container.providerRepository.apiKey(it) }
            }
            val config = ProviderConfig(
                id = editor.id ?: "probe",
                label = editor.label,
                type = editor.type,
                baseUrl = url.trimEnd('/')
            )
            _probe.value = when (val result = probe.listModels(config, key)) {
                is ProbeResult.Ok -> ProbeState.Success(
                    models = result.models,
                    message = if (result.models.isEmpty()) {
                        container.strings.get(R.string.providers_probe_ok_empty)
                    } else {
                        container.strings.get(R.string.providers_probe_ok, result.models.size)
                    }
                )

                is ProbeResult.Failure -> ProbeState.Failure(result.error.message)
            }
        }
    }

    fun updateModelQuery(query: String) {
        _modelQuery.value = query
    }

    /** Adds or drops one discovered model id in the editor's list. */
    fun toggleModel(modelId: String) {
        val editor = _editor.value ?: return
        val current = editor.modelIds()
        val next = if (modelId in current) current - modelId else current + modelId
        _editor.value = editor.copy(models = next.joinToString(", "))
    }

    /**
     * Appends every model matching the current filter.
     *
     * Gateways like OpenRouter list hundreds, so this respects the search box: it
     * adds what the user is looking at, not the whole registry.
     */
    fun addAllModels(models: List<AiModel>) {
        val editor = _editor.value ?: return
        val current = editor.modelIds()
        val next = current + models.map { it.id }.filterNot { it in current }
        _editor.value = editor.copy(models = next.joinToString(", "))
    }

    private fun resetProbe() {
        probeJob?.cancel()
        probeJob = null
        _probe.value = ProbeState.Idle
        _modelQuery.value = ""
    }

    fun cancelEdit() {
        // Anything picked and then abandoned would otherwise sit in app storage
        // forever with nothing pointing at it.
        _editor.value?.discardDraftImage()
        _editor.value = null
        resetProbe()
    }

    /**
     * Deletes the editor's current image only when it is a copy this session
     * made. The provider's already-saved image is left alone: it is still the
     * one on disk if the edit is abandoned.
     */
    private fun ProviderEditor.discardDraftImage() {
        if (iconImagePath != null && iconImagePath != savedIconImagePath) {
            deleteProviderIcon(iconImagePath)
        }
    }

    fun saveEditor() {
        val editor = _editor.value ?: return
        viewModelScope.launch {
            // A discovered model keeps the name the endpoint gave it, so the chip
            // reads "Claude 3.5 Sonnet" rather than a raw slug.
            val discovered = (_probe.value as? ProbeState.Success)?.models.orEmpty()
                .associateBy { it.id }
            val models = editor.modelIds().map { id -> discovered[id] ?: AiModel(id) }

            val config = ProviderConfig(
                id = editor.id ?: "custom-${UUID.randomUUID().toString().take(8)}",
                label = editor.label.ifBlank {
                    container.strings.get(R.string.providers_custom_label)
                },
                labelKey = editor.labelKey,
                type = editor.type,
                baseUrl = editor.baseUrl.trim().trimEnd('/'),
                models = models,
                defaultModel = models.firstOrNull()?.id.orEmpty(),
                builtIn = editor.builtIn,
                iconKey = editor.iconKey,
                iconImagePath = editor.iconImagePath
            )
            // The replaced image is only safe to drop once the new one is stored.
            if (editor.savedIconImagePath != null &&
                editor.savedIconImagePath != editor.iconImagePath
            ) {
                deleteProviderIcon(editor.savedIconImagePath)
            }
            container.providerRepository.upsert(config)
            if (editor.apiKey.isNotBlank()) {
                container.providerRepository.setApiKey(config.id, editor.apiKey.trim())
            }
            // Measured after the key is stored, so the probe can authenticate, and
            // deliberately not awaited: the sheet closes now and the answer lands
            // when it lands.
            measureCapabilities(config)
            // With an empty list on a fresh install, the first endpoint saved has
            // to become the active one or chat would have nothing to talk to.
            if (container.settingsRepository.settings.first().activeProviderId.isBlank()) {
                activateConfig(config)
            }
            _editor.value = null
            resetProbe()
            _message.value = container.strings.get(
                R.string.providers_saved,
                config.displayLabel(container.strings)
            )
        }
    }

    /**
     * Finds out, by asking, which of this provider's models can read an image.
     *
     * ### Why this runs on save
     * The alternative is to keep inferring vision from the model id, which is
     * structurally always out of date -- the pattern list can only know the names
     * that existed when the build shipped, so every model released afterwards is
     * reported as blind. Users hit that as "the app says this model cannot read
     * images" when it plainly can, and no amount of list maintenance fixes it for
     * the next release.
     *
     * Adding a provider is the right moment to settle it: the key was just
     * entered, the user is already waiting on a network round trip, and the answer
     * is stored on the model so it is bought once rather than per chat.
     *
     * ### Why it is fire-and-forget
     * The save must not block on it. A slow endpoint would hold the sheet open for
     * twenty seconds to learn something the id heuristic can approximate in the
     * meantime, and a failed probe is not a failed save -- Unknown simply leaves
     * the existing guess in charge.
     *
     * ### Why it is capped
     * A gateway like OpenRouter can have hundreds of models on one key. Probing
     * all of them would be hundreds of requests the user never asked for, so this
     * takes the first few, which are the ones the picker shows first and the ones a
     * new provider is actually used with. The rest stay Unknown until something
     * asks about them.
     */
    private fun measureCapabilities(config: ProviderConfig) {
        capabilityJob?.cancel()
        capabilityJob = viewModelScope.launch {
            val key = container.providerRepository.apiKey(config.id)
            // A keyless local server is the case where guessing is worst, so a
            // missing key only aborts when the endpoint actually wants one.
            if (key.isNullOrBlank() && config.requiresApiKey) return@launch

            // Only what has never been measured. Re-asking about a model whose
            // answer is already on disk spends a request to learn nothing.
            val vision = config.models
                .filter { it.vision == VisionSupport.Unknown }
                .take(MAX_VISION_PROBES)
                .associate { model -> model.id to probe.probeVision(config, key, model.id) }
                .filterValues { it != VisionSupport.Unknown }

            // Tools and streaming are asked about one model, not six. They are
            // near-uniform across an endpoint, and the honest budget for "user
            // pressed Save" is a handful of requests -- three probes times six
            // models is eighteen, which is a stall, not a check.
            val headline = config.models.firstOrNull { it.id == config.defaultModel }
                ?: config.models.firstOrNull()
            val tools = headline
                ?.takeIf { it.toolsProbe == ProbeVerdict.Unknown }
                ?.let { probe.probeTools(config, key, it.id) }
                ?.takeIf { it != ProbeVerdict.Unknown }
            val streaming = headline
                ?.takeIf { it.streamProbe == ProbeVerdict.Unknown }
                ?.let { probe.probeStreaming(config, key, it.id) }
                ?.takeIf { it != ProbeVerdict.Unknown }

            if (vision.isEmpty() && tools == null && streaming == null) return@launch

            // Re-read rather than reuse the local copy: the user may have edited
            // this provider again while the probes were in flight, and their typing
            // outranks our measurement.
            val current = container.providerRepository.get(config.id) ?: return@launch
            val updated = current.copy(
                models = current.models.map { model ->
                    var next = model
                    val seen = vision[model.id]
                    if (seen != null && model.vision == VisionSupport.Unknown) {
                        next = next.copy(vision = seen)
                    }
                    if (model.id == headline?.id) {
                        if (tools != null && model.toolsProbe == ProbeVerdict.Unknown) {
                            next = next.copy(toolsProbe = tools)
                        }
                        if (streaming != null && model.streamProbe == ProbeVerdict.Unknown) {
                            next = next.copy(streamProbe = streaming)
                        }
                    }
                    next
                }
            )
            if (updated.models != current.models) {
                container.providerRepository.upsert(updated)
            }
        }
    }

    fun activate(config: ProviderConfig) {
        viewModelScope.launch { activateConfig(config) }
    }

    private suspend fun activateConfig(config: ProviderConfig) {
        container.settingsRepository.update {
            it.copy(
                activeProviderId = config.id,
                activeModel = config.defaultModel.ifBlank {
                    config.models.firstOrNull()?.id.orEmpty()
                }
            )
        }
    }

    fun selectModel(config: ProviderConfig, modelId: String) {
        viewModelScope.launch {
            container.settingsRepository.update {
                it.copy(activeProviderId = config.id, activeModel = modelId)
            }
        }
    }

    fun removeKey(config: ProviderConfig) {
        viewModelScope.launch {
            container.providerRepository.clearApiKey(config.id)
            _message.value = container.strings.get(
                R.string.providers_removed_key,
                config.displayLabel(container.strings)
            )
        }
    }

    fun delete(config: ProviderConfig) {
        viewModelScope.launch {
            val label = config.displayLabel(container.strings)
            // An editor still open on this provider would write it straight back
            // into the list on save, so it closes with the row.
            if (_editor.value?.id == config.id) _editor.value = null

            // The row is gone for good, so the file behind its picture goes too.
            deleteProviderIcon(config.iconImagePath)
            container.providerRepository.delete(config.id)

            // The deleted id must not stay selected: every screen resolves the
            // active provider by id and would silently find nothing.
            val settings = container.settingsRepository.settings.first()
            if (settings.activeProviderId == config.id) {
                val remaining = container.providerRepository.providers().filter { it.enabled }
                val next = remaining.firstOrNull { it.hasKey } ?: remaining.firstOrNull()
                container.settingsRepository.update {
                    it.copy(
                        activeProviderId = next?.id.orEmpty(),
                        activeModel = next?.defaultModel
                            ?.ifBlank { next.models.firstOrNull()?.id.orEmpty() }
                            .orEmpty()
                    )
                }
            }
            _message.value = container.strings.get(R.string.providers_deleted, label)
        }
    }

    /**
     * Sweeps the local network for model servers.
     *
     * ### Why this is a button and not automatic
     * A sweep opens hundreds of sockets. Doing that unasked, on every visit to
     * this screen, on someone's office network, is not a courtesy -- so it runs
     * when a person asks for it and reports what it found.
     */
    fun scanLocalServers() {
        discoveryJob?.cancel()
        _discovery.value = DiscoveryState.Scanning
        discoveryJob = viewModelScope.launch {
            val found = runCatching { scanner.scan() }.getOrDefault(emptyList())
            // Already-added endpoints are dropped: offering to add the provider
            // the user is currently talking to is noise, not a discovery.
            val known = container.providerRepository.providers().map { it.baseUrl.trimEnd('/') }
            _discovery.value = DiscoveryState.Done(
                found.filterNot { known.contains(it.baseUrl.trimEnd('/')) }
            )
        }
    }

    fun dismissDiscovery() {
        discoveryJob?.cancel()
        _discovery.value = DiscoveryState.Idle
    }

    /**
     * Turns a found server into a provider, ready to use.
     *
     * No editor is opened and no key is asked for: the whole point of a LAN
     * endpoint is that there is nothing left to type. The models come from its own
     * catalogue, so the picker is populated before the first request.
     */
    fun addLocalServer(server: LocalServer) {
        viewModelScope.launch {
            val id = "local-" + server.host.replace('.', '-') + "-" + server.port
            val config = ProviderConfig(
                id = id,
                label = server.engine + " " + server.displayHost,
                type = ProviderType.OpenAiCompatible,
                baseUrl = server.baseUrl,
                models = server.models,
                defaultModel = server.models.firstOrNull()?.id.orEmpty(),
                enabled = true,
                builtIn = false,
                hasKey = false
            )
            container.providerRepository.upsert(config)
            _discovery.value = DiscoveryState.Idle
            _message.value = container.strings.get(
                R.string.providers_discover_added,
                config.label
            )
            // Measure it straight away: a local model's name says nothing reliable
            // about what it can do, which is exactly what the probe is for.
            measureCapabilities(config)
        }
    }

    fun openCatalog() {
        _catalogOpen.value = true
    }

    fun closeCatalog() {
        _catalogOpen.value = false
    }

    /**
     * Adds a preset as an ordinary provider and opens the editor on it, because a
     * keyed endpoint cannot answer anything until the user pastes their key. The
     * two local engines need none, so they are simply activated.
     */
    fun addPreset(preset: ProviderPreset) {
        viewModelScope.launch {
            _catalogOpen.value = false
            container.providerRepository.upsert(preset.config)
            if (preset.requiresKey) {
                startEdit(preset.config)
            } else {
                activateConfig(preset.config)
            }
            _message.value = container.strings.get(
                R.string.providers_added,
                preset.config.displayLabel(container.strings)
            )
        }
    }

    fun consumeMessage() {
        _message.value = null
    }

    private companion object {
        /**
         * How many models one save may ask about.
         *
         * Small on purpose: this is a courtesy request against someone else's
         * rate limit, made without the user asking for it.
         */
        const val MAX_VISION_PROBES = 6
    }
}
