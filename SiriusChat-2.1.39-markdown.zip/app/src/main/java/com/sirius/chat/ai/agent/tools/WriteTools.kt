package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.string
import com.sirius.chat.ai.agent.stringOrEmpty
import com.sirius.chat.domain.model.ChangeKind
import com.sirius.chat.domain.model.PendingChange
import kotlinx.serialization.json.JsonObject
import java.util.UUID

/**
 * Mutating tools never write by themselves: they resolve the target, capture the
 * current content for the diff and hand a proposal back. Whether that proposal
 * waits for the review sheet or lands right now is decided by [settle], from the
 * auto-apply flag carried on [AgentContext].
 */

/**
 * Queues [change] for review, or writes it immediately when auto-apply is on.
 *
 * ### Why the mode has to reach the model in words
 * Every mutating tool used to report "queued for your review" unconditionally,
 * and that one string produced a reproducible failure: the agent created
 * `game/index.html`, was told the call succeeded, ran `cd game` -- which reads
 * the real filesystem, not the queue -- got "No such file or directory", and
 * created the same file a second time before concluding out loud that the
 * environment required manual approval.
 *
 * Auto-apply did not rescue it either, because proposals were flushed once, from
 * the end of the agent loop, so "applied immediately so the next step sees the
 * file" actually applied after the *last* step. Writing here, inside the tool
 * call, is what puts the file on disk between steps.
 */
private suspend fun settle(
    context: AgentContext,
    change: PendingChange,
    summary: String
): AgentToolResult {
    val apply = context.applyChange
    if (!context.autoApply || apply == null) {
        return AgentToolResult(
            "$summary \u2014 QUEUED for the user's review. It is NOT on disk yet: " +
                "run_command, list_directory and read_file cannot see it until the user " +
                "approves it. Do not create it again and do not cd into it.",
            proposal = change
        )
    }
    val failure = apply(change)
    if (failure == null) {
        return AgentToolResult("$summary \u2014 written to disk now.")
    }
    // Still handed back as a proposal. The user trusted auto-apply, so a change
    // that did not land has to stay visible in review rather than vanish.
    return AgentToolResult(
        "$summary \u2014 could NOT be written: $failure. Queued for review instead.",
        success = false,
        proposal = change
    )
}

private suspend fun proposeWrite(
    context: AgentContext,
    path: String,
    newContent: String,
    allowCreate: Boolean
): AgentToolResult {
    val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
    val existing = context.workspace.findByPath(tree, path)

    if (existing != null && existing.isDirectory) {
        return AgentToolResult("$path is a directory.", success = false)
    }
    if (existing == null && !allowCreate) {
        return AgentToolResult("File not found: $path. Use create_file instead.", success = false)
    }

    // Walk up until something exists, remembering what has to be created. A
    // hard failure here is what previously made nested paths unreachable.
    val parentPath = path.trim('/').substringBeforeLast('/', "")
    val root = context.workspace.rootNode(tree)
    var parent = if (parentPath.isBlank()) root else context.workspace.findByPath(tree, parentPath)
    val missing = ArrayDeque<String>()

    if (existing == null && parent == null) {
        val segments = parentPath.split('/').filter { it.isNotBlank() }
        var depth = segments.size
        while (depth > 0 && parent == null) {
            missing.addFirst(segments[depth - 1])
            depth--
            parent = if (depth == 0) root
            else context.workspace.findByPath(tree, segments.take(depth).joinToString("/"))
        }
        if (parent == null) {
            return AgentToolResult("Cannot resolve workspace root for $path.", success = false)
        }
    }

    if (parent != null && !parent.isDirectory) {
        return AgentToolResult("$parentPath is a file, not a folder.", success = false)
    }

    val oldContent = existing?.let { context.workspace.readText(tree, it.documentId) }
    if (oldContent == newContent) {
        return AgentToolResult("No changes: $path already has this content.")
    }

    val change = PendingChange(
        id = UUID.randomUUID().toString(),
        sessionId = context.sessionId,
        kind = if (existing == null) ChangeKind.Create else ChangeKind.Modify,
        path = path,
        documentId = existing?.documentId,
        parentDocumentId = parent?.documentId,
        oldContent = oldContent,
        newContent = newContent,
        missingParents = missing.toList()
    )
    val verb = if (existing == null) "Create" else "Update"
    // Naming the folders in the tool result matters: the agent needs to know the
    // path became reachable, otherwise it retries with the workaround it invented
    // last time (writing to temp files) and fails again.
    val folders = if (missing.isEmpty()) "" else
        " (creating ${missing.joinToString("/")}/)"
    return settle(context, change, "$verb $path$folders")
}

class WriteFileTool : AgentTool {
    override val name = "write_file"
    override val description = "Replace the full contents of an existing file. Always read it first."
    override val usage = """{"path": "src/Main.kt", "content": "full new file content"}"""
    override val requiredArgs = listOf("path")
    override val mutating = true

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val path = args.string("path") ?: return AgentToolResult("Missing 'path'.", success = false)
        val content = args.stringOrEmpty("content")
        return proposeWrite(context, path, content, allowCreate = false)
    }
}

class CreateFileTool : AgentTool {
    override val name = "create_file"
    override val description = "Create a new file with the given content."
    override val usage = """{"path": "src/NewScreen.kt", "content": "file content"}"""
    override val requiredArgs = listOf("path")
    override val mutating = true

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val path = args.string("path") ?: return AgentToolResult("Missing 'path'.", success = false)
        val content = args.stringOrEmpty("content")
        return proposeWrite(context, path, content, allowCreate = true)
    }
}

class DeleteFileTool : AgentTool {
    override val name = "delete_file"
    override val description = "Delete a file from the workspace."
    override val usage = """{"path": "src/Obsolete.kt"}"""
    override val requiredArgs = listOf("path")
    override val mutating = true

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val path = args.string("path") ?: return AgentToolResult("Missing 'path'.", success = false)
        val node = context.workspace.findByPath(tree, path)
            ?: return AgentToolResult("File not found: $path", success = false)

        val old = if (node.isDirectory) null else context.workspace.readText(tree, node.documentId)
        val change = PendingChange(
            id = UUID.randomUUID().toString(),
            sessionId = context.sessionId,
            kind = ChangeKind.Delete,
            path = path,
            documentId = node.documentId,
            parentDocumentId = null,
            oldContent = old,
            newContent = null
        )
        return settle(context, change, "Delete $path")
    }
}

class RenameFileTool : AgentTool {
    override val name = "rename_file"
    override val description = "Rename a file or folder in place."
    override val usage = """{"path": "src/Old.kt", "new_name": "New.kt"}"""
    override val requiredArgs = listOf("path")
    override val mutating = true

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val path = args.string("path") ?: return AgentToolResult("Missing 'path'.", success = false)
        val newName = args.string("new_name") ?: args.string("newName")
            ?: return AgentToolResult("Missing 'new_name'.", success = false)
        val node = context.workspace.findByPath(tree, path)
            ?: return AgentToolResult("Not found: $path", success = false)

        val change = PendingChange(
            id = UUID.randomUUID().toString(),
            sessionId = context.sessionId,
            kind = ChangeKind.Rename,
            path = path,
            documentId = node.documentId,
            parentDocumentId = null,
            oldContent = null,
            newContent = null,
            newName = newName
        )
        return settle(context, change, "Rename $path \u2192 $newName")
    }
}

class MoveFileTool : AgentTool {
    override val name = "move_file"
    override val description = "Move a file into another existing folder."
    override val usage = """{"path": "src/Old.kt", "target_dir": "src/feature"}"""
    override val requiredArgs = listOf("path")
    override val mutating = true

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val path = args.string("path") ?: return AgentToolResult("Missing 'path'.", success = false)
        val target = args.string("target_dir") ?: args.string("targetDir")
            ?: return AgentToolResult("Missing 'target_dir'.", success = false)

        val node = context.workspace.findByPath(tree, path)
            ?: return AgentToolResult("Not found: $path", success = false)
        val targetDir = context.workspace.findByPath(tree, target)
            ?: return AgentToolResult("Target folder not found: $target", success = false)
        if (!targetDir.isDirectory) return AgentToolResult("$target is not a folder.", success = false)

        if (node.isDirectory) {
            return AgentToolResult(
                "$path is a folder; moving folders is not supported.",
                success = false
            )
        }

        val content = context.workspace.readText(tree, node.documentId)
        val change = PendingChange(
            id = UUID.randomUUID().toString(),
            sessionId = context.sessionId,
            kind = ChangeKind.Move,
            path = "$target/${node.name}",
            // Source document, so applying can delete it once the copy landed.
            documentId = node.documentId,
            parentDocumentId = targetDir.documentId,
            oldContent = null,
            newContent = content,
            newName = node.name
        )
        return settle(context, change, "Move $path \u2192 $target")
    }
}
