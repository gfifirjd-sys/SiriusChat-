package com.sirius.chat.ai.provider

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * One shared client for the whole app: connection pooling matters a lot on
 * mobile networks, and streaming needs a long read timeout.
 *
 * The read timeout is now the last limit on how long a reply may take, since the
 * agent's own stall watchdog is off. It is measured between bytes rather than
 * over the whole call, so a reasoning model that thinks for twenty minutes and
 * then answers is fine as long as something -- a token, a ping, an SSE comment --
 * arrives inside the window. Half an hour of total silence is a dead socket, not
 * a slow model.
 */
object HttpClientProvider {

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.MINUTES)
            .writeTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}
