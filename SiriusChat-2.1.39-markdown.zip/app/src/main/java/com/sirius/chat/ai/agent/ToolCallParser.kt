package com.sirius.chat.ai.agent

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.util.Locale

data class ParsedToolCall(val tool: String, val args: JsonObject, val rawBlock: String)

/**
 * Extracts tool calls from an assistant message.
 *
 * A fenced ```sirius-tool block is used instead of vendor specific function
 * calling so that *every* OpenAI or Anthropic compatible endpoint, including
 * small local models, can drive the agent.
 *
 * ### Why this is deliberately forgiving
 * The JSON shape was always lenient — `tool` or `name`, `args` or `arguments` or
 * `parameters` — but the *fence* used to be matched literally, and that made the
 * agent look broken on exactly the models this format exists to support. A weak
 * model that emitted a perfectly correct call inside a ```json fence produced
 * zero parsed calls, the run ended, and the user saw "I forgot to call the
 * tools" followed by nothing. The call was there; the parser refused to see it.
 *
 * So an info string is now accepted if it *names* a tool block in any of the
 * spellings models actually produce.
 *
 * ### The [known] gate
 * Generic fences are held to a stricter standard than explicit ones. An early
 * version accepted any object with a `tool` *or* `name` key inside a ```json
 * fence, which meant a user asking for `{"name": "Ivan", "age": 30}` got their
 * JSON parsed as a call to a tool named `Ivan` — rejected downstream, but also
 * stripped from the transcript, so the data they asked for silently vanished.
 * `name` is simply too common a key in ordinary JSON to treat as an instruction.
 *
 * So an ambiguous fence, and an unfenced object, must name a tool that actually
 * exists. An explicit `sirius-tool` fence does not: there the model has stated
 * its intent, and a typo in the tool name should surface as "unknown tool"
 * rather than be silently ignored.
 *
 * Nothing here loosens *what* gets run. [AgentEngine] still resolves every name
 * against the registry.
 *
 * ### Locale
 * Case folding is pinned to [Locale.ROOT] explicitly. Kotlin's no-argument
 * `lowercase()` is already locale invariant, so this is documentation rather
 * than a fix — but the failure it documents is real for the Java method it is
 * easily confused with: `toLowerCase()` on a Turkish device folds the `I` in
 * `SIRIUS-TOOL` to a dotless `ı`, the tag stops matching, and every tool call is
 * silently ignored on those devices only. Naming the locale keeps the next
 * person from "simplifying" this into that bug.
 */
object ToolCallParser {

    private const val FENCE = "```"
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    /** Info strings that unambiguously mean "this is a tool call". */
    private val explicitTags = setOf(
        "sirius-tool", "sirius_tool", "siriustool",
        "tool", "tool-call", "tool_call", "toolcall",
        "tool-calls", "tool_calls", "function", "function_call"
    )

    /**
     * Info strings that only count when the body looks like a call. `json` is
     * here because it is by far the most common substitution, and the empty
     * string covers a bare ``` fence with no tag at all.
     */
    private val ambiguousTags = setOf("json", "json5", "jsonc", "")

    private val toolKeys = listOf("tool", "name", "tool_name", "function")

    private data class Fence(val tag: String, val body: String, val start: Int, val end: Int)

    /**
     * @param known names of the registered tools. Empty means "accept explicit
     *   fences only", which is the safe reading when the registry is unknown.
     */
    fun parse(text: String, known: Set<String> = emptySet()): List<ParsedToolCall> {
        // The model's own draft is not an instruction: see [withoutThinking].
        val body = withoutThinking(text)
        val calls = ArrayList<ParsedToolCall>()
        for (fence in fences(body)) {
            val tag = fence.tag.lowercase(Locale.ROOT)
            calls += when {
                tag in explicitTags -> decode(fence.body)
                tag in ambiguousTags -> decode(fence.body).filter { known.hasTool(it.tool) }
                else -> emptyList()
            }
        }
        // Next, calls written as XML rather than JSON. Several hosted models
        // emit `<|DSML|>invoke name="tool">{args}</invoke>` and expect their own
        // runtime to strip the sentinels; over a plain completions endpoint
        // nothing does, so the app used to print every line of it as prose and
        // run none of it.
        if (calls.isEmpty()) calls += parseInvokes(body)
        // Last resort: a model that emitted the JSON with no fence at all. Only
        // tried when nothing was fenced, so a message that already produced calls
        // is never scanned twice.
        if (calls.isEmpty()) calls += parseUnfenced(body, known)
        return calls
    }

    /** Strips tool blocks so the transcript shows only the prose. */
    fun stripToolBlocks(text: String, known: Set<String> = emptySet()): String {
        // Harness markup comes off first and unconditionally. A sentinel token
        // is never something a person wrote or wants to read: it arrived in the
        // bubble as `<|DSML|>tool_calls>` and made a working call look like a
        // broken app.
        val clean = stripInvokes(withoutThinking(text))
        val executed = fences(clean).filter { fence ->
            val tag = fence.tag.lowercase(Locale.ROOT)
            when {
                tag in explicitTags -> true
                // An ambiguous fence is only hidden if it was actually run;
                // otherwise a JSON snippet the user asked for would vanish.
                tag in ambiguousTags -> decode(fence.body).any { known.hasTool(it.tool) }
                else -> false
            }
        }
        if (executed.isEmpty()) return dropOpenTail(stripUnfenced(clean, known), known).trim()

        val builder = StringBuilder(clean.length)
        var index = 0
        for (fence in executed) {
            builder.append(clean, index, fence.start)
            index = fence.end
        }
        builder.append(clean, index, clean.length)
        return dropOpenTail(builder.toString(), known).trim()
    }

    /**
     * A tool name reduced to the spelling the registry uses.
     *
     * Models namespace their calls the way their training data did --
     * `functions.read_file`, `default_api.read_file`, `tools:read_file` -- and
     * hyphenate or capitalise when writing JSON by hand. Every one of those came
     * back as "Unknown tool", which costs a step and, on a weaker model, the
     * rest of the run: it apologises, tries the same spelling again, and stops.
     *
     * Only the shape of the name is normalised. Nothing about *which* tools
     * exist is loosened -- [AgentEngine] still resolves the result against the
     * registry, and an invented name still fails.
     */
    fun canonicalName(raw: String): String = raw.trim()
        .trim('"', '\'', '`')
        .substringAfterLast('.')
        .substringAfterLast(':')
        .substringAfterLast('/')
        .trim()
        .replace(' ', '_')
        .replace('-', '_')
        .lowercase(Locale.ROOT)

    /** Whether the registry holds this tool under any spelling of its name. */
    private fun Set<String>.hasTool(name: String): Boolean {
        if (name in this) return true
        val canonical = canonicalName(name)
        return any { canonicalName(it) == canonical }
    }

    /**
     * A closed thinking block, in the spellings that reach `content`.
     *
     * Reasoning belongs in a field of its own and usually is in one, but a
     * gateway that passes the model's raw output through -- llama.cpp, Ollama,
     * some vLLM builds -- leaves the tags inline.
     */
    private val thinkBlock =
        Regex("""(?is)<\s*(think|thinking|reasoning|thought)\s*>.*?</\s*\1\s*>""")

    /** A block still being written: everything after the tag is draft. */
    private val openThink =
        Regex("""(?is)<\s*(?:think|thinking|reasoning|thought)\s*>.*\Z""")

    /** A sentinel mid-arrival, so it never flashes into the bubble. */
    private val partialSentinel = Regex("""<[|\uFF5C][^\n]{0,32}\Z""")

    /**
     * The message without the model's own draft.
     *
     * Applied before parsing as well as before display, and the parsing half
     * matters more: a reasoning model writes out the call it is *about* to make,
     * arguments and all, and running that draft meant acting on arguments it had
     * already talked itself out of -- or running the tool twice, once from the
     * draft and once for real.
     */
    private fun withoutThinking(text: String): String =
        openThink.replace(thinkBlock.replace(text, ""), "")

    /**
     * Hides a fenced tool block that has not finished arriving.
     *
     * The strip runs on every published frame of a streaming answer, and until
     * the closing fence lands there is no block to match -- so the raw JSON of a
     * call sat in the bubble for as long as it took to stream and then vanished
     * when the final text replaced it. That reads as a glitch, and it is the
     * same JSON the user reported seeing.
     *
     * Only the tail is considered, and only when the fences are unbalanced: a
     * complete block earlier in the message is [fences]' business.
     */
    private fun dropOpenTail(text: String, known: Set<String>): String {
        val cleaned = partialSentinel.replace(text, "")
        val marker = cleaned.lastIndexOf(FENCE)
        if (marker < 0) return cleaned
        if ((cleaned.split(FENCE).size - 1) % 2 == 0) return cleaned
        val lineEnd = cleaned.indexOf('\n', marker)
        if (lineEnd < 0) {
            // The info string itself is still arriving; `sir` is already enough
            // to know that `sirius-tool` is on its way.
            val partial = cleaned.substring(marker + FENCE.length).trim().lowercase(Locale.ROOT)
            val opening = partial.isNotEmpty() && explicitTags.any { it.startsWith(partial) }
            return if (opening) cleaned.substring(0, marker) else cleaned
        }
        val tag = cleaned.substring(marker + FENCE.length, lineEnd).trim().lowercase(Locale.ROOT)
        val rest = cleaned.substring(lineEnd + 1)
        val hidden = tag in explicitTags ||
            (
                tag in ambiguousTags &&
                    rest.trimStart().startsWith("{") &&
                    known.any { "\"" + it + "\"" in rest }
                )
        return if (hidden) cleaned.substring(0, marker) else cleaned
    }

    /** Every fenced block in the message, with its info string. */
    private fun fences(text: String): List<Fence> {
        val result = ArrayList<Fence>()
        var index = 0
        while (true) {
            val start = text.indexOf(FENCE, index)
            if (start < 0) break
            val infoEnd = text.indexOf('\n', start)
            if (infoEnd < 0) break
            val tag = text.substring(start + FENCE.length, infoEnd).trim()
            val close = text.indexOf(FENCE, infoEnd)
            if (close < 0) break
            result += Fence(
                tag = tag,
                body = text.substring(infoEnd + 1, close).trim(),
                start = start,
                end = close + FENCE.length
            )
            index = close + FENCE.length
        }
        return result
    }

    /**
     * Harness sentinels: `<|DSML|>`, `</|DSML|>`, `<|im_start|>`, and the
     * fullwidth-bar spellings some models prefer.
     *
     * These tokens exist to be eaten by the vendor's own runtime. Talking to
     * the same model over a plain completions endpoint means nobody eats them,
     * so they arrive as text and used to be displayed as if the model had
     * written them on purpose.
     */
    private val sentinelToken = Regex("""</?[|\uFF5C]{1,2}[^|\uFF5C\n<>]{0,40}[|\uFF5C]{1,2}>?""")

    /** What a wrapper leaves behind once its sentinels are gone: `tool_calls>`. */
    private val wrapperLine = Regex(
        """(?m)^[ \t]*<?/?(?:antml:)?(?:tool_calls|tool_call|function_calls|invoke)[ \t]*>[ \t]*(?:\n|\Z)"""
    )

    /** A closing tag, wherever it ended up. */
    private val closingTag =
        Regex("""</\s*(?:antml:)?(?:invoke|tool_calls|tool_call|function_calls)\s*>""")

    /** `invoke name="download_file">`, in any of its stripped spellings. */
    private val invokeHead =
        Regex("""(?:antml:)?invoke\s+name\s*=\s*["']([A-Za-z0-9_.\-]+)["']\s*>""")

    private val blankRun = Regex("""\n{3,}""")

    /**
     * Calls written as XML rather than JSON: `invoke name="tool">{args}</invoke>`.
     *
     * Arguments are brace matched rather than pattern matched, for the same
     * reason as everywhere else here: they are usually file contents, and a
     * lazy pattern stops at the first `}` inside them.
     *
     * Unlike an ambiguous fence this is not gated on [known] names. The model
     * has stated its intent as plainly as it can, so a typo in the name should
     * surface as "unknown tool" rather than be silently swallowed.
     */
    private fun parseInvokes(text: String): List<ParsedToolCall> {
        if (!text.contains("invoke")) return emptyList()
        val clean = sentinelToken.replace(text, "")
        val calls = ArrayList<ParsedToolCall>()
        for (head in invokeHead.findAll(clean)) {
            val name = head.groupValues[1]
            if (name.isBlank()) continue
            val body = argumentRange(clean, head.range.last + 1)?.let { clean.substring(it) }
            val args = body
                ?.let { runCatching { json.parseToJsonElement(it).jsonObject }.getOrNull() }
                ?: JsonObject(emptyMap())
            calls += ParsedToolCall(name, args, body ?: head.value)
        }
        return calls
    }

    /** The `{...}` that follows [from], skipping whitespace only, or null. */
    private fun argumentRange(text: String, from: Int): IntRange? {
        var i = from
        while (i < text.length && text[i].isWhitespace()) i++
        if (i >= text.length || text[i] != '{') return null
        val end = matchBracket(text, i)
        return if (end < 0) null else i..end
    }

    /**
     * Removes sentinels, wrapper tags and XML shaped calls, leaving prose.
     *
     * Runs on every message regardless of what parsed, because none of what it
     * removes is readable text under any circumstances.
     */
    private fun stripInvokes(text: String): String {
        var out = sentinelToken.replace(text, "")
        if (invokeHead.containsMatchIn(out)) {
            val builder = StringBuilder(out.length)
            var index = 0
            for (head in invokeHead.findAll(out)) {
                if (head.range.first < index) continue
                builder.append(out, index, head.range.first)
                val span = argumentRange(out, head.range.last + 1)
                index = when {
                    span != null -> span.last + 1
                    // A call still arriving. Its arguments are the tail of the
                    // message, so the tail goes: half a call in the bubble for
                    // as long as it takes to stream reads as a broken app.
                    else -> out.length
                }
            }
            builder.append(out, index, out.length)
            out = builder.toString()
        }
        out = wrapperLine.replace(out, "")
        out = closingTag.replace(out, "")
        return blankRun.replace(out, "\n\n")
    }

    /**
     * Scans for a bare `{...}` or `[...]` that decodes to a tool call.
     *
     * Brace-matched rather than regex-matched because tool arguments are usually
     * file contents, which contain braces and newlines of their own.
     */
    private fun parseUnfenced(text: String, known: Set<String>): List<ParsedToolCall> {
        if (known.isEmpty()) return emptyList()
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (ch != '{' && ch != '[') { i++; continue }
            val end = matchBracket(text, i)
            if (end < 0) return emptyList()
            val decoded = decode(text.substring(i, end + 1)).filter { known.hasTool(it.tool) }
            if (decoded.isNotEmpty()) return decoded
            i = end + 1
        }
        return emptyList()
    }

    private fun stripUnfenced(text: String, known: Set<String>): String {
        if (known.isEmpty()) return text
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (ch != '{' && ch != '[') { i++; continue }
            val end = matchBracket(text, i)
            if (end < 0) return text
            if (decode(text.substring(i, end + 1)).any { known.hasTool(it.tool) }) {
                return text.removeRange(i, end + 1)
            }
            i = end + 1
        }
        return text
    }

    /** Index of the bracket closing the one at [open], or -1. String-aware. */
    private fun matchBracket(text: String, open: Int): Int {
        val closer = if (text[open] == '{') '}' else ']'
        val opener = text[open]
        var depth = 0
        var i = open
        var inString = false
        var escaped = false
        while (i < text.length) {
            val c = text[i]
            when {
                escaped -> escaped = false
                c == '\\' && inString -> escaped = true
                c == '"' -> inString = !inString
                inString -> Unit
                c == opener -> depth++
                c == closer -> {
                    depth--
                    if (depth == 0) return i
                }
            }
            i++
        }
        return -1
    }

    private fun decode(body: String): List<ParsedToolCall> = runCatching {
        when (val element = json.parseToJsonElement(body)) {
            is JsonArray -> element.mapNotNull { it.toCall(body) }
            is JsonObject -> listOfNotNull(element.toCall(body))
            else -> emptyList()
        }
    }.getOrDefault(emptyList())

    private fun JsonElement.toCall(raw: String): ParsedToolCall? {
        val obj = runCatching { jsonObject }.getOrNull() ?: return null
        val name = toolKeys.firstNotNullOfOrNull { key ->
            obj[key]?.let { runCatching { it.jsonPrimitive.content }.getOrNull() }
        }?.takeIf { it.isNotBlank() } ?: return null
        val args = (obj["args"] ?: obj["arguments"] ?: obj["parameters"] ?: obj["input"])
            ?.let { runCatching { it.jsonObject }.getOrNull() }
            ?: JsonObject(emptyMap())
        return ParsedToolCall(name, args, raw)
    }
}
