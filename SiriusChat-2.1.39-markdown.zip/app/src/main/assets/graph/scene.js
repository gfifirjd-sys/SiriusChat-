/*
 * The memory scene.
 *
 * Kotlin owns the data and this file owns the look. The graph arrives as JSON
 * through window.siriusRender, view options through window.siriusApply, and
 * taps travel back the other way over the Sirius bridge.
 *
 * The renderer is vasturiano/3d-force-graph, loaded by index.html. Everything
 * here is written so that a missing renderer is a fallback rather than a blank
 * screen: the page waits for it, and tells the app when it never arrives.
 */
(function () {
	'use strict'

	/** How many captions may sit on screen at once. Beyond this it is soup. */
	var LABEL_BUDGET = 18
	/** Captions are a hint, not the fact; the sheet has the whole text. */
	var LABEL_CHARS = 28
	var SPIN_SPEED = 0.4
	var PARTICLE_SPEED = 0.004
	/** How long to wait for a renderer before handing the screen back. */
	var LIBRARY_TIMEOUT = 8000
	var LIBRARY_POLL = 120

	var graph = null
	var payload = { nodes: [], links: [] }
	var view = { selected: null, labels: true, spin: true }
	var textures = {}
	var labelled = []
	var chips = {}
	var announced = false
	var failed = false
	var waited = 0

	/** One-way call into the app. It is not obliged to be listening. */
	function bridge(name, argument) {
		try {
			var host = window.Sirius
			if (!host || typeof host[name] !== 'function') return
			if (typeof argument === 'undefined') host[name]()
			else host[name](argument)
		} catch (error) {
			/* Nothing to do: the scene works with or without the app. */
		}
	}

	function scene() {
		return document.getElementById('scene')
	}

	function layer() {
		return document.getElementById('labels')
	}

	/**
	 * A ball of light as a texture, drawn once per colour and reused.
	 *
	 * The library already gives every node a lit sphere; this sprite sits behind
	 * it and bleeds its colour into the dark around it. That bleed is the whole
	 * difference between a coloured dot and something that glows.
	 */
	function glowTexture(colour) {
		if (textures[colour]) return textures[colour]
		var size = 128
		var canvas = document.createElement('canvas')
		canvas.width = size
		canvas.height = size
		var context = canvas.getContext('2d')
		var middle = size / 2
		var gradient = context.createRadialGradient(middle, middle, 0, middle, middle, middle)
		gradient.addColorStop(0, colour)
		gradient.addColorStop(0.22, colour)
		gradient.addColorStop(1, 'rgba(0, 0, 0, 0)')
		context.globalAlpha = 0.5
		context.fillStyle = gradient
		context.fillRect(0, 0, size, size)
		var texture = new THREE.Texture(canvas)
		texture.needsUpdate = true
		textures[colour] = texture
		return texture
	}

	/** The halo drawn around a node, or null when three.js is not there. */
	function glowSprite(node) {
		if (typeof THREE === 'undefined') return null
		try {
			var material = new THREE.SpriteMaterial({
				map: glowTexture(node.color || '#7c5cff'),
				transparent: true,
				depthWrite: false,
				blending: THREE.AdditiveBlending
			})
			var sprite = new THREE.Sprite(material)
			var scale = 7 + (node.size || 1) * 3
			sprite.scale.set(scale, scale, 1)
			return sprite
		} catch (error) {
			// A scene without haloes is duller, not broken.
			return null
		}
	}

	function build() {
		var host = scene()
		if (!host || typeof ForceGraph3D === 'undefined') return false
		graph = ForceGraph3D()(host)
			.backgroundColor('rgba(0,0,0,0)')
			.showNavInfo(false)
			.nodeRelSize(3.4)
			.nodeVal(function (node) { return node.size || 1 })
			.nodeColor(function (node) { return node.color || '#7c5cff' })
			.nodeOpacity(0.95)
			.nodeResolution(14)
			.nodeLabel(function (node) { return node.text || '' })
			.linkColor(function (link) { return link.color || '#9a93d6' })
			.linkWidth(function (link) { return link.group ? 0.35 : 0.5 })
			.linkOpacity(0.22)
			// A light travelling along a stated link, the way the reference
			// example does it. The ties inside one memory file get none: they
			// are scaffolding, not a relationship worth animating.
			.linkDirectionalParticles(function (link) { return link.group ? 0 : 1 })
			.linkDirectionalParticleWidth(0.5)
			.linkDirectionalParticleSpeed(PARTICLE_SPEED)
			.enableNodeDrag(false)
			.onNodeClick(function (node) {
				focus(node)
				bridge('onNodeTap', node.id)
			})
			.onBackgroundClick(function () { bridge('onBackgroundTap') })

		try {
			graph.nodeThreeObject(glowSprite).nodeThreeObjectExtend(true)
		} catch (error) {
			/* Older builds of the library do not extend; spheres alone are fine. */
		}

		var controls = graph.controls()
		if (controls) {
			controls.autoRotate = view.spin
			controls.autoRotateSpeed = SPIN_SPEED
			controls.enableDamping = true
			controls.dampingFactor = 0.12
		}

		window.addEventListener('resize', resize)
		resize()
		window.requestAnimationFrame(frame)
		return true
	}

	function resize() {
		if (!graph) return
		graph.width(window.innerWidth).height(window.innerHeight)
	}

	/** Fly to a node without slamming into it. */
	function focus(node) {
		if (!graph || !node) return
		var x = node.x || 0
		var y = node.y || 0
		var z = node.z || 0
		var length = Math.sqrt(x * x + y * y + z * z) || 1
		var ratio = 1 + 120 / length
		try {
			graph.cameraPosition({ x: x * ratio, y: y * ratio, z: z * ratio }, node, 900)
		} catch (error) {
			/* A camera that will not move is not worth a broken tap. */
		}
	}

	function shorten(text) {
		var flat = String(text || '').replace(/\s+/g, ' ').trim()
		if (flat.length <= LABEL_CHARS) return flat
		return flat.slice(0, LABEL_CHARS - 1) + '\u2026'
	}

	/**
	 * Builds the caption chips once per graph.
	 *
	 * The busiest facts get them: a caption on every node is unreadable, and the
	 * nodes with the most ties are the ones worth naming. Position is updated per
	 * frame; the text is not touched again.
	 */
	function rebuildLabels() {
		var host = layer()
		if (!host) return
		host.innerHTML = ''
		chips = {}
		labelled = (payload.nodes || []).slice().sort(function (a, b) {
			return (b.size || 1) - (a.size || 1)
		}).slice(0, LABEL_BUDGET)
		for (var i = 0; i < labelled.length; i++) {
			var node = labelled[i]
			var chip = document.createElement('div')
			chip.className = 'label'
			chip.textContent = shorten(node.text)
			host.appendChild(chip)
			chips[node.id] = chip
		}
	}

	function clearLabels() {
		var host = layer()
		if (host) host.innerHTML = ''
		chips = {}
		labelled = []
	}

	function place() {
		if (!graph || !view.labels) return
		for (var i = 0; i < labelled.length; i++) {
			var node = labelled[i]
			var chip = chips[node.id]
			if (!chip) continue
			var point = null
			try {
				point = graph.graph2ScreenCoords(node.x || 0, node.y || 0, node.z || 0)
			} catch (error) {
				point = null
			}
			if (!point) {
				chip.style.opacity = '0'
				continue
			}
			chip.style.opacity = '1'
			chip.style.left = Math.round(point.x) + 'px'
			chip.style.top = Math.round(point.y) + 'px'
			chip.className = node.id === view.selected ? 'label lit' : 'label'
		}
	}

	function frame() {
		place()
		window.requestAnimationFrame(frame)
	}

	/**
	 * Runs [callback] once a renderer exists, or reports that none ever will.
	 *
	 * index.html tries the vendored copy and then the published one, both of
	 * which land asynchronously, so this polls rather than assuming.
	 */
	function whenReady(callback) {
		if (graph) {
			callback()
			return
		}
		if (typeof ForceGraph3D !== 'undefined' && build()) {
			callback()
			return
		}
		if (waited >= LIBRARY_TIMEOUT) {
			if (!failed) {
				failed = true
				bridge('onSceneFailed')
			}
			return
		}
		waited += LIBRARY_POLL
		window.setTimeout(function () { whenReady(callback) }, LIBRARY_POLL)
	}

	/** The graph, as a JSON string or an object. Called whenever it changes. */
	window.siriusRender = function (input) {
		try {
			payload = typeof input === 'string' ? JSON.parse(input) : (input || { nodes: [], links: [] })
		} catch (error) {
			payload = { nodes: [], links: [] }
		}
		whenReady(function () {
			graph.graphData({ nodes: payload.nodes || [], links: payload.links || [] })
			if (view.labels) rebuildLabels()
			if (!announced) {
				announced = true
				bridge('onSceneReady')
			}
		})
	}

	/** Selection, captions and spin. Cheap enough to call on every frame. */
	window.siriusApply = function (input) {
		var next = null
		try {
			next = typeof input === 'string' ? JSON.parse(input) : input
		} catch (error) {
			next = null
		}
		if (!next) return
		var wanted = typeof next.labels === 'boolean' ? next.labels : view.labels
		var showing = view.labels
		view.labels = wanted
		if (typeof next.spin === 'boolean') view.spin = next.spin
		view.selected = next.selected || null
		if (!graph) return
		var controls = graph.controls()
		if (controls) controls.autoRotate = view.spin
		if (!wanted && showing) clearLabels()
		if (wanted && !labelled.length) rebuildLabels()
	}
})()
