# ---- Sirius Chat R8 rules ----

# Kotlin metadata / coroutines
-dontwarn kotlinx.coroutines.**
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }

# kotlinx.serialization: keep generated serializers of our DTO/model classes
-keepattributes *Annotation*, InnerClasses, Signature, RuntimeVisibleAnnotations
-dontnote kotlinx.serialization.**
-keepclassmembers class ** {
    *** Companion;
}
-keepclasseswithmembers class ** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.sirius.chat.**$$serializer { *; }
-keepclassmembers class com.sirius.chat.** {
    *** Companion;
    kotlinx.serialization.KSerializer serializer(...);
}

# Room
-keep class * extends androidx.room.RoomDatabase { <init>(); }
-dontwarn androidx.room.paging.**

# OkHttp / Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# Compose keeps itself, just silence tooling
-dontwarn androidx.compose.ui.tooling.**

# JGit ships desktop-only code paths (AWT prompts, JMX, Apache HTTP, JSch) that
# the local-only commands used here never reach.
-dontwarn org.eclipse.jgit.**
-dontwarn org.slf4j.**
-dontwarn javax.management.**
-dontwarn java.lang.instrument.**
-dontwarn com.googlecode.javaewah.**
# Reflection inside JGit resolves these by name.
-keep class org.eclipse.jgit.util.SystemReader { *; }
-keep class * extends org.eclipse.jgit.util.SystemReader { *; }
-keep class org.eclipse.jgit.internal.storage.file.** { *; }
-keepnames class org.eclipse.jgit.lib.** { *; }

# The memory scene's page talks back through @JavascriptInterface. R8 cannot see
# calls that arrive from JavaScript, so those methods have to be kept by name.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
