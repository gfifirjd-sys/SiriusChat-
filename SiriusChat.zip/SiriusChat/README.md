# Sirius Chat

Мобильная AI-IDE для Android: чат с LLM, агент, который читает и правит ваш код,
просмотр диффов перед применением, файловый менеджер, редактор кода и терминал.
Аналог Cursor / Codex, но целиком на телефоне.

Проект специально собран так, чтобы компилироваться **прямо на телефоне в AndroidIDE**
(JDK 17, AGP 8.5.2, Gradle 8.9, Kotlin 2.0.21), а также на обычном Android Studio.

---

## 1. Что уже есть

| Модуль | Что делает |
|---|---|
| **Chat** | Потоковые ответы (настоящий SSE, токен за токеном), markdown, подсветка кода, копирование блоков, редактирование своих сообщений с «перемоткой» диалога, вложения из проекта |
| **Agent** | 21 инструмент: локально — `read_file`, `list_directory`, `search_files`, `search_text`, `analyze_project`, `create_file`, `write_file`, `delete_file`, `rename_file`, `move_file`; в GitHub — `github_status`, `github_list_repos`, `github_create_repo`, `github_set_visibility`, `github_list_files`, `github_read_file`, `github_write_file`, `github_delete_file`, `github_create_folder`, `github_build_apk`, `github_build_status` |
| **GitHub** | Подключение по personal access token (шифруется в Keystore), список репозиториев, смена public/private, сборка APK на GitHub Actions, скачивание артефакта и установка. Инструкция: [docs/GITHUB.md](docs/GITHUB.md) |
| **Review (diff)** | Ни один изменяющий инструмент не пишет на диск. Он создаёт `PendingChange`, вы смотрите дифф по ханкам и применяете выборочно |
| **Files** | Реальный файловый менеджер поверх SAF: навигация, поиск по именам и по содержимому, сортировка, создание/переименование/удаление |
| **Editor** | Редактор с подсветкой синтаксиса, номерами строк, фолдингом, undo/redo, автосохранением сессии, поиском/заменой (все совпадения подсвечены, «дальше» прокручивает к совпадению) и панелью быстрых символов над клавиатурой |
| **Terminal** | Настоящий `sh` внутри песочницы приложения, потоковый вывод, история |
| **Projects** | Несколько проектов, у каждого свой рабочий каталог (SAF), свои чаты и акцентный цвет |
| **Settings** | Провайдеры, модели, температура/токены, тема, **выбор цвета интерфейса** (12 пресетов + свой цвет по HSL), уровень «стекла», reduce motion, настройки редактора, GitHub |

### Провайдеры «из коробки»
* **OpenAI** — `https://api.openai.com/v1` (`gpt-4o-mini`, `gpt-4o`, `gpt-4.1-mini`)
* **Anthropic** — `https://api.anthropic.com/v1` (`claude-3-5-haiku-latest`, `claude-3-5-sonnet-latest`, `claude-sonnet-4-0`)
* **Custom / локальный** — `http://127.0.0.1:11434/v1`, модель `qwen2.5-coder:7b`
  (Ollama, LM Studio, OpenRouter, vLLM — всё, что говорит по OpenAI-совместимому API)

Ключей в коде нет. Вы вводите их в приложении, они шифруются **AES-256/GCM
в Android Keystore** (алиас `sirius_credentials_v1`) и лежат зашифрованными в DataStore.

---

## 2. Архитектура

```
app/src/main/java/com/sirius/chat/
├── core/         дизайн-система (liquid glass), навигация, утилиты (diff, markdown, highlighter)
├── domain/       модели, интерфейсы репозиториев, use-cases
├── data/         Room, DataStore, Keystore, SAF-репозиторий, терминал
├── ai/           провайдеры, SSE, агент, инструменты, системные промпты
├── feature/      home / chat / projects / files / editor / diff / terminal / settings / onboarding
└── di/           AppContainer — ручной DI, всё lazy
```

Ключевые решения:

* **Ручной DI вместо Hilt.** Никакого annotation processing на UI-слое — на телефоне
  каждая секунда сборки на счету. Граф маленький и полностью ленивый.
* **SAF через `DocumentsContract` напрямую**, а не `DocumentFile`. Один курсор на
  директорию вместо запроса на каждый атрибут — разница в скорости листинга на порядок.
* **Протокол инструментов через ```` ```sirius-tool ```` JSON-блоки**, а не vendor
  function calling. Поэтому агент работает с любым эндпоинтом, включая маленькие
  локальные модели, которые не умеют tool calls.
* **Liquid glass без backdrop blur.** Градиент + hairline-бордер + тень; blur только
  для aurora-подложки и только на API 31+. Иначе на среднем телефоне падают кадры.
* **Разрешения:** только `INTERNET` и `ACCESS_NETWORK_STATE`.
  Никакого `MANAGE_EXTERNAL_STORAGE` — доступ к файлам только через SAF, который выдали вы.

---

## 3. Сборка

> Корень проекта — папка **`SiriusChat/`**: в ней лежат `settings.gradle.kts`, `gradlew`,
> `gradle/` и модуль `app/`. Открывайте в IDE именно эту папку, все команды ниже
> запускайте из неё.

> **В пути к проекту не должно быть пробелов.** Имя папки — `SiriusChat`, а не
> `Sirius Chat`. Сборочные обёртки (AndroidIDE, скрипты через ssh/dropbear, часть
> CI-раннеров) подставляют путь в `cd` без кавычек, и пробел ломает саму команду
> ещё до Gradle:
>
> ```
> bash: line 0: cd: too many arguments
> bash: ./gradlew: No such file or directory
> ```
>
> Вторая строка здесь — следствие первой: `cd` не выполнился, поэтому `./gradlew`
> искали не в той папке. Ни к коду, ни к Gradle это отношения не имеет.
>
> Заодно проверьте бит выполнения — некоторые распаковщики его теряют:
>
> ```
> chmod +x gradlew
> ```

### Gradle wrapper

`gradle/wrapper/gradle-wrapper.jar` **уже в архиве** — ничего доустанавливать не нужно,
`./gradlew` работает сразу. При первом запуске он сам скачает Gradle 8.9
(~130 МБ, нужен Wi-Fi) в стандартный кеш `~/.gradle/wrapper/dists/`.

Jar собран вручную, потому что скачать официальный было неоткуда. Он делает ровно то же,
что и штатный: читает `gradle-wrapper.properties`, качает и распаковывает дистрибутив,
передаёт управление `org.gradle.launcher.GradleMain`. Схема кеша и хеширование URL
совпадают с официальными (base36 от MD5 адреса), поэтому дистрибутив общий с любым
другим проектом на Gradle. Исходник лежит рядом — `gradle/wrapper/source/`.

Если хотите канонический wrapper от Gradle, замените его одной командой:

```
gradle wrapper --gradle-version 8.9
```

### AndroidIDE (на телефоне)

1. Распакуйте архив в `/sdcard/AndroidIDEProjects/SiriusChat`.
2. В AndroidIDE: *Open project* → выберите папку.
3. Settings → Build & Run → **JDK 17**, Gradle **8.9**.
4. Дайте скачать Gradle и зависимости (первый раз — долго, нужен Wi-Fi).
5. Build → **Assemble debug**.

### Android Studio / командная строка

```
./gradlew assembleDebug
# или релиз (R8 + shrink resources)
./gradlew assembleRelease
```

`assembleRelease` работает сразу: если нет `keystore.properties`, сборка
автоматически падает обратно на debug-ключ. Для настоящей подписи создайте в корне:

```properties
storeFile=/абсолютный/путь/release.jks
storePassword=...
keyAlias=...
keyPassword=...
```

`compileSdk 35`, `minSdk 26`.

---

## 4. Первый запуск

1. Onboarding → **Settings → Providers** → добавьте ключ для нужного провайдера
   (или укажите свой URL, если гоняете локальную модель).
2. **Projects → New project** → выберите папку через системный пикер SAF.
   Именно эта папка станет рабочим каталогом агента.
3. Откройте чат, включите **Agent mode** и попросите что-нибудь сделать.
4. Когда агент предложит правки — вкладка **Review**, смотрите дифф, применяйте
   целиком или по отдельным ханкам.

---

## 5. Честные ограничения

* **Первый проход компиляции пройден.** `compileReleaseKotlin` дал 4 ошибки в двух
  файлах, все исправлены:
  * `AnthropicProvider.normaliseTurns` — `buildList` без параметра типа выводился в
    `Any?`, из-за чего отваливались `copy`, `content` и возникала неоднозначность
    перегрузки `String?.plus`. Добавлен явный `List<AiMessage>`.
  * `ReviewViewModel` — не был импортирован `kotlinx.coroutines.flow.stateIn`.

  У меня по-прежнему нет Android SDK, поэтому дальше сборку гоняете вы. Kotlin
  выдаёт все ошибки резолва за один проход, так что фронтенд должен пройти целиком.
* **Терминал не выходит за пределы песочницы приложения.** Так устроен Android,
  обойти это нельзя. Поэтому `TerminalBackend` — интерфейс: позже можно подключить
  Termux (`RUN_COMMAND`), SSH или ADB-over-network, не трогая UI.
* **Агент не запускает сборку вашего проекта.** Он читает, ищет и предлагает правки.
  Компиляцию делает AndroidIDE.
* **Нет тестов.** Юнит-тесты для `DiffEngine`, `ToolCallParser` и `SseParser` —
  первое, что стоит написать, они чистые и легко тестируются.

---

## 6. Куда расти дальше

* Termux-бэкенд для терминала → агент сможет сам собирать проект и читать ошибки
* Git-интеграция (JGit) — статус, дифф, коммит
* Индексация проекта с embeddings для семантического поиска по коду
* Голосовой ввод
* Мультифайловые правки одной транзакцией с откатом

---

Package: `com.sirius.chat` · ~106 Kotlin-файлов, ~13 700 строк · Jetpack Compose + Material 3
