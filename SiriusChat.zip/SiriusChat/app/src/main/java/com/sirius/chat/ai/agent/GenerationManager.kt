package com.sirius.chat.ai.agent

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.provider.AiProvider
import com.sirius.chat.core.locale.displayLabel
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.GenerationParams
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.model.MessageStatus
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.ToolRun
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Live assistant answer that is not persisted yet. */
data class StreamingAnswer(
    /** What the user sees: prose only, tool blocks removed. */
    val text: String = "",
    /** Everything the model emitted, needed to strip partial tool fences. */
    val raw: String = "",
    val toolRuns: List<ToolRun> = emptyList(),
    val activeTool: String? = null,
    val step: Int = 0,
    /** Title of the session, so a notification can name it without a lookup. */
    val sessionTitle: String = ""
)

/** A failure attached to a session, kept until the user dismisses or retries. */
data class GenerationFailure(
    val message: String,
    val retryable: Boolean
)

/**
 * Owns every running generation in the app.
 *
 * This used to live in `ChatViewModel`, which made the model's answer a property
 * of a screen: closing the chat cancelled `viewModelScope`, and the answer died
 * mid-sentence. Generation is not a screen concern — the user asked a question and
 * expects the answer to exist whether or not they are looking at it. So the work
 * runs on the application scope, keyed by session, and the chat screen is just one
 * observer of it.
 *
 * Several sessions can run at once. That is deliberate: with the work no longer
 * tied to the visible chat there is nothing left to serialise, and a user who
 * starts a long agent run and then asks something else in another chat should not
 * be told to wait.
 */
class GenerationManager(
    private val container: AppContainer,
    private val scope: CoroutineScope
) {

    private val _streams = MutableStateFlow<Map<String, StreamingAnswer>>(emptyMap())

    /** Live answers by session id. A session absent from the map is idle. */
    val streams: StateFlow<Map<String, StreamingAnswer>> = _streams.asStateFlow()

    private val _failures = MutableStateFlow<Map<String, GenerationFailure>>(emptyMap())
    val failures: StateFlow<Map<String, GenerationFailure>> = _failures.asStateFlow()

    /** Session ids currently generating, for the chat list indicator. */
    val activeSessions: StateFlow<Set<String>> = MutableStateFlow<Set<String>>(emptySet()).also { flow ->
        scope.launch {
            _streams.map { it.keys }.distinctUntilChanged().collect { flow.value = it }
        }
    }.asStateFlow()

    // Concurrent: sessions start and finish from different coroutines, and a plain
    // HashMap here can lose an entry or corrupt itself under exactly the case this
    // class exists for -- two chats generating at once.
    private val jobs = ConcurrentHashMap<String, Job>()

    /**
     * Sessions whose partial answer is being written after a manual stop.
     *
     * Marks the window in which the cancelled job's cleanup must not clear the
     * streaming bubble, because `stop()` is still moving that bubble into the
     * database.
     */
    private val handovers = ConcurrentHashMap.newKeySet<String>()

    fun stream(sessionId: String): Flow<StreamingAnswer?> =
        _streams.map { it[sessionId] }.distinctUntilChanged()

    fun failure(sessionId: String): Flow<GenerationFailure?> =
        _failures.map { it[sessionId] }.distinctUntilChanged()

    fun isRunning(sessionId: String): Boolean = _streams.value.containsKey(sessionId)

    fun clearFailure(sessionId: String) {
        _failures.update { it - sessionId }
    }

    /**
     * Starts generating an answer for [sessionId].
     *
     * A second call while the session is already running is ignored rather than
     * queued: two concurrent answers to one conversation would interleave their
     * tool calls over the same files.
     */
    fun start(sessionId: String) {
        if (jobs[sessionId]?.isActive == true) return
        _failures.update { it - sessionId }
        jobs[sessionId] = scope.launch {
            try {
                generate(sessionId)
            } finally {
                jobs.remove(sessionId)
                // Whatever happened — success, failure, cancellation — the session
                // must not stay marked as running, or the chat list pulses forever.
                //
                // Skipped while a handover is in flight: `stop()` cancels this job and
                // then persists the partial answer itself, and clearing the stream here
                // would pull the bubble out from under that write.
                if (!handovers.contains(sessionId)) {
                    _streams.update { it - sessionId }
                }
            }
        }
    }

    /** Stops [sessionId], keeping whatever the model already said. */
    fun stop(sessionId: String) {
        // Keeping the partial itself rather than a separate boolean means the
        // write below cannot be reached without the text it is about to store.
        val keep = _streams.value[sessionId]
            ?.takeIf { it.text.isNotBlank() || it.toolRuns.isNotEmpty() }

        // Claim the handover *before* cancelling, so the job's own cleanup cannot
        // clear the bubble in the gap between the cancel and the write.
        if (keep != null) handovers.add(sessionId)
        jobs.remove(sessionId)?.cancel()

        if (keep != null) {
            // Clear inside the coroutine, after the row is visible. Clearing here
            // instead would drop the bubble while the write was still in flight and
            // blank the answer the user just chose to keep.
            scope.launch {
                try {
                    val stored = persist(sessionId, keep, MessageStatus.Cancelled)
                    if (stored != null) awaitVisible(sessionId, stored)
                } finally {
                    handovers.remove(sessionId)
                    _streams.update { it - sessionId }
                }
            }
        } else {
            _streams.update { it - sessionId }
        }
    }

    // ------------------------------------------------------------------ internals

    /** Atomic read-modify-write: two sessions stream into this map at the same time. */
    private fun update(sessionId: String, block: (StreamingAnswer) -> StreamingAnswer) {
        _streams.update { current ->
            current + (sessionId to block(current[sessionId] ?: StreamingAnswer()))
        }
    }

    private suspend fun generate(sessionId: String) {
        val session = container.chatRepository.getSession(sessionId) ?: return
        val settings = container.settingsRepository.current()
        val provider = container.providerFactory.create(session.providerId)
        if (provider == null) {
            fail(sessionId, container.strings.get(R.string.chat_error_provider_missing), false)
            return
        }
        val config = container.providerRepository.get(session.providerId)
        if (config != null && container.providerFactory.requiresApiKey(config) && !config.hasKey) {
            fail(
                sessionId,
                container.strings.get(
                    R.string.chat_error_no_key,
                    config.displayLabel(container.strings)
                ),
                false
            )
            return
        }

        _streams.update { it + (sessionId to StreamingAnswer(sessionTitle = session.title)) }

        val project = session.projectId?.let { container.projectRepository.get(it) }
        val history = container.buildPrompt(container.chatRepository.messages(sessionId))
        val projectContext = runCatching {
            container.projectContextBuilder.projectSummary(project)
        }.getOrNull()
        val attachmentsText = runCatching {
            container.projectContextBuilder.attachmentsBlock(
                project?.treeUri,
                history.lastOrNull()?.attachments.orEmpty()
            )
        }.getOrDefault("")

        val wire = history.map { message ->
            val role = if (message.role == MessageRole.User) AiRole.User else AiRole.Assistant
            AiMessage(role, message.content)
        }.toMutableList()
        if (attachmentsText.isNotBlank() && wire.isNotEmpty()) {
            val last = wire.removeAt(wire.lastIndex)
            wire += last.copy(content = last.content + "\n\nAttached files:\n" + attachmentsText)
        }

        runAgent(
            sessionId = sessionId,
            provider = provider,
            session = session,
            project = project,
            wire = wire,
            projectContext = projectContext,
            params = GenerationParams(
                temperature = settings.temperature,
                maxTokens = settings.maxTokens
            ),
            maxSteps = settings.agentMaxSteps
        )
    }

    private suspend fun runAgent(
        sessionId: String,
        provider: AiProvider,
        session: ChatSession,
        project: Project?,
        wire: List<AiMessage>,
        projectContext: String?,
        params: GenerationParams,
        maxSteps: Int
    ) {
        val context = AgentContext(
            sessionId = sessionId,
            projectId = project?.id,
            treeUri = project?.treeUri,
            workspace = container.workspaceRepository
        )

        container.agentEngine.run(
            provider = provider,
            model = session.model,
            history = wire,
            context = context,
            projectContext = projectContext,
            params = params,
            maxSteps = maxSteps
        ).collect { event ->
            when (event) {
                is AgentEvent.StepStarted -> update(sessionId) { it.copy(step = event.step) }
                is AgentEvent.Delta -> update(sessionId) {
                    // Strip on every delta, not once at the end: otherwise the
                    // tool-call JSON is on screen for the whole call.
                    val raw = it.raw + event.text
                    it.copy(raw = raw, text = ToolCallParser.stripToolBlocks(raw))
                }
                is AgentEvent.ToolStarted -> update(sessionId) { it.copy(activeTool = event.toolName) }
                is AgentEvent.ToolFinished -> update(sessionId) {
                    it.copy(toolRuns = it.toolRuns + event.run, activeTool = null)
                }
                is AgentEvent.Proposals -> container.changeStore.submit(event.changes)
                is AgentEvent.Completed -> {
                    val current = _streams.value[sessionId] ?: StreamingAnswer()
                    // Write first, clear second: the other order left a window with
                    // no streaming bubble and no stored message, and the answer
                    // blinked out of the chat.
                    val stored = persist(
                        sessionId,
                        current.copy(text = event.text.ifBlank { current.text }),
                        MessageStatus.Complete
                    )
                    // Writing is not enough -- the row also has to have travelled
                    // through Room's Flow into the message list before the bubble
                    // goes away, or the chat is briefly missing the answer entirely
                    // and looks like it reset. Wait for the id to actually show up.
                    if (stored != null) awaitVisible(sessionId, stored)
                    _streams.update { it - sessionId }
                    container.projectContextBuilder.invalidate()
                }
                is AgentEvent.Failure -> {
                    val partial = _streams.value[sessionId]
                    if (partial != null && (partial.text.isNotBlank() || partial.toolRuns.isNotEmpty())) {
                        // Half an answer plus an error is recoverable; an empty chat
                        // plus an error is not.
                        val stored = persist(sessionId, partial, MessageStatus.Failed)
                        if (stored != null) awaitVisible(sessionId, stored)
                    }
                    _streams.update { it - sessionId }
                    fail(sessionId, event.error.message, event.error.isRetryable)
                }
            }
        }
    }

    /**
     * Stores a finished (or stopped, or failed) answer.
     *
     * [NonCancellable] is the point: an answer that reached the screen must reach
     * the database, even if the caller is being cancelled at that exact moment.
     * An empty answer with no tool runs is dropped — a blank bubble is worse than
     * no bubble.
     *
     * Returns the id of the stored message, or null when nothing was worth storing.
     */
    private suspend fun persist(
        sessionId: String,
        answer: StreamingAnswer,
        status: MessageStatus
    ): String? {
        val session = container.chatRepository.getSession(sessionId) ?: return null
        val text = answer.text.trim()
        if (text.isEmpty() && answer.toolRuns.isEmpty()) return null
        val id = UUID.randomUUID().toString()
        withContext(NonCancellable) {
            container.chatRepository.addMessage(
                ChatMessage(
                    id = id,
                    sessionId = sessionId,
                    role = MessageRole.Assistant,
                    content = text,
                    createdAt = System.currentTimeMillis(),
                    model = session.model,
                    providerId = session.providerId,
                    status = status,
                    toolRuns = answer.toolRuns
                )
            )
        }
        return id
    }

    /**
     * Suspends until [messageId] is observable in the session's message list.
     *
     * The insert and the UI's `observeMessages` collection are separate hops. Between
     * them the streaming bubble and the stored row can both be absent for a frame or
     * two, which reads as the chat wiping itself right as the answer lands. Handing
     * over only once the row is actually visible removes the gap.
     *
     * The timeout keeps this a smoothing step rather than a new way to hang: if the
     * row never arrives the bubble is cleared anyway.
     */
    private suspend fun awaitVisible(sessionId: String, messageId: String) {
        // Only the timeout is caught. A bare `runCatching` here would also swallow
        // the CancellationException that `withTimeout` throws to unwind, which
        // breaks cancellation for the caller.
        try {
            withTimeout(HANDOVER_TIMEOUT_MS) {
                container.chatRepository.observeMessages(sessionId)
                    .first { messages -> messages.any { it.id == messageId } }
            }
        } catch (timeout: TimeoutCancellationException) {
            // The row did not surface in time; the caller clears the bubble anyway.
        }
    }

    private fun fail(sessionId: String, message: String, retryable: Boolean) {
        _failures.update { it + (sessionId to GenerationFailure(message, retryable)) }
        _streams.update { it - sessionId }
    }

    private companion object {
        /** Upper bound on the stream-to-database handover wait. */
        const val HANDOVER_TIMEOUT_MS = 2_000L
    }
}
