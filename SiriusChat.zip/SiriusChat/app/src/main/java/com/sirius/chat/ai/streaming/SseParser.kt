package com.sirius.chat.ai.streaming

import okio.BufferedSource

/** One server-sent event. */
data class SseEvent(val event: String?, val data: String)

/**
 * Minimal SSE reader. It works directly on an Okio source so no intermediate
 * buffering of the whole response is required and tokens surface immediately.
 */
object SseParser {

    const val DONE = "[DONE]"

    inline fun read(source: BufferedSource, onEvent: (SseEvent) -> Boolean) {
        var eventName: String? = null
        val data = StringBuilder()

        while (true) {
            val line = source.readUtf8Line() ?: break
            when {
                line.isEmpty() -> {
                    if (data.isNotEmpty()) {
                        val payload = data.toString()
                        data.setLength(0)
                        val keepGoing = onEvent(SseEvent(eventName, payload))
                        eventName = null
                        if (!keepGoing) return
                    }
                }
                line.startsWith(":") -> Unit // comment / keep-alive
                line.startsWith("event:") -> eventName = line.removePrefix("event:").trim()
                line.startsWith("data:") -> {
                    if (data.isNotEmpty()) data.append('\n')
                    data.append(line.removePrefix("data:").trim())
                }
            }
        }
        if (data.isNotEmpty()) onEvent(SseEvent(eventName, data.toString()))
    }
}
