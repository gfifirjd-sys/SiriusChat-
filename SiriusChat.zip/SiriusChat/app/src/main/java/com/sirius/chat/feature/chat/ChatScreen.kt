package com.sirius.chat.feature.chat

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.CompareArrows
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.SiriusOrb
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.SiriusTypingDots
import com.sirius.chat.core.designsystem.components.labelled
import com.sirius.chat.core.designsystem.effects.beamBorder
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.designsystem.siriusFadeThrough
import com.sirius.chat.core.designsystem.siriusRise
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.domain.model.ToolRun
import com.sirius.chat.feature.chat.components.AttachmentSheet
import com.sirius.chat.feature.chat.components.ChatInputBar
import com.sirius.chat.feature.chat.components.EditMessageDialog
import com.sirius.chat.feature.chat.components.MarkdownText
import com.sirius.chat.feature.chat.components.MessageBubble
import com.sirius.chat.feature.chat.components.ModelPickerSheet
import com.sirius.chat.feature.chat.components.ToolRunList
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    sessionId: String,
    onBack: () -> Unit,
    onOpenReview: () -> Unit,
    onOpenProviders: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: ChatViewModel = siriusViewModel(key = "chat-$sessionId") {
        ChatViewModel(it, sessionId)
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val attachmentResults by viewModel.attachmentResults.collectAsStateWithLifecycle()
    val attachmentQuery by viewModel.attachmentQuery.collectAsStateWithLifecycle()
    val codeFontSize by viewModel.codeFontSize.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var showModelPicker by remember { mutableStateOf(false) }
    var showAttachments by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Pair<String, String>?>(null) }

    val itemCount = state.messages.size + if (state.streaming != null) 1 else 0
    val atBottom by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= (info.totalItemsCount - 2)
        }
    }

    // Follow the answer while it streams, but never fight the user's scroll.
    LaunchedEffect(itemCount, state.streaming?.text?.length) {
        if (atBottom && itemCount > 0) {
            listState.animateScrollToItem((itemCount - 1).coerceAtLeast(0))
        }
    }

    val latestDraft = rememberUpdatedState(state.input)
    DisposableEffect(Unit) {
        onDispose {
            if (latestDraft.value.isNotBlank()) viewModel.persistDraft()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = state.session?.title ?: stringResource(R.string.chat_title_fallback),
            subtitle = state.project?.name?.let {
                stringResource(R.string.chat_project_prefix, it)
            } ?: state.session?.model,
            onBack = onBack,
            actions = {
                if (state.pendingChanges.isNotEmpty()) {
                    val pendingCount = state.pendingChanges.size
                    // On its own this reads as a naked "3" to a screen reader.
                    // The banner below says it in full, so the badge borrows that
                    // sentence instead of inventing a shorter, vaguer one.
                    val pendingLabel = pluralStringResource(
                        R.plurals.chat_review_banner_title,
                        pendingCount,
                        pendingCount
                    )
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(SiriusRadius.pill))
                            .softSurface(RoundedCornerShape(SiriusRadius.pill))
                            .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xxs)
                            .labelled(pendingLabel),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.AutoMirrored.Rounded.CompareArrows,
                            contentDescription = null,
                            tint = colors.warning,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(Modifier.width(SiriusSpacing.xxs))
                        Text(
                            text = pendingCount.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.warning
                        )
                    }
                    Spacer(Modifier.width(SiriusSpacing.xxs))
                }
            }
        )

        // The banner shows up mid-conversation and pushes the transcript down,
        // so it rises into that space rather than materialising in it.
        val (bannerEnter, bannerExit) = siriusRise()
        AnimatedVisibility(
            visible = state.pendingChanges.isNotEmpty(),
            enter = bannerEnter,
            exit = bannerExit
        ) {
            ReviewBanner(
                count = state.pendingChanges.size,
                onReview = onOpenReview,
                modifier = Modifier.padding(horizontal = SiriusSpacing.sm)
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = SiriusSpacing.sm,
                    end = SiriusSpacing.sm,
                    top = SiriusSpacing.xs,
                    bottom = SiriusSpacing.sm
                ),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                if (state.messages.isEmpty() && state.streaming == null) {
                    item(key = "empty") {
                        EmptyConversation()
                    }
                }

                items(state.messages, key = { it.id }) { message ->
                    MessageBubble(
                        message = message,
                        codeFontSize = codeFontSize,
                        onEdit = { editing = message.id to it },
                        onRegenerate = viewModel::regenerate,
                        onDelete = { viewModel.deleteMessage(message.id) }
                    )
                }

                state.streaming?.let { streaming ->
                    item(key = "streaming") {
                        StreamingBubble(
                            text = streaming.text,
                            activeTool = streaming.activeTool,
                            step = streaming.step,
                            toolRuns = streaming.toolRuns,
                            codeFontSize = codeFontSize
                        )
                    }
                }
            }

            // Kept in its own composable: inside this Box the Column receiver from
            // the screen root is still in scope, and AnimatedVisibility would bind
            // to the ColumnScope overload it cannot reach from here.
            JumpToBottomButton(
                visible = !atBottom && itemCount > 2,
                onClick = {
                    scope.launch { listState.animateScrollToItem((itemCount - 1).coerceAtLeast(0)) }
                },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = SiriusSpacing.xs)
            )
        }

        // Failures used to snap in above the composer, which read as a layout
        // glitch rather than an answer to the tap. It rises like the review
        // banner, and announces itself so the error is not silent.
        val (errorEnter, errorExit) = siriusRise(distancePx = 16)
        // The text has to outlive the state that produced it, otherwise the
        // banner blanks out for the length of its own exit animation.
        var lastError by remember { mutableStateOf("") }
        LaunchedEffect(state.error) {
            state.error?.let { lastError = it }
        }
        AnimatedVisibility(
            visible = state.error != null,
            enter = errorEnter,
            exit = errorExit
        ) {
            ErrorBanner(
                message = lastError,
                retryable = state.retryable,
                onRetry = viewModel::retry,
                onDismiss = viewModel::dismissError
            )
        }

        ChatInputBar(
            value = state.input,
            onValueChange = viewModel::onInputChange,
            onSend = viewModel::send,
            onStop = viewModel::stop,
            onAttach = {
                showAttachments = true
                viewModel.searchAttachments("")
            },
            onPickModel = { showModelPicker = true },
            generating = state.isGenerating,
            canSend = state.canSend,
            modelLabel = state.session?.model ?: stringResource(R.string.chat_no_model),
            attachments = state.attachments,
            onRemoveAttachment = viewModel::removeAttachment
        )
    }

    if (showModelPicker) {
        ModelPickerSheet(
            providers = state.providers,
            activeProviderId = state.session?.providerId,
            activeModel = state.session?.model,
            onSelect = { providerId, model ->
                viewModel.selectModel(providerId, model)
                showModelPicker = false
            },
            onManageProviders = {
                showModelPicker = false
                onOpenProviders()
            },
            onDismiss = { showModelPicker = false }
        )
    }

    if (showAttachments) {
        AttachmentSheet(
            results = attachmentResults,
            query = attachmentQuery,
            onQueryChange = viewModel::searchAttachments,
            onPick = { node ->
                viewModel.attach(node)
                showAttachments = false
            },
            onDismiss = { showAttachments = false },
            hasWorkspace = state.project?.hasWorkspace == true
        )
    }

    editing?.let { (messageId, text) ->
        EditMessageDialog(
            initial = text,
            onDismiss = { editing = null },
            onConfirm = { updated ->
                editing = null
                viewModel.editAndResend(messageId, updated)
            }
        )
    }
}

/**
 * The button that returns the reader to the live end of the transcript. It uses
 * the shared fade-through so it honours reduce-motion like every other element
 * that swaps in, and it lives here rather than inline because at the call site
 * an outer ColumnScope shadows the plain [AnimatedVisibility] overload.
 */
@Composable
private fun JumpToBottomButton(
    visible: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (enter, exit) = siriusFadeThrough()
    AnimatedVisibility(
        visible = visible,
        enter = enter,
        exit = exit,
        modifier = modifier
    ) {
        GlassIconButton(
            icon = Icons.Rounded.KeyboardArrowDown,
            contentDescription = stringResource(R.string.chat_scroll_to_bottom),
            onClick = onClick
        )
    }
}

@Composable
private fun EmptyConversation() {
    val colors = SiriusTheme.colors
    // A fresh conversation is the one moment with nothing to read, so the orb
    // gets to be the subject rather than an icon next to a title.
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = SiriusSpacing.xxl, bottom = SiriusSpacing.lg)
            .padding(horizontal = SiriusSpacing.md),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SiriusOrb(size = 72.dp, active = true)
        Spacer(Modifier.height(SiriusSpacing.lg))
        Text(
            text = stringResource(R.string.chat_agent_mode),
            style = MaterialTheme.typography.headlineSmall,
            color = colors.textPrimary,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(SiriusSpacing.xs))
        Text(
            text = stringResource(R.string.chat_empty_agent_body),
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
            // Keeps the line length in the comfortable 45-75 character band
            // instead of stretching edge to edge on a tablet.
            modifier = Modifier.widthIn(max = 340.dp)
        )
    }
}

@Composable
private fun StreamingBubble(
    text: String,
    activeTool: String?,
    step: Int,
    toolRuns: List<ToolRun>,
    codeFontSize: Int
) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.lg)
    val label = when {
        activeTool != null -> stringResource(R.string.chat_running_tool, activeTool)
        step > 1 -> stringResource(R.string.chat_thinking_step, step)
        else -> stringResource(R.string.chat_thinking)
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = SiriusSpacing.xxs)
            .glassSurface(shape = shape, elevation = 6.dp)
            // The beam earns its place here: this is the one element on screen
            // that is genuinely mid-flight.
            .beamBorder(shape = shape, active = true)
            .padding(SiriusSpacing.sm)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SiriusOrb(size = 16.dp, active = true, contentDescription = label)
            Spacer(Modifier.width(SiriusSpacing.xs))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = colors.textSecondary,
                modifier = Modifier.weight(1f, fill = false)
            )
            Spacer(Modifier.width(SiriusSpacing.xs))
            SiriusTypingDots(dotSize = 4.dp)
        }
        if (toolRuns.isNotEmpty()) {
            Spacer(Modifier.height(SiriusSpacing.xs))
            ToolRunList(toolRuns)
        }
        if (text.isNotBlank()) {
            Spacer(Modifier.height(SiriusSpacing.xs))
            MarkdownText(markdown = text, codeFontSize = codeFontSize)
        }
    }
}

@Composable
private fun ReviewBanner(count: Int, onReview: () -> Unit, modifier: Modifier = Modifier) {
    val colors = SiriusTheme.colors
    GlassCard(
        modifier = modifier.fillMaxWidth(),
        onClick = onReview,
        tint = colors.warning.copy(alpha = 0.14f),
        contentPadding = SiriusSpacing.sm
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.AutoMirrored.Rounded.CompareArrows,
                contentDescription = null,
                tint = colors.warning,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(SiriusSpacing.xs))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = pluralStringResource(R.plurals.chat_review_banner_title, count, count),
                    style = MaterialTheme.typography.titleSmall,
                    color = colors.textPrimary
                )
                Text(
                    text = stringResource(R.string.chat_review_banner_subtitle),
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary
                )
            }
            Text(
                text = stringResource(R.string.action_review),
                style = MaterialTheme.typography.labelLarge,
                color = colors.primary
            )
        }
    }
}

@Composable
private fun ErrorBanner(
    message: String,
    retryable: Boolean,
    onRetry: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xxs)
            .glassSurface(
                shape = RoundedCornerShape(SiriusRadius.md),
                tint = colors.error.copy(alpha = 0.18f),
                elevation = 4.dp
            )
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
            // TalkBack has no reason to look at the bottom of the screen after a
            // send, so the failure has to speak for itself.
            .semantics { liveRegion = LiveRegionMode.Polite },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Rounded.ErrorOutline,
            contentDescription = null,
            tint = colors.error,
            modifier = Modifier.size(16.dp)
        )
        Spacer(Modifier.width(SiriusSpacing.xs))
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f)
        )
        if (retryable) {
            GlassIconButton(
                icon = Icons.Rounded.Refresh,
                contentDescription = stringResource(R.string.action_retry),
                onClick = onRetry,
                size = 30.dp,
                iconSize = 15.dp,
                tint = colors.primary
            )
            Spacer(Modifier.width(SiriusSpacing.xxs))
        }
        GlassIconButton(
            icon = Icons.Rounded.Close,
            contentDescription = stringResource(R.string.action_dismiss),
            onClick = onDismiss,
            size = 30.dp,
            iconSize = 15.dp
        )
    }
}
