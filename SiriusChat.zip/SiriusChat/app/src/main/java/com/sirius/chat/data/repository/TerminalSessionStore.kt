package com.sirius.chat.data.repository

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class TerminalLineType { Command, Stdout, Stderr, System }

data class TerminalLine(
    val id: Long,
    val type: TerminalLineType,
    val text: String
)

/** Terminal scrollback and history, kept alive across navigation. */
class TerminalSessionStore {

    private var nextId = 0L

    private val _lines = MutableStateFlow<List<TerminalLine>>(emptyList())
    val lines: StateFlow<List<TerminalLine>> = _lines.asStateFlow()

    private val _history = MutableStateFlow<List<String>>(emptyList())
    val history: StateFlow<List<String>> = _history.asStateFlow()

    private val _workingDirectory = MutableStateFlow("")
    val workingDirectory: StateFlow<String> = _workingDirectory.asStateFlow()

    fun append(type: TerminalLineType, text: String) {
        val line = TerminalLine(nextId++, type, text)
        val current = _lines.value
        // Bound the scrollback so a chatty command cannot exhaust memory.
        _lines.value = if (current.size >= MAX_LINES) {
            current.drop(current.size - MAX_LINES + 1) + line
        } else {
            current + line
        }
    }

    fun rememberCommand(command: String) {
        if (command.isBlank()) return
        _history.value = (_history.value - command + command).takeLast(MAX_HISTORY)
    }

    fun setWorkingDirectory(path: String) {
        _workingDirectory.value = path
    }

    fun clear() {
        _lines.value = emptyList()
    }

    private companion object {
        const val MAX_LINES = 2000
        const val MAX_HISTORY = 80
    }
}
