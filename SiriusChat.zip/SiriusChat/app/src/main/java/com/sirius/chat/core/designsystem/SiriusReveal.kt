package com.sirius.chat.core.designsystem

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.util.rememberHaptics
import kotlinx.coroutines.delay

/**
 * Entry motion for content that was not there a frame ago.
 *
 * Chat had this from the start — new messages rise into place — while Home,
 * Projects, Git and Settings popped in fully formed. That inconsistency is what
 * made the app feel like two products: the same repository list appearing
 * instantly under a composer that animates every keystroke reads as unfinished
 * rather than fast.
 *
 * The whole effect is one fade plus a short rise, driven by a single
 * [Animatable] read in the draw phase via [graphicsLayer]. No layout is
 * remeasured and nothing recomposes while it runs, so a screenful of rows costs
 * one extra draw pass rather than N recompositions.
 *
 * [index] staggers siblings. The delay is capped by [maxStagger] on purpose:
 * ungated, a 40-row list would still be dealing itself out a second and a half
 * after the screen opened, which stops being an entrance and becomes a wait.
 * Eight steps of 26ms covers the tallest visible group and everything below the
 * fold arrives together.
 *
 * ### Lazy lists
 * Pass this a **keyed** item and the animation plays once. [rememberSaveable] is
 * scoped to the item key inside `LazyColumn`/`LazyRow`, so a row that scrolls out
 * of view and back is restored as already-played instead of fading in again —
 * which is the single most common way staggered entry animations turn into
 * scroll-jank flicker.
 */
@Composable
fun Modifier.revealIn(
    index: Int = 0,
    distance: Dp = 14.dp,
    stagger: Int = 26,
    maxStagger: Int = 8,
    durationMillis: Int = SiriusMotion.Base
): Modifier {
    // Reduced motion is a promise, not a hint: no fade, no rise, no delay.
    if (SiriusTheme.reduceMotion) return this

    var played by rememberSaveable { mutableStateOf(false) }
    val progress = remember { Animatable(if (played) 1f else 0f) }
    val offsetPx = with(LocalDensity.current) { distance.toPx() }

    LaunchedEffect(Unit) {
        if (played) return@LaunchedEffect
        delay((stagger.toLong() * index.coerceIn(0, maxStagger)))
        progress.animateTo(1f, tween(durationMillis, easing = SiriusMotion.Emphasized))
        played = true
    }

    return graphicsLayer {
        val p = progress.value
        alpha = p
        // Rise only. A scale here would betray the flat surface language: a card
        // growing into place implies depth the design system does not have.
        translationY = (1f - p) * offsetPx
    }
}

/**
 * The press response shared by every tappable surface that is not a button.
 *
 * `SiriusPrimaryButton` and `GlassIconButton` already spring on press; cards and
 * list rows did not, so tapping a project felt inert next to tapping Send. This
 * gives them the same physics with a shallower travel — a row is wide, and the
 * scale that reads as "pushed" on a 48dp button reads as "wobbling" across a
 * full-width card.
 *
 * Ripple is suppressed deliberately. On a near-black flat surface an expanding
 * white circle is the loudest thing on screen and it fights the hairline edges;
 * the scale plus the caller's own tint change carries the feedback instead.
 *
 * [haptic] fires on the click rather than on press-down, so it confirms the
 * action that happened instead of the finger that landed.
 */
@Composable
fun Modifier.pressable(
    onClick: () -> Unit,
    enabled: Boolean = true,
    pressedScale: Float = 0.985f,
    haptic: Boolean = true,
    role: Role = Role.Button
): Modifier {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) pressedScale else 1f,
        animationSpec = siriusSpring(SiriusMotion.SpringGentle),
        label = "pressableScale"
    )

    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            enabled = enabled,
            interactionSource = interaction,
            indication = null,
            role = role
        ) {
            if (haptic) haptics.light()
            onClick()
        }
}

/**
 * [revealIn] for content whose composable does not take a `Modifier`.
 *
 * Most of the app's rows do accept one and should use the modifier directly. The
 * Git, GitHub and Settings lists are built from row composables that never
 * needed a modifier parameter, and threading one through a dozen private
 * signatures to add a fade is a worse trade than one extra layout node per row.
 *
 * A [Column], not a [Box]: a `LazyColumn` item block is a column scope, and
 * several callers put a header, a spacer and a card in one item. Wrapping those
 * in a Box would silently stack all three on top of each other.
 *
 * `fillMaxWidth` because every caller is a full-width list item; a wrapper that
 * shrank to its content would left-align rows that currently stretch.
 */
@Composable
fun Reveal(
    index: Int = 0,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier.fillMaxWidth().revealIn(index),
        content = content
    )
}
