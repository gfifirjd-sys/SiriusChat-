package com.sirius.chat.core.util

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext

/**
 * Composable wrappers around [Formatters] so screens do not have to thread a
 * `Context` through. They read `LocalContext`, which is language-scoped by
 * `ProvideAppLanguage`, so the text follows the in-app language switch.
 */
@Composable
fun relativeTimeText(timestamp: Long): String {
    val context = LocalContext.current
    LocalConfiguration.current // re-read when the locale changes
    return Formatters.relativeTime(context, timestamp)
}

@Composable
fun clockTimeText(timestamp: Long): String {
    val context = LocalContext.current
    LocalConfiguration.current
    return Formatters.clockTime(context, timestamp)
}
