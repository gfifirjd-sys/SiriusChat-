package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.effects.glassSurface

/** Edits a user turn and re-runs the conversation from that point. */
@Composable
fun EditMessageDialog(
    initial: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    val colors = SiriusTheme.colors
    // The dialog exists to be typed in, so the caret starts in the field rather
    // than costing a second tap before the edit can begin.
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .glassSurface(shape = RoundedCornerShape(SiriusRadius.lg), elevation = 24.dp)
                .padding(SiriusSpacing.md)
        ) {
            Text(
                text = stringResource(R.string.chat_edit_title),
                style = MaterialTheme.typography.titleLarge,
                color = colors.textPrimary
            )
            Text(
                text = stringResource(R.string.chat_edit_body),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary
            )
            VSpace(SiriusSpacing.sm)
            SiriusTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = false,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 90.dp, max = 240.dp)
                    .focusRequester(focus)
            )
            VSpace(SiriusSpacing.md)
            Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                SiriusGhostButton(text = stringResource(R.string.action_cancel), onClick = onDismiss, modifier = Modifier.weight(1f))
                SiriusPrimaryButton(
                    text = stringResource(R.string.chat_resend),
                    onClick = { onConfirm(text.trim()) },
                    enabled = text.isNotBlank(),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
