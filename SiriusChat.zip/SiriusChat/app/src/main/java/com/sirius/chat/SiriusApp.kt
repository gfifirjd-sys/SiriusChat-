package com.sirius.chat

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.sirius.chat.core.designsystem.components.SiriusBackground
import com.sirius.chat.core.navigation.Routes
import com.sirius.chat.core.navigation.SiriusBottomBar
import com.sirius.chat.core.navigation.TopLevelDestination
import com.sirius.chat.feature.chat.ChatListScreen
import com.sirius.chat.feature.chat.ChatScreen
import com.sirius.chat.feature.diff.ReviewScreen
import com.sirius.chat.feature.editor.EditorScreen
import com.sirius.chat.feature.files.FilesScreen
import com.sirius.chat.feature.git.GitScreen
import com.sirius.chat.feature.github.GitHubScreen
import com.sirius.chat.feature.home.HomeScreen
import com.sirius.chat.feature.onboarding.OnboardingScreen
import com.sirius.chat.feature.projects.ProjectDetailScreen
import com.sirius.chat.feature.projects.ProjectsScreen
import com.sirius.chat.feature.settings.AboutScreen
import com.sirius.chat.feature.settings.EditorSettingsScreen
import com.sirius.chat.feature.settings.ProvidersScreen
import com.sirius.chat.feature.settings.SettingsScreen

/**
 * Root composable. Top level destinations live behind a floating glass tab bar;
 * everything else is pushed onto the same graph so the back stack stays simple.
 */
@Composable
fun SiriusApp(startWithOnboarding: Boolean) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val topLevel = TopLevelDestination.fromRoute(currentRoute)

    SiriusBackground {
        Scaffold(
            containerColor = Color.Transparent,
            contentColor = androidx.compose.material3.MaterialTheme.colorScheme.onBackground,
            contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0)
        ) { padding ->
            Box(modifier = Modifier.fillMaxSize()) {
                SiriusNavHost(
                    navController = navController,
                    startDestination = if (startWithOnboarding) Routes.ONBOARDING else Routes.HOME,
                    contentPadding = PaddingValues(
                        bottom = if (topLevel != null) 92.dp else padding.calculateBottomPadding()
                    )
                )

                if (topLevel != null) {
                    Box(modifier = Modifier.align(Alignment.BottomCenter)) {
                        SiriusBottomBar(
                            current = topLevel,
                            onSelect = { destination ->
                                navController.navigateTopLevel(destination.route)
                            }
                        )
                    }
                }
            }
        }
    }
}

private fun NavHostController.navigateTopLevel(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
private fun SiriusNavHost(
    navController: NavHostController,
    startDestination: String,
    contentPadding: PaddingValues
) {
    val slideIn = slideInHorizontally(tween(260)) { it / 6 } + fadeIn(tween(220))
    val slideOut = slideOutHorizontally(tween(220)) { -it / 8 } + fadeOut(tween(180))
    val popIn = slideInHorizontally(tween(260)) { -it / 6 } + fadeIn(tween(220))
    val popOut = slideOutHorizontally(tween(220)) { it / 8 } + fadeOut(tween(180))

    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = Modifier.fillMaxSize(),
        enterTransition = { slideIn },
        exitTransition = { slideOut },
        popEnterTransition = { popIn },
        popExitTransition = { popOut }
    ) {
        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                onFinished = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                },
                onOpenProviders = { navController.navigate(Routes.SETTINGS_PROVIDERS) }
            )
        }

        composable(Routes.HOME) {
            HomeScreen(
                onOpenChat = { navController.navigate(Routes.chat(it)) },
                onOpenProjects = { navController.navigate(Routes.PROJECTS) },
                onOpenProject = { navController.navigate(Routes.project(it)) },
                onOpenFiles = { navController.navigateTopLevel(Routes.FILES) },
                onOpenTerminal = { navController.navigateTopLevel(Routes.TERMINAL) },
                onOpenGit = { navController.navigate(Routes.GIT) },
                onOpenGitHub = { navController.navigate(Routes.GITHUB) },
                onOpenProviders = { navController.navigate(Routes.SETTINGS_PROVIDERS) },
                contentPadding = contentPadding
            )
        }

        composable(Routes.CHATS) {
            ChatListScreen(
                onOpenChat = { navController.navigate(Routes.chat(it)) },
                onOpenProviders = { navController.navigate(Routes.SETTINGS_PROVIDERS) },
                contentPadding = contentPadding
            )
        }

        composable(Routes.CHAT) { entry ->
            val sessionId = entry.arguments?.getString("sessionId").orEmpty()
            ChatScreen(
                sessionId = sessionId,
                onBack = { navController.popBackStack() },
                onOpenReview = { navController.navigate(Routes.REVIEW) },
                onOpenProviders = { navController.navigate(Routes.SETTINGS_PROVIDERS) },
                contentPadding = PaddingValues(0.dp)
            )
        }

        composable(Routes.PROJECTS) {
            ProjectsScreen(
                onBack = { navController.popBackStack() },
                onOpenProject = { navController.navigate(Routes.project(it)) },
                contentPadding = contentPadding
            )
        }

        composable(Routes.PROJECT_DETAIL) { entry ->
            val projectId = entry.arguments?.getString("projectId").orEmpty()
            ProjectDetailScreen(
                projectId = projectId,
                onBack = { navController.popBackStack() },
                onOpenChat = { navController.navigate(Routes.chat(it)) },
                onOpenFiles = { navController.navigateTopLevel(Routes.FILES) },
                onOpenEditor = { navController.navigate(Routes.EDITOR) },
                onOpenGit = { navController.navigate(Routes.GIT) },
                onOpenProviders = { navController.navigate(Routes.SETTINGS_PROVIDERS) },
                contentPadding = contentPadding
            )
        }

        composable(Routes.FILES) {
            FilesScreen(
                onOpenEditor = { navController.navigate(Routes.EDITOR) },
                onOpenProjects = { navController.navigate(Routes.PROJECTS) },
                onOpenGit = { navController.navigate(Routes.GIT) },
                contentPadding = contentPadding
            )
        }

        composable(Routes.EDITOR) {
            EditorScreen(
                onBack = { navController.popBackStack() },
                onOpenFiles = { navController.navigateTopLevel(Routes.FILES) },
                contentPadding = PaddingValues(0.dp)
            )
        }

        composable(Routes.REVIEW) {
            ReviewScreen(
                onBack = { navController.popBackStack() },
                contentPadding = PaddingValues(0.dp)
            )
        }

        composable(Routes.GIT) {
            GitScreen(
                onBack = { navController.popBackStack() },
                contentPadding = PaddingValues(0.dp)
            )
        }

        composable(Routes.TERMINAL) {
            TerminalRoute(contentPadding)
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                onOpenProviders = { navController.navigate(Routes.SETTINGS_PROVIDERS) },
                onOpenGitHub = { navController.navigate(Routes.GITHUB) },
                onOpenEditorSettings = { navController.navigate(Routes.SETTINGS_EDITOR) },
                onOpenAbout = { navController.navigate(Routes.ABOUT) },
                contentPadding = contentPadding
            )
        }

        composable(Routes.SETTINGS_PROVIDERS) {
            ProvidersScreen(
                onBack = { navController.popBackStack() },
                contentPadding = PaddingValues(0.dp)
            )
        }

        composable(Routes.GITHUB) {
            GitHubScreen(
                onBack = { navController.popBackStack() },
                contentPadding = PaddingValues(0.dp)
            )
        }

        composable(Routes.SETTINGS_EDITOR) {
            EditorSettingsScreen(
                onBack = { navController.popBackStack() },
                contentPadding = PaddingValues(0.dp)
            )
        }

        composable(Routes.ABOUT) {
            AboutScreen(
                onBack = { navController.popBackStack() },
                contentPadding = PaddingValues(0.dp)
            )
        }
    }
}

@Composable
private fun TerminalRoute(contentPadding: PaddingValues) {
    com.sirius.chat.feature.terminal.TerminalScreen(contentPadding = contentPadding)
}
