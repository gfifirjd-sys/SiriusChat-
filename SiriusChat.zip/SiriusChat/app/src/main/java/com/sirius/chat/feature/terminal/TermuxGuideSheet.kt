package com.sirius.chat.feature.terminal

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.touchTarget
import com.sirius.chat.core.util.rememberHaptics
import kotlinx.coroutines.delay

/**
 * Setup walkthrough for the Termux engine.
 *
 * Every one of the four steps fails silently in a different way — an install
 * from the wrong store, a properties file that was never written, a permission
 * Android grants without a dialog — and the engine only ever reports the last
 * of them. Stating them in order, with the exact line to paste, is the cheapest
 * fix: the commands are long enough that retyping them by hand is where users
 * actually lose the setup, so each one is copyable rather than decorative.
 *
 * Steps that this app can act on carry their own action ([onInstall],
 * [onOpenTermux], [onGrantPermission]); the rest are read and performed inside
 * Termux, which no intent can do on the user's behalf.
 */
@Composable
fun TermuxGuideSheet(
    onInstall: () -> Unit,
    onOpenTermux: (() -> Unit)?,
    onGrantPermission: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors
    SiriusBottomSheet(
        title = stringResource(R.string.terminal_guide_title),
        subtitle = stringResource(R.string.terminal_guide_subtitle),
        onDismiss = onDismiss
    ) {
        // The guide is longer than a short phone on purpose: cutting a step would
        // leave the user with a bridge that reports "cannot reach Termux". The
        // scroll belongs to the sheet, so there is only ever one scroll container.
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            GuideStep(
                index = 1,
                title = stringResource(R.string.terminal_guide_install_title),
                body = stringResource(R.string.terminal_guide_install_body)
            ) {
                // A tappable link rather than plain text: the F-Droid URL is the
                // one part of this step that cannot be paraphrased.
                SiriusGhostButton(
                    text = stringResource(R.string.terminal_guide_link),
                    onClick = onInstall,
                    icon = Icons.AutoMirrored.Rounded.OpenInNew,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            GuideStep(
                index = 2,
                title = stringResource(R.string.terminal_guide_allow_title),
                body = stringResource(R.string.terminal_guide_allow_body)
            ) {
                CopyableCommand(stringResource(R.string.terminal_guide_allow_command))
                // Only offered once Termux exists to be opened; before that the
                // button would lead nowhere and this step is done in step 1.
                onOpenTermux?.let { open ->
                    VSpace(6.dp)
                    SiriusGhostButton(
                        text = stringResource(R.string.terminal_termux_open),
                        onClick = open,
                        icon = Icons.AutoMirrored.Rounded.OpenInNew,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            GuideStep(
                index = 3,
                title = stringResource(R.string.terminal_guide_permission_title),
                body = stringResource(R.string.terminal_guide_permission_body)
            ) {
                SiriusGhostButton(
                    text = stringResource(R.string.terminal_termux_grant),
                    onClick = onGrantPermission,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            GuideStep(
                index = 4,
                title = stringResource(R.string.terminal_guide_select_title),
                body = stringResource(R.string.terminal_guide_select_body)
            ) {
                CopyableCommand(stringResource(R.string.terminal_guide_select_command))
            }

            GuideStep(
                index = null,
                title = stringResource(R.string.terminal_guide_extras_title),
                body = stringResource(R.string.terminal_guide_extras_body)
            ) {
                CopyableCommand(stringResource(R.string.terminal_guide_extras_command))
            }

            VSpace(SiriusSpacing.xs)
            Text(
                text = stringResource(R.string.terminal_guide_footnote),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary,
                modifier = Modifier.padding(horizontal = SiriusSpacing.sm)
            )
        }
    }
}

/**
 * One numbered step.
 *
 * [index] is null for the optional trailing step: numbering something that is
 * not part of the required sequence would imply the setup is unfinished without
 * it.
 */
@Composable
private fun GuideStep(
    index: Int?,
    title: String,
    body: String,
    content: @Composable () -> Unit
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SiriusSpacing.sm, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(SiriusRadius.pill))
                .background(if (index == null) colors.metalBody else colors.primary),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = index?.toString() ?: "\u00B7",
                style = MaterialTheme.typography.labelSmall,
                color = if (index == null) colors.textTertiary else colors.onPrimary
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary
            )
            VSpace(2.dp)
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
            VSpace(8.dp)
            content()
        }
    }
}

/**
 * A shell line the user is meant to run in Termux.
 *
 * Copying is the whole point: these lines contain quoting and `&&` chains that
 * are misretyped far more often than not, and a wrong `termux.properties` line
 * fails as a generic "cannot reach Termux" much later. Scrolls horizontally
 * rather than wrapping, so the command stays readable as one command.
 */
@Composable
private fun CopyableCommand(command: String) {
    val colors = SiriusTheme.colors
    val clipboard = LocalClipboardManager.current
    val haptics = rememberHaptics()
    var copied by remember(command) { mutableStateOf(false) }
    val copyLabel = stringResource(R.string.action_copy)

    LaunchedEffect(copied) {
        if (copied) {
            delay(1600)
            copied = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.sm))
            .background(colors.codeBackground)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 4.dp)
        ) {
            Text(
                text = command,
                style = codeTextStyle(12),
                color = colors.codePlain,
                maxLines = 1
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(end = 4.dp, bottom = 2.dp),
            horizontalArrangement = Arrangement.End
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(SiriusRadius.pill))
                    // One button, one label: the icon and the word next to it are
                    // the same control, so TalkBack announces it once.
                    .clickable(role = Role.Button, onClickLabel = copyLabel) {
                        clipboard.setText(AnnotatedString(command))
                        haptics.light()
                        copied = true
                    }
                    .touchTarget(44.dp)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .semantics(mergeDescendants = true) {}
            ) {
                Icon(
                    imageVector = if (copied) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                    contentDescription = null,
                    tint = if (copied) colors.success else colors.codeComment,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = if (copied) {
                        stringResource(R.string.chat_copied)
                    } else {
                        stringResource(R.string.action_copy)
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (copied) colors.success else colors.codeComment
                )
            }
        }
    }
}
