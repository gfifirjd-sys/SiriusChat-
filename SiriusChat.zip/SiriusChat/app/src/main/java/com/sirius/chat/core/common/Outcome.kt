package com.sirius.chat.core.common

/** Minimal result type; avoids leaking exceptions into the UI layer. */
sealed interface Outcome<out T> {
    data class Success<T>(val value: T) : Outcome<T>
    data class Failure(val message: String, val cause: Throwable? = null) : Outcome<Nothing>

    val valueOrNull: T? get() = (this as? Success)?.value
}

inline fun <T> runCatchingOutcome(block: () -> T): Outcome<T> = try {
    Outcome.Success(block())
} catch (t: Throwable) {
    if (t is kotlinx.coroutines.CancellationException) throw t
    Outcome.Failure(t.message ?: t::class.java.simpleName, t)
}
