package com.sirius.chat.feature.git

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.core.common.Outcome
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.FileDiff
import com.sirius.chat.domain.model.GitCommit
import com.sirius.chat.domain.model.GitFileStatus
import com.sirius.chat.domain.model.GitStatus
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.repository.GitAvailability
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class GitTab { Changes, History, Branches }

/** The file whose diff is on screen, and which side of the index it came from. */
data class GitDiffTarget(val path: String, val staged: Boolean)

/** A commit opened from the history list. */
data class GitCommitDetail(
    val commit: GitCommit,
    val files: List<String> = emptyList(),
    val loadingFiles: Boolean = true
)

data class GitUiState(
    val loading: Boolean = true,
    val availability: GitAvailability? = null,
    val status: GitStatus? = null,
    val project: Project? = null,
    val tab: GitTab = GitTab.Changes,
    val commitMessage: String = "",
    /** Set while a git command runs, so the whole screen can refuse input. */
    val busy: Boolean = false,
    val diffTarget: GitDiffTarget? = null,
    val diff: FileDiff? = null,
    val diffLoading: Boolean = false,
    val commitDetail: GitCommitDetail? = null,
    val message: String? = null
) {
    val ready: Boolean get() = availability is GitAvailability.Ready
    val repositoryPath: String? get() = (availability as? GitAvailability.Ready)?.path
    val canCommit: Boolean
        get() = status?.canCommit == true && commitMessage.isNotBlank() && !busy
}

/**
 * State for the git screen.
 *
 * Git has no change notifications to observe, so this is a read-then-refresh
 * model: every command re-reads status when it finishes, and the screen also
 * refreshes when it comes back to the foreground (the user may have granted
 * all-files access in Settings, or edited files in the editor meanwhile).
 *
 * The project comes from a flow rather than a one-time read, because attaching
 * a folder while this screen is open must turn "no workspace" into a repository
 * without a restart.
 */
class GitViewModel(private val container: AppContainer) : ViewModel() {

    private val _state = MutableStateFlow(GitUiState())
    val state: StateFlow<GitUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                container.settingsRepository.settings,
                container.projectRepository.observeProjects()
            ) { settings, projects ->
                projects.firstOrNull { it.id == settings.activeProjectId && it.hasWorkspace }
                    ?: projects.firstOrNull { it.hasWorkspace }
            }.distinctUntilChanged().collect { project ->
                _state.update { it.copy(project = project) }
                refresh()
            }
        }
    }

    /** Re-reads availability and, when the repository opens, the full status. */
    fun refresh() {
        val treeUri = _state.value.project?.treeUri
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val availability = container.gitRepository.availability(treeUri)
            if (availability !is GitAvailability.Ready || treeUri == null) {
                _state.update {
                    it.copy(loading = false, availability = availability, status = null)
                }
                return@launch
            }
            when (val result = container.gitRepository.status(treeUri)) {
                is Outcome.Success -> _state.update {
                    it.copy(loading = false, availability = availability, status = result.value)
                }

                is Outcome.Failure -> _state.update {
                    it.copy(
                        loading = false,
                        availability = availability,
                        message = result.message
                    )
                }
            }
        }
    }

    /**
     * Points the active project at a folder the user just picked, so the "no
     * workspace" state can be resolved without a trip to the projects screen.
     * A project that already exists is reused rather than duplicated.
     */
    fun attachWorkspace(treeUri: String) {
        viewModelScope.launch {
            val settings = container.settingsRepository.settings.first()
            val existing = container.projectRepository.observeProjects().first()
            val target = existing.firstOrNull { it.id == settings.activeProjectId }
                ?: existing.firstOrNull()
            if (target != null) {
                container.attachWorkspace(target.id, treeUri)
                container.settingsRepository.update { it.copy(activeProjectId = target.id) }
            } else {
                val project = container.createProject(name = "", treeUri = treeUri)
                container.settingsRepository.update { it.copy(activeProjectId = project.id) }
            }
            container.projectContextBuilder.invalidate()
            refresh()
        }
    }

    fun selectTab(tab: GitTab) {
        _state.update { it.copy(tab = tab) }
    }

    fun setCommitMessage(value: String) {
        _state.update { it.copy(commitMessage = value) }
    }

    // ------------------------------------------------------------- commands

    fun initRepository() = command { treeUri ->
        container.gitRepository.init(treeUri)
    }

    fun stage(file: GitFileStatus) = command { treeUri ->
        container.gitRepository.stage(treeUri, listOf(file.path))
    }

    fun unstage(file: GitFileStatus) = command { treeUri ->
        container.gitRepository.unstage(treeUri, listOf(file.path))
    }

    fun discard(file: GitFileStatus) = command { treeUri ->
        container.gitRepository.discard(treeUri, listOf(file.path))
    }

    fun stageAll() {
        val paths = _state.value.status?.files
            ?.filter { it.isDirty }
            ?.map { it.path }
            .orEmpty()
        if (paths.isEmpty()) return
        command { treeUri -> container.gitRepository.stage(treeUri, paths) }
    }

    fun unstageAll() {
        val paths = _state.value.status?.stagedFiles?.map { it.path }.orEmpty()
        if (paths.isEmpty()) return
        command { treeUri -> container.gitRepository.unstage(treeUri, paths) }
    }

    fun discardAll() {
        val paths = _state.value.status?.unstagedFiles?.map { it.path }.orEmpty()
        if (paths.isEmpty()) return
        command { treeUri -> container.gitRepository.discard(treeUri, paths) }
    }

    fun commit(amend: Boolean = false) {
        val message = _state.value.commitMessage
        if (message.isBlank()) return
        command(
            onSuccess = {
                // The message belongs to the commit that just landed; leaving it
                // in the field invites committing it twice.
                _state.update { it.copy(commitMessage = "") }
                container.strings.get(R.string.git_committed)
            }
        ) { treeUri ->
            container.gitRepository.commit(treeUri, message, amend)
        }
    }

    fun createBranch(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        command(
            onSuccess = { container.strings.get(R.string.git_branch_created, trimmed) }
        ) { treeUri -> container.gitRepository.createBranch(treeUri, trimmed) }
    }

    fun checkout(name: String) {
        command(
            onSuccess = { container.strings.get(R.string.git_switched_to, name) }
        ) { treeUri -> container.gitRepository.checkout(treeUri, name) }
    }

    // ----------------------------------------------------------------- diff

    fun openDiff(file: GitFileStatus) {
        // A file that is only staged has nothing to show against the working
        // tree, so the staged side is the one worth opening.
        val staged = file.isStaged && !file.isDirty
        openDiff(GitDiffTarget(file.path, staged))
    }

    fun openDiff(target: GitDiffTarget) {
        val treeUri = _state.value.project?.treeUri ?: return
        _state.update { it.copy(diffTarget = target, diff = null, diffLoading = true) }
        viewModelScope.launch {
            when (val result = container.gitRepository.diff(treeUri, target.path, target.staged)) {
                is Outcome.Success -> _state.update {
                    // Ignore a diff that finished after the sheet moved on.
                    if (it.diffTarget != target) it
                    else it.copy(diff = result.value, diffLoading = false)
                }

                is Outcome.Failure -> _state.update {
                    it.copy(diffLoading = false, message = result.message)
                }
            }
        }
    }

    /** Flips an open diff between the staged and working-tree comparison. */
    fun toggleDiffSide() {
        val target = _state.value.diffTarget ?: return
        openDiff(target.copy(staged = !target.staged))
    }

    fun closeDiff() {
        _state.update { it.copy(diffTarget = null, diff = null, diffLoading = false) }
    }

    // -------------------------------------------------------------- history

    fun openCommit(commit: GitCommit) {
        val treeUri = _state.value.project?.treeUri ?: return
        _state.update { it.copy(commitDetail = GitCommitDetail(commit)) }
        viewModelScope.launch {
            val files = container.gitRepository.commitFiles(treeUri, commit.id)
            _state.update { current ->
                if (current.commitDetail?.commit?.id != commit.id) current
                else current.copy(
                    commitDetail = current.commitDetail.copy(
                        files = files.valueOrNull.orEmpty(),
                        loadingFiles = false
                    )
                )
            }
        }
    }

    fun closeCommit() {
        _state.update { it.copy(commitDetail = null) }
    }

    fun consumeMessage() {
        _state.update { it.copy(message = null) }
    }

    /**
     * Runs one git command against the attached workspace.
     *
     * Every command ends in the same place: a status refresh. Guessing the new
     * state locally would drift from what git actually recorded, and on a phone
     * a second read costs a few milliseconds.
     */
    private fun command(
        onSuccess: (() -> String?)? = null,
        block: suspend (String) -> Outcome<*>
    ) {
        val treeUri = _state.value.project?.treeUri ?: run {
            _state.update { it.copy(message = container.strings.get(R.string.git_no_workspace)) }
            return
        }
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val result = block(treeUri)
            val note = when (result) {
                is Outcome.Failure -> result.message
                else -> onSuccess?.invoke()
            }
            _state.update { it.copy(busy = false, message = note) }
            refresh()
        }
    }
}
