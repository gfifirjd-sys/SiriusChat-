package com.sirius.chat.core.designsystem.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.domain.model.GlassLevel
import kotlin.math.cos
import kotlin.math.sin

/**
 * The orb is Sirius' signature element, and — together with the liquid-metal
 * ring on the primary action — the only ornament the flat design system allows.
 * Every surface around it is inert dark chrome; this is the one thing that
 * glows.
 *
 * Because it is the signature, it is strictly rationed: it only ever marks the
 * assistant itself (its turns, its thinking state, the empty state of a chat).
 * It is never decoration on a card or a list row.
 *
 * It is drawn, not animated as a sprite: a halo, a body lit from the upper-left,
 * two internal pools orbiting out of phase, a rim, and a hard specular dot. All
 * of it is radial gradients, so it renders at 14dp in a message header and at
 * 96dp in an empty state from the same code.
 */
@Composable
fun SiriusOrb(
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    active: Boolean = true,
    core: Color? = null,
    halo: Color? = null,
    contentDescription: String? = null
) {
    val colors = SiriusTheme.colors
    val reduceMotion = SiriusTheme.reduceMotion
    val effectsOff = SiriusTheme.glass == GlassLevel.Off
    val still = reduceMotion || effectsOff || !active

    val coreColor = core ?: colors.primary
    val haloColor = halo ?: colors.secondary

    val phase: State<Float> = if (still) {
        rememberUpdatedState(0.8f)
    } else {
        rememberInfiniteTransition(label = "orb").animateFloat(
            initialValue = 0f,
            targetValue = (2f * Math.PI).toFloat(),
            animationSpec = infiniteRepeatable(
                animation = tween(SiriusMotion.AmbientBreath * 2, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "orbPhase"
        )
    }

    val semantics = if (contentDescription != null) {
        Modifier.clearAndSetSemantics { this.contentDescription = contentDescription }
    } else {
        Modifier
    }

    Box(modifier = modifier.size(size).then(semantics)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val p = phase.value
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val outer = minOf(this.size.width, this.size.height) / 2f
            // Breathing is tiny on purpose: 3% is felt, 10% is a heartbeat GIF.
            val breath = if (still) 1f else 1f + 0.03f * sin(p * 1.6f)
            val body = outer * 0.66f * breath

            if (!effectsOff) {
                drawCircle(
                    brush = Brush.radialGradient(
                        0.00f to haloColor.copy(alpha = 0.34f),
                        0.55f to haloColor.copy(alpha = 0.14f),
                        1.00f to Color.Transparent,
                        center = center,
                        radius = outer
                    ),
                    radius = outer,
                    center = center
                )
            }

            // Body, lit from the upper-left so it agrees with the metal layer's
            // light direction.
            val lit = Offset(center.x - body * 0.34f, center.y - body * 0.40f)
            drawCircle(
                brush = Brush.radialGradient(
                    0.00f to lerp(coreColor, Color.White, 0.55f),
                    0.32f to coreColor,
                    0.74f to lerp(haloColor, Color.Black, 0.18f),
                    1.00f to lerp(coreColor, Color.Black, 0.42f),
                    center = lit,
                    radius = body * 1.5f
                ),
                radius = body,
                center = center
            )

            // Internal weather: two pools orbiting out of phase give the orb the
            // sense that something is happening inside it.
            if (!effectsOff) {
                orbPool(
                    center = Offset(
                        center.x + body * 0.30f * cos(p),
                        center.y + body * 0.30f * sin(p * 0.85f)
                    ),
                    radius = body * 0.62f,
                    color = colors.accent.copy(alpha = 0.38f),
                    clipCenter = center,
                    clipRadius = body
                )
                orbPool(
                    center = Offset(
                        center.x - body * 0.26f * cos(p * 0.7f + 1.2f),
                        center.y + body * 0.24f * sin(p * 1.1f + 0.6f)
                    ),
                    radius = body * 0.54f,
                    color = haloColor.copy(alpha = 0.34f),
                    clipCenter = center,
                    clipRadius = body
                )
            }

            // Rim + specular. The dot is what stops it reading as a flat blob.
            drawCircle(
                brush = Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.55f),
                        Color.White.copy(alpha = 0.06f),
                        Color.Black.copy(alpha = 0.22f)
                    )
                ),
                radius = body,
                center = center,
                style = Stroke(width = (body * 0.055f).coerceAtLeast(0.7f))
            )
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.85f), Color.Transparent),
                    center = lit,
                    radius = body * 0.42f
                ),
                radius = body * 0.42f,
                center = lit
            )
        }
    }
}

/**
 * "The assistant is composing." Three dots that rise in sequence — a shape
 * people already read as typing, so it needs no label. Reduced motion turns it
 * into three static dots of graded opacity rather than freezing mid-cycle.
 */
@Composable
fun SiriusTypingDots(
    modifier: Modifier = Modifier,
    dotSize: Dp = 5.dp,
    color: Color? = null
) {
    val colors = SiriusTheme.colors
    val tint = color ?: colors.primary
    val reduceMotion = SiriusTheme.reduceMotion

    val phase: State<Float> = if (reduceMotion) {
        rememberUpdatedState(0f)
    } else {
        rememberInfiniteTransition(label = "typing").animateFloat(
            initialValue = 0f,
            targetValue = (2f * Math.PI).toFloat(),
            animationSpec = infiniteRepeatable(
                animation = tween(1_200, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "typingPhase"
        )
    }

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(dotSize * 0.6f),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(3) { index ->
            Canvas(modifier = Modifier.size(dotSize * 2f)) {
                val local = phase.value - index * 0.7f
                val wave = if (reduceMotion) 0f else (sin(local) * 0.5f + 0.5f)
                val alpha = if (reduceMotion) 0.9f - index * 0.22f else 0.35f + wave * 0.65f
                val lift = if (reduceMotion) 0f else -wave * this.size.height * 0.16f
                drawCircle(
                    color = tint.copy(alpha = alpha),
                    radius = this.size.minDimension * 0.24f,
                    center = Offset(this.size.width / 2f, this.size.height / 2f + lift)
                )
            }
        }
    }
}

private fun DrawScope.orbPool(
    center: Offset,
    radius: Float,
    color: Color,
    clipCenter: Offset,
    clipRadius: Float
) {
    // A soft radial pool clipped to the sphere. Clipping to a circle path would
    // cost a save layer at every size; keeping the pool inside the body radius
    // by construction is cheaper and visually identical.
    val pulled = Offset(
        clipCenter.x + (center.x - clipCenter.x) * 0.75f,
        clipCenter.y + (center.y - clipCenter.y) * 0.75f
    )
    drawCircle(
        brush = Brush.radialGradient(
            listOf(color, Color.Transparent),
            center = pulled,
            radius = radius
        ),
        radius = clipRadius,
        center = clipCenter
    )
}

private fun lerp(a: Color, b: Color, t: Float): Color = Color(
    red = a.red + (b.red - a.red) * t,
    green = a.green + (b.green - a.green) * t,
    blue = a.blue + (b.blue - a.blue) * t,
    alpha = a.alpha + (b.alpha - a.alpha) * t
)
