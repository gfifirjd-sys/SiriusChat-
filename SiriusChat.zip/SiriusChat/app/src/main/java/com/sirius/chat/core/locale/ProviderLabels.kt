package com.sirius.chat.core.locale

import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.sirius.chat.R
import com.sirius.chat.data.local.preferences.ProviderPresets
import com.sirius.chat.domain.model.ProviderConfig

/**
 * Resolves the display name of a provider.
 *
 * Shipped templates carry a [ProviderConfig.labelKey] instead of a fixed
 * English name so they follow the in-app language; user-created providers keep
 * whatever the user typed.
 */
@StringRes
fun providerLabelResOrNull(labelKey: String?): Int? = when (labelKey) {
    ProviderPresets.CUSTOM_ENDPOINT_LABEL_KEY -> R.string.providers_custom_label
    else -> null
}

/** For composables; follows the locale provided by `ProvideAppLanguage`. */
@Composable
fun providerDisplayLabel(labelKey: String?, fallback: String): String =
    providerLabelResOrNull(labelKey)?.let { stringResource(it) } ?: fallback

/** For ViewModels and other non-composition callers. */
fun providerDisplayLabel(labelKey: String?, fallback: String, strings: StringProvider): String =
    providerLabelResOrNull(labelKey)?.let { strings.get(it) } ?: fallback

/** For composables; follows the locale provided by `ProvideAppLanguage`. */
@Composable
fun ProviderConfig.displayLabel(): String = providerDisplayLabel(labelKey, label)

/** For ViewModels and other non-composition callers. */
fun ProviderConfig.displayLabel(strings: StringProvider): String =
    providerDisplayLabel(labelKey, label, strings)
