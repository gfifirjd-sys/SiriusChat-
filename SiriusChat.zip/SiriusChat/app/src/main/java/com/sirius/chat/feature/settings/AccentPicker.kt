package com.sirius.chat.feature.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Colorize
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.InterfaceAccents
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.util.rememberHaptics
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Interface colour.
 *
 * This is what replaced the Material You switch. A wallpaper-derived scheme is a
 * promise the app cannot keep — the chrome here is a fixed near-black ramp, so
 * whatever came out of the wallpaper only ever landed on four slots anyway, and
 * it was impossible to predict which four. Picking the colour directly is both
 * honest about what changes and instantly checkable, because every swatch is
 * already painted in the colour it applies.
 *
 * The first swatch is the monochrome default, then twelve curated accents, then
 * one that opens hue/saturation/lightness for anything else. The sliders commit
 * on release rather than on every pixel of drag: a settings write per frame would
 * be a hundred DataStore commits per gesture.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AccentColorPicker(
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val presets = InterfaceAccents
    val isPreset = selected != 0 && presets.any { it.toArgb() == selected }
    val custom = selected != 0 && !isPreset

    var customOpen by remember { mutableStateOf(custom) }
    // Seeded from whatever is live, so opening the sliders starts where the eye is
    // rather than jumping to some default red.
    val seed = if (selected == 0) presets.first() else Color(selected)
    val seedHsl = remember(selected) { seed.toHsl() }
    var hue by remember(selected) { mutableFloatStateOf(seedHsl[0]) }
    var saturation by remember(selected) { mutableFloatStateOf(seedHsl[1]) }
    var lightness by remember(selected) { mutableFloatStateOf(seedHsl[2]) }
    val live = Color.hsl(hue.coerceIn(0f, 359.9f), saturation, lightness)

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = stringResource(R.string.settings_accent),
            style = MaterialTheme.typography.labelLarge,
            color = colors.textSecondary
        )
        VSpace(SiriusSpacing.xxs)
        Text(
            text = stringResource(R.string.settings_accent_subtitle),
            style = MaterialTheme.typography.bodySmall,
            color = colors.textTertiary
        )
        VSpace(SiriusSpacing.xs)

        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .selectableGroup(),
            horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
        ) {
            Swatch(
                color = if (colors.isDark) Color(0xFFEDEDED) else Color(0xFF141414),
                selected = selected == 0,
                label = stringResource(R.string.settings_accent_default),
                onClick = {
                    haptics.light()
                    customOpen = false
                    onSelect(0)
                }
            )
            presets.forEach { preset ->
                val argb = preset.toArgb()
                Swatch(
                    color = preset,
                    selected = selected == argb,
                    label = stringResource(R.string.settings_accent_swatch, preset.hexLabel()),
                    onClick = {
                        haptics.light()
                        customOpen = false
                        onSelect(argb)
                    }
                )
            }
            Swatch(
                color = if (custom) Color(selected) else live,
                selected = custom,
                label = stringResource(R.string.settings_accent_custom),
                icon = Icons.Rounded.Colorize,
                onClick = {
                    haptics.light()
                    customOpen = !customOpen
                    if (customOpen) onSelect(live.toArgb())
                }
            )
        }

        AnimatedVisibility(visible = customOpen) {
            Column(modifier = Modifier.fillMaxWidth()) {
                VSpace(SiriusSpacing.sm)
                // A preview strip rather than a number: the swatch above is 40dp
                // and a tint is judged on an area, not on a dot.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .clip(RoundedCornerShape(SiriusRadius.md))
                        .background(live)
                        .padding(horizontal = SiriusSpacing.sm),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = live.hexLabel(),
                        style = MaterialTheme.typography.labelLarge,
                        // Ink follows the preview, exactly like `withAccent` does,
                        // so the strip doubles as a contrast check.
                        color = if (live.luminance() > 0.42f) Color(0xFF0A0A0A) else Color.White
                    )
                }
                VSpace(SiriusSpacing.xs)
                ChannelSlider(
                    label = stringResource(R.string.settings_accent_hue),
                    value = hue,
                    range = 0f..359f,
                    track = Brush.horizontalGradient(
                        (0..6).map { Color.hsl(it * 60f % 360f, saturation, lightness) }
                    ),
                    onChange = { hue = it },
                    onCommit = { onSelect(live.toArgb()) }
                )
                ChannelSlider(
                    label = stringResource(R.string.settings_accent_saturation),
                    value = saturation * 100f,
                    range = 0f..100f,
                    track = Brush.horizontalGradient(
                        listOf(
                            Color.hsl(hue, 0f, lightness),
                            Color.hsl(hue, 1f, lightness)
                        )
                    ),
                    onChange = { saturation = it / 100f },
                    onCommit = { onSelect(live.toArgb()) }
                )
                ChannelSlider(
                    label = stringResource(R.string.settings_accent_lightness),
                    value = lightness * 100f,
                    range = 0f..100f,
                    track = Brush.horizontalGradient(
                        listOf(
                            Color.hsl(hue, saturation, 0.12f),
                            Color.hsl(hue, saturation, 0.5f),
                            Color.hsl(hue, saturation, 0.9f)
                        )
                    ),
                    onChange = { lightness = it / 100f },
                    onCommit = { onSelect(live.toArgb()) }
                )
            }
        }
    }
}

/**
 * One 40dp dot. Selection is a ring that grows *outside* the dot, so the colour
 * itself is never covered by the affordance that says it is chosen.
 */
@Composable
private fun Swatch(
    color: Color,
    selected: Boolean,
    label: String,
    onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    val colors = SiriusTheme.colors
    val ring by animateDpAsState(
        targetValue = if (selected) 2.dp else 1.dp,
        label = "swatchRing"
    )
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(role = Role.RadioButton, onClickLabel = label, onClick = onClick)
            .semantics {
                this.selected = selected
                contentDescription = label
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(if (selected) 34.dp else 32.dp)
                .clip(CircleShape)
                .background(color)
                .border(
                    width = ring,
                    color = if (selected) colors.textPrimary else colors.metalRim,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            val ink = if (color.luminance() > 0.42f) Color(0xFF0A0A0A) else Color.White
            when {
                selected -> Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    tint = ink,
                    modifier = Modifier.size(18.dp)
                )

                icon != null -> Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = ink,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

/** Label, value and a slider whose track is painted in what it controls. */
@Composable
private fun ChannelSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    track: Brush,
    onChange: (Float) -> Unit,
    onCommit: () -> Unit
) {
    val colors = SiriusTheme.colors
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = value.roundToInt().toString(),
                style = MaterialTheme.typography.labelMedium,
                color = colors.textTertiary
            )
        }
        Box(contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(SiriusRadius.pill))
                    .background(track)
            )
            Slider(
                value = value,
                onValueChange = onChange,
                onValueChangeFinished = onCommit,
                valueRange = range,
                colors = SliderDefaults.colors(
                    thumbColor = colors.textPrimary,
                    // The painted strip behind the slider *is* the track.
                    activeTrackColor = Color.Transparent,
                    inactiveTrackColor = Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/** `#RRGGBB`, uppercase, for the preview strip and the swatch labels. */
private fun Color.hexLabel(): String {
    val argb = toArgb()
    return "#%02X%02X%02X".format((argb shr 16) and 0xFF, (argb shr 8) and 0xFF, argb and 0xFF)
}

/**
 * sRGB to HSL, so opening the custom sliders starts from the colour that is
 * currently applied instead of resetting it.
 */
private fun Color.toHsl(): FloatArray {
    val r = red
    val g = green
    val b = blue
    val maxC = max(r, max(g, b))
    val minC = min(r, min(g, b))
    val delta = maxC - minC
    val l = (maxC + minC) / 2f
    if (delta < 1e-4f) return floatArrayOf(0f, 0f, l)
    val s = delta / (1f - abs(2f * l - 1f))
    val h = when (maxC) {
        r -> 60f * (((g - b) / delta) % 6f)
        g -> 60f * (((b - r) / delta) + 2f)
        else -> 60f * (((r - g) / delta) + 4f)
    }
    return floatArrayOf(if (h < 0f) h + 360f else h, s.coerceIn(0f, 1f), l)
}
