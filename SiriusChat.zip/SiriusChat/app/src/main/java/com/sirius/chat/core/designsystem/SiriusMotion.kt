package com.sirius.chat.core.designsystem

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.Composable

/**
 * One place that owns *how* Sirius moves.
 *
 * Before this existed every call site invented its own `tween(120)` or
 * `spring(0.6f)`, so nothing in the app felt like it belonged to the same
 * object. Four durations and three springs cover the whole product:
 *
 *  - [Instant] state flips the user already expects (press, tint swap)
 *  - [Quick]   small reveals that must not delay a tap
 *  - [Base]    the default for anything that changes layout
 *  - [Slow]    full-screen or hero transitions
 *
 * Easing is asymmetric on purpose: things enter with [Emphasized] (fast out of
 * the gate, long soft landing) and leave with [Exit] (slow start, quick away),
 * which is what makes a transition read as intentional rather than linear.
 */
object SiriusMotion {
    const val Instant = 90
    const val Quick = 150
    const val Base = 240
    const val Slow = 380

    /** Ambient loops (background flow, orbs, beams) run on their own clock. */
    const val AmbientSlow = 26_000
    const val AmbientBeam = 3_400
    const val AmbientBreath = 4_200

    /** Enter: leaves immediately, settles gently. */
    val Emphasized: Easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)

    /** Neutral both ways, for color and opacity. */
    val Standard: Easing = CubicBezierEasing(0.3f, 0f, 0.2f, 1f)

    /** Exit: hesitates, then gets out of the way. */
    val Exit: Easing = CubicBezierEasing(0.4f, 0f, 1f, 1f)

    /** No overshoot. Use when the element must land exactly where promised. */
    val SpringPrecise: SpringSpec<Float> =
        spring(dampingRatio = 1f, stiffness = Spring.StiffnessMediumLow)

    /** A single soft overshoot. The default for anything that appears. */
    val SpringGentle: SpringSpec<Float> =
        spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow)

    /** Visible bounce. Reserved for the send button and tab selection. */
    val SpringBouncy: SpringSpec<Float> =
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium)
}

/**
 * A tween that collapses to a single frame when the user asked for reduced
 * motion. Every animated value in the app should go through this or through
 * [SiriusTheme.reduceMotion] directly, so "Reduce motion" is a real promise and
 * not a suggestion.
 */
@Composable
fun <T> siriusTween(
    durationMillis: Int = SiriusMotion.Base,
    easing: Easing = SiriusMotion.Standard
): FiniteAnimationSpec<T> = tween(
    durationMillis = if (SiriusTheme.reduceMotion) 0 else durationMillis,
    easing = easing
)

@Composable
fun siriusSpring(base: SpringSpec<Float> = SiriusMotion.SpringGentle): FiniteAnimationSpec<Float> =
    if (SiriusTheme.reduceMotion) tween(0) else base

/**
 * Fade-through: the shared "one thing replaced another" transition. Reduced
 * motion keeps the cross-fade (it carries meaning) but drops the scale.
 */
@Composable
fun siriusFadeThrough(): Pair<EnterTransition, ExitTransition> {
    val reduce = SiriusTheme.reduceMotion
    val enter = fadeIn(siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)) +
        if (reduce) EnterTransition.None else scaleIn(
            initialScale = 0.94f,
            animationSpec = siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)
        )
    val exit = fadeOut(siriusTween(SiriusMotion.Quick, SiriusMotion.Exit)) +
        if (reduce) ExitTransition.None else scaleOut(
            targetScale = 0.96f,
            animationSpec = siriusTween(SiriusMotion.Quick, SiriusMotion.Exit)
        )
    return enter to exit
}

/** Content that arrives from below: banners, composer rows, new messages. */
@Composable
fun siriusRise(distancePx: Int = 24): Pair<EnterTransition, ExitTransition> {
    val reduce = SiriusTheme.reduceMotion
    val enter = fadeIn(siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)) +
        if (reduce) EnterTransition.None else slideInVertically(
            animationSpec = siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized)
        ) { distancePx }
    val exit = fadeOut(siriusTween(SiriusMotion.Quick, SiriusMotion.Exit)) +
        if (reduce) ExitTransition.None else slideOutVertically(
            animationSpec = siriusTween(SiriusMotion.Quick, SiriusMotion.Exit)
        ) { distancePx / 2 }
    return enter to exit
}
