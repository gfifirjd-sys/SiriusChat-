package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import com.sirius.chat.core.util.ColorTokens

/**
 * Inline markdown: bold, italic, inline code, strikethrough, links and colour
 * swatches. Deliberately single-pass and allocation-light because it runs on
 * every token while an answer streams in.
 *
 * Two things go beyond text styling. Links are real [LinkAnnotation.Url]s, so
 * they are tappable and screen-reader-announced instead of merely being blue.
 * And any colour literal — in code or in prose — gets an inline swatch
 * placeholder, which is the only way `#3B82F6` becomes readable in a chat
 * bubble. The swatch ids are returned rather than resolved here because the
 * chips are composables and this is a pure function.
 */
object InlineMarkdown {

    /** Rendered span text plus the swatch ids it references, in first-use order. */
    data class Inline(
        val text: AnnotatedString,
        val swatches: List<Pair<String, Color>>
    )

    fun render(
        text: String,
        codeColor: Color,
        codeBackground: Color,
        linkColor: Color
    ): Inline {
        val swatches = LinkedHashMap<String, Color>()
        val annotated = buildAnnotatedString {
            var index = 0
            while (index < text.length) {
                when {
                    text.startsWith("**", index) -> {
                        val end = text.indexOf("**", index + 2)
                        if (end > 0) {
                            pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                            appendColorAware(text.substring(index + 2, end), swatches)
                            pop()
                            index = end + 2
                        } else {
                            append(text[index]); index++
                        }
                    }

                    text.startsWith("`", index) -> {
                        val end = text.indexOf('`', index + 1)
                        if (end > 0) {
                            pushStyle(
                                SpanStyle(
                                    fontFamily = FontFamily.Monospace,
                                    color = codeColor,
                                    background = codeBackground
                                )
                            )
                            appendColorAware(text.substring(index + 1, end), swatches)
                            pop()
                            index = end + 1
                        } else {
                            append(text[index]); index++
                        }
                    }

                    text.startsWith("*", index) || text.startsWith("_", index) -> {
                        val marker = text[index]
                        val end = text.indexOf(marker, index + 1)
                        if (end > index + 1 && !text.startsWith("$marker$marker", index)) {
                            pushStyle(SpanStyle(fontStyle = FontStyle.Italic))
                            appendColorAware(text.substring(index + 1, end), swatches)
                            pop()
                            index = end + 1
                        } else {
                            append(text[index]); index++
                        }
                    }

                    text.startsWith("~~", index) -> {
                        val end = text.indexOf("~~", index + 2)
                        if (end > 0) {
                            pushStyle(SpanStyle(textDecoration = TextDecoration.LineThrough))
                            append(text.substring(index + 2, end))
                            pop()
                            index = end + 2
                        } else {
                            append(text[index]); index++
                        }
                    }

                    text.startsWith("[", index) -> {
                        val labelEnd = text.indexOf(']', index)
                        val urlStart = if (labelEnd > 0) labelEnd + 1 else -1
                        if (labelEnd > 0 && urlStart < text.length && text.getOrNull(urlStart) == '(') {
                            val urlEnd = text.indexOf(')', urlStart)
                            if (urlEnd > 0) {
                                val label = text.substring(index + 1, labelEnd)
                                val url = text.substring(urlStart + 1, urlEnd)
                                withLink(
                                    LinkAnnotation.Url(
                                        url = url,
                                        styles = TextLinkStyles(
                                            style = SpanStyle(
                                                color = linkColor,
                                                textDecoration = TextDecoration.Underline
                                            )
                                        )
                                    )
                                ) {
                                    append(label)
                                }
                                index = urlEnd + 1
                            } else {
                                append(text[index]); index++
                            }
                        } else {
                            append(text[index]); index++
                        }
                    }

                    else -> {
                        // Plain run: consume up to the next marker in one go so
                        // colour scanning happens on whole words, not characters.
                        val next = nextMarker(text, index + 1)
                        appendColorAware(text.substring(index, next), swatches)
                        index = next
                    }
                }
            }
        }
        return Inline(annotated, swatches.entries.map { it.key to it.value })
    }

    /** Stable id for a swatch chip: same colour, same key, one map entry. */
    fun swatchId(color: Color): String = "sw:" + color.toArgb().toUInt().toString(16)

    private fun AnnotatedString.Builder.appendColorAware(
        run: String,
        swatches: MutableMap<String, Color>
    ) {
        val matches = ColorTokens.findAll(run)
        if (matches.isEmpty()) {
            append(run)
            return
        }
        var cursor = 0
        for (match in matches) {
            if (match.range.first > cursor) append(run.substring(cursor, match.range.first))
            val id = swatchId(match.color)
            swatches[id] = match.color
            appendInlineContent(id, "\u25FB")
            append(match.text)
            cursor = match.range.last + 1
        }
        if (cursor < run.length) append(run.substring(cursor))
    }

    private fun nextMarker(text: String, from: Int): Int {
        var i = from
        while (i < text.length) {
            when (text[i]) {
                '*', '_', '`', '~', '[' -> return i
                else -> i++
            }
        }
        return text.length
    }
}
