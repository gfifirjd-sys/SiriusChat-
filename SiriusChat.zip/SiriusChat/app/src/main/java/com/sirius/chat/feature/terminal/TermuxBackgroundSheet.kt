package com.sirius.chat.feature.terminal

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.VSpace

/**
 * One-off explanation of why Termux has to be allowed to run in the background.
 *
 * This is the failure users cannot diagnose on their own. Termux is a separate
 * app with its own process: when Android's battery optimiser stops it, the
 * RUN_COMMAND service still exists, the engine still reports itself as
 * available, and commands simply stop coming back. Nothing in either app says
 * why, so the fix — one switch in Termux's own App Info — has to be stated
 * before the first command rather than after the tenth silent failure.
 *
 * Shown once, the first time the Termux engine is selected, and dismissed by a
 * button that persists the flag. It can be reopened from the warning banner,
 * because the setting is the sort of thing an OEM cleaner app silently reverts.
 *
 * Sirius is recommended for the same treatment: the generation service keeps
 * answering with the app in the background, and the same optimiser kills that
 * too.
 */
@Composable
fun TermuxBackgroundSheet(
    siriusUnrestricted: Boolean,
    onOpenTermuxSettings: (() -> Unit)?,
    onOpenSiriusSettings: () -> Unit,
    onUnderstood: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors
    SiriusBottomSheet(
        title = stringResource(R.string.terminal_background_title),
        subtitle = stringResource(R.string.terminal_background_subtitle),
        onDismiss = onDismiss
    ) {
        Text(
            text = stringResource(R.string.terminal_background_why),
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = SiriusSpacing.sm)
        )

        VSpace(SiriusSpacing.sm)

        // The path is spelled out step by step because the label differs between
        // OEM builds ("Unrestricted", "No restrictions", "Allow background
        // activity") and a user who cannot find the word gives up on the feature.
        BackgroundStep(
            index = 1,
            title = stringResource(R.string.terminal_background_step_termux_title),
            body = stringResource(R.string.terminal_background_step_termux_body)
        ) {
            // Null while Termux is absent: App Info for a package that is not
            // installed opens an empty error screen.
            onOpenTermuxSettings?.let { open ->
                SiriusGhostButton(
                    text = stringResource(R.string.terminal_background_open_termux_settings),
                    onClick = open,
                    icon = Icons.AutoMirrored.Rounded.OpenInNew,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        BackgroundStep(
            index = 2,
            title = stringResource(R.string.terminal_background_step_sirius_title),
            body = stringResource(R.string.terminal_background_step_sirius_body)
        ) {
            SiriusGhostButton(
                text = stringResource(
                    if (siriusUnrestricted) {
                        R.string.terminal_background_sirius_ok
                    } else {
                        R.string.terminal_background_open_sirius_settings
                    }
                ),
                onClick = onOpenSiriusSettings,
                icon = Icons.AutoMirrored.Rounded.OpenInNew,
                // Already exempt: the row stays, greyed, so the user can see the
                // step is done instead of wondering whether it was skipped.
                tint = if (siriusUnrestricted) colors.success else null,
                modifier = Modifier.fillMaxWidth()
            )
        }

        VSpace(SiriusSpacing.xs)
        Text(
            text = stringResource(R.string.terminal_background_footnote),
            style = MaterialTheme.typography.bodySmall,
            color = colors.textTertiary,
            modifier = Modifier.padding(horizontal = SiriusSpacing.sm)
        )
        VSpace(SiriusSpacing.sm)
        SiriusPrimaryButton(
            text = stringResource(R.string.terminal_background_understood),
            onClick = onUnderstood,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = SiriusSpacing.sm)
        )
        VSpace(SiriusSpacing.xs)
    }
}

/** One numbered step, laid out like the steps in the Termux setup guide. */
@Composable
private fun BackgroundStep(
    index: Int,
    title: String,
    body: String,
    content: @Composable () -> Unit
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SiriusSpacing.sm, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(SiriusRadius.pill))
                .background(colors.primary),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = index.toString(),
                style = MaterialTheme.typography.labelSmall,
                color = colors.onPrimary
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary
            )
            VSpace(2.dp)
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary
            )
            VSpace(8.dp)
            content()
        }
    }
}
