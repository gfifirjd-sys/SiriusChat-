package com.sirius.chat.core.designsystem.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.effects.beamBorder
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.designsystem.siriusSpring

/**
 * The one text field used by settings, dialogs and search.
 *
 * Focus is expressed the way "live" is expressed everywhere else in the app: the
 * field grows a travelling [beamBorder] and its leading icon warms to the brand
 * colour. That replaces Material's underline entirely, so a focused field looks
 * like it belongs to the same object as the composer. An [isError] field keeps
 * the beam but recolours it, so the error state is never colour-only — it moves.
 */
@Composable
fun SiriusTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    label: String? = null,
    leadingIcon: ImageVector? = null,
    trailing: @Composable (() -> Unit)? = null,
    enabled: Boolean = true,
    singleLine: Boolean = true,
    isPassword: Boolean = false,
    isError: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Done,
    onImeAction: () -> Unit = {}
) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.md)
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val accent = when {
        isError -> colors.error
        focused -> colors.primary
        else -> colors.textTertiary
    }
    val iconAlpha by animateFloatAsState(
        targetValue = if (focused) 1f else 0.72f,
        animationSpec = siriusSpring(),
        label = "fieldIcon"
    )

    Row(
        modifier = modifier
            .softSurface(shape)
            .beamBorder(
                shape = shape,
                active = focused || isError,
                head = if (isError) colors.error else colors.primary,
                tail = if (isError) colors.warning else colors.secondary,
                rim = false
            )
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .heightIn(min = 24.dp)
            .then(
                if (label != null) {
                    Modifier.semantics { contentDescription = label }
                } else {
                    Modifier
                }
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leadingIcon != null) {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                tint = accent.copy(alpha = iconAlpha),
                modifier = Modifier.size(17.dp)
            )
            Spacer(Modifier.width(9.dp))
        }
        Box(modifier = Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(
                    text = placeholder,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textTertiary
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                enabled = enabled,
                singleLine = singleLine,
                interactionSource = interaction,
                // Disabled dims the ink, not the whole node: fading the node also
                // faded the plate and the field stopped looking like a field.
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    color = if (enabled) colors.textPrimary else colors.textPrimary.copy(alpha = 0.5f)
                ),
                cursorBrush = SolidColor(if (isError) colors.error else colors.primary),
                visualTransformation = if (isPassword) {
                    PasswordVisualTransformation()
                } else {
                    VisualTransformation.None
                },
                keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
                keyboardActions = KeyboardActions(
                    onDone = { onImeAction() },
                    onSearch = { onImeAction() },
                    onGo = { onImeAction() }
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}
