package com.sirius.chat.domain.usecase

import com.sirius.chat.R
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.repository.ChatRepository
import java.util.UUID

/** The placeholder title a conversation keeps until the first user message. */
internal fun untitledChatTitle(): String =
    AppStrings.get(R.string.chats_untitled, fallback = "New chat")

/** Creates a conversation with sensible defaults and stores it. */
class CreateSessionUseCase(private val chatRepository: ChatRepository) {
    suspend operator fun invoke(
        providerId: String,
        model: String,
        projectId: String? = null,
        title: String = untitledChatTitle()
    ): ChatSession {
        val now = System.currentTimeMillis()
        val session = ChatSession(
            id = UUID.randomUUID().toString(),
            title = title,
            projectId = projectId,
            providerId = providerId,
            model = model,
            agentMode = true,
            createdAt = now,
            updatedAt = now
        )
        return chatRepository.createSession(session)
    }
}

/**
 * Derives a short human title from the first user message so the history list
 * stays readable without an extra model round-trip.
 */
class DeriveSessionTitleUseCase {
    operator fun invoke(text: String): String {
        val cleaned = text.trim()
            .replace(Regex("\\s+"), " ")
            .removePrefix("#").trim()
        if (cleaned.isEmpty()) return untitledChatTitle()
        val cut = cleaned.take(48)
        return if (cleaned.length > 48) cut.substringBeforeLast(' ', cut) + "\u2026" else cut
    }
}

/** Rolls the transcript back to just before [messageId] for edit / regenerate. */
class RewindConversationUseCase(private val chatRepository: ChatRepository) {
    suspend operator fun invoke(sessionId: String, messageId: String) {
        chatRepository.truncateFrom(sessionId, messageId)
    }
}

/** Builds the list handed to the provider, trimmed to a token-ish budget. */
class BuildPromptUseCase {
    operator fun invoke(history: List<ChatMessage>, maxChars: Int = 24_000): List<ChatMessage> {
        val usable = history.filter {
            it.role != MessageRole.System && it.content.isNotBlank()
        }
        var budget = maxChars
        val result = ArrayList<ChatMessage>(usable.size)
        for (message in usable.asReversed()) {
            budget -= message.content.length
            if (budget < 0 && result.isNotEmpty()) break
            result.add(message)
        }
        return result.asReversed()
    }
}
