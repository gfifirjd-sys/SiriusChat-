package com.sirius.chat.feature.git.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.CallMerge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.components.sheetDragGuard
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassDivider
import com.sirius.chat.core.designsystem.components.InlineBusyRow
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.util.relativeTimeText
import com.sirius.chat.domain.model.GitCommit
import com.sirius.chat.feature.git.GitCommitDetail

/**
 * One commit in the history list.
 *
 * The subject line is the only part shown; a commit body can be a page long and
 * would turn the list into a wall of text. Tapping opens the full message.
 */
@Composable
fun GitCommitRow(
    commit: GitCommit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    val when0 = relativeTimeText(commit.timestamp)
    val label = "${commit.summary}, ${commit.authorName}, $when0"

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.sm))
            .clickable(onClick = onClick)
            .heightIn(min = 56.dp)
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .semantics { contentDescription = label },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = commit.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${commit.shortId} \u00B7 ${commit.authorName} \u00B7 $when0",
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (commit.isMerge) {
            SiriusChip(
                text = stringResource(R.string.git_merge),
                icon = Icons.AutoMirrored.Rounded.CallMerge,
                color = colors.info
            )
        }
    }
}

/** Full message and touched paths for one commit. */
@Composable
fun GitCommitSheet(
    detail: GitCommitDetail,
    onOpenFile: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors
    val commit = detail.commit

    SiriusBottomSheet(
        title = commit.shortId,
        subtitle = relativeTimeText(commit.timestamp),
        onDismiss = onDismiss,
        scrollable = false
    ) {
        Text(
            text = commit.message,
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textPrimary
        )
        Text(
            text = "${commit.authorName} <${commit.authorEmail}>",
            style = MaterialTheme.typography.labelSmall,
            color = colors.textTertiary,
            modifier = Modifier.padding(top = SiriusSpacing.xxs)
        )

        GlassDivider(modifier = Modifier.padding(vertical = SiriusSpacing.xs))

        when {
            detail.loadingFiles -> InlineBusyRow(label = stringResource(R.string.git_commit_files_loading))

            detail.files.isEmpty() -> Text(
                text = stringResource(R.string.git_commit_no_files),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary
            )

            else -> LazyColumn(
                modifier = Modifier
                    .heightIn(max = 280.dp)
                    .sheetDragGuard()
            ) {
                items(detail.files.size, key = { detail.files[it] }) { index ->
                    val path = detail.files[index]
                    Text(
                        text = path,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(SiriusRadius.xs))
                            .clickable { onOpenFile(path) }
                            .heightIn(min = 44.dp)
                            .padding(horizontal = 8.dp, vertical = 12.dp)
                    )
                }
            }
        }
    }
}
