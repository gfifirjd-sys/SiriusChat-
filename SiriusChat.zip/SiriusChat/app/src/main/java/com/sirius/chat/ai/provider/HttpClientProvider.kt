package com.sirius.chat.ai.provider

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * One shared client for the whole app: connection pooling matters a lot on
 * mobile networks, and streaming needs a long read timeout.
 */
object HttpClientProvider {

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.MINUTES)
            .writeTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}
