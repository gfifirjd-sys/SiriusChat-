package com.sirius.chat.data.repository

import com.sirius.chat.core.util.CodeLanguage
import com.sirius.chat.core.util.CodeLanguages
import com.sirius.chat.domain.model.FileNode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** One open editor tab. */
data class EditorTab(
    val documentId: String,
    val name: String,
    val path: String,
    val language: CodeLanguage,
    val savedContent: String,
    val content: String,
    val caret: Int = 0,
    val scrollLine: Int = 0,
    val readOnly: Boolean = false,
    val sizeBytes: Long = 0L
) {
    val dirty: Boolean get() = content != savedContent
}

/**
 * Holds open tabs outside of any ViewModel so the editor keeps its state while
 * the user walks through Files, Chat or Terminal and comes back.
 */
class EditorSessionStore {

    private val _tabs = MutableStateFlow<List<EditorTab>>(emptyList())
    val tabs: StateFlow<List<EditorTab>> = _tabs.asStateFlow()

    private val _activeId = MutableStateFlow<String?>(null)
    val activeId: StateFlow<String?> = _activeId.asStateFlow()

    val hasUnsaved: Boolean get() = _tabs.value.any { it.dirty }

    fun open(node: FileNode, content: String, readOnly: Boolean = false) {
        val existing = _tabs.value.firstOrNull { it.documentId == node.documentId }
        when {
            existing == null -> _tabs.value = _tabs.value + EditorTab(
                documentId = node.documentId,
                name = node.name,
                path = node.path,
                language = CodeLanguages.fromFileName(node.name),
                savedContent = content,
                content = content,
                readOnly = readOnly,
                sizeBytes = node.sizeBytes
            )
            // The file may have been rewritten meanwhile (agent apply, review,
            // another app), so a clean tab has to pick the new text up instead
            // of showing a stale snapshot. Dirty tabs keep the user's work.
            !existing.dirty -> update(node.documentId) {
                it.copy(
                    name = node.name,
                    path = node.path,
                    language = CodeLanguages.fromFileName(node.name),
                    savedContent = content,
                    content = content,
                    caret = it.caret.coerceIn(0, content.length),
                    readOnly = readOnly,
                    sizeBytes = node.sizeBytes
                )
            }
        }
        _activeId.value = node.documentId
    }

    fun activate(documentId: String) {
        if (_tabs.value.any { it.documentId == documentId }) _activeId.value = documentId
    }

    fun update(documentId: String, transform: (EditorTab) -> EditorTab) {
        _tabs.value = _tabs.value.map { if (it.documentId == documentId) transform(it) else it }
    }

    fun close(documentId: String) {
        val remaining = _tabs.value.filterNot { it.documentId == documentId }
        _tabs.value = remaining
        if (_activeId.value == documentId) _activeId.value = remaining.lastOrNull()?.documentId
    }

    /** Closes every tab that lived inside a deleted or moved folder. */
    fun closeUnder(path: String) {
        val folder = path.trimEnd('/')
        if (folder.isEmpty()) return
        val prefix = "$folder/"
        val remaining = _tabs.value.filterNot { it.path == folder || it.path.startsWith(prefix) }
        if (remaining.size == _tabs.value.size) return
        _tabs.value = remaining
        if (remaining.none { it.documentId == _activeId.value }) {
            _activeId.value = remaining.lastOrNull()?.documentId
        }
    }

    /**
     * Reflects a write that happened outside the editor (applying a proposal).
     * Tabs with unsaved edits are left alone so nothing is silently overwritten.
     */
    fun syncExternalWrite(documentId: String, content: String) {
        val tab = tab(documentId) ?: return
        if (tab.dirty) return
        update(documentId) {
            it.copy(
                content = content,
                savedContent = content,
                caret = it.caret.coerceIn(0, content.length)
            )
        }
    }

    fun closeAll() {
        _tabs.value = emptyList()
        _activeId.value = null
    }

    fun tab(documentId: String?): EditorTab? =
        _tabs.value.firstOrNull { it.documentId == documentId }
}
