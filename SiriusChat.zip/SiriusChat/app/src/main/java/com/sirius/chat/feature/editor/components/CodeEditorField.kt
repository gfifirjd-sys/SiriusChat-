package com.sirius.chat.feature.editor.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusPalette
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.util.CodeLanguage
import com.sirius.chat.core.util.SyntaxHighlighter

/** Shared by the gutter and the text so line N sits next to line N. */
private val CodeTopPadding = 8.dp

/**
 * One match of the find bar, in document offsets.
 *
 * The bar keeps the offsets and the field keeps the caret, so a match has to
 * travel between them as data rather than as a shared mutable cursor.
 */
data class EditorMatches(
    val offsets: List<Int> = emptyList(),
    val length: Int = 0,
    val current: Int = -1
) {
    val currentOffset: Int? get() = offsets.getOrNull(current)
}

/**
 * Handle on the text field, so things outside it can type into the document.
 *
 * The quick-symbol bar needs to insert at the caret, and only the field knows
 * where the caret is: a plain `content + "("` from the screen would append to the
 * end of the file, which is the single most annoying way to get a bracket wrong.
 * The controller keeps the [TextFieldValue] (text *and* selection) in one place
 * and hands out edits that respect the current selection.
 */
class CodeEditorController {

    internal var value by mutableStateOf(TextFieldValue(""))
        private set

    internal var onEdit: ((String, Int) -> Unit)? = null

    internal fun set(next: TextFieldValue) {
        value = next
    }

    /** True when the field has been composed and can accept an insert. */
    val ready: Boolean get() = onEdit != null

    /**
     * Replaces the selection with [text] and leaves the caret [caretOffset]
     * characters into what was inserted.
     *
     * [caretOffset] is what makes pairs usable: inserting "()" with an offset of
     * 1 leaves the caret between the brackets, which is where the next character
     * belongs.
     */
    fun insert(text: String, caretOffset: Int = text.length) {
        val current = value
        val start = current.selection.min.coerceIn(0, current.text.length)
        val end = current.selection.max.coerceIn(0, current.text.length)
        val updated = current.text.replaceRange(start, end, text)
        val caret = (start + caretOffset).coerceIn(0, updated.length)
        value = TextFieldValue(text = updated, selection = TextRange(caret))
        onEdit?.invoke(updated, caret)
    }

    /** Deletes one character before the caret, or the selection when there is one. */
    fun backspace() {
        val current = value
        val start = current.selection.min
        val end = current.selection.max
        if (start == end) {
            if (start == 0) return
            val updated = current.text.removeRange(start - 1, start)
            value = TextFieldValue(updated, TextRange(start - 1))
            onEdit?.invoke(updated, start - 1)
        } else {
            val updated = current.text.removeRange(start, end)
            value = TextFieldValue(updated, TextRange(start))
            onEdit?.invoke(updated, start)
        }
    }

    /** Selects [start]..[end] without editing, used to reveal a search match. */
    internal fun select(start: Int, end: Int) {
        val length = value.text.length
        value = value.copy(
            selection = TextRange(start.coerceIn(0, length), end.coerceIn(0, length))
        )
    }
}

@Composable
fun rememberCodeEditorController(documentId: String): CodeEditorController =
    remember(documentId) { CodeEditorController() }

/**
 * Syntax colouring plus search highlighting, applied as a [VisualTransformation]
 * with an identity offset mapping: the underlying text never changes, so the
 * caret and selection keep working exactly like in a plain field.
 *
 * Search hits are drawn here rather than as an overlay because this is the only
 * layer that already knows where every character ended up. The current hit gets a
 * stronger wash than the rest — "all matches" and "the one you are on" are two
 * different questions and one colour cannot answer both.
 */
private class CodeTransformation(
    private val language: CodeLanguage,
    private val palette: SiriusPalette,
    private val matches: EditorMatches
) : VisualTransformation {

    override fun filter(text: AnnotatedString): TransformedText {
        val plain = text.text
        val base = if (plain.length > MAX_LIVE_HIGHLIGHT) {
            text
        } else {
            SyntaxHighlighter.highlight(plain, language, palette)
        }
        if (matches.offsets.isEmpty() || matches.length <= 0) {
            return TransformedText(base, OffsetMapping.Identity)
        }
        val marked = buildAnnotatedString {
            append(base)
            matches.offsets.forEachIndexed { index, start ->
                val end = start + matches.length
                if (start >= 0 && end <= plain.length) {
                    addStyle(
                        SpanStyle(
                            background = if (index == matches.current) {
                                palette.primary.copy(alpha = 0.42f)
                            } else {
                                palette.primary.copy(alpha = 0.16f)
                            }
                        ),
                        start,
                        end
                    )
                }
            }
        }
        return TransformedText(marked, OffsetMapping.Identity)
    }

    private companion object {
        // Highlighting is skipped for very large buffers to protect typing latency.
        const val MAX_LIVE_HIGHLIGHT = 40_000
    }
}

@Composable
fun CodeEditorField(
    documentId: String,
    content: String,
    language: CodeLanguage,
    fontSize: Int,
    showLineNumbers: Boolean,
    wordWrap: Boolean,
    readOnly: Boolean,
    onContentChange: (String, Int) -> Unit,
    modifier: Modifier = Modifier,
    controller: CodeEditorController = rememberCodeEditorController(documentId),
    matches: EditorMatches = EditorMatches()
) {
    val colors = SiriusTheme.colors
    val textStyle = codeTextStyle(fontSize)
    val verticalScroll = rememberScrollState()
    val horizontalScroll = rememberScrollState()
    val focusRequester = remember { FocusRequester() }

    var layout by remember(documentId) { mutableStateOf<TextLayoutResult?>(null) }
    // getLineTop() answers in pixels; the field's own top padding is in dp, and
    // mixing the two put every scroll-to-match a line or two off.
    val topPaddingPx = with(LocalDensity.current) { CodeTopPadding.toPx().toInt() }

    LaunchedEffect(controller, documentId) {
        controller.set(TextFieldValue(content))
        controller.onEdit = onContentChange
    }

    // External edits (undo, replace, format, agent apply) must reach the field.
    LaunchedEffect(content) {
        if (content != controller.value.text) {
            controller.set(
                controller.value.copy(
                    text = content,
                    selection = TextRange(controller.value.selection.start.coerceIn(0, content.length))
                )
            )
        }
    }

    // Stepping through matches is the whole point of "next": select the hit so it
    // is visibly the active one, then bring it on screen. Scrolling without
    // selecting left the user looking at a wash of identical highlights.
    LaunchedEffect(matches.current, matches.offsets, layout) {
        val start = matches.currentOffset ?: return@LaunchedEffect
        val end = (start + matches.length).coerceAtMost(controller.value.text.length)
        controller.select(start, end)
        val result = layout ?: return@LaunchedEffect
        val line = result.getLineForOffset(start.coerceIn(0, result.layoutInput.text.length))
        val top = result.getLineTop(line).toInt() + topPaddingPx
        val viewport = verticalScroll.viewportSize
        // A third of the way down, not pinned to the top edge: the line above a
        // match is usually what tells you whether it is the one you wanted.
        val target = (top - viewport / 3).coerceIn(0, verticalScroll.maxValue)
        verticalScroll.animateScrollTo(target)
        if (!readOnly) {
            runCatching { focusRequester.requestFocus() }
        }
    }

    val lineCount = remember(content) { content.count { it == '\n' } + 1 }
    val gutterWidth by animateFloatAsState(
        targetValue = if (showLineNumbers) 22f + fontSize * 1.4f * lineCount.toString().length / 2 else 0f,
        label = "gutter"
    )

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(colors.codeBackground)
            .verticalScroll(verticalScroll)
            .then(if (wordWrap) Modifier else Modifier.horizontalScroll(horizontalScroll))
            .padding(bottom = 120.dp)
    ) {
        if (showLineNumbers) {
            Column(
                modifier = Modifier
                    .width(gutterWidth.dp)
                    .padding(top = CodeTopPadding, start = 6.dp, end = 6.dp)
            ) {
                repeat(lineCount) { index ->
                    Text(
                        text = "${index + 1}",
                        style = textStyle,
                        color = colors.codeComment,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        Box(
            modifier = if (wordWrap) {
                Modifier.fillMaxWidth()
            } else {
                Modifier.widthIn(min = 260.dp)
            }
        ) {
            BasicTextField(
                value = controller.value,
                onValueChange = { updated ->
                    controller.set(updated)
                    onContentChange(updated.text, updated.selection.start)
                },
                readOnly = readOnly,
                textStyle = textStyle.copy(color = colors.codePlain),
                cursorBrush = SolidColor(colors.primary),
                visualTransformation = CodeTransformation(language, colors, matches),
                onTextLayout = { result -> layout = result },
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(focusRequester)
                    .padding(top = CodeTopPadding, start = 4.dp, end = 12.dp)
            )
        }
    }
}
