package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.int
import com.sirius.chat.ai.agent.string
import com.sirius.chat.ai.agent.stringOrEmpty
import com.sirius.chat.core.util.Formatters
import kotlinx.serialization.json.JsonObject

class ReadFileTool : AgentTool {
    override val name = "read_file"
    override val description = "Read the contents of a file in the workspace."
    override val usage = """{"path": "app/src/main/java/Main.kt"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val path = args.string("path") ?: return AgentToolResult("Missing 'path'.", success = false)
        val node = context.workspace.findByPath(tree, path)
            ?: return AgentToolResult("File not found: $path", success = false)
        if (node.isDirectory) return AgentToolResult("$path is a directory.", success = false)

        val content = context.workspace.readText(tree, node.documentId, maxBytes = 200_000)
        val numbered = content.lineSequence()
            .mapIndexed { index, line -> "${index + 1}\t$line" }
            .joinToString("\n")
        return AgentToolResult("File: $path (${Formatters.fileSize(node.sizeBytes)})\n$numbered")
    }
}

class ListDirectoryTool : AgentTool {
    override val name = "list_directory"
    override val description = "List files and folders of a directory."
    override val usage = """{"path": "app/src/main"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val path = args.stringOrEmpty("path")
        val node = if (path.isBlank() || path == "." || path == "/") {
            context.workspace.rootNode(tree)
        } else {
            context.workspace.findByPath(tree, path)
        } ?: return AgentToolResult("Directory not found: $path", success = false)

        val children = context.workspace.listChildren(tree, node.documentId, node.path)
        if (children.isEmpty()) return AgentToolResult("$path is empty.")
        val listing = children.joinToString("\n") { child ->
            if (child.isDirectory) "dir   ${child.name}/"
            else "file  ${child.name}  ${Formatters.fileSize(child.sizeBytes)}"
        }
        return AgentToolResult("Contents of ${node.path.ifBlank { "/" }}:\n$listing")
    }
}

class SearchFilesTool : AgentTool {
    override val name = "search_files"
    override val description = "Find files whose name contains a substring."
    override val usage = """{"query": "ViewModel", "limit": 40}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val query = args.string("query") ?: return AgentToolResult("Missing 'query'.", success = false)
        val limit = args.int("limit", 40).coerceIn(1, 200)
        val results = context.workspace.searchFiles(tree, query, limit)
        if (results.isEmpty()) return AgentToolResult("No files match '$query'.")
        return AgentToolResult(results.joinToString("\n") { it.path })
    }
}

class SearchTextTool : AgentTool {
    override val name = "search_text"
    override val description = "Search the workspace for a text fragment and return matching lines."
    override val usage = """{"query": "fun onCreate", "limit": 40}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val query = args.string("query") ?: return AgentToolResult("Missing 'query'.", success = false)
        val limit = args.int("limit", 40).coerceIn(1, 200)
        val matches = context.workspace.searchText(tree, query, limit)
        if (matches.isEmpty()) return AgentToolResult("No matches for '$query'.")
        return AgentToolResult(matches.joinToString("\n") { "${it.path}:${it.lineNumber}: ${it.line}" })
    }
}

class AnalyzeProjectTool : AgentTool {
    override val name = "analyze_project"
    override val description = "Summarise the project: size, languages and directory tree."
    override val usage = """{}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val tree = context.treeUri ?: return AgentToolResult("No workspace attached.", success = false)
        val snapshot = context.workspace.snapshot(tree)
        val languages = snapshot.languages.entries.joinToString(", ") { "${it.key} \u00D7 ${it.value}" }
        return AgentToolResult(
            buildString {
                appendLine("Project: ${snapshot.rootName}")
                appendLine("Files: ${snapshot.fileCount}, folders: ${snapshot.directoryCount}, size: ${Formatters.fileSize(snapshot.totalBytes)}")
                appendLine("Languages: $languages")
                appendLine()
                appendLine("Tree:")
                append(snapshot.tree)
                if (snapshot.truncated) appendLine("\u2026 tree truncated \u2026")
            }
        )
    }
}
