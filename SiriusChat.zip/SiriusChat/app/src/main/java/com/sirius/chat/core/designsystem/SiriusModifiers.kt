package com.sirius.chat.core.designsystem

import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Guarantees a control is at least [min] on both axes for *touch* purposes while
 * leaving its painted size alone.
 *
 * Sirius has a lot of deliberately small controls — 13dp message actions, 14dp
 * attachment chips — because dense chrome is part of the look. Small ink is fine;
 * small targets are not. This reserves the accessible 48dp box around the icon
 * and centres the visual inside it, which satisfies the platform guidance
 * without inflating the design.
 *
 * Apply it *inside* the clickable so the clickable inherits the expanded bounds:
 * `Modifier.clickable(...).touchTarget().size(14.dp)`.
 */
fun Modifier.touchTarget(min: Dp = 48.dp): Modifier = layout { measurable, constraints ->
    val placeable = measurable.measure(constraints)
    val minPx = min.roundToPx()
    val width = maxOf(placeable.width, minPx)
    val height = maxOf(placeable.height, minPx)
    layout(width, height) {
        placeable.place(
            x = (width - placeable.width) / 2,
            y = (height - placeable.height) / 2
        )
    }
}
