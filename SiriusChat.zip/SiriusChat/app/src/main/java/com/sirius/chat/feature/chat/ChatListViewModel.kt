package com.sirius.chat.feature.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.Project
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatListUiState(
    val sessions: List<ChatSession> = emptyList(),
    val projects: List<Project> = emptyList(),
    val query: String = "",
    val projectFilter: String? = null,
    /** One-shot text for the toast; consumed by the screen. */
    val message: String? = null,
    /** Sessions the model is answering in right now, including closed ones. */
    val generating: Set<String> = emptySet()
) {
    val filtered: List<ChatSession>
        get() = sessions.filter { session ->
            (projectFilter == null || session.projectId == projectFilter) &&
                (query.isBlank() ||
                    session.title.contains(query, true) ||
                    session.lastMessagePreview.contains(query, true))
        }
}

class ChatListViewModel(private val container: AppContainer) : ViewModel() {

    private val _query = MutableStateFlow("")
    private val _projectFilter = MutableStateFlow<String?>(null)
    private val _message = MutableStateFlow<String?>(null)

    val state: StateFlow<ChatListUiState> = combine(
        container.chatRepository.observeSessions(),
        container.projectRepository.observeProjects(),
        _query,
        _projectFilter,
        _message,
        container.generations.activeSessions
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        ChatListUiState(
            sessions = values[0] as List<ChatSession>,
            projects = values[1] as List<Project>,
            query = values[2] as String,
            projectFilter = values[3] as String?,
            message = values[4] as String?,
            generating = values[5] as Set<String>
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ChatListUiState())

    /** Stops a background run from the list, without opening the chat. */
    fun stopGeneration(sessionId: String) = container.generations.stop(sessionId)

    fun consumeMessage() {
        _message.value = null
    }

    fun onQueryChange(value: String) {
        _query.value = value
    }

    fun onProjectFilter(projectId: String?) {
        _projectFilter.value = projectId
    }

    fun togglePin(session: ChatSession) {
        viewModelScope.launch { container.chatRepository.setPinned(session.id, !session.pinned) }
    }

    fun delete(session: ChatSession) {
        viewModelScope.launch { container.chatRepository.deleteSession(session.id) }
    }

    /**
     * Creates a session and hands its id back.
     *
     * [onNeedsProvider] exists because the provider list starts empty: the old
     * `?: return@launch` made this button do nothing at all on a fresh install,
     * with no message and no navigation. A tap has to end in either a chat or an
     * explanation, never in silence.
     */
    fun newChat(onReady: (String) -> Unit, onNeedsProvider: () -> Unit = {}) {
        viewModelScope.launch {
            val settings = container.settingsRepository.current()
            val providers = container.providerRepository.providers()
            val provider = providers.firstOrNull { it.id == settings.activeProviderId }
                ?: providers.firstOrNull { it.hasKey }
                ?: providers.firstOrNull()
            if (provider == null) {
                _message.value = container.strings.get(R.string.chats_needs_provider)
                onNeedsProvider()
                return@launch
            }
            val session = container.createSession(
                providerId = provider.id,
                model = settings.activeModel.ifBlank { provider.defaultModel },
                projectId = _projectFilter.value ?: settings.activeProjectId.takeIf { it.isNotBlank() },
                title = container.strings.get(R.string.chats_untitled_agent)
            )
            onReady(session.id)
        }
    }
}
