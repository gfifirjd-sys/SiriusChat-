package com.sirius.chat.domain.model

/**
 * The GitHub side of the app.
 *
 * Everything here is a projection of the REST payloads down to the fields the UI
 * and the agent actually use. Keeping the models this narrow is deliberate: the
 * `/user/repos` response alone is ~90 fields per entry, and parsing all of them
 * would mean a schema change every time GitHub adds one.
 */
data class GitHubAccount(
    val login: String,
    val name: String,
    val avatarUrl: String,
    /** From the `x-oauth-scopes` header. Empty for fine-grained tokens. */
    val scopes: List<String>
) {
    val displayName: String get() = name.ifBlank { login }

    /**
     * Classic tokens advertise their scopes, so a missing `repo` can be reported
     * before the first write fails with a 404 that looks like a typo. A
     * fine-grained token sends no scopes at all, and we must not accuse it of
     * being under-privileged.
     */
    val canWriteRepos: Boolean
        get() = scopes.isEmpty() || scopes.any { it == "repo" || it == "public_repo" }

    val canRunWorkflows: Boolean
        get() = scopes.isEmpty() || scopes.any { it == "repo" || it == "workflow" }
}

data class GitHubRepo(
    val owner: String,
    val name: String,
    val isPrivate: Boolean,
    val defaultBranch: String,
    val description: String,
    val htmlUrl: String,
    val updatedAt: String,
    val language: String
) {
    val fullName: String get() = "$owner/$name"
}

/** One entry of a directory listing, or one file's metadata. */
data class GitHubEntry(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val sha: String
)

/** A CI run. [conclusion] is empty while [status] is still `queued`/`in_progress`. */
data class GitHubRun(
    val id: Long,
    val name: String,
    val status: String,
    val conclusion: String,
    val branch: String,
    val htmlUrl: String,
    val createdAt: String,
    val runNumber: Int
) {
    val finished: Boolean get() = status == "completed"
    val succeeded: Boolean get() = conclusion == "success"
}

/** A build output. For this app that is nearly always the APK zip. */
data class GitHubArtifact(
    val id: Long,
    val name: String,
    val sizeBytes: Long,
    val expired: Boolean
)
