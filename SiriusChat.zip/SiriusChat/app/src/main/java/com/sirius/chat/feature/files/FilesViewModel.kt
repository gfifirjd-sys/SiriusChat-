package com.sirius.chat.feature.files

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.core.util.CodeLanguages
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.FileNode
import com.sirius.chat.domain.model.FileSort
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.RecentFile
import com.sirius.chat.domain.model.TextMatch
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

/** Clipboard for file move / copy operations. */
data class FileClipboard(val node: FileNode, val parentId: String, val cut: Boolean)

data class FilesUiState(
    val project: Project? = null,
    val breadcrumbs: List<FileNode> = emptyList(),
    val children: List<FileNode> = emptyList(),
    val sort: FileSort = FileSort.Name,
    val query: String = "",
    val searching: Boolean = false,
    val fileMatches: List<FileNode> = emptyList(),
    val textMatches: List<TextMatch> = emptyList(),
    val loading: Boolean = false,
    val clipboard: FileClipboard? = null,
    val message: String? = null
) {
    val currentDirectory: FileNode? get() = breadcrumbs.lastOrNull()
    val hasWorkspace: Boolean get() = project?.hasWorkspace == true
    val inSearch: Boolean get() = query.isNotBlank()

    val sorted: List<FileNode>
        get() {
            val comparator = when (sort) {
                FileSort.Name -> compareBy<FileNode> { it.name.lowercase() }
                FileSort.Modified -> compareByDescending { it.lastModified }
                FileSort.Size -> compareByDescending { it.sizeBytes }
                FileSort.Type -> compareBy { it.extension }
            }
            return children.sortedWith(compareByDescending<FileNode> { it.isDirectory }.then(comparator))
        }
}

class FilesViewModel(private val container: AppContainer) : ViewModel() {

    private val _state = MutableStateFlow(FilesUiState())
    val state: StateFlow<FilesUiState> = _state.asStateFlow()

    private var searchJob: Job? = null

    init {
        // The active project can be created or re-linked from the Projects screen while
        // this screen is alive, so keep following it instead of reading it once.
        viewModelScope.launch {
            combine(
                container.settingsRepository.settings,
                container.projectRepository.observeProjects()
            ) { settings, projects ->
                projects.firstOrNull { it.id == settings.activeProjectId }
                    ?: projects.firstOrNull { it.hasWorkspace }
            }.distinctUntilChanged().collect { project ->
                val previousTree = _state.value.project?.treeUri
                _state.value = _state.value.copy(project = project)
                val tree = project?.treeUri
                when {
                    tree == null -> _state.value = _state.value.copy(
                        breadcrumbs = emptyList(),
                        children = emptyList(),
                        query = "",
                        fileMatches = emptyList(),
                        textMatches = emptyList(),
                        clipboard = null,
                        loading = false
                    )
                    tree != previousTree -> openRoot(tree)
                }
            }
        }
    }

    private fun openRoot(treeUri: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            val root = container.workspaceRepository.rootNode(treeUri)
            if (root == null) {
                _state.value = _state.value.copy(loading = false, message = container.strings.get(R.string.files_cannot_open_folder))
                return@launch
            }
            val children = container.workspaceRepository.listChildren(treeUri, root.documentId, "")
            _state.value = _state.value.copy(
                breadcrumbs = listOf(root),
                children = children,
                loading = false
            )
        }
    }

    fun reload() {
        val tree = _state.value.project?.treeUri ?: return
        val current = _state.value.currentDirectory ?: return openRoot(tree)
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            val children = container.workspaceRepository
                .listChildren(tree, current.documentId, current.path)
            _state.value = _state.value.copy(children = children, loading = false)
        }
    }

    fun enter(node: FileNode) {
        if (!node.isDirectory) return
        val tree = _state.value.project?.treeUri ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            val children = container.workspaceRepository.listChildren(tree, node.documentId, node.path)
            _state.value = _state.value.copy(
                breadcrumbs = _state.value.breadcrumbs + node,
                children = children,
                loading = false,
                query = ""
            )
        }
    }

    fun navigateTo(index: Int) {
        val crumbs = _state.value.breadcrumbs
        if (index !in crumbs.indices) return
        val tree = _state.value.project?.treeUri ?: return
        val target = crumbs[index]
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true)
            val children = container.workspaceRepository.listChildren(tree, target.documentId, target.path)
            _state.value = _state.value.copy(
                breadcrumbs = crumbs.take(index + 1),
                children = children,
                loading = false
            )
        }
    }

    fun up(): Boolean {
        val crumbs = _state.value.breadcrumbs
        if (crumbs.size <= 1) return false
        navigateTo(crumbs.size - 2)
        return true
    }

    fun setSort(sort: FileSort) {
        _state.value = _state.value.copy(sort = sort)
    }

    fun search(query: String) {
        _state.value = _state.value.copy(query = query)
        searchJob?.cancel()
        val tree = _state.value.project?.treeUri ?: return
        if (query.isBlank()) {
            _state.value = _state.value.copy(fileMatches = emptyList(), textMatches = emptyList(), searching = false)
            return
        }
        searchJob = viewModelScope.launch {
            delay(280)
            _state.value = _state.value.copy(searching = true)
            val files = container.workspaceRepository.searchFiles(tree, query, limit = 60)
            val text = if (query.length >= 3) {
                container.workspaceRepository.searchText(tree, query, limit = 40)
            } else {
                emptyList()
            }
            _state.value = _state.value.copy(fileMatches = files, textMatches = text, searching = false)
        }
    }

    // ------------------------------------------------------------ mutations

    fun createFile(name: String) = mutate { tree, parent ->
        val created = container.workspaceRepository.createFile(tree, parent.documentId, name)
        if (created == null) container.strings.get(R.string.files_could_not_create, name) else null
    }

    fun createFolder(name: String) = mutate { tree, parent ->
        val created = container.workspaceRepository.createDirectory(tree, parent.documentId, name)
        if (created == null) container.strings.get(R.string.files_could_not_create, name) else null
    }

    fun rename(node: FileNode, newName: String) = mutate { tree, _ ->
        val result = container.workspaceRepository.rename(tree, node.documentId, newName)
        // SAF hands back a brand new document id, so an open tab still points at
        // the old name and would fail on save.
        if (result != null) {
            container.editorSessionStore.close(node.documentId)
            if (node.isDirectory) container.editorSessionStore.closeUnder(node.path)
        }
        if (result == null) container.strings.get(R.string.files_could_not_rename, node.name) else null
    }

    fun delete(node: FileNode) = mutate { tree, _ ->
        val ok = container.workspaceRepository.delete(tree, node.documentId)
        // A tab pointing at a deleted document can never be saved again, and
        // deleting a folder takes every file inside it with it.
        if (ok) {
            container.editorSessionStore.close(node.documentId)
            if (node.isDirectory) container.editorSessionStore.closeUnder(node.path)
        }
        if (!ok) container.strings.get(R.string.files_could_not_delete, node.name) else null
    }

    fun copyToClipboard(node: FileNode, cut: Boolean) {
        val parent = _state.value.currentDirectory ?: return
        _state.value = _state.value.copy(clipboard = FileClipboard(node, parent.documentId, cut))
    }

    fun clearClipboard() {
        _state.value = _state.value.copy(clipboard = null)
    }

    fun paste() {
        val clipboard = _state.value.clipboard ?: return
        mutate { tree, parent ->
            val result = if (clipboard.cut) {
                container.workspaceRepository.move(
                    tree, clipboard.node.documentId, clipboard.parentId, parent.documentId
                ).also { moved ->
                    // The old document id and path are gone after a move, so a
                    // tab left over from it could never be saved again.
                    if (moved != null) {
                        container.editorSessionStore.close(clipboard.node.documentId)
                        if (clipboard.node.isDirectory) {
                            container.editorSessionStore.closeUnder(clipboard.node.path)
                        }
                    }
                }
            } else {
                container.workspaceRepository.copy(tree, clipboard.node.documentId, parent.documentId)
            }
            _state.value = _state.value.copy(clipboard = null)
            if (result == null) container.strings.get(R.string.files_could_not_paste, clipboard.node.name) else null
        }
    }

    private fun mutate(block: suspend (String, FileNode) -> String?) {
        val tree = _state.value.project?.treeUri ?: return
        val parent = _state.value.currentDirectory ?: return
        viewModelScope.launch {
            val error = block(tree, parent)
            _state.value = _state.value.copy(message = error)
            reload()
        }
    }

    fun consumeMessage() {
        _state.value = _state.value.copy(message = null)
    }

    // -------------------------------------------------------------- editor

    /** Loads a file into the editor session store and reports whether it worked. */
    fun openInEditor(node: FileNode, onOpened: () -> Unit) {
        val tree = _state.value.project?.treeUri ?: return
        viewModelScope.launch {
            if (!CodeLanguages.isProbablyText(node.name, node.mimeType)) {
                _state.value = _state.value.copy(message = container.strings.get(R.string.files_not_text, node.name))
                return@launch
            }
            val content = container.workspaceRepository.readText(tree, node.documentId)
            container.editorSessionStore.open(
                node = node,
                content = content,
                readOnly = node.sizeBytes > LARGE_FILE_BYTES
            )
            _state.value.project?.let { project ->
                container.projectRepository.rememberFile(
                    RecentFile(
                        documentId = node.documentId,
                        projectId = project.id,
                        name = node.name,
                        path = node.path,
                        openedAt = System.currentTimeMillis()
                    )
                )
            }
            onOpened()
        }
    }

    fun openMatch(match: TextMatch, onOpened: () -> Unit) {
        val tree = _state.value.project?.treeUri ?: return
        viewModelScope.launch {
            val node = container.workspaceRepository.findByPath(tree, match.path) ?: run {
                // Tapping a stale search hit used to do nothing at all.
                _state.value = _state.value.copy(
                    message = container.strings.get(R.string.files_could_not_open, match.path)
                )
                return@launch
            }
            openInEditor(node, onOpened)
        }
    }

    private companion object {
        const val LARGE_FILE_BYTES = 512L * 1024
    }
}
