package com.sirius.chat.core.util

/** A collapsible region of a source file, `startLine` is 0-based. */
data class FoldRegion(val startLine: Int, val endLine: Int, val label: String) {
    val lineCount: Int get() = endLine - startLine
}

/**
 * Very small folding analyser: brace matching for C-like languages and
 * indentation for the rest. Only regions of 2+ lines are reported so the gutter
 * does not fill with noise.
 */
object CodeFolding {

    fun regions(lines: List<String>, language: CodeLanguage): List<FoldRegion> =
        if (language.isBraceLanguage) braceRegions(lines) else indentRegions(lines)

    private fun braceRegions(lines: List<String>): List<FoldRegion> {
        val stack = ArrayDeque<Int>()
        val regions = ArrayList<FoldRegion>()
        lines.forEachIndexed { index, raw ->
            val line = stripStringsAndComments(raw)
            line.forEach { ch ->
                when (ch) {
                    '{' -> stack.addLast(index)
                    '}' -> {
                        val start = stack.removeLastOrNull()
                        if (start != null && index - start >= 2) {
                            regions += FoldRegion(start, index, lines[start].trim().take(60))
                        }
                    }
                }
            }
        }
        return regions.sortedBy { it.startLine }
    }

    private fun indentRegions(lines: List<String>): List<FoldRegion> {
        val regions = ArrayList<FoldRegion>()
        var index = 0
        while (index < lines.size) {
            val line = lines[index]
            if (line.isBlank()) {
                index++
                continue
            }
            val indent = line.indentWidth()
            var end = index + 1
            while (end < lines.size && (lines[end].isBlank() || lines[end].indentWidth() > indent)) end++
            val last = end - 1
            if (last - index >= 2) {
                regions += FoldRegion(index, last, line.trim().take(60))
            }
            index++
        }
        return regions
    }

    private fun String.indentWidth(): Int {
        var width = 0
        for (ch in this) {
            when (ch) {
                ' ' -> width++
                '\t' -> width += 4
                else -> return width
            }
        }
        return width
    }

    private fun stripStringsAndComments(line: String): String {
        val builder = StringBuilder(line.length)
        var inString = false
        var quote = ' '
        var index = 0
        while (index < line.length) {
            val ch = line[index]
            when {
                inString -> {
                    if (ch == '\\') index++
                    else if (ch == quote) inString = false
                }
                ch == '"' || ch == '\'' -> {
                    inString = true
                    quote = ch
                }
                ch == '/' && index + 1 < line.length && line[index + 1] == '/' -> return builder.toString()
                else -> builder.append(ch)
            }
            index++
        }
        return builder.toString()
    }
}
