package com.sirius.chat.core.designsystem.components

import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateDp
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.rememberTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.designsystem.effects.ambientGlow
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.util.rememberHaptics

/** One row of a [MorphMenu]. */
data class MorphMenuItem(
    val icon: ImageVector,
    val label: String,
    val onClick: () -> Unit,
    val enabled: Boolean = true,
    val destructive: Boolean = false,
    /**
     * Marks the current value when the menu is a choice rather than a list of
     * commands (a sort order, say). Carried by a check mark and not by colour
     * alone, so it survives a colour-blind reading and a screen reader.
     */
    val selected: Boolean = false
)

/**
 * A menu that grows out of the control that opened it.
 *
 * The bottom sheet this replaces was correct but wrong-feeling: tapping a 44dp
 * button in the composer threw a full-width panel up from the bottom of the
 * screen, so the eye lost the connection between the thing pressed and the thing
 * that appeared. Here the surface expands from the trigger's own corner — scale,
 * corner radius and opacity all animate from button to panel — and the rows fade
 * in behind it, staggered, so the panel reads as *unfolding* rather than
 * cross-fading into place.
 *
 * The morph is a real transition, not two states: the same [MutableTransitionState]
 * drives entry and exit, so dismissing collapses the panel back into the button
 * instead of blinking out. [SiriusTheme.reduceMotion] flattens every duration to
 * zero, which leaves a plain menu that appears and disappears — correct, just not
 * animated.
 */
@Composable
fun MorphMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    items: List<MorphMenuItem>,
    modifier: Modifier = Modifier,
    minWidth: Dp = 216.dp,
    trigger: @Composable (expanded: Boolean) -> Unit
) {
    Box(modifier = modifier) {
        trigger(expanded)

        // The popup has to outlive `expanded == false` for the collapse to be
        // visible, so the transition state — not the flag — decides when it is
        // torn down.
        val state = remember { MutableTransitionState(false) }
        state.targetState = expanded
        if (state.currentState || state.targetState) {
            val density = LocalDensity.current
            val gapPx = with(density) { SiriusSpacing.xs.roundToPx() }
            val marginPx = with(density) { SiriusSpacing.sm.roundToPx() }
            val provider = remember(gapPx, marginPx) { MorphMenuPosition(gapPx, marginPx) }
            Popup(
                popupPositionProvider = provider,
                onDismissRequest = onDismissRequest,
                // Focusable so back and an outside tap both close it, which is
                // what a menu is expected to do and what the sheet gave for free.
                properties = PopupProperties(focusable = true)
            ) {
                MorphMenuSurface(
                    state = state,
                    items = items,
                    minWidth = minWidth,
                    onDismissRequest = onDismissRequest
                )
            }
        }
    }
}

@Composable
private fun MorphMenuSurface(
    state: MutableTransitionState<Boolean>,
    items: List<MorphMenuItem>,
    minWidth: Dp,
    onDismissRequest: () -> Unit
) {
    val colors = SiriusTheme.colors
    val reduce = SiriusTheme.reduceMotion
    val enterMs = if (reduce) 0 else SiriusMotion.Base
    val exitMs = if (reduce) 0 else SiriusMotion.Quick
    val transition = rememberTransition(state, label = "morphMenu")

    val scale by transition.animateFloat(
        transitionSpec = {
            if (targetState) {
                tween(enterMs, easing = SiriusMotion.Emphasized)
            } else {
                tween(exitMs, easing = SiriusMotion.Exit)
            }
        },
        label = "morphScale"
    ) { isOpen -> if (isOpen) 1f else 0.7f }

    val panelAlpha by transition.animateFloat(
        transitionSpec = {
            if (targetState) {
                tween(enterMs, easing = SiriusMotion.Standard)
            } else {
                tween(exitMs, easing = SiriusMotion.Exit)
            }
        },
        label = "morphAlpha"
    ) { isOpen -> if (isOpen) 1f else 0f }

    // The radius is the other half of the morph: a 44dp circle turning into a
    // panel. Without it the surface only grows, which reads as a zoom rather
    // than a shape becoming another shape.
    val radius by transition.animateDp(
        transitionSpec = {
            if (targetState) {
                tween(enterMs, easing = SiriusMotion.Emphasized)
            } else {
                tween(exitMs, easing = SiriusMotion.Exit)
            }
        },
        label = "morphRadius"
    ) { isOpen -> if (isOpen) SiriusRadius.lg else 26.dp }

    Column(
        modifier = Modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = panelAlpha
                // Bottom-left: the trigger sits under the panel's lower corner,
                // so that is the point the panel has to grow out of.
                transformOrigin = TransformOrigin(0.12f, 1f)
            }
            .widthIn(min = minWidth, max = 320.dp)
            .ambientGlow(
                color = colors.accent,
                shape = RoundedCornerShape(radius),
                radius = 22.dp,
                alpha = 0.18f * panelAlpha
            )
            .glassSurface(shape = RoundedCornerShape(radius), elevation = 18.dp)
            .padding(vertical = SiriusSpacing.xs),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        items.forEachIndexed { index, item ->
            // Stagger: the rows arrive after the surface has started opening, in
            // reading order. All of them leave together — a staggered exit just
            // makes dismissing feel slow.
            val itemAlpha by transition.animateFloat(
                transitionSpec = {
                    if (targetState) {
                        tween(
                            durationMillis = if (reduce) 0 else SiriusMotion.Quick,
                            delayMillis = if (reduce) 0 else 40 + index * 45,
                            easing = SiriusMotion.Standard
                        )
                    } else {
                        tween(if (reduce) 0 else SiriusMotion.Instant, easing = SiriusMotion.Exit)
                    }
                },
                label = "morphItem$index"
            ) { isOpen -> if (isOpen) 1f else 0f }

            MorphMenuRow(
                item = item,
                appear = itemAlpha,
                onClick = {
                    onDismissRequest()
                    item.onClick()
                }
            )
        }
    }
}

@Composable
private fun MorphMenuRow(
    item: MorphMenuItem,
    appear: Float,
    onClick: () -> Unit
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
        label = "morphRowPress"
    )
    val tint = when {
        !item.enabled -> colors.textTertiary
        item.destructive -> colors.error
        item.selected -> colors.primary
        else -> colors.textPrimary
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = appear
                // A few pixels of travel per row is what turns a fade into an
                // unfold; it is deliberately small so nothing overshoots the panel.
                translationX = (1f - appear) * 14.dp.toPx()
            }
            .scale(pressScale)
            .clickable(
                enabled = item.enabled,
                interactionSource = interaction,
                indication = null,
                role = if (item.selected) Role.RadioButton else Role.Button,
                onClickLabel = item.label
            ) {
                haptics.light()
                onClick()
            }
            .heightIn(min = 48.dp)
            .padding(horizontal = SiriusSpacing.md),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = item.icon,
            contentDescription = null,
            tint = if (item.destructive) colors.error else colors.textSecondary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(SiriusSpacing.sm))
        Text(
            text = item.label,
            style = MaterialTheme.typography.bodyLarge,
            color = tint,
            // A menu row is one line by definition: a long translation must
            // truncate, never stack one letter per line in a narrow panel.
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (item.selected) {
            Spacer(Modifier.width(SiriusSpacing.sm))
            Spacer(Modifier.weight(1f))
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = null,
                tint = colors.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * Places the panel above its trigger, aligned to the trigger's leading edge, and
 * flips below only when there is genuinely no room — a menu opened from the
 * composer must not end up under the keyboard.
 */
private class MorphMenuPosition(
    private val gapPx: Int,
    private val marginPx: Int
) : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize
    ): IntOffset {
        val maxX = (windowSize.width - popupContentSize.width - marginPx).coerceAtLeast(marginPx)
        val x = if (layoutDirection == LayoutDirection.Ltr) {
            anchorBounds.left.coerceIn(marginPx, maxX)
        } else {
            (anchorBounds.right - popupContentSize.width).coerceIn(marginPx, maxX)
        }
        val above = anchorBounds.top - popupContentSize.height - gapPx
        val below = anchorBounds.bottom + gapPx
        val maxY = (windowSize.height - popupContentSize.height - marginPx).coerceAtLeast(marginPx)
        val y = if (above >= marginPx) above else below.coerceIn(marginPx, maxY)
        return IntOffset(x, y)
    }
}
