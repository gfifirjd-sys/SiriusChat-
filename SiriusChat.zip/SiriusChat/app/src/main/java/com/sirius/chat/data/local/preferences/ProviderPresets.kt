package com.sirius.chat.data.local.preferences

import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType

/**
 * A ready-made endpoint the user can add from the catalogue.
 *
 * A preset is a starting point, not a fixture: once added it is an ordinary
 * provider the user can rename, re-point, re-model and delete. Nothing here is
 * installed on its own — the list starts empty and stays the user's own.
 */
data class ProviderPreset(
    val config: ProviderConfig,
    /** `false` for engines that run on the phone and answer without a key. */
    val requiresKey: Boolean = true
)

/**
 * Endpoint templates shipped with the app.
 *
 * They contain no credentials: the user supplies a key when adding one. Model
 * ids are starting points, not a fixed list — the editor's connection check asks
 * the endpoint itself what it serves and the user picks from that. Everything
 * except Anthropic speaks the OpenAI protocol, which is why one client covers
 * them all.
 */
object ProviderPresets {

    /**
     * Kept for installs that stored a provider carrying this key before the
     * catalogue existed, so their row still shows a localized name.
     */
    const val CUSTOM_ENDPOINT_LABEL_KEY = "custom_endpoint"

    val all: List<ProviderPreset> = listOf(
        ProviderPreset(
            ProviderConfig(
                id = "openai",
                label = "OpenAI",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.openai.com/v1",
                models = listOf(
                    AiModel("gpt-4o-mini", "GPT-4o mini", 128_000),
                    AiModel("gpt-4o", "GPT-4o", 128_000),
                    AiModel("gpt-4.1-mini", "GPT-4.1 mini", 200_000)
                ),
                defaultModel = "gpt-4o-mini",
                iconKey = "brand-openai"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "anthropic",
                label = "Anthropic",
                type = ProviderType.AnthropicCompatible,
                baseUrl = "https://api.anthropic.com/v1",
                models = listOf(
                    AiModel("claude-3-5-haiku-latest", "Claude 3.5 Haiku", 200_000),
                    AiModel("claude-3-5-sonnet-latest", "Claude 3.5 Sonnet", 200_000),
                    AiModel("claude-sonnet-4-0", "Claude Sonnet 4", 200_000)
                ),
                defaultModel = "claude-3-5-sonnet-latest",
                iconKey = "brand-anthropic"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "google-gemini",
                label = "Google Gemini",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://generativelanguage.googleapis.com/v1beta/openai",
                models = listOf(
                    AiModel("gemini-2.0-flash", "Gemini 2.0 Flash", 1_000_000),
                    AiModel("gemini-2.5-flash", "Gemini 2.5 Flash", 1_000_000),
                    AiModel("gemini-2.5-pro", "Gemini 2.5 Pro", 1_000_000)
                ),
                defaultModel = "gemini-2.5-flash",
                iconKey = "brand-gemini"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "xai",
                label = "xAI Grok",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.x.ai/v1",
                models = listOf(
                    AiModel("grok-3-mini", "Grok 3 mini", 131_000),
                    AiModel("grok-3", "Grok 3", 131_000),
                    AiModel("grok-4", "Grok 4", 256_000)
                ),
                defaultModel = "grok-3",
                iconKey = "brand-xai"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "deepseek",
                label = "DeepSeek",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.deepseek.com/v1",
                models = listOf(
                    AiModel("deepseek-chat", "DeepSeek V3", 64_000),
                    AiModel("deepseek-reasoner", "DeepSeek R1", 64_000)
                ),
                defaultModel = "deepseek-chat",
                iconKey = "brand-deepseek"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "moonshot",
                label = "Moonshot (Kimi)",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.moonshot.ai/v1",
                models = listOf(
                    AiModel("kimi-k2-0905-preview", "Kimi K2", 256_000),
                    AiModel("kimi-k2-turbo-preview", "Kimi K2 Turbo", 256_000),
                    AiModel("moonshot-v1-128k", "Moonshot v1 128K", 128_000)
                ),
                defaultModel = "kimi-k2-0905-preview",
                iconKey = "brand-moonshot"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "zai",
                label = "Z.ai (GLM)",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.z.ai/api/paas/v4",
                models = listOf(
                    AiModel("glm-4.6", "GLM-4.6", 200_000),
                    AiModel("glm-4.5-air", "GLM-4.5 Air", 128_000),
                    AiModel("glm-4.5-flash", "GLM-4.5 Flash", 128_000)
                ),
                defaultModel = "glm-4.6",
                iconKey = "brand-zhipu"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "minimax",
                label = "MiniMax",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.minimax.io/v1",
                models = listOf(
                    AiModel("MiniMax-M2", "MiniMax M2", 200_000),
                    AiModel("MiniMax-Text-01", "MiniMax Text 01", 1_000_000)
                ),
                defaultModel = "MiniMax-M2",
                iconKey = "brand-minimax"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "novita",
                label = "Novita AI",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.novita.ai/v3/openai",
                models = listOf(
                    AiModel("deepseek/deepseek-v3-0324", "DeepSeek V3", 64_000),
                    AiModel("qwen/qwen3-coder-480b-a35b-instruct", "Qwen3 Coder 480B", 262_000),
                    AiModel("meta-llama/llama-3.3-70b-instruct", "Llama 3.3 70B", 128_000)
                ),
                defaultModel = "deepseek/deepseek-v3-0324",
                iconKey = "brand-novita"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "deepinfra",
                label = "DeepInfra",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.deepinfra.com/v1/openai",
                models = listOf(
                    AiModel("deepseek-ai/DeepSeek-V3", "DeepSeek V3", 64_000),
                    AiModel("Qwen/Qwen2.5-Coder-32B-Instruct", "Qwen2.5 Coder 32B", 32_000),
                    AiModel("meta-llama/Llama-3.3-70B-Instruct", "Llama 3.3 70B", 128_000)
                ),
                defaultModel = "deepseek-ai/DeepSeek-V3",
                iconKey = "brand-deepinfra"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "sambanova",
                label = "SambaNova",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.sambanova.ai/v1",
                models = listOf(
                    AiModel("Meta-Llama-3.3-70B-Instruct", "Llama 3.3 70B", 128_000),
                    AiModel("DeepSeek-R1", "DeepSeek R1", 32_000),
                    AiModel("Qwen3-32B", "Qwen3 32B", 32_000)
                ),
                defaultModel = "Meta-Llama-3.3-70B-Instruct",
                iconKey = "brand-sambanova"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "nebius",
                label = "Nebius AI Studio",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.studio.nebius.com/v1",
                models = listOf(
                    AiModel("deepseek-ai/DeepSeek-V3-0324", "DeepSeek V3", 64_000),
                    AiModel("Qwen/Qwen2.5-Coder-32B-Instruct", "Qwen2.5 Coder 32B", 32_000)
                ),
                defaultModel = "deepseek-ai/DeepSeek-V3-0324",
                iconKey = "brand-nebius"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "mistral",
                label = "Mistral",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.mistral.ai/v1",
                models = listOf(
                    AiModel("mistral-small-latest", "Mistral Small", 128_000),
                    AiModel("mistral-large-latest", "Mistral Large", 128_000),
                    AiModel("codestral-latest", "Codestral", 256_000)
                ),
                defaultModel = "mistral-small-latest",
                iconKey = "brand-mistral"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "groq",
                label = "Groq",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.groq.com/openai/v1",
                models = listOf(
                    AiModel("llama-3.3-70b-versatile", "Llama 3.3 70B", 128_000),
                    AiModel("llama-3.1-8b-instant", "Llama 3.1 8B", 128_000),
                    AiModel("openai/gpt-oss-120b", "GPT-OSS 120B", 128_000)
                ),
                defaultModel = "llama-3.3-70b-versatile",
                iconKey = "brand-groq"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "openrouter",
                label = "OpenRouter",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://openrouter.ai/api/v1",
                models = listOf(
                    AiModel("openai/gpt-4o-mini", "GPT-4o mini", 128_000),
                    AiModel("anthropic/claude-3.5-sonnet", "Claude 3.5 Sonnet", 200_000),
                    AiModel("meta-llama/llama-3.3-70b-instruct", "Llama 3.3 70B", 128_000)
                ),
                defaultModel = "openai/gpt-4o-mini",
                iconKey = "brand-openrouter"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "together",
                label = "Together AI",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.together.xyz/v1",
                models = listOf(
                    AiModel("meta-llama/Llama-3.3-70B-Instruct-Turbo", "Llama 3.3 70B Turbo", 128_000),
                    AiModel("Qwen/Qwen2.5-Coder-32B-Instruct", "Qwen2.5 Coder 32B", 32_000)
                ),
                defaultModel = "meta-llama/Llama-3.3-70B-Instruct-Turbo",
                iconKey = "brand-together"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "fireworks",
                label = "Fireworks AI",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.fireworks.ai/inference/v1",
                models = listOf(
                    AiModel(
                        "accounts/fireworks/models/llama-v3p3-70b-instruct",
                        "Llama 3.3 70B",
                        128_000
                    ),
                    AiModel(
                        "accounts/fireworks/models/qwen2p5-coder-32b-instruct",
                        "Qwen2.5 Coder 32B",
                        32_000
                    )
                ),
                defaultModel = "accounts/fireworks/models/llama-v3p3-70b-instruct",
                iconKey = "brand-fireworks"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "perplexity",
                label = "Perplexity",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.perplexity.ai",
                models = listOf(
                    AiModel("sonar", "Sonar", 128_000),
                    AiModel("sonar-pro", "Sonar Pro", 200_000),
                    AiModel("sonar-reasoning", "Sonar Reasoning", 128_000)
                ),
                defaultModel = "sonar",
                iconKey = "brand-perplexity"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "cohere",
                label = "Cohere",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.cohere.ai/compatibility/v1",
                models = listOf(
                    AiModel("command-r-08-2024", "Command R", 128_000),
                    AiModel("command-r-plus-08-2024", "Command R+", 128_000)
                ),
                defaultModel = "command-r-08-2024",
                iconKey = "brand-cohere"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "qwen",
                label = "Qwen (DashScope)",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
                models = listOf(
                    AiModel("qwen-plus", "Qwen Plus", 131_000),
                    AiModel("qwen-max", "Qwen Max", 32_000),
                    AiModel("qwen3-coder-plus", "Qwen3 Coder Plus", 1_000_000)
                ),
                defaultModel = "qwen-plus",
                iconKey = "brand-qwen"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "cerebras",
                label = "Cerebras",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://api.cerebras.ai/v1",
                models = listOf(
                    AiModel("llama-3.3-70b", "Llama 3.3 70B", 128_000),
                    AiModel("llama3.1-8b", "Llama 3.1 8B", 32_000),
                    AiModel("qwen-3-32b", "Qwen 3 32B", 128_000)
                ),
                defaultModel = "llama-3.3-70b",
                iconKey = "brand-cerebras"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "nvidia-nim",
                label = "NVIDIA NIM",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://integrate.api.nvidia.com/v1",
                models = listOf(
                    AiModel("meta/llama-3.3-70b-instruct", "Llama 3.3 70B", 128_000),
                    AiModel("deepseek-ai/deepseek-r1", "DeepSeek R1", 64_000),
                    AiModel("qwen/qwen2.5-coder-32b-instruct", "Qwen2.5 Coder 32B", 32_000)
                ),
                defaultModel = "meta/llama-3.3-70b-instruct",
                iconKey = "brand-nvidia"
            )
        ),
        ProviderPreset(
            ProviderConfig(
                id = "huggingface",
                label = "Hugging Face",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "https://router.huggingface.co/v1",
                models = listOf(
                    AiModel("meta-llama/Llama-3.3-70B-Instruct", "Llama 3.3 70B", 128_000),
                    AiModel("Qwen/Qwen2.5-Coder-32B-Instruct", "Qwen2.5 Coder 32B", 32_000)
                ),
                defaultModel = "meta-llama/Llama-3.3-70B-Instruct",
                iconKey = "brand-huggingface"
            )
        ),
        // The two below serve models from the device or the local network, so
        // they answer without a key at all.
        ProviderPreset(
            ProviderConfig(
                id = "ollama",
                label = "Ollama",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "http://127.0.0.1:11434/v1",
                models = listOf(
                    AiModel("qwen2.5-coder:7b", "Qwen2.5 Coder 7B", 32_000),
                    AiModel("llama3.1:8b", "Llama 3.1 8B", 128_000),
                    AiModel("deepseek-r1:7b", "DeepSeek R1 7B", 64_000)
                ),
                defaultModel = "qwen2.5-coder:7b",
                iconKey = "brand-ollama"
            ),
            requiresKey = false
        ),
        ProviderPreset(
            ProviderConfig(
                id = "lmstudio",
                label = "LM Studio",
                type = ProviderType.OpenAiCompatible,
                baseUrl = "http://127.0.0.1:1234/v1",
                models = listOf(AiModel("local-model", "Local model", 8_000)),
                defaultModel = "local-model",
                iconKey = "brand-lmstudio"
            ),
            requiresKey = false
        )
    )
}
