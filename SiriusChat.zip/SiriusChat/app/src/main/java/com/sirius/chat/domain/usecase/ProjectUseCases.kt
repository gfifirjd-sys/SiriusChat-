package com.sirius.chat.domain.usecase

import com.sirius.chat.R
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.core.util.WorkspaceNames
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.repository.ProjectRepository
import com.sirius.chat.domain.repository.WorkspaceRepository
import java.util.UUID

class CreateProjectUseCase(
    private val projectRepository: ProjectRepository,
    private val workspaceRepository: WorkspaceRepository
) {
    suspend operator fun invoke(
        name: String,
        treeUri: String?,
        description: String = "",
        accentIndex: Int = 0
    ): Project {
        val now = System.currentTimeMillis()
        val label = treeUri?.let { uri ->
            workspaceRepository.persistAccess(uri)
            workspaceRepository.rootNode(uri)?.name.orEmpty()
        }.orEmpty()
        val project = Project(
            id = UUID.randomUUID().toString(),
            // Callers that just picked a folder pass a blank name and get the
            // name the file picker showed the user. They used to derive it
            // themselves from the raw tree uri, which is percent-encoded, so a
            // Cyrillic folder arrived here already ruined.
            name = name.ifBlank {
                label.ifBlank {
                    WorkspaceNames.folderName(treeUri).ifBlank {
                        AppStrings.get(R.string.projects_untitled, fallback = "Untitled project")
                    }
                }
            },
            description = description,
            treeUri = treeUri,
            workspaceLabel = label,
            accentIndex = accentIndex,
            createdAt = now,
            lastOpenedAt = now
        )
        projectRepository.upsert(project)
        return project
    }
}

class AttachWorkspaceUseCase(
    private val projectRepository: ProjectRepository,
    private val workspaceRepository: WorkspaceRepository
) {
    suspend operator fun invoke(projectId: String, treeUri: String): Project? {
        val project = projectRepository.get(projectId) ?: return null
        workspaceRepository.persistAccess(treeUri)
        val label = workspaceRepository.rootNode(treeUri)?.name.orEmpty()
        val updated = project.copy(
            treeUri = treeUri,
            workspaceLabel = label,
            lastOpenedAt = System.currentTimeMillis()
        )
        projectRepository.upsert(updated)
        return updated
    }
}

class DeleteProjectUseCase(
    private val projectRepository: ProjectRepository,
    private val workspaceRepository: WorkspaceRepository
) {
    /** Deletes app-side metadata only; user files are never touched. */
    suspend operator fun invoke(projectId: String, releaseAccess: Boolean) {
        val project = projectRepository.get(projectId)
        if (releaseAccess) project?.treeUri?.let(workspaceRepository::releaseAccess)
        projectRepository.delete(projectId)
    }
}
