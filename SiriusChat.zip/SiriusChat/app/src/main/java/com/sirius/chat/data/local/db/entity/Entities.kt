package com.sirius.chat.data.local.db.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val treeUri: String?,
    val workspaceLabel: String,
    val providerId: String?,
    val model: String?,
    val accentIndex: Int,
    val favorite: Boolean,
    val createdAt: Long,
    val lastOpenedAt: Long
)

@Entity(
    tableName = "recent_files",
    primaryKeys = ["documentId", "projectId"],
    indices = [Index("projectId"), Index("openedAt")]
)
data class RecentFileEntity(
    val documentId: String,
    val projectId: String,
    val name: String,
    val path: String,
    val openedAt: Long,
    val caretOffset: Int,
    val scrollLine: Int
)

@Entity(
    tableName = "chat_sessions",
    indices = [Index("projectId"), Index("updatedAt")]
)
data class ChatSessionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val projectId: String?,
    val providerId: String,
    val model: String,
    val agentMode: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean,
    val draft: String = ""
)

@Entity(
    tableName = "chat_messages",
    indices = [Index("sessionId"), Index("createdAt")],
    foreignKeys = [
        ForeignKey(
            entity = ChatSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val role: String,
    val content: String,
    val createdAt: Long,
    val model: String?,
    val providerId: String?,
    val status: String,
    val error: String?,
    /** JSON encoded attachments; small and read together with the message. */
    val attachmentsJson: String = "[]",
    val toolRunsJson: String = "[]"
)

/** Denormalised counters used by the sessions list. */
data class SessionWithStats(
    val id: String,
    val title: String,
    val projectId: String?,
    val providerId: String,
    val model: String,
    val agentMode: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean,
    val messageCount: Int,
    val lastMessagePreview: String?
)
