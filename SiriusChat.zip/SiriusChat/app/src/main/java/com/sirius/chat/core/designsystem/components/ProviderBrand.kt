package com.sirius.chat.core.designsystem.components

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusTheme

/**
 * The real mark of a real service.
 *
 * Logos come from theSVG (thesvg.org), converted to Android vectors so they
 * stay sharp at any plate size and add nothing to the download but path data.
 * The marks are trademarks of their owners and are used here only to identify
 * the endpoint a request goes to.
 *
 * Most of these ship as single-shape marks, which is why they carry a
 * [brandColor] and are drawn as a tinted icon. A mark that is monochrome by
 * design (OpenAI, Anthropic, xAI, Ollama, OpenRouter) has no colour of its own
 * and follows the theme's ink instead, so it reads in light and dark alike.
 * [multicolor] marks already carry their own palette and are drawn untouched.
 */
enum class ProviderBrand(
    val key: String,
    @DrawableRes val drawable: Int,
    /** Brand names are not translated, so this is plain text, not a resource. */
    val label: String,
    private val brandColor: Color? = null,
    val multicolor: Boolean = false
) {
    OpenAi("brand-openai", R.drawable.brand_openai, "OpenAI"),
    Anthropic("brand-anthropic", R.drawable.brand_anthropic, "Anthropic"),
    GoogleGemini(
        "brand-gemini",
        R.drawable.brand_google_gemini,
        "Google Gemini",
        Color(0xFF8E75B2)
    ),
    XAi("brand-xai", R.drawable.brand_xai, "xAI"),
    DeepSeek("brand-deepseek", R.drawable.brand_deepseek, "DeepSeek", Color(0xFF4D6BFE)),
    Mistral("brand-mistral", R.drawable.brand_mistral, "Mistral", Color(0xFFFA520F)),
    Groq("brand-groq", R.drawable.brand_groq, "Groq", multicolor = true),
    OpenRouter("brand-openrouter", R.drawable.brand_openrouter, "OpenRouter"),
    Together(
        "brand-together",
        R.drawable.brand_togetherdotai,
        "Together AI",
        Color(0xFF0F6FFF)
    ),
    Fireworks(
        "brand-fireworks",
        R.drawable.brand_fireworks,
        "Fireworks AI",
        Color(0xFF6D28D9)
    ),
    Perplexity(
        "brand-perplexity",
        R.drawable.brand_perplexity,
        "Perplexity",
        Color(0xFF1FB8CD)
    ),
    Cohere("brand-cohere", R.drawable.brand_cohere, "Cohere", multicolor = true),
    Qwen("brand-qwen", R.drawable.brand_qwen, "Qwen", Color(0xFF615CED)),
    Ollama("brand-ollama", R.drawable.brand_ollama, "Ollama"),
    LmStudio("brand-lmstudio", R.drawable.brand_lm_studio, "LM Studio", Color(0xFF4F46E5)),
    HuggingFace(
        "brand-huggingface",
        R.drawable.brand_hugging_face,
        "Hugging Face",
        multicolor = true
    ),
    Cerebras("brand-cerebras", R.drawable.brand_cerebras, "Cerebras", Color(0xFFF15A29)),
    Nvidia("brand-nvidia", R.drawable.brand_nvidia, "NVIDIA NIM", Color(0xFF76B900)),
    // Moonshot and DeepInfra ship marks that are black or white by design, so
    // they take the theme's ink like OpenAI's does.
    Moonshot("brand-moonshot", R.drawable.brand_moonshot, "Moonshot Kimi"),
    Zhipu("brand-zhipu", R.drawable.brand_zhipu, "Z.ai GLM", Color(0xFF3859FF)),
    MiniMax("brand-minimax", R.drawable.brand_minimax, "MiniMax", Color(0xFFE73562)),
    Novita("brand-novita", R.drawable.brand_novita, "Novita AI", Color(0xFF23D57C)),
    DeepInfra("brand-deepinfra", R.drawable.brand_deepinfra, "DeepInfra"),
    SambaNova("brand-sambanova", R.drawable.brand_sambanova, "SambaNova", Color(0xFFEE7624)),
    Nebius("brand-nebius", R.drawable.brand_nebius, "Nebius", Color(0xFFDAFF33));

    /**
     * The colour to draw the mark in, or `null` when the mark paints itself.
     *
     * A brand colour is kept unless the theme would swallow it, in which case it
     * is pulled toward the ink just far enough to stay visible. A logo nobody can
     * see is worse for the brand than one a shade off.
     */
    val tint: Color?
        @Composable get() {
            if (multicolor) return null
            val colors = SiriusTheme.colors
            val brand = brandColor ?: return colors.textPrimary
            val light = brand.luminance()
            return when {
                colors.isDark && light < 0.16f -> lerp(brand, Color.White, 0.45f)
                !colors.isDark && light > 0.72f -> lerp(brand, Color.Black, 0.35f)
                else -> brand
            }
        }

    companion object {
        fun fromKey(key: String?): ProviderBrand? =
            key?.let { candidate -> entries.firstOrNull { it.key == candidate } }
    }
}
