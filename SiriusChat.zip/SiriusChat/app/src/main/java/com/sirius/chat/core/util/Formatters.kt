package com.sirius.chat.core.util

import android.content.Context
import com.sirius.chat.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object Formatters {

    /**
     * Date patterns are built per locale instead of once at class-init, because
     * the in-app language switch can change the locale while the process lives.
     */
    private fun localeOf(context: Context): Locale =
        context.resources.configuration.locales[0]

    private fun formatter(context: Context, pattern: String) =
        SimpleDateFormat(pattern, localeOf(context))

    fun relativeTime(
        context: Context,
        timestamp: Long,
        now: Long = System.currentTimeMillis()
    ): String {
        val resources = context.resources
        if (timestamp <= 0L) return resources.getString(R.string.value_placeholder)
        val delta = now - timestamp
        return when {
            delta < TimeUnit.MINUTES.toMillis(1) -> resources.getString(R.string.time_just_now)

            delta < TimeUnit.HOURS.toMillis(1) -> {
                val minutes = TimeUnit.MILLISECONDS.toMinutes(delta).toInt()
                resources.getQuantityString(R.plurals.time_minutes_ago, minutes, minutes)
            }

            delta < TimeUnit.DAYS.toMillis(1) -> {
                val hours = TimeUnit.MILLISECONDS.toHours(delta).toInt()
                resources.getQuantityString(R.plurals.time_hours_ago, hours, hours)
            }

            delta < TimeUnit.DAYS.toMillis(7) -> {
                val days = TimeUnit.MILLISECONDS.toDays(delta).toInt()
                resources.getQuantityString(R.plurals.time_days_ago, days, days)
            }

            else -> formatter(context, "d MMM").format(Date(timestamp))
        }
    }

    fun clockTime(context: Context, timestamp: Long): String =
        formatter(context, "HH:mm").format(Date(timestamp))

    fun fullTime(context: Context, timestamp: Long): String =
        formatter(context, "d MMM yyyy, HH:mm").format(Date(timestamp))

    /** Byte units stay in their conventional form and need no locale. */
    fun fileSize(bytes: Long): String = when {
        bytes < 0 -> "\u2014"
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        bytes < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024))
        else -> String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024 * 1024))
    }

    fun duration(millis: Long): String = when {
        millis < 1000 -> "${millis}ms"
        millis < 60_000 -> String.format(Locale.US, "%.1fs", millis / 1000.0)
        else -> "${millis / 60_000}m ${(millis % 60_000) / 1000}s"
    }

    /**
     * Shortens a workspace path from the *front*.
     *
     * A path is identified by its tail — `.../ui/ChatScreen.kt` says everything,
     * `app/src/main/java/com/…` says nothing. Compose can only ellipsise the end
     * before UI 1.8, so the head is dropped here instead and the leading `…`
     * keeps it honest about being truncated.
     */
    fun shortPath(path: String, maxSegments: Int = 3): String {
        val segments = path.split('/').filter { it.isNotEmpty() }
        if (segments.size <= maxSegments) return path
        return "\u2026/" + segments.takeLast(maxSegments).joinToString("/")
    }

    fun compactNumber(value: Int): String = when {
        value < 1000 -> value.toString()
        value < 1_000_000 -> String.format(Locale.US, "%.1fk", value / 1000.0)
        else -> String.format(Locale.US, "%.1fM", value / 1_000_000.0)
    }
}
