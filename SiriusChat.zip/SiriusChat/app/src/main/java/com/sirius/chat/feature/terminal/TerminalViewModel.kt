package com.sirius.chat.feature.terminal

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.data.repository.TerminalLine
import com.sirius.chat.data.repository.TerminalLineType
import com.sirius.chat.data.terminal.TerminalBackend
import com.sirius.chat.data.terminal.TerminalEvent
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.TerminalEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class TerminalUiState(
    val lines: List<TerminalLine> = emptyList(),
    val history: List<String> = emptyList(),
    val input: String = "",
    val running: Boolean = false,
    val workingDirectory: String = "",
    val lastExitCode: Int? = null,
    val engine: TerminalEngine = TerminalEngine.DeviceShell,
    val backendName: String = "",
    val backendAvailable: Boolean = true,
    /** Why the engine cannot run, already localised by the backend. */
    val backendUnavailableReason: String? = null,
    /** True when Termux is installed but has not granted RUN_COMMAND. */
    val permissionRequired: Boolean = false,
    /** True when the Termux engine is selected but Termux is not installed. */
    val termuxMissing: Boolean = false,
    /** Whether Termux is on the device at all, whichever engine is selected. */
    val termuxInstalled: Boolean = false
)

/**
 * Terminal front-end.
 *
 * Built-ins (`cd`, `clear`, `help`, `pwd`) are handled here; everything else is
 * delegated to the engine selected in settings, so switching between the device
 * shell and Termux is a preference rather than a code path.
 */
class TerminalViewModel(private val container: AppContainer) : ViewModel() {

    private val store = container.terminalSessionStore
    private val settings = container.settingsRepository
    private val strings = container.strings

    private val _input = MutableStateFlow("")
    private val _running = MutableStateFlow(false)
    private val _exitCode = MutableStateFlow<Int?>(null)

    /**
     * Bumped after the user returns from a permission dialog or from Termux, so
     * availability is re-read instead of being cached for the session.
     */
    private val _availability = MutableStateFlow(0)

    private val _engine = MutableStateFlow(TerminalEngine.DeviceShell)

    /**
     * The working directory has to be part of the state stream: as a plain field
     * it only reached the UI when some other flow happened to emit.
     */
    private val _directory = MutableStateFlow(container.terminalHome)
    private val currentDirectory: File get() = _directory.value
    private var job: Job? = null

    private val backend: TerminalBackend get() = container.terminalBackend(_engine.value)

    /** Each engine has its own filesystem, so "home" moves with the engine. */
    private fun home(): File = backend.home ?: container.terminalHome

    private val runState = combine(_running, _exitCode, _availability) { running, exitCode, epoch ->
        Triple(running, exitCode, epoch)
    }

    private val place = combine(_directory, _engine) { directory, engine -> directory to engine }

    val state: StateFlow<TerminalUiState> = combine(
        store.lines,
        store.history,
        _input,
        runState,
        place
    ) { lines, history, input, run, location ->
        val engine = location.second
        val active = container.terminalBackend(engine)
        val reason = active.unavailableReason()
        // One package query per emission, reused by both Termux states below.
        val termuxInstalled = container.termuxBackend.isInstalled()
        TerminalUiState(
            lines = lines,
            history = history,
            input = input,
            running = run.first,
            workingDirectory = location.first.absolutePath,
            lastExitCode = run.second,
            engine = engine,
            backendName = active.displayName,
            backendAvailable = reason == null,
            backendUnavailableReason = reason,
            permissionRequired = engine == TerminalEngine.Termux &&
                termuxInstalled &&
                !container.termuxBackend.hasPermission(),
            // Separate from the permission state on purpose: the two look the
            // same in a log line but need opposite actions, and asking for a
            // permission that no app on the device defines can only fail.
            termuxMissing = engine == TerminalEngine.Termux && !termuxInstalled,
            termuxInstalled = termuxInstalled
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), TerminalUiState())

    /** True until the persisted engine has been applied once. */
    private var engineApplied = false

    init {
        viewModelScope.launch {
            settings.settings
                .map { it.terminalEngine }
                .distinctUntilChanged()
                .collect { engine -> applyEngine(engine) }
        }
    }

    private fun applyEngine(engine: TerminalEngine) {
        // Re-emitting the engine already in use must not touch a running
        // command. The backends are application-wide singletons, so an
        // unconditional stop here killed the live process of a command that had
        // only just started, and the terminal sat on "running" forever.
        if (engineApplied && engine == _engine.value) return

        // A command belongs to the engine that started it; switching engines
        // mid-run would attribute its output to the wrong shell.
        if (engineApplied) stopSilently()

        _engine.value = engine
        val home = home()
        _directory.value = home
        store.setWorkingDirectory(home.absolutePath)
        _exitCode.value = null

        val active = backend
        if (!engineApplied) {
            engineApplied = true
            if (store.lines.value.isEmpty()) {
                store.append(
                    TerminalLineType.System,
                    strings.get(R.string.terminal_banner, active.displayName)
                )
                store.append(TerminalLineType.System, active.description)
                store.append(TerminalLineType.System, strings.get(R.string.terminal_help_hint))
            }
        } else {
            store.append(
                TerminalLineType.System,
                strings.get(R.string.terminal_engine_switched, active.displayName)
            )
            store.append(TerminalLineType.System, active.description)
        }

        active.unavailableReason()?.let { reason ->
            store.append(TerminalLineType.Stderr, reason)
        }
    }

    fun onInputChange(value: String) {
        _input.value = value
    }

    fun recall(command: String) {
        _input.value = command
    }

    fun clear() = store.clear()

    fun setEngine(engine: TerminalEngine) {
        if (engine == _engine.value) return
        viewModelScope.launch { settings.update { it.copy(terminalEngine = engine) } }
    }

    /**
     * Re-reads whether the engine can run. Called after a permission dialog and
     * on every return to the screen, because both Termux's presence and its
     * permission can change while the app sits in the background.
     */
    fun refreshAvailability() {
        _availability.value += 1
    }

    /**
     * Where `RUN_COMMAND` can be toggled by hand.
     *
     * The runtime request is tried first by the screen, but a permission defined
     * by another app is frequently denied without ever showing a dialog, and
     * then this App Info screen — Additional permissions — is the only place it
     * exists. Kept as an intent rather than a launch so the screen starts it
     * from an activity context and can react to it failing.
     */
    fun permissionSettingsIntent() = container.termuxBackend.permissionSettingsIntent()

    /** F-Droid page for Termux; the engine cannot work without the app. */
    fun termuxInstallIntent() = container.termuxBackend.installTermuxIntent()

    /**
     * Termux itself, so `allow-external-apps=true` can be written. Null when
     * Termux is absent, which the caller reports rather than crashing on.
     */
    fun termuxLaunchIntent() = container.termuxBackend.launchTermuxIntent()

    /**
     * Reports a setup action that could not be started at all — a Settings app
     * without the details screen, no browser for the F-Droid page. Written to
     * the log because the button the user just pressed has nowhere else to say
     * that nothing happened.
     */
    fun noteSetupActionUnavailable() {
        store.append(
            TerminalLineType.Stderr,
            strings.get(R.string.terminal_termux_action_unavailable)
        )
    }

    fun stop() {
        // Nothing is running, so there is nothing to report as stopped.
        if (!_running.value && job == null) return
        val active = backend
        stopSilently()
        store.append(TerminalLineType.System, strings.get(R.string.terminal_process_stopped))
        // An engine that cannot kill its process must not let the stopped line
        // imply that it did.
        active.stopNotice?.let { store.append(TerminalLineType.System, it) }
    }

    /**
     * Ends the running command without writing to the log.
     *
     * The engine is killed before the coroutine is cancelled: cancelling first
     * tears down the flow's `awaitClose`, and a long-lived process such as `top`
     * could survive that race and keep running unattached with nothing left
     * holding a handle to it.
     */
    private fun stopSilently() {
        runCatching { backend.stop() }
        job?.cancel()
        job = null
        _running.value = false
    }

    fun run() {
        val command = _input.value.trim()
        if (command.isEmpty() || _running.value) return
        _input.value = ""
        store.rememberCommand(command)
        store.append(TerminalLineType.Command, "${prompt()} $command")

        // The badge belongs to the command that is starting now, not the last one.
        _exitCode.value = null
        if (handleBuiltIn(command)) return

        // Set before launching. viewModelScope.launch dispatches on the main
        // thread and may run the body before `job` is assigned, so a stop
        // arriving in that window has to already see the running state.
        _running.value = true
        val engine = backend
        val started = viewModelScope.launch {
            try {
                engine.execute(command, currentDirectory).collect { event ->
                    when (event) {
                        is TerminalEvent.Started -> Unit
                        is TerminalEvent.Stdout -> store.append(TerminalLineType.Stdout, event.line)
                        is TerminalEvent.Stderr -> store.append(TerminalLineType.Stderr, event.line)
                        is TerminalEvent.Notice -> store.append(TerminalLineType.System, event.message)
                        is TerminalEvent.Failed -> store.append(TerminalLineType.Stderr, event.reason)
                        is TerminalEvent.Exited -> {
                            _exitCode.value = event.code
                            if (event.code != 0) {
                                store.append(
                                    TerminalLineType.System,
                                    strings.get(
                                        R.string.terminal_exit_with_duration,
                                        event.code,
                                        event.durationMs
                                    )
                                )
                            }
                        }
                    }
                }
            } finally {
                // finally, so an exception or a cancellation clears the running
                // state too. Leaving it set is what kept the UI on "running"
                // with no way back except restarting the screen.
                _running.value = false
                job = null
            }
        }
        // Only claim the job if nothing else took over while it was starting.
        if (_running.value) job = started else started.cancel()
    }

    private fun prompt(): String = "${currentDirectory.name} $"

    private fun handleBuiltIn(command: String): Boolean = when {
        command == "clear" || command == "cls" -> {
            store.clear()
            true
        }

        command == "help" -> {
            val active = backend
            store.append(
                TerminalLineType.System,
                buildString {
                    appendLine(strings.get(R.string.terminal_help_builtins))
                    appendLine(strings.get(R.string.terminal_help_backend, active.displayName))
                    appendLine(strings.get(R.string.terminal_help_cwd, currentDirectory.absolutePath))
                    append(
                        if (active.filesystemVisible) {
                            strings.get(R.string.terminal_help_sandbox)
                        } else {
                            strings.get(R.string.terminal_help_external_engine)
                        }
                    )
                }
            )
            true
        }

        // `pwd` is deliberately NOT intercepted: it is a real command and must
        // report the directory the engine actually runs in. Answering it from
        // local state hid any drift between the two.

        // "cdate" or "cdn" are ordinary commands, only a bare "cd" is built in.
        command == "cd" || command.startsWith("cd ") -> {
            val target = command.removePrefix("cd").trim()
            val next = when {
                target.isEmpty() || target == "~" -> home()
                target == "." -> currentDirectory
                target == ".." -> currentDirectory.parentFile ?: currentDirectory
                target.startsWith("/") -> File(target)
                target.startsWith("~/") -> File(home(), target.removePrefix("~/"))
                else -> File(currentDirectory, target)
            }
            // An engine running under another uid has an opaque filesystem, so
            // the path is taken on trust and the engine reports the failure.
            if (!backend.filesystemVisible || next.isDirectory) {
                val resolved = runCatching { next.canonicalFile }.getOrDefault(next)
                _directory.value = resolved
                store.setWorkingDirectory(resolved.absolutePath)
                store.append(TerminalLineType.System, resolved.absolutePath)
            } else {
                store.append(
                    TerminalLineType.Stderr,
                    strings.get(R.string.terminal_cd_not_found, target)
                )
            }
            true
        }

        else -> false
    }

    override fun onCleared() {
        super.onCleared()
        // The backends outlive this ViewModel, so cancelling the coroutine alone
        // would strand the OS process: `top` would keep burning CPU with nothing
        // left to read or kill it. Kill the process first, then the collector.
        stopSilently()
    }
}
