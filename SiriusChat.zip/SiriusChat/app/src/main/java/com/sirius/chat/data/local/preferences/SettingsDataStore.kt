package com.sirius.chat.data.local.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.GlassLevel
import com.sirius.chat.domain.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "sirius_settings")

/** Single source of truth for user preferences. */
class SettingsDataStore(private val context: Context) {

    private object Keys {
        val language = stringPreferencesKey("app_language")
        val themeMode = stringPreferencesKey("theme_mode")
        val accentColor = intPreferencesKey("accent_color")
        val glassLevel = stringPreferencesKey("glass_level")
        val reduceMotion = booleanPreferencesKey("reduce_motion")
        val haptics = booleanPreferencesKey("haptics")
        val streaming = booleanPreferencesKey("streaming")
        val activeProviderId = stringPreferencesKey("active_provider")
        val activeModel = stringPreferencesKey("active_model")
        val temperature = floatPreferencesKey("temperature")
        val maxTokens = intPreferencesKey("max_tokens")
        val agentAutoApproveReads = booleanPreferencesKey("agent_auto_reads")
        val agentMaxSteps = intPreferencesKey("agent_max_steps")
        val editorFontSize = intPreferencesKey("editor_font_size")
        val editorTabSize = intPreferencesKey("editor_tab_size")
        val editorWordWrap = booleanPreferencesKey("editor_word_wrap")
        val editorLineNumbers = booleanPreferencesKey("editor_line_numbers")
        val editorAutoSave = booleanPreferencesKey("editor_auto_save")
        val terminalFontSize = intPreferencesKey("terminal_font_size")
        val terminalEngine = stringPreferencesKey("terminal_engine")
        val activeProjectId = stringPreferencesKey("active_project")
        val githubRepo = stringPreferencesKey("github_repo")
        val onboardingDone = booleanPreferencesKey("onboarding_done")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { it.toSettings() }

    suspend fun current(): AppSettings = settings.first()

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { prefs ->
            val updated = transform(prefs.toSettings())
            prefs[Keys.language] = updated.language.name
            prefs[Keys.themeMode] = updated.themeMode.name
            prefs[Keys.accentColor] = updated.accentColor
            prefs[Keys.glassLevel] = updated.glassLevel.name
            prefs[Keys.reduceMotion] = updated.reduceMotion
            prefs[Keys.haptics] = updated.hapticsEnabled
            prefs[Keys.streaming] = updated.streamingEnabled
            prefs[Keys.activeProviderId] = updated.activeProviderId
            prefs[Keys.activeModel] = updated.activeModel
            prefs[Keys.temperature] = updated.temperature
            prefs[Keys.maxTokens] = updated.maxTokens
                prefs[Keys.agentAutoApproveReads] = updated.agentAutoApproveReads
            prefs[Keys.agentMaxSteps] = updated.agentMaxSteps
            prefs[Keys.editorFontSize] = updated.editorFontSize
            prefs[Keys.editorTabSize] = updated.editorTabSize
            prefs[Keys.editorWordWrap] = updated.editorWordWrap
            prefs[Keys.editorLineNumbers] = updated.editorLineNumbers
            prefs[Keys.editorAutoSave] = updated.editorAutoSave
            prefs[Keys.terminalFontSize] = updated.terminalFontSize
            prefs[Keys.terminalEngine] = updated.terminalEngine.name
            prefs[Keys.activeProjectId] = updated.activeProjectId
            prefs[Keys.githubRepo] = updated.githubRepo
            prefs[Keys.onboardingDone] = updated.onboardingDone
        }
    }

    private fun Preferences.toSettings(): AppSettings {
        val defaults = AppSettings()
        return AppSettings(
            language = enumOrDefault(this[Keys.language], defaults.language),
            themeMode = enumOrDefault(this[Keys.themeMode], defaults.themeMode),
            accentColor = this[Keys.accentColor] ?: defaults.accentColor,
            glassLevel = enumOrDefault(this[Keys.glassLevel], defaults.glassLevel),
            reduceMotion = this[Keys.reduceMotion] ?: defaults.reduceMotion,
            hapticsEnabled = this[Keys.haptics] ?: defaults.hapticsEnabled,
            streamingEnabled = this[Keys.streaming] ?: defaults.streamingEnabled,
            activeProviderId = this[Keys.activeProviderId] ?: defaults.activeProviderId,
            activeModel = this[Keys.activeModel] ?: defaults.activeModel,
            temperature = this[Keys.temperature] ?: defaults.temperature,
            maxTokens = this[Keys.maxTokens] ?: defaults.maxTokens,
            agentAutoApproveReads = this[Keys.agentAutoApproveReads] ?: defaults.agentAutoApproveReads,
            agentMaxSteps = this[Keys.agentMaxSteps] ?: defaults.agentMaxSteps,
            editorFontSize = this[Keys.editorFontSize] ?: defaults.editorFontSize,
            editorTabSize = this[Keys.editorTabSize] ?: defaults.editorTabSize,
            editorWordWrap = this[Keys.editorWordWrap] ?: defaults.editorWordWrap,
            editorLineNumbers = this[Keys.editorLineNumbers] ?: defaults.editorLineNumbers,
            editorAutoSave = this[Keys.editorAutoSave] ?: defaults.editorAutoSave,
            terminalFontSize = this[Keys.terminalFontSize] ?: defaults.terminalFontSize,
            terminalEngine = enumOrDefault(this[Keys.terminalEngine], defaults.terminalEngine),
            activeProjectId = this[Keys.activeProjectId] ?: defaults.activeProjectId,
            githubRepo = this[Keys.githubRepo] ?: defaults.githubRepo,
            onboardingDone = this[Keys.onboardingDone] ?: defaults.onboardingDone
        )
    }

    private inline fun <reified T : Enum<T>> enumOrDefault(raw: String?, fallback: T): T =
        raw?.let { value -> enumValues<T>().firstOrNull { it.name == value } } ?: fallback

    companion object {
        fun themeModeOf(name: String): ThemeMode =
            ThemeMode.entries.firstOrNull { it.name == name } ?: ThemeMode.System

        fun glassLevelOf(name: String): GlassLevel =
            GlassLevel.entries.firstOrNull { it.name == name } ?: GlassLevel.Full
    }
}
