package com.sirius.chat.core.util

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback

/** Thin wrapper so feature code never talks to the haptic API directly. */
class SiriusHaptics(
    private val performer: (HapticFeedbackType) -> Unit,
    private val enabled: Boolean
) {
    fun light() {
        if (enabled) performer(HapticFeedbackType.TextHandleMove)
    }

    fun strong() {
        if (enabled) performer(HapticFeedbackType.LongPress)
    }
}

@Composable
fun rememberHaptics(enabled: Boolean = true): SiriusHaptics {
    val haptic = LocalHapticFeedback.current
    return remember(haptic, enabled) {
        SiriusHaptics(performer = { haptic.performHapticFeedback(it) }, enabled = enabled)
    }
}
