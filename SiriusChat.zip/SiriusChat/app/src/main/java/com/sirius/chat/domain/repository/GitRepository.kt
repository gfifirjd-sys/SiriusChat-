package com.sirius.chat.domain.repository

import com.sirius.chat.core.common.Outcome
import com.sirius.chat.domain.model.FileDiff
import com.sirius.chat.domain.model.GitCommit
import com.sirius.chat.domain.model.GitStatus
import com.sirius.chat.domain.model.GitUnavailable

/**
 * Whether git can run against a workspace at all.
 *
 * This is a separate answer from [GitRepository.status] because "there is no
 * repository here" is not an error the user can retry — it needs a different
 * screen with a different button — while a failed status read is.
 */
sealed interface GitAvailability {
    /** The repository opened; [path] is shown so the user can verify it. */
    data class Ready(val path: String) : GitAvailability
    data class Unavailable(val reason: GitUnavailable) : GitAvailability
}

/**
 * Local git operations on the folder attached to a project.
 *
 * Everything is addressed by the project's SAF tree uri, the same identifier
 * the rest of the app uses, so callers never handle filesystem paths. Paths
 * inside the repository are always relative and slash-separated, which is what
 * git itself stores.
 *
 * Nothing here touches the network: no remotes, no credentials, no fetch. That
 * keeps the feature offline-only and avoids storing tokens on device.
 */
interface GitRepository {

    suspend fun availability(treeUri: String?): GitAvailability

    /** Status, branch list and recent history in one pass. */
    suspend fun status(treeUri: String, historyLimit: Int = 40): Outcome<GitStatus>

    /** Creates a repository in the workspace root. */
    suspend fun init(treeUri: String): Outcome<Unit>

    suspend fun stage(treeUri: String, paths: List<String>): Outcome<Unit>
    suspend fun unstage(treeUri: String, paths: List<String>): Outcome<Unit>

    /** Throws away working-tree edits, and deletes files that were untracked. */
    suspend fun discard(treeUri: String, paths: List<String>): Outcome<Unit>

    suspend fun commit(treeUri: String, message: String, amend: Boolean = false): Outcome<GitCommit>

    /**
     * Diff for one path.
     *
     * [staged] selects HEAD against the index; otherwise the index (or HEAD,
     * for a path that is not in the index) against the file on disk.
     */
    suspend fun diff(treeUri: String, path: String, staged: Boolean): Outcome<FileDiff>

    suspend fun createBranch(treeUri: String, name: String): Outcome<Unit>
    suspend fun checkout(treeUri: String, name: String): Outcome<Unit>

    /** Full message and metadata of a single commit, for the history detail. */
    suspend fun commitDetail(treeUri: String, id: String): Outcome<GitCommit>

    /** Paths touched by [id], relative to its first parent. */
    suspend fun commitFiles(treeUri: String, id: String): Outcome<List<String>>
}
