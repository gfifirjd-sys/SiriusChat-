package com.sirius.chat.ai.provider

import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.domain.model.AiModel
import kotlinx.coroutines.flow.Flow

/**
 * A pluggable AI backend.
 *
 * Everything above this interface (chat, agent, UI) is provider agnostic:
 * adding a new vendor means adding one implementation and registering it in
 * [ProviderFactory], nothing else changes.
 */
interface AiProvider {
    val id: String
    val label: String
    val models: List<AiModel>

    /** Cold flow; collecting starts the request, cancelling aborts it. */
    fun chat(request: ChatRequest): Flow<ChatStreamEvent>
}
