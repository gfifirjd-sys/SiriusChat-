package com.sirius.chat.core.designsystem

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/** Generous, continuous-feeling radii are a core part of the Sirius look. */
object SiriusRadius {
    val xs = 8.dp
    val sm = 12.dp
    val md = 18.dp
    val lg = 24.dp
    val xl = 30.dp
    val pill = 999.dp
}

object SiriusSpacing {
    val xxs = 4.dp
    val xs = 8.dp
    val sm = 12.dp
    val md = 16.dp
    val lg = 20.dp
    val xl = 28.dp
    val xxl = 40.dp
}

val SiriusShapes = Shapes(
    extraSmall = RoundedCornerShape(SiriusRadius.xs),
    small = RoundedCornerShape(SiriusRadius.sm),
    medium = RoundedCornerShape(SiriusRadius.md),
    large = RoundedCornerShape(SiriusRadius.lg),
    extraLarge = RoundedCornerShape(SiriusRadius.xl)
)
