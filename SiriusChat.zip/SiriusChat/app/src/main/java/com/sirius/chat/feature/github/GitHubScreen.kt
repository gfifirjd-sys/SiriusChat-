package com.sirius.chat.feature.github

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.NoteAdd
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.domain.model.GitHubEntry
import com.sirius.chat.feature.editor.components.CodeEditorField
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.EmptyState
import com.sirius.chat.core.designsystem.Reveal
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.SectionHeader
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.sheetDragGuard
import com.sirius.chat.core.designsystem.components.ToastTone
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.CodeLanguages
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.domain.model.GitHubRepo
import com.sirius.chat.domain.model.GitHubRun
import java.io.File

private const val TOKEN_URL =
    "https://github.com/settings/tokens/new?scopes=repo,workflow&description=Sirius%20Chat"
private const val DOCS_URL = "https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens"

/**
 * GitHub: connect an account, pick a repository, build an APK in the cloud.
 *
 * The screen is deliberately one column of three questions in order — who are
 * you, which repo, what do you want built — because that is the only order in
 * which the answers make sense. Nothing below the account block renders until a
 * token has been verified, so there is never a build button that cannot work.
 *
 * A personal access token is used rather than OAuth. An OAuth app needs a client
 * secret and a redirect the app can receive; shipping a secret inside an APK that
 * anyone can unzip makes it not a secret, and a token the user pastes has scopes
 * they chose and can revoke from a page they already trust.
 */
@Composable
fun GitHubScreen(
    onBack: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: GitHubViewModel = siriusViewModel { GitHubViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors
    val context = LocalContext.current

    val listState = rememberLazyListState()
    val scrolled by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 4
        }
    }
    var token by remember { mutableStateOf("") }
    var creating by remember { mutableStateOf<CreateKind?>(null) }
    var createName by remember { mutableStateOf("") }
    var commitMessage by remember { mutableStateOf("") }

    // The selected repository comes from settings, so on entering the screen the
    // tree is known but not yet fetched. Keyed on the repo: switching repositories
    // re-runs this instead of leaving the previous tree on screen.
    LaunchedEffect(state.selectedRepo) {
        if (state.selectedRepo.isNotBlank() && state.entries.isEmpty()) {
            viewModel.browse("")
        }
    }

    fun openUrl(url: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.github_title),
            subtitle = stringResource(R.string.github_subtitle),
            scrolled = scrolled,
            onBack = onBack,
            actions = {
                if (state.connected) {
                    SiriusGhostButton(
                        text = stringResource(R.string.action_refresh),
                        icon = Icons.Rounded.Refresh,
                        onClick = {
                            viewModel.refreshRepos()
                            viewModel.refreshRuns()
                        }
                    )
                }
            }
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = SiriusSpacing.md,
                end = SiriusSpacing.md,
                top = SiriusSpacing.xs,
                bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xxl
            ),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
        ) {
            if (!state.connected) {
                item {
                    ConnectCard(
                        token = token,
                        onTokenChange = { token = it },
                        busy = state.busy.isNotEmpty(),
                        onConnect = {
                            viewModel.connect(token)
                            token = ""
                        },
                        onOpenTokenPage = { openUrl(TOKEN_URL) },
                        onOpenDocs = { openUrl(DOCS_URL) }
                    )
                }
            } else {
                item {
                    AccountCard(
                        login = state.account?.login.orEmpty(),
                        name = state.account?.displayName.orEmpty(),
                        warning = when {
                            state.account?.canWriteRepos == false ->
                                stringResource(R.string.github_scope_missing_repo)

                            state.account?.canRunWorkflows == false ->
                                stringResource(R.string.github_scope_missing_workflow)

                            else -> null
                        },
                        onDisconnect = viewModel::disconnect,
                        onOpenProfile = { openUrl("https://github.com/${state.account?.login}") }
                    )
                }

                item {
                    SectionHeader(
                        title = stringResource(R.string.github_repos),
                        subtitle = stringResource(R.string.github_repos_subtitle)
                    )
                }

                if (state.repos.isEmpty()) {
                    item {
                        EmptyState(
                            icon = Icons.Rounded.Cloud,
                            title = stringResource(R.string.github_no_repos),
                            message = stringResource(R.string.github_no_repos_body)
                        )
                    }
                } else {
                    itemsIndexed(
                        state.repos,
                        key = { _, repo -> repo.fullName }
                    ) { index, repo ->
                        Reveal(index) {
                            RepoRow(
                                repo = repo,
                                selected = repo.fullName == state.selectedRepo,
                                onClick = { viewModel.selectRepo(repo.fullName) }
                            )
                        }
                    }
                }

                val selected = state.selected
                if (selected != null) {
                    item {
                        VSpace(SiriusSpacing.xs)
                        SectionHeader(
                            title = stringResource(R.string.github_files),
                            subtitle = state.browsePath.ifBlank { selected.fullName }
                        )
                    }
                    item {
                        BrowserBar(
                            breadcrumbs = state.breadcrumbs,
                            canGoUp = state.parentPath != null,
                            busy = state.busy.isNotEmpty(),
                            onRoot = { viewModel.browse("") },
                            onCrumb = { viewModel.browse(it) },
                            onUp = viewModel::browseUp,
                            onNewFile = { creating = CreateKind.File },
                            onNewFolder = { creating = CreateKind.Folder },
                            onRefresh = { viewModel.browse() }
                        )
                    }
                    if (state.entries.isEmpty()) {
                        item {
                            EmptyState(
                                icon = Icons.Rounded.Folder,
                                title = stringResource(R.string.github_empty_folder),
                                message = stringResource(R.string.github_empty_folder_body)
                            )
                        }
                    } else {
                        itemsIndexed(
                            state.entries,
                            key = { _, entry -> entry.path }
                        ) { index, entry ->
                            Reveal(index) {
                                EntryRow(
                                    entry = entry,
                                    enabled = state.busy.isEmpty(),
                                    onClick = {
                                        if (entry.isDirectory) viewModel.browse(entry.path)
                                        else viewModel.openFile(entry)
                                    },
                                    onDelete = { viewModel.deleteEntry(entry) }
                                )
                            }
                        }
                    }

                    item {
                        VSpace(SiriusSpacing.xs)
                        SectionHeader(
                            title = stringResource(R.string.github_build),
                            subtitle = selected.fullName
                        )
                    }
                    item {
                        BuildCard(
                            repo = selected,
                            busy = state.busy,
                            building = state.building,
                            onBuild = viewModel::build,
                            onToggleVisibility = viewModel::toggleVisibility,
                            onOpenActions = { openUrl("${selected.htmlUrl}/actions") }
                        )
                    }
                    itemsIndexed(state.runs, key = { _, run -> run.id }) { index, run ->
                        Reveal(index) {
                            RunRow(run = run, onOpen = { openUrl(run.htmlUrl) })
                        }
                    }
                    if (state.artifacts.isNotEmpty()) {
                        item {
                            SectionHeader(title = stringResource(R.string.github_artifacts))
                        }
                        items(state.artifacts, key = { it.id }) { artifact ->
                            GlassCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = artifact.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = colors.textPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = Formatters.fileSize(artifact.sizeBytes),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = colors.textTertiary
                                        )
                                    }
                                    SiriusGhostButton(
                                        text = stringResource(R.string.github_download),
                                        icon = Icons.Rounded.Download,
                                        enabled = !artifact.expired && state.busy.isEmpty(),
                                        onClick = { viewModel.download(context, artifact) }
                                    )
                                }
                            }
                        }
                    }
                    if (state.apkPath.isNotBlank()) {
                        item {
                            GlassCard {
                                Text(
                                    text = stringResource(R.string.github_apk_ready),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = colors.textPrimary
                                )
                                Text(
                                    text = File(state.apkPath).name,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.textTertiary
                                )
                                VSpace(SiriusSpacing.xs)
                                SiriusPrimaryButton(
                                    text = stringResource(R.string.github_install),
                                    icon = Icons.Rounded.Android,
                                    onClick = { installApk(context, File(state.apkPath)) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Create file / create folder share one sheet: the only difference is what the
    // name means, and two nearly identical sheets is twice the surface to keep in
    // sync for no gain to the user.
    val kind = creating
    if (kind != null) {
        SiriusBottomSheet(
            title = stringResource(
                if (kind == CreateKind.File) R.string.github_new_file else R.string.github_new_folder
            ),
            subtitle = state.browsePath.ifBlank { state.selectedRepo },
            onDismiss = {
                creating = null
                createName = ""
            }
        ) {
            SiriusTextField(
                value = createName,
                onValueChange = { createName = it },
                label = stringResource(
                    if (kind == CreateKind.File) R.string.github_new_file_label
                    else R.string.github_new_folder_label
                ),
                placeholder = if (kind == CreateKind.File) "README.md" else "docs",
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = stringResource(R.string.github_new_path_hint),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary
            )
            VSpace(SiriusSpacing.xs)
            SiriusPrimaryButton(
                text = stringResource(R.string.action_create),
                icon = Icons.Rounded.Add,
                enabled = createName.isNotBlank() && state.busy.isEmpty(),
                onClick = {
                    if (kind == CreateKind.File) viewModel.createFile(createName)
                    else viewModel.createFolder(createName)
                    creating = null
                    createName = ""
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    val open = state.openFile
    if (open != null) {
        SiriusBottomSheet(
            title = open.name,
            subtitle = open.path,
            // The editor brings its own scroll; the sheet must not add a second one.
            scrollable = false,
            onDismiss = {
                viewModel.closeFile()
                commitMessage = ""
            }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 220.dp, max = 380.dp)
                    .clip(RoundedCornerShape(SiriusRadius.md))
                    .sheetDragGuard()
            ) {
                CodeEditorField(
                    documentId = "github:${open.path}",
                    content = open.content,
                    language = CodeLanguages.fromFileName(open.name),
                    fontSize = 13,
                    showLineNumbers = true,
                    wordWrap = false,
                    readOnly = false,
                    onContentChange = { text, _ -> viewModel.editOpenFile(text) }
                )
            }
            VSpace(SiriusSpacing.xs)
            SiriusTextField(
                value = commitMessage,
                onValueChange = { commitMessage = it },
                label = stringResource(R.string.github_commit_message),
                placeholder = "Update ${open.name}",
                modifier = Modifier.fillMaxWidth()
            )
            VSpace(SiriusSpacing.xs)
            Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                SiriusPrimaryButton(
                    text = stringResource(R.string.github_commit),
                    icon = Icons.Rounded.Check,
                    // Nothing to commit is not an error worth a toast: the button
                    // simply stays inert until the text actually differs.
                    enabled = open.dirty && state.busy.isEmpty(),
                    onClick = { viewModel.commitOpenFile(commitMessage) },
                    modifier = Modifier.weight(1f)
                )
                SiriusGhostButton(
                    text = stringResource(R.string.action_close),
                    onClick = {
                        viewModel.closeFile()
                        commitMessage = ""
                    }
                )
            }
        }
    }

    MessageToast(
        message = state.message.takeIf { it.isNotBlank() },
        tone = if (state.messageIsError) ToastTone.Error else ToastTone.Success,
        bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.lg
    )
}

/**
 * The connect step, with the token page one tap away.
 *
 * The link carries `scopes=repo,workflow` so GitHub's own form arrives with the
 * right boxes ticked. Making the user find two checkboxes in a long list is the
 * single most common way this flow fails.
 */
@Composable
private fun ConnectCard(
    token: String,
    onTokenChange: (String) -> Unit,
    busy: Boolean,
    onConnect: () -> Unit,
    onOpenTokenPage: () -> Unit,
    onOpenDocs: () -> Unit
) {
    val colors = SiriusTheme.colors
    GlassCard {
        Text(
            text = stringResource(R.string.github_connect_title),
            style = MaterialTheme.typography.titleMedium,
            color = colors.textPrimary
        )
        VSpace(SiriusSpacing.xxs)
        Text(
            text = stringResource(R.string.github_connect_body),
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary
        )
        VSpace(SiriusSpacing.sm)
        listOf(
            R.string.github_step_1,
            R.string.github_step_2,
            R.string.github_step_3,
            R.string.github_step_4
        ).forEachIndexed { index, res ->
            Row(modifier = Modifier.fillMaxWidth().padding(bottom = SiriusSpacing.xxs)) {
                Text(
                    text = "${index + 1}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.accent,
                    modifier = Modifier.size(width = 20.dp, height = 20.dp)
                )
                Text(
                    text = stringResource(res),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
            }
        }
        VSpace(SiriusSpacing.xs)
        Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
            SiriusGhostButton(
                text = stringResource(R.string.github_open_token_page),
                icon = Icons.AutoMirrored.Rounded.OpenInNew,
                onClick = onOpenTokenPage
            )
            SiriusGhostButton(
                text = stringResource(R.string.github_open_docs),
                onClick = onOpenDocs
            )
        }
        VSpace(SiriusSpacing.sm)
        SiriusTextField(
            value = token,
            onValueChange = onTokenChange,
            label = stringResource(R.string.github_token_label),
            placeholder = "ghp_...",
            // The token is a credential: masked by default, like every API key
            // in this app.
            isPassword = true,
            imeAction = ImeAction.Done,
            onImeAction = onConnect
        )
        VSpace(SiriusSpacing.sm)
        SiriusPrimaryButton(
            text = stringResource(R.string.github_connect),
            icon = Icons.Rounded.Link,
            enabled = token.isNotBlank() && !busy,
            loading = busy,
            onClick = onConnect,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun AccountCard(
    login: String,
    name: String,
    warning: String?,
    onDisconnect: () -> Unit,
    onOpenProfile: () -> Unit
) {
    val colors = SiriusTheme.colors
    GlassCard(onClick = onOpenProfile, onClickLabel = stringResource(R.string.github_open_profile)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name.ifBlank { login },
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary
                )
                Text(
                    text = "@$login",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary
                )
            }
            SiriusGhostButton(
                text = stringResource(R.string.github_disconnect),
                icon = Icons.Rounded.LinkOff,
                tint = colors.error,
                onClick = onDisconnect
            )
        }
        if (warning != null) {
            VSpace(SiriusSpacing.xs)
            Text(
                text = warning,
                style = MaterialTheme.typography.bodySmall,
                color = colors.warning
            )
        }
    }
}

@Composable
private fun RepoRow(repo: GitHubRepo, selected: Boolean, onClick: () -> Unit) {
    val colors = SiriusTheme.colors
    GlassCard(onClick = onClick, active = selected) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (repo.isPrivate) Icons.Rounded.Lock else Icons.Rounded.Public,
                contentDescription = null,
                tint = if (repo.isPrivate) colors.textTertiary else colors.accent,
                modifier = Modifier.size(18.dp)
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = SiriusSpacing.xs)
            ) {
                Text(
                    text = repo.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = repo.description.ifBlank { repo.fullName },
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (repo.language.isNotBlank()) {
                SiriusChip(text = repo.language)
            }
        }
    }
}

@Composable
private fun BuildCard(
    repo: GitHubRepo,
    busy: String,
    building: Boolean,
    onBuild: (String) -> Unit,
    onToggleVisibility: () -> Unit,
    onOpenActions: () -> Unit
) {
    val colors = SiriusTheme.colors
    GlassCard {
        Text(
            text = stringResource(R.string.github_build_body),
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary
        )
        VSpace(SiriusSpacing.sm)
        Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
            SiriusPrimaryButton(
                text = stringResource(R.string.github_build_debug),
                icon = Icons.Rounded.Android,
                enabled = busy.isEmpty() && !building,
                loading = busy.isNotEmpty(),
                onClick = { onBuild("debug") },
                modifier = Modifier.weight(1f)
            )
            SiriusGhostButton(
                text = stringResource(R.string.github_build_release),
                enabled = busy.isEmpty() && !building,
                onClick = { onBuild("release") }
            )
        }
        VSpace(SiriusSpacing.xs)
        Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
            SiriusGhostButton(
                text = stringResource(
                    if (repo.isPrivate) R.string.github_make_public else R.string.github_make_private
                ),
                icon = if (repo.isPrivate) Icons.Rounded.Public else Icons.Rounded.Lock,
                enabled = busy.isEmpty(),
                onClick = onToggleVisibility
            )
            SiriusGhostButton(
                text = stringResource(R.string.github_open_actions),
                icon = Icons.AutoMirrored.Rounded.OpenInNew,
                onClick = onOpenActions
            )
        }
    }
}

@Composable
private fun RunRow(run: GitHubRun, onOpen: () -> Unit) {
    val colors = SiriusTheme.colors
    // Colour carries the same meaning as the word next to it, never on its own.
    val tint = when {
        !run.finished -> colors.warning
        run.succeeded -> colors.success
        else -> colors.error
    }
    val state = if (run.finished) run.conclusion.ifBlank { "completed" } else run.status
    GlassCard(onClick = onOpen, onClickLabel = stringResource(R.string.github_open_run)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "#${run.runNumber} ${run.name}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = run.branch,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary
                )
            }
            SiriusChip(text = state, color = tint)
        }
    }
}

/**
 * Hands the APK to the system installer.
 *
 * A `file://` URI would be rejected on Android 7 and later, so the file is served
 * through the app's FileProvider with a one-shot read grant. If the user has not
 * allowed this app to install packages the system asks them; if no installer
 * exists at all the failure is swallowed rather than crashing the screen.
 */
private fun installApk(context: android.content.Context, apk: File) {
    val uri = runCatching {
        FileProvider.getUriForFile(context, "${context.packageName}.files", apk)
    }.getOrNull() ?: return
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "application/vnd.android.package-archive")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    try {
        context.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        // No package installer on this device; nothing useful to offer.
    }
}

/** Which of the two "create" flows the shared sheet is serving. */
private enum class CreateKind { File, Folder }

/**
 * Breadcrumb plus the actions that apply to the directory being shown.
 *
 * The breadcrumb scrolls horizontally instead of eliding the middle: in a deep
 * Android tree (`app/src/main/java/com/sirius/chat/...`) the middle is exactly
 * the part that tells you where you are.
 */
@Composable
private fun BrowserBar(
    breadcrumbs: List<Pair<String, String>>,
    canGoUp: Boolean,
    busy: Boolean,
    onRoot: () -> Unit,
    onCrumb: (String) -> Unit,
    onUp: () -> Unit,
    onNewFile: () -> Unit,
    onNewFolder: () -> Unit,
    onRefresh: () -> Unit
) {
    val colors = SiriusTheme.colors
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlassIconButton(
                icon = Icons.Rounded.ArrowUpward,
                contentDescription = stringResource(R.string.github_up),
                enabled = canGoUp && !busy,
                size = 34.dp,
                iconSize = 16.dp,
                onClick = onUp
            )
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = SiriusSpacing.xs),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "/",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (breadcrumbs.isEmpty()) colors.textPrimary else colors.primary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(SiriusRadius.sm))
                        .clickable(enabled = !busy, onClick = onRoot)
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                )
                breadcrumbs.forEachIndexed { index, (name, path) ->
                    Text(
                        text = name,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (index == breadcrumbs.lastIndex) colors.textPrimary else colors.primary,
                        maxLines = 1,
                        modifier = Modifier
                            .clip(RoundedCornerShape(SiriusRadius.sm))
                            .clickable(enabled = !busy) { onCrumb(path) }
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                    if (index != breadcrumbs.lastIndex) {
                        Text(
                            text = "/",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textTertiary
                        )
                    }
                }
            }
            GlassIconButton(
                icon = Icons.Rounded.Refresh,
                contentDescription = stringResource(R.string.action_refresh),
                enabled = !busy,
                size = 34.dp,
                iconSize = 16.dp,
                onClick = onRefresh
            )
        }
        VSpace(SiriusSpacing.xs)
        Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
            SiriusGhostButton(
                text = stringResource(R.string.github_new_file),
                icon = Icons.AutoMirrored.Rounded.NoteAdd,
                enabled = !busy,
                onClick = onNewFile,
                modifier = Modifier.weight(1f)
            )
            SiriusGhostButton(
                text = stringResource(R.string.github_new_folder),
                icon = Icons.Rounded.CreateNewFolder,
                enabled = !busy,
                onClick = onNewFolder,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

/** One row of the repository tree: folder to descend into, or a file to open. */
@Composable
private fun EntryRow(
    entry: GitHubEntry,
    enabled: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = SiriusTheme.colors
    GlassCard(onClick = if (enabled) onClick else null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (entry.isDirectory) Icons.Rounded.Folder else Icons.Rounded.Description,
                contentDescription = null,
                tint = if (entry.isDirectory) colors.primary else colors.textSecondary,
                modifier = Modifier.size(18.dp)
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = SiriusSpacing.xs)
            ) {
                Text(
                    text = entry.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!entry.isDirectory) {
                    Text(
                        text = Formatters.fileSize(entry.sizeBytes),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textTertiary
                    )
                }
            }
            if (!entry.isDirectory) {
                GlassIconButton(
                    icon = Icons.Rounded.DeleteOutline,
                    contentDescription = stringResource(R.string.action_delete),
                    enabled = enabled,
                    size = 32.dp,
                    iconSize = 15.dp,
                    onClick = onDelete
                )
            }
        }
    }
}
