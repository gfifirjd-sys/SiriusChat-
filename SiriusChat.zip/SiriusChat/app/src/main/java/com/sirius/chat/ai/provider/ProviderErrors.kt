package com.sirius.chat.ai.provider

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.core.locale.AppStrings
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

private val errorJson = Json { ignoreUnknownKeys = true }

/** Maps transport exceptions to a stable, user-presentable error. */
internal fun Throwable.toAiError(): AiError = when (this) {
    is UnknownHostException -> AiError(
        AiError.Kind.Network,
        AppStrings.get(
            R.string.error_unreachable,
            fallback = "Cannot reach the provider. Check the base URL and your connection."
        )
    )
    is SocketTimeoutException -> AiError(
        AiError.Kind.Network,
        AppStrings.get(R.string.error_timeout, fallback = "The provider timed out.")
    )
    is java.util.concurrent.CancellationException -> AiError(
        AiError.Kind.Cancelled,
        AppStrings.get(R.string.error_cancelled, fallback = "Generation stopped.")
    )
    is IOException -> AiError(
        AiError.Kind.Network,
        message ?: AppStrings.get(R.string.error_network, fallback = "Network error")
    )
    else -> AiError(
        AiError.Kind.Unknown,
        message ?: AppStrings.get(R.string.error_unexpected, fallback = "Unexpected error")
    )
}

/** Maps an HTTP failure, extracting the provider's own message when present. */
internal fun httpError(code: Int, body: String): AiError {
    val detail = runCatching {
        val root = errorJson.parseToJsonElement(body).jsonObject
        val error = root["error"]
        when {
            error != null -> error.jsonObject["message"]?.jsonPrimitive?.contentOrNull
            else -> root["message"]?.jsonPrimitive?.contentOrNull
        }
    }.getOrNull()

    val kind = when (code) {
        401, 403 -> AiError.Kind.Unauthorized
        429 -> AiError.Kind.RateLimited
        in 400..499 -> AiError.Kind.BadRequest
        in 500..599 -> AiError.Kind.Server
        else -> AiError.Kind.Unknown
    }

    val fallback = when (kind) {
        AiError.Kind.Unauthorized -> AppStrings.get(
            R.string.error_unauthorized,
            fallback = "Invalid or missing API key for this provider."
        )
        AiError.Kind.RateLimited -> AppStrings.get(
            R.string.error_rate_limited,
            fallback = "Rate limited by the provider. Try again shortly."
        )
        AiError.Kind.BadRequest -> AppStrings.format(
            R.string.error_bad_request,
            code,
            fallback = "The provider rejected the request (HTTP $code)."
        )
        AiError.Kind.Server -> AppStrings.format(
            R.string.error_server,
            code,
            fallback = "The provider is having trouble (HTTP $code)."
        )
        else -> AppStrings.format(
            R.string.error_request_failed,
            code,
            fallback = "Request failed (HTTP $code)."
        )
    }

    return AiError(kind, detail?.takeIf { it.isNotBlank() } ?: fallback, code)
}
