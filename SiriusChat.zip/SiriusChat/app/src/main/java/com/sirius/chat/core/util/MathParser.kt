package com.sirius.chat.core.util

/** Nodes the maths renderer knows how to lay out. */
sealed interface MathNode {
    /** A single mathematical symbol. [italic] marks variables, per convention. */
    data class Sym(val text: String, val italic: Boolean) : MathNode
    /** Upright prose inside a formula: `\text{...}`, `\mathrm{...}`. */
    data class TextRun(val text: String) : MathNode
    data class Group(val body: List<MathNode>) : MathNode
    data class Frac(val numerator: List<MathNode>, val denominator: List<MathNode>) : MathNode
    data class Sqrt(val body: List<MathNode>) : MathNode
    data class Fenced(val open: String, val close: String, val body: List<MathNode>) : MathNode
    /**
     * Base with a power and/or an index. Both live on one node so `x_i^2` stacks
     * them rather than putting the index after the power.
     */
    data class Script(
        val base: MathNode,
        val superscript: List<MathNode> = emptyList(),
        val subscript: List<MathNode> = emptyList()
    ) : MathNode
}

/**
 * Parses the LaTeX subset that shows up in assistant answers.
 *
 * Not a TeX implementation: no macro expansion, no environments, no measurement.
 * It covers fractions, roots, scripts, greek letters, the common operators and
 * `\text`, and turns anything else into visible source so an unsupported command
 * is obvious instead of silently dropped.
 */
object MathParser {

    /** Splits on `\\` and parses each row; a single formula yields one row. */
    fun parse(latex: String): List<List<MathNode>> =
        latex.split("\\\\")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { Cursor(it).parseNodes(null) }

    /** Rough character width of a subtree, used to size fraction rules. */
    fun widthOf(nodes: List<MathNode>): Int = nodes.sumOf { node ->
        when (node) {
            is MathNode.Sym -> node.text.length
            is MathNode.TextRun -> node.text.length
            is MathNode.Group -> widthOf(node.body)
            is MathNode.Frac -> maxOf(widthOf(node.numerator), widthOf(node.denominator))
            is MathNode.Sqrt -> widthOf(node.body) + 1
            is MathNode.Fenced -> widthOf(node.body) + 2
            is MathNode.Script -> widthOf(listOf(node.base)) +
                (widthOf(node.superscript) + widthOf(node.subscript) + 1) / 2
        }
    }

    private val greek = mapOf(
        "alpha" to "\u03B1", "beta" to "\u03B2", "gamma" to "\u03B3", "delta" to "\u03B4", "epsilon" to "\u03B5",
        "varepsilon" to "\u03B5", "zeta" to "\u03B6", "eta" to "\u03B7", "theta" to "\u03B8", "iota" to "\u03B9",
        "kappa" to "\u03BA", "lambda" to "\u03BB", "mu" to "\u03BC", "nu" to "\u03BD", "xi" to "\u03BE", "pi" to "\u03C0",
        "rho" to "\u03C1", "sigma" to "\u03C3", "tau" to "\u03C4", "upsilon" to "\u03C5", "phi" to "\u03C6",
        "varphi" to "\u03C6", "chi" to "\u03C7", "psi" to "\u03C8", "omega" to "\u03C9",
        "Gamma" to "\u0393", "Delta" to "\u0394", "Theta" to "\u0398", "Lambda" to "\u039B", "Xi" to "\u039E",
        "Pi" to "\u03A0", "Sigma" to "\u03A3", "Upsilon" to "\u03A5", "Phi" to "\u03A6", "Psi" to "\u03A8", "Omega" to "\u03A9"
    )

    private val operators = mapOf(
        "cdot" to "\u00B7", "times" to "\u00D7", "div" to "\u00F7", "pm" to "\u00B1", "mp" to "\u2213",
        "leq" to "\u2264", "le" to "\u2264", "geq" to "\u2265", "ge" to "\u2265", "neq" to "\u2260", "ne" to "\u2260",
        "approx" to "\u2248", "equiv" to "\u2261", "sim" to "\u223C", "propto" to "\u221D",
        "to" to "\u2192", "rightarrow" to "\u2192", "leftarrow" to "\u2190", "Rightarrow" to "\u21D2",
        "infty" to "\u221E", "sum" to "\u2211", "prod" to "\u220F", "int" to "\u222B", "partial" to "\u2202",
        "nabla" to "\u2207", "in" to "\u2208", "notin" to "\u2209", "subset" to "\u2282", "subseteq" to "\u2286",
        "cup" to "\u222A", "cap" to "\u2229", "emptyset" to "\u2205", "forall" to "\u2200", "exists" to "\u2203",
        "ldots" to "\u2026", "cdots" to "\u22EF", "angle" to "\u2220", "degree" to "\u00B0", "circ" to "\u2218",
        "ast" to "\u2217", "star" to "\u22C6", "oplus" to "\u2295", "otimes" to "\u2297", "sqrtsym" to "\u221A"
    )

    private val upright = setOf("text", "mathrm", "mathbf", "mathit", "operatorname", "mathsf")

    private class Cursor(val src: String) {
        var i = 0

        fun parseNodes(stopAt: Char?): List<MathNode> {
            val out = ArrayList<MathNode>()
            while (i < src.length) {
                val c = src[i]
                if (stopAt != null && c == stopAt) break
                when {
                    c == '}' -> break
                    c == '{' -> {
                        i++
                        out += MathNode.Group(parseNodes('}'))
                        if (i < src.length && src[i] == '}') i++
                    }
                    c == '^' || c == '_' -> {
                        i++
                        val script = parseAtom()
                        val previous = out.removeLastOrNull() ?: MathNode.Sym("", false)
                        out += attachScript(previous, script, superscript = c == '^')
                    }
                    c == '\\' -> parseCommand()?.let { out += it }
                    // Spacing in TeX is typographic, and layout already provides it.
                    c == ' ' || c == '&' -> i++
                    else -> {
                        out += symbolFor(c)
                        i++
                    }
                }
            }
            return out
        }

        /** Merges into an existing [MathNode.Script] so `x_i^2` stacks properly. */
        private fun attachScript(base: MathNode, script: List<MathNode>, superscript: Boolean): MathNode =
            if (base is MathNode.Script) {
                if (superscript) base.copy(superscript = script) else base.copy(subscript = script)
            } else {
                if (superscript) {
                    MathNode.Script(base, superscript = script)
                } else {
                    MathNode.Script(base, subscript = script)
                }
            }

        /** One argument: a braced group, a command, or a single character. */
        private fun parseAtom(): List<MathNode> {
            while (i < src.length && src[i] == ' ') i++
            if (i >= src.length) return emptyList()
            return when (src[i]) {
                '{' -> {
                    i++
                    val body = parseNodes('}')
                    if (i < src.length && src[i] == '}') i++
                    body
                }
                '\\' -> listOfNotNull(parseCommand())
                else -> listOf(symbolFor(src[i])).also { i++ }
            }
        }

        private fun rawGroup(): String {
            while (i < src.length && src[i] == ' ') i++
            if (i >= src.length || src[i] != '{') {
                // `\text x` is malformed but common; take the next character.
                return if (i < src.length) src[i].toString().also { i++ } else ""
            }
            i++
            val start = i
            var depth = 1
            while (i < src.length && depth > 0) {
                when (src[i]) {
                    '{' -> depth++
                    '}' -> depth--
                }
                if (depth > 0) i++
            }
            val body = src.substring(start, i)
            if (i < src.length && src[i] == '}') i++
            return body
        }

        private fun parseCommand(): MathNode? {
            i++ // consume the backslash
            if (i >= src.length) return null
            if (!src[i].isLetter()) {
                // Escaped punctuation: \{, \%, \$ and friends.
                return symbolFor(src[i]).also { i++ }
            }
            val start = i
            while (i < src.length && src[i].isLetter()) i++
            val name = src.substring(start, i)

            return when {
                name == "frac" || name == "dfrac" || name == "tfrac" ->
                    MathNode.Frac(parseAtom(), parseAtom())

                name == "sqrt" -> {
                    // Optional index (\sqrt[3]{x}) is parsed and dropped: showing
                    // a cube root as a square root is wrong, so it is prefixed
                    // to the body instead of being silently ignored.
                    var index: String? = null
                    if (i < src.length && src[i] == '[') {
                        val close = src.indexOf(']', i)
                        if (close > 0) {
                            index = src.substring(i + 1, close)
                            i = close + 1
                        }
                    }
                    val body = parseAtom()
                    if (index == null) {
                        MathNode.Sqrt(body)
                    } else {
                        MathNode.Sqrt(listOf(MathNode.TextRun("$index:")) + body)
                    }
                }

                name in upright -> MathNode.TextRun(rawGroup())

                name == "left" || name == "right" -> {
                    val delim = if (i < src.length) src[i].toString() else ""
                    if (delim.isNotEmpty()) i++
                    MathNode.Sym(if (delim == ".") "" else delim, italic = false)
                }

                greek.containsKey(name) -> MathNode.Sym(greek.getValue(name), italic = false)
                operators.containsKey(name) -> MathNode.Sym(operators.getValue(name), italic = false)

                // Unknown: keep the source visible.
                else -> MathNode.TextRun("\\$name")
            }
        }

        private fun symbolFor(c: Char): MathNode =
            MathNode.Sym(c.toString(), italic = c.isLetter())
    }
}
