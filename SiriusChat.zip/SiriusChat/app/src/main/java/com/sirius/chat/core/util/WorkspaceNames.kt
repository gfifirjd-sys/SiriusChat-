package com.sirius.chat.core.util

import android.net.Uri

/**
 * Human-readable names for a Storage Access Framework tree.
 *
 * A tree uri is percent-encoded, so the tail of the string is not a folder name:
 * picking a folder called `тест` produced a project literally named
 * `%D1%82%D0%B5%D1%81%D1%82` in the chat header, because four separate call
 * sites each did their own `substringAfterLast` on the raw uri. ASCII folder
 * names survive that unharmed, which is why it went unnoticed.
 *
 * The authority on the display name is the provider itself (`rootNode(...)?.name`);
 * this is the fallback for when that query fails, and the repair path for rows
 * written by older builds.
 */
object WorkspaceNames {

    /**
     * Last path component of [treeUri], decoded.
     *
     * `primary:Documents/тест` -> `тест`. Everything before the final `:` is the
     * storage volume, and `content:` earlier in the string is harmless because
     * only the last colon is used.
     */
    fun folderName(treeUri: String?): String {
        if (treeUri.isNullOrBlank()) return ""
        val decoded = runCatching { Uri.decode(treeUri) }.getOrNull() ?: treeUri
        return decoded
            .substringAfterLast(':')
            .substringAfterLast('/')
            .trim()
    }

    /**
     * True when [name] still carries percent escapes, i.e. it was built from a
     * raw uri instead of a decoded one.
     *
     * Deliberately narrow: it requires the full `%XX` shape, so a project the
     * user genuinely named "100% done" is left alone.
     */
    fun looksEncoded(name: String): Boolean = ENCODED.containsMatchIn(name)

    private val ENCODED = Regex("%[0-9A-Fa-f]{2}")
}
