package com.sirius.chat.domain.model

/** Wire protocol implemented by a provider endpoint. */
enum class ProviderType { OpenAiCompatible, AnthropicCompatible, Custom }

data class AiModel(
    val id: String,
    val label: String = id,
    val contextWindow: Int = 0,
    val supportsStreaming: Boolean = true,
    val supportsTools: Boolean = true
)

/**
 * User-owned provider endpoint. The API key is never part of this object: it is
 * kept encrypted in the keystore-backed [com.sirius.chat.data.local.security.SecureCredentialStore]
 * and only resolved at request time.
 */
data class ProviderConfig(
    val id: String,
    val label: String,
    val type: ProviderType,
    val baseUrl: String,
    val models: List<AiModel> = emptyList(),
    val defaultModel: String = models.firstOrNull()?.id.orEmpty(),
    val enabled: Boolean = true,
    val builtIn: Boolean = false,
    val hasKey: Boolean = false,
    /**
     * Stable key a shipped template uses instead of a fixed English [label], so
     * the name can follow the in-app language. The UI layer maps it to a string
     * resource; `null` means [label] is user-authored and shown verbatim.
     *
     * Brand names (OpenAI, Anthropic) intentionally have no key.
     */
    val labelKey: String? = null,
    /**
     * Key of the built-in mark shown next to the name, from
     * `com.sirius.chat.core.designsystem.components.ProviderIcon`. `null` falls
     * back to a mark chosen from [type].
     */
    val iconKey: String? = null,
    /**
     * Absolute path to an image the user picked from the gallery. It is a copy
     * inside app storage, not the gallery Uri, because that permission dies with
     * the picker session. Takes precedence over [iconKey] when set.
     */
    val iconImagePath: String? = null
)

data class GenerationParams(
    val temperature: Float = 0.3f,
    val topP: Float = 1f,
    val maxTokens: Int = 4096
)
