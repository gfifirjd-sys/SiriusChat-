package com.sirius.chat.ai.agent

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.util.Locale

data class ParsedToolCall(val tool: String, val args: JsonObject, val rawBlock: String)

/**
 * Extracts tool calls from an assistant message.
 *
 * A fenced ```sirius-tool block is used instead of vendor specific function
 * calling so that *every* OpenAI or Anthropic compatible endpoint, including
 * small local models, can drive the agent.
 *
 * ### Why this is deliberately forgiving
 * The JSON shape was always lenient — `tool` or `name`, `args` or `arguments` or
 * `parameters` — but the *fence* used to be matched literally, and that made the
 * agent look broken on exactly the models this format exists to support. A weak
 * model that emitted a perfectly correct call inside a ```json fence produced
 * zero parsed calls, the run ended, and the user saw "I forgot to call the
 * tools" followed by nothing. The call was there; the parser refused to see it.
 *
 * So an info string is now accepted if it *names* a tool block in any of the
 * spellings models actually produce.
 *
 * ### The [known] gate
 * Generic fences are held to a stricter standard than explicit ones. An early
 * version accepted any object with a `tool` *or* `name` key inside a ```json
 * fence, which meant a user asking for `{"name": "Ivan", "age": 30}` got their
 * JSON parsed as a call to a tool named `Ivan` — rejected downstream, but also
 * stripped from the transcript, so the data they asked for silently vanished.
 * `name` is simply too common a key in ordinary JSON to treat as an instruction.
 *
 * So an ambiguous fence, and an unfenced object, must name a tool that actually
 * exists. An explicit `sirius-tool` fence does not: there the model has stated
 * its intent, and a typo in the tool name should surface as "unknown tool"
 * rather than be silently ignored.
 *
 * Nothing here loosens *what* gets run. [AgentEngine] still resolves every name
 * against the registry.
 *
 * ### Locale
 * Case folding is pinned to [Locale.ROOT] explicitly. Kotlin's no-argument
 * `lowercase()` is already locale invariant, so this is documentation rather
 * than a fix — but the failure it documents is real for the Java method it is
 * easily confused with: `toLowerCase()` on a Turkish device folds the `I` in
 * `SIRIUS-TOOL` to a dotless `ı`, the tag stops matching, and every tool call is
 * silently ignored on those devices only. Naming the locale keeps the next
 * person from "simplifying" this into that bug.
 */
object ToolCallParser {

    private const val FENCE = "```"
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    /** Info strings that unambiguously mean "this is a tool call". */
    private val explicitTags = setOf(
        "sirius-tool", "sirius_tool", "siriustool",
        "tool", "tool-call", "tool_call", "toolcall",
        "tool-calls", "tool_calls", "function", "function_call"
    )

    /**
     * Info strings that only count when the body looks like a call. `json` is
     * here because it is by far the most common substitution, and the empty
     * string covers a bare ``` fence with no tag at all.
     */
    private val ambiguousTags = setOf("json", "json5", "jsonc", "")

    private val toolKeys = listOf("tool", "name", "tool_name", "function")

    private data class Fence(val tag: String, val body: String, val start: Int, val end: Int)

    /**
     * @param known names of the registered tools. Empty means "accept explicit
     *   fences only", which is the safe reading when the registry is unknown.
     */
    fun parse(text: String, known: Set<String> = emptySet()): List<ParsedToolCall> {
        val calls = ArrayList<ParsedToolCall>()
        for (fence in fences(text)) {
            val tag = fence.tag.lowercase(Locale.ROOT)
            calls += when {
                tag in explicitTags -> decode(fence.body)
                tag in ambiguousTags -> decode(fence.body).filter { it.tool in known }
                else -> emptyList()
            }
        }
        // Last resort: a model that emitted the JSON with no fence at all. Only
        // tried when nothing was fenced, so a message that already produced calls
        // is never scanned twice.
        if (calls.isEmpty()) calls += parseUnfenced(text, known)
        return calls
    }

    /** Strips tool blocks so the transcript shows only the prose. */
    fun stripToolBlocks(text: String, known: Set<String> = emptySet()): String {
        val executed = fences(text).filter { fence ->
            val tag = fence.tag.lowercase(Locale.ROOT)
            when {
                tag in explicitTags -> true
                // An ambiguous fence is only hidden if it was actually run;
                // otherwise a JSON snippet the user asked for would vanish.
                tag in ambiguousTags -> decode(fence.body).any { it.tool in known }
                else -> false
            }
        }
        if (executed.isEmpty()) return stripUnfenced(text, known).trim()

        val builder = StringBuilder(text.length)
        var index = 0
        for (fence in executed) {
            builder.append(text, index, fence.start)
            index = fence.end
        }
        builder.append(text, index, text.length)
        return builder.toString().trim()
    }

    /** Every fenced block in the message, with its info string. */
    private fun fences(text: String): List<Fence> {
        val result = ArrayList<Fence>()
        var index = 0
        while (true) {
            val start = text.indexOf(FENCE, index)
            if (start < 0) break
            val infoEnd = text.indexOf('\n', start)
            if (infoEnd < 0) break
            val tag = text.substring(start + FENCE.length, infoEnd).trim()
            val close = text.indexOf(FENCE, infoEnd)
            if (close < 0) break
            result += Fence(
                tag = tag,
                body = text.substring(infoEnd + 1, close).trim(),
                start = start,
                end = close + FENCE.length
            )
            index = close + FENCE.length
        }
        return result
    }

    /**
     * Scans for a bare `{...}` or `[...]` that decodes to a tool call.
     *
     * Brace-matched rather than regex-matched because tool arguments are usually
     * file contents, which contain braces and newlines of their own.
     */
    private fun parseUnfenced(text: String, known: Set<String>): List<ParsedToolCall> {
        if (known.isEmpty()) return emptyList()
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (ch != '{' && ch != '[') { i++; continue }
            val end = matchBracket(text, i)
            if (end < 0) return emptyList()
            val decoded = decode(text.substring(i, end + 1)).filter { it.tool in known }
            if (decoded.isNotEmpty()) return decoded
            i = end + 1
        }
        return emptyList()
    }

    private fun stripUnfenced(text: String, known: Set<String>): String {
        if (known.isEmpty()) return text
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (ch != '{' && ch != '[') { i++; continue }
            val end = matchBracket(text, i)
            if (end < 0) return text
            if (decode(text.substring(i, end + 1)).any { it.tool in known }) {
                return text.removeRange(i, end + 1)
            }
            i = end + 1
        }
        return text
    }

    /** Index of the bracket closing the one at [open], or -1. String-aware. */
    private fun matchBracket(text: String, open: Int): Int {
        val closer = if (text[open] == '{') '}' else ']'
        val opener = text[open]
        var depth = 0
        var i = open
        var inString = false
        var escaped = false
        while (i < text.length) {
            val c = text[i]
            when {
                escaped -> escaped = false
                c == '\\' && inString -> escaped = true
                c == '"' -> inString = !inString
                inString -> Unit
                c == opener -> depth++
                c == closer -> {
                    depth--
                    if (depth == 0) return i
                }
            }
            i++
        }
        return -1
    }

    private fun decode(body: String): List<ParsedToolCall> = runCatching {
        when (val element = json.parseToJsonElement(body)) {
            is JsonArray -> element.mapNotNull { it.toCall(body) }
            is JsonObject -> listOfNotNull(element.toCall(body))
            else -> emptyList()
        }
    }.getOrDefault(emptyList())

    private fun JsonElement.toCall(raw: String): ParsedToolCall? {
        val obj = runCatching { jsonObject }.getOrNull() ?: return null
        val name = toolKeys.firstNotNullOfOrNull { key ->
            obj[key]?.let { runCatching { it.jsonPrimitive.content }.getOrNull() }
        }?.takeIf { it.isNotBlank() } ?: return null
        val args = (obj["args"] ?: obj["arguments"] ?: obj["parameters"] ?: obj["input"])
            ?.let { runCatching { it.jsonObject }.getOrNull() }
            ?: JsonObject(emptyMap())
        return ParsedToolCall(name, args, raw)
    }
}
