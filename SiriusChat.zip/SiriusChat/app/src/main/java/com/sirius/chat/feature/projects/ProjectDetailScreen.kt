package com.sirius.chat.feature.projects

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.AccountTree
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.EmptyState
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.SectionHeader
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.ToastTone
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.components.labelled
import com.sirius.chat.core.ui.rememberWorkspacePicker
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.core.util.relativeTimeText

@Composable
fun ProjectDetailScreen(
    projectId: String,
    onBack: () -> Unit,
    onOpenChat: (String) -> Unit,
    onOpenFiles: () -> Unit,
    onOpenEditor: () -> Unit,
    onOpenGit: () -> Unit,
    onOpenProviders: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: ProjectDetailViewModel = siriusViewModel(key = "project-$projectId") {
        ProjectDetailViewModel(it, projectId)
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors
    val picker = rememberWorkspacePicker { viewModel.attachWorkspace(it) }

    val listState = rememberLazyListState()
    // The bar only earns its seam once there is content hidden behind it.
    val scrolled by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 4 }
    }

    var renaming by remember { mutableStateOf(false) }
    // A stale recent file resolves to nothing; the failure has to be voiced or
    // the tap looks like the row is simply dead.
    var toast by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(state.message) {
        val message = state.message ?: return@LaunchedEffect
        toast = message
        viewModel.consumeMessage()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = state.project?.name ?: stringResource(R.string.project_title_fallback),
            subtitle = state.project?.workspaceLabel?.takeIf { it.isNotBlank() }
                ?: stringResource(R.string.projects_no_folder_attached),
            scrolled = scrolled,
            onBack = onBack,
            actions = {
                // Renaming needs the loaded project to seed the field.
                if (state.project == null) return@SiriusTopBar
                GlassIconButton(
                    icon = Icons.Rounded.DriveFileRenameOutline,
                    contentDescription = stringResource(R.string.project_rename),
                    onClick = { renaming = true }
                )
            }
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            state = listState,
            contentPadding = PaddingValues(
                start = SiriusSpacing.sm,
                end = SiriusSpacing.sm,
                top = SiriusSpacing.xs,
                bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
            ),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.sm)
        ) {
            item(key = "actions") {
                GlassCard {
                    SiriusPrimaryButton(
                        text = stringResource(R.string.chats_agent),
                        icon = Icons.Rounded.AutoAwesome,
                        onClick = { viewModel.startChat(onOpenChat, onOpenProviders) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    VSpace(SiriusSpacing.xs)
                    Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                        SiriusGhostButton(
                            text = if (state.project?.hasWorkspace == true) stringResource(R.string.project_change_folder)
                            else stringResource(R.string.project_attach_folder),
                            icon = Icons.Rounded.FolderOpen,
                            onClick = { picker.launch(null) },
                            modifier = Modifier.weight(1f)
                        )
                        SiriusGhostButton(
                            text = stringResource(R.string.files_title),
                            icon = Icons.AutoMirrored.Rounded.InsertDriveFile,
                            // Without a folder the Files tab has nothing to list.
                            enabled = state.project?.hasWorkspace == true,
                            onClick = onOpenFiles,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    VSpace(SiriusSpacing.xs)
                    Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                        SiriusGhostButton(
                            text = stringResource(R.string.git_title),
                            icon = Icons.Rounded.AccountTree,
                            // Git reads the folder itself; there is nothing to open
                            // until one is attached.
                            enabled = state.project?.hasWorkspace == true,
                            onClick = onOpenGit,
                            modifier = Modifier.weight(1f)
                        )
                        // The editor had no entry point of its own: it was reachable
                        // only by tapping a file, which is no way to get back to the
                        // tabs you already had open. It also filled the empty half of
                        // this row, which read as a missing button.
                        SiriusGhostButton(
                            text = stringResource(R.string.editor_title),
                            icon = Icons.Rounded.Code,
                            onClick = onOpenEditor,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            item(key = "insights") {
                GlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.Insights,
                            contentDescription = null,
                            tint = colors.accent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(SiriusSpacing.xs))
                        Text(
                            text = stringResource(R.string.project_insights),
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        if (state.analyzing) {
                            // A bare spinner is silent to a screen reader, so it
                            // announces the work it stands for.
                            CircularProgressIndicator(
                                modifier = Modifier
                                    .size(15.dp)
                                    .labelled(stringResource(R.string.project_analyzing)),
                                strokeWidth = 2.dp,
                                color = colors.primary
                            )
                        }
                    }
                    VSpace(SiriusSpacing.xs)
                    Text(
                        text = state.summary ?: stringResource(R.string.project_insights_empty),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    VSpace(SiriusSpacing.xs)
                    SiriusGhostButton(
                        text = stringResource(R.string.project_analyze),
                        onClick = viewModel::analyze,
                        enabled = state.project?.hasWorkspace == true && !state.analyzing,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            if (state.recentFiles.isNotEmpty()) {
                item(key = "recent-header") {
                    SectionHeader(title = stringResource(R.string.project_recent_files))
                }
                items(state.recentFiles, key = { it.documentId }) { file ->
                    GlassCard(
                        onClick = { viewModel.openRecentFile(file, onOpenEditor) },
                        onClickLabel = stringResource(R.string.files_open_in_editor),
                        contentPadding = SiriusSpacing.sm
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.AutoMirrored.Rounded.InsertDriveFile,
                                contentDescription = null,
                                tint = colors.primary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(Modifier.width(SiriusSpacing.xs))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = file.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    // A deep path is trimmed from the front, where
                                    // the least meaning lives.
                                    text = Formatters.shortPath(file.path),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colors.textTertiary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(Modifier.width(SiriusSpacing.xs))
                            Text(
                                text = relativeTimeText(file.openedAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.textTertiary
                            )
                        }
                    }
                }
            }

            item(key = "chats-header") {
                SectionHeader(
                    title = stringResource(R.string.project_conversations),
                    subtitle = pluralStringResource(
                        R.plurals.project_conversations_count,
                        state.sessions.size,
                        state.sessions.size
                    )
                )
            }
            if (state.sessions.isEmpty()) {
                item(key = "chats-empty") {
                    EmptyState(
                        icon = Icons.Rounded.ChatBubbleOutline,
                        title = stringResource(R.string.project_conversations_empty_title),
                        message = stringResource(R.string.project_conversations_empty_message)
                    )
                }
            }
            items(state.sessions, key = { it.id }) { session ->
                GlassCard(
                    onClick = { onOpenChat(session.id) },
                    onClickLabel = session.title,
                    contentPadding = SiriusSpacing.sm,
                    modifier = Modifier.animateItem()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = session.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = colors.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = relativeTimeText(session.updatedAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.textTertiary
                            )
                        }
                    }
                }
            }
        }
    }

    // The sheet needs the loaded name to seed its field, so it is bound to the
    // project rather than to the flag alone.
    state.project?.takeIf { renaming }?.let { project ->
        RenameProjectSheet(
            initial = project.name,
            onDismiss = { renaming = false },
            onConfirm = { name ->
                renaming = false
                viewModel.rename(name)
            }
        )
    }

    MessageToast(
        message = toast,
        tone = ToastTone.Error,
        bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.sm
    )
}

/**
 * Renames the project in place.
 *
 * The name is the only field, so the sheet opens with the keyboard up and the
 * IME action commits — the same contract as the naming sheet in Files.
 */
@Composable
private fun RenameProjectSheet(
    initial: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var value by remember { mutableStateOf(initial) }
    val trimmed = value.trim()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    SiriusBottomSheet(title = stringResource(R.string.project_rename), onDismiss = onDismiss) {
        SiriusTextField(
            value = value,
            onValueChange = { value = it },
            placeholder = stringResource(R.string.projects_name_placeholder),
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(focus),
            onImeAction = { if (trimmed.isNotBlank()) onConfirm(trimmed) }
        )
        VSpace(SiriusSpacing.md)
        SiriusPrimaryButton(
            text = stringResource(R.string.action_rename),
            onClick = { onConfirm(trimmed) },
            enabled = trimmed.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
