package com.sirius.chat.ai.provider

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.AiContentPart
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.streaming.SseParser
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.ProviderConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.job
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Speaks the `/chat/completions` protocol, which covers OpenAI itself plus
 * OpenRouter, Groq, Together, vLLM, LM Studio, Ollama and most self-hosted
 * gateways.
 */
class OpenAiCompatibleProvider(
    private val config: ProviderConfig,
    private val apiKey: String?,
    private val client: OkHttpClient = HttpClientProvider.client
) : AiProvider {

    override val id: String = config.id
    override val label: String = config.label
    override val models: List<AiModel> = config.models

    private val json = Json { ignoreUnknownKeys = true }

    override fun chat(request: ChatRequest): Flow<ChatStreamEvent> = flow {
        emit(ChatStreamEvent.Started)

        val payload = buildJsonObject {
            put("model", request.model)
            put("temperature", request.params.temperature)
            put("max_tokens", request.params.maxTokens)
            put("stream", request.stream)
            putJsonArray("messages") {
                request.systemPrompt?.takeIf { it.isNotBlank() }?.let { system ->
                    add(buildJsonObject {
                        put("role", "system")
                        put("content", system)
                    })
                }
                request.messages.forEach { message ->
                    add(buildJsonObject {
                        put("role", message.role.wireName())
                        if (message.parts.isEmpty()) {
                            // String content, exactly as before: some
                            // OpenAI-compatible servers reject the array form
                            // outright, so it is only used when there is something
                            // that needs it.
                            put("content", message.content)
                        } else {
                            putJsonArray("content") {
                                message.parts.forEach { part -> add(contentBlock(part)) }
                            }
                        }
                    })
                }
            }
        }

        val httpRequest = Request.Builder()
            .url(config.baseUrl.trimEnd('/') + "/chat/completions")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .apply {
                header("Content-Type", "application/json")
                if (!apiKey.isNullOrBlank()) header("Authorization", "Bearer $apiKey")
                if (request.stream) header("Accept", "text/event-stream")
            }
            .build()

        val call = client.newCall(httpRequest)
        // OkHttp reads block; cancelling the coroutine must abort the socket.
        currentCoroutineContext().job.invokeOnCompletion { if (!call.isCanceled()) call.cancel() }

        val response = runCatching { call.execute() }.getOrElse { error ->
            emit(ChatStreamEvent.Failure(error.toAiError()))
            return@flow
        }

        response.use { httpResponse ->
            if (!httpResponse.isSuccessful) {
                val body = runCatching { httpResponse.body?.string() }.getOrNull().orEmpty()
                emit(ChatStreamEvent.Failure(httpError(httpResponse.code, body)))
                return@flow
            }
            val source = httpResponse.body?.source()
            if (source == null) {
                emit(
                    ChatStreamEvent.Failure(
                        AiError(
                            AiError.Kind.Server,
                            AppStrings.get(R.string.error_empty_body, fallback = "Empty response body")
                        )
                    )
                )
                return@flow
            }

            val builder = StringBuilder()
            var finishReason: String? = null
            var reasoningChars = 0
            var streamError: String? = null

            if (!request.stream) {
                val text = source.readUtf8()
                val root = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
                streamError = root?.errorMessage()
                val choice = root?.get("choices")?.jsonArray?.firstOrNull()?.jsonObject
                val message = choice?.get("message")?.jsonObject
                val content = (message?.get("content") as? JsonPrimitive)?.contentOrNull
                reasoningChars = message?.reasoningText()?.length ?: 0
                finishReason = (choice?.get("finish_reason") as? JsonPrimitive)?.contentOrNull
                if (content != null) {
                    builder.append(content)
                    emit(ChatStreamEvent.Delta(content))
                }
            } else {
                // SseParser.read is inline, so tokens are emitted downstream the
                // moment they arrive instead of being buffered.
                SseParser.read(source) { event ->
                    if (event.data == SseParser.DONE) return@read false
                    val chunk = extractDelta(event.data)
                    if (chunk.error != null) {
                        streamError = chunk.error
                        return@read false
                    }
                    if (chunk.finish != null) finishReason = chunk.finish
                    chunk.reasoning?.let { reasoningChars += it.length }
                    val text = chunk.content
                    if (!text.isNullOrEmpty()) {
                        builder.append(text)
                        emit(ChatStreamEvent.Delta(text))
                    }
                    true
                }
            }

            val problem = streamError
            if (problem != null) {
                emit(ChatStreamEvent.Failure(AiError(AiError.Kind.Server, problem)))
                return@use
            }

            emit(ChatStreamEvent.Completed(finishReason, builder.toString(), reasoningChars))
        }
    }.flowOn(Dispatchers.IO)

    /**
     * One SSE payload, split into what belongs in the answer and what does not.
     *
     * Reasoning models return their thinking in a field of its own --
     * `reasoning_content` on DeepSeek, `reasoning` on OpenRouter -- and it must
     * never be concatenated into the answer: it is a draft, often in another
     * language, and the tool-call parser would try to read it.
     *
     * It cannot be discarded either. A turn that spends its whole `max_tokens`
     * budget thinking arrives here with an empty `content`, and only the
     * reasoning tells the difference between "this model thought and ran out of
     * room" and "this endpoint sent nothing".
     *
     * Fields are read through `as? JsonPrimitive` rather than `.jsonPrimitive`,
     * which throws: a gateway that returns `content` as an array of parts used
     * to take down the whole stream with an exception instead of dropping one
     * chunk.
     */
    private data class Chunk(
        val content: String?,
        val reasoning: String?,
        val finish: String?,
        /**
         * Gateway error delivered inside a 200 response.
         *
         * Rate limits and upstream provider failures routinely arrive as
         * `data: {"error":{...}}` *after* the headers are already on the wire,
         * so the HTTP status is 200 and the old parser, which only looked at
         * `choices`, dropped the message on the floor and reported an empty
         * answer. The one thing the user needed to see was in that payload.
         */
        val error: String? = null
    )

    private fun extractDelta(data: String): Chunk {
        val root = runCatching { json.parseToJsonElement(data).jsonObject }.getOrNull()
            ?: return EMPTY_CHUNK
        root.errorMessage()?.let { return EMPTY_CHUNK.copy(error = it) }
        val choice = (root["choices"] as? JsonArray)?.firstOrNull()?.jsonObject
            ?: return EMPTY_CHUNK
        val delta = choice["delta"] as? JsonObject
        return Chunk(
            content = (delta?.get("content") as? JsonPrimitive)?.contentOrNull,
            reasoning = delta?.reasoningText(),
            finish = (choice["finish_reason"] as? JsonPrimitive)?.contentOrNull
        )
    }

    /** Thinking text under either of the two field names in use. */
    private fun JsonObject.reasoningText(): String? =
        (this["reasoning_content"] as? JsonPrimitive)?.contentOrNull
            ?: (this["reasoning"] as? JsonPrimitive)?.contentOrNull

    /**
     * Error text from an `error` field, whether it is an object or a bare string.
     *
     * Blank is treated as absent so an `"error": ""` field, which some gateways
     * send on every chunk, cannot abort a healthy stream.
     */
    private fun JsonObject.errorMessage(): String? {
        val node = this["error"] ?: return null
        val text = when (node) {
            is JsonObject -> (node["message"] as? JsonPrimitive)?.contentOrNull
            is JsonPrimitive -> node.contentOrNull
            else -> null
        }
        return text?.takeIf { it.isNotBlank() }
    }

    private fun AiRole.wireName(): String = when (this) {
        AiRole.System -> "system"
        AiRole.User -> "user"
        AiRole.Assistant -> "assistant"
    }

    private companion object {
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        val EMPTY_CHUNK = Chunk(null, null, null)
    }

    /**
     * One content block in the OpenAI chat-completions format.
     *
     * Images travel as `image_url` with a data uri. PDFs have no equivalent here,
     * so instead of sending something the endpoint would reject, the model is told
     * the document exists and cannot be read — which is recoverable, unlike a
     * failed request.
     */
    private fun contentBlock(part: AiContentPart): JsonObject = when (part) {
        is AiContentPart.Text -> buildJsonObject {
            put("type", "text")
            put("text", part.text)
        }
        is AiContentPart.Image -> buildJsonObject {
            put("type", "image_url")
            putJsonObject("image_url") {
                put("url", "data:${part.mediaType};base64,${part.base64}")
            }
        }
        is AiContentPart.Document -> buildJsonObject {
            put("type", "text")
            put(
                "text",
                "[Attached document \"${part.name}\" — this provider cannot receive PDF " +
                    "documents. Ask the user for the relevant text, or to switch to a provider " +
                    "that supports documents.]"
            )
        }
    }

}
