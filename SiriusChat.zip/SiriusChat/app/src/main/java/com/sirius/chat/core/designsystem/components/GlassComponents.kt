package com.sirius.chat.core.designsystem.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.effects.beamBorder
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.effects.shimmer
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.util.rememberHaptics

/**
 * The workhorse container of the whole app.
 *
 * A tappable card is a physical object: it sinks on press (spring, not tween)
 * and loses a little of its elevation at the same time, which is what sells the
 * metal plate as something being pushed rather than a rectangle being tinted.
 * [active] lends the card the app's single "live" signal for the rare row that
 * is genuinely working (a running terminal, a streaming turn).
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(SiriusRadius.lg),
    elevation: Dp = 10.dp,
    tint: Color? = null,
    onClick: (() -> Unit)? = null,
    onClickLabel: String? = null,
    active: Boolean = false,
    contentPadding: Dp = SiriusSpacing.md,
    content: @Composable ColumnScope.() -> Unit
) {
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val interactive = onClick != null
    val scale by animateFloatAsState(
        targetValue = if (pressed && interactive) 0.978f else 1f,
        animationSpec = siriusSpring(),
        label = "cardPress"
    )
    val lift by animateFloatAsState(
        targetValue = if (pressed && interactive) 0.45f else 1f,
        animationSpec = siriusSpring(),
        label = "cardLift"
    )

    Column(
        modifier = modifier
            .scale(scale)
            .glassSurface(shape = shape, elevation = elevation * lift, tint = tint)
            .beamBorder(shape = shape, active = active, rim = false)
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interaction,
                        indication = null,
                        role = Role.Button,
                        onClickLabel = onClickLabel
                    ) {
                        haptics.light()
                        onClick()
                    }
                } else {
                    Modifier
                }
            )
            .padding(contentPadding),
        content = content
    )
}

/**
 * Small milled label used for statuses, models, languages and counts.
 *
 * Selection animates the text and icon colour rather than swapping it, and a
 * selected chip reports itself as such to the accessibility layer instead of
 * relying on the tint alone.
 */
@Composable
fun SiriusChip(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    color: Color? = null,
    selected: Boolean = false,
    enabled: Boolean = true,
    onClick: (() -> Unit)? = null
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val accent = color ?: colors.textSecondary
    val shape = RoundedCornerShape(SiriusRadius.pill)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && onClick != null) 0.94f else 1f,
        animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
        label = "chipPress"
    )
    val content by animateColorAsState(
        targetValue = when {
            !enabled -> colors.textTertiary
            selected -> colors.primary
            else -> accent
        },
        animationSpec = siriusTween(SiriusMotion.Quick),
        label = "chipTint"
    )

    Row(
        modifier = modifier
            .scale(scale)
            .then(
                if (selected) {
                    Modifier
                        .background(colors.primarySoft, shape)
                        .softSurface(shape, alpha = 0.4f)
                } else {
                    Modifier.softSurface(shape)
                }
            )
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        enabled = enabled,
                        interactionSource = interaction,
                        indication = null,
                        role = Role.Tab
                    ) {
                        haptics.light()
                        onClick()
                    }
                } else {
                    Modifier
                }
            )
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = content,
                modifier = Modifier.size(14.dp)
            )
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = content,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Section title with an optional trailing action.
 *
 * The eyebrow-free version: a semibold title, a quiet subtitle, and a text
 * action whose touch box is padded out to a real target.
 */
@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = SiriusSpacing.xxs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
                fontWeight = FontWeight.SemiBold
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary
                )
            }
        }
        if (actionLabel != null && onAction != null) {
            Text(
                text = actionLabel,
                style = MaterialTheme.typography.labelLarge,
                color = colors.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(SiriusRadius.pill))
                    .clickable(role = Role.Button, onClick = onAction)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}

/**
 * Separator that fades out at both ends instead of hitting the edges, so a list
 * reads as one continuous surface with seams rather than as stacked boxes.
 */
@Composable
fun GlassDivider(modifier: Modifier = Modifier, alpha: Float = 1f) {
    val colors = SiriusTheme.colors
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(
                Brush.horizontalGradient(
                    0.00f to Color.Transparent,
                    0.12f to colors.outline.copy(alpha = colors.outline.alpha * alpha),
                    0.88f to colors.outline.copy(alpha = colors.outline.alpha * alpha),
                    1.00f to Color.Transparent
                )
            )
    )
}

/**
 * Placeholder block for content that is on its way.
 *
 * Skeletons beat spinners for lists because they hold the layout still — the
 * real row lands where the placeholder already was, so nothing jumps. The sweep
 * comes from [shimmer], which parks itself under reduced motion.
 */
@Composable
fun SkeletonBlock(
    modifier: Modifier = Modifier,
    height: Dp = 14.dp,
    widthFraction: Float = 1f,
    shape: Shape = RoundedCornerShape(SiriusRadius.xs)
) {
    val colors = SiriusTheme.colors
    Box(
        modifier = modifier
            .fillMaxWidth(widthFraction)
            .height(height)
            .clip(shape)
            .background(colors.surfaceMuted.copy(alpha = 0.7f), shape)
            .shimmer(shape = shape)
            .clearAndSetSemantics { }
    )
}

/** A skeleton shaped like a list row: avatar plate, title line, meta line. */
@Composable
fun SkeletonRow(
    modifier: Modifier = Modifier,
    showLeading: Boolean = true,
    lines: Int = 2
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = SiriusSpacing.xs),
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.sm),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showLeading) {
            SkeletonBlock(
                modifier = Modifier.size(40.dp),
                height = 40.dp,
                shape = RoundedCornerShape(SiriusRadius.sm)
            )
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
        ) {
            SkeletonBlock(height = 13.dp, widthFraction = 0.62f)
            if (lines > 1) SkeletonBlock(height = 11.dp, widthFraction = 0.88f)
            if (lines > 2) SkeletonBlock(height = 11.dp, widthFraction = 0.4f)
        }
    }
}

@Composable
fun VSpace(height: Dp) = Spacer(Modifier.height(height))

@Composable
fun HSpace(width: Dp) = Spacer(Modifier.width(width))

/** Provides a default content color for a subtree. */
@Composable
fun WithContentColor(color: Color, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalContentColor provides color, content = content)
}

/** Marks a purely decorative subtree as invisible to screen readers. */
fun Modifier.decorative(): Modifier = clearAndSetSemantics { }

/** Attaches a label to an otherwise unlabelled visual. */
fun Modifier.labelled(label: String): Modifier =
    clearAndSetSemantics { contentDescription = label }
