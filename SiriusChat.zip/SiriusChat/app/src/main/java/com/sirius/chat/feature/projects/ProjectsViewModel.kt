package com.sirius.chat.feature.projects

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.core.util.CodeLanguages
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.RecentFile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProjectsUiState(
    val projects: List<Project> = emptyList(),
    val activeProjectId: String = "",
    val pendingTreeUri: String? = null,
    /**
     * True only until the first list arrives from the database, so the screen can
     * hold a skeleton instead of flashing the "no projects yet" empty state at a
     * user who has plenty of them.
     */
    val loading: Boolean = true
)

class ProjectsViewModel(private val container: AppContainer) : ViewModel() {

    private val _pendingTreeUri = MutableStateFlow<String?>(null)

    val state: StateFlow<ProjectsUiState> = combine(
        container.projectRepository.observeProjects(),
        container.settingsRepository.settings,
        _pendingTreeUri
    ) { projects, settings, pending ->
        ProjectsUiState(projects, settings.activeProjectId, pending, loading = false)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ProjectsUiState())

    fun onFolderPicked(treeUri: String) {
        _pendingTreeUri.value = treeUri
    }

    fun cancelCreation() {
        _pendingTreeUri.value = null
    }

    fun confirmCreation(name: String, accentIndex: Int, onCreated: (String) -> Unit) {
        val treeUri = _pendingTreeUri.value ?: return
        _pendingTreeUri.value = null
        viewModelScope.launch {
            val project = container.createProject(
                name = name,
                treeUri = treeUri,
                accentIndex = accentIndex
            )
            container.settingsRepository.update { it.copy(activeProjectId = project.id) }
            onCreated(project.id)
        }
    }

    fun activate(project: Project) {
        viewModelScope.launch {
            container.settingsRepository.update { it.copy(activeProjectId = project.id) }
            container.projectRepository.touch(project.id)
            container.projectContextBuilder.invalidate()
        }
    }

    fun toggleFavorite(project: Project) {
        viewModelScope.launch {
            container.projectRepository.setFavorite(project.id, !project.favorite)
        }
    }

    fun delete(project: Project) {
        viewModelScope.launch { container.deleteProject(project.id, releaseAccess = true) }
    }
}

data class ProjectDetailUiState(
    val project: Project? = null,
    val sessions: List<ChatSession> = emptyList(),
    val recentFiles: List<RecentFile> = emptyList(),
    val fileCount: Int = 0,
    val analyzing: Boolean = false,
    val summary: String? = null,
    val message: String? = null
)

class ProjectDetailViewModel(
    private val container: AppContainer,
    private val projectId: String
) : ViewModel() {

    /**
     * Everything this screen owns rather than observes, kept in one flow because
     * [combine] only reaches five sources and the repositories already use three.
     */
    private data class Local(
        val analyzing: Boolean = false,
        val summary: String? = null,
        val message: String? = null
    )

    private val local = MutableStateFlow(Local())

    val state: StateFlow<ProjectDetailUiState> = combine(
        container.projectRepository.observeProject(projectId),
        container.chatRepository.observeSessions(projectId),
        container.projectRepository.observeRecentFiles(projectId),
        local
    ) { project, sessions, files, own ->
        ProjectDetailUiState(
            project = project,
            sessions = sessions,
            recentFiles = files,
            fileCount = files.size,
            analyzing = own.analyzing,
            summary = own.summary,
            message = own.message
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ProjectDetailUiState())

    /**
     * Scans the attached folder.
     *
     * Without a folder there is nothing to scan, and the button used to swallow
     * the tap: the card says "scan the folder", so the answer to "which folder?"
     * has to be said out loud rather than implied.
     */
    fun analyze() {
        viewModelScope.launch {
            val project = container.projectRepository.get(projectId)
            val tree = project?.treeUri
            if (tree == null) {
                local.value = local.value.copy(
                    message = container.strings.get(R.string.project_needs_workspace)
                )
                return@launch
            }
            local.value = local.value.copy(analyzing = true)
            val snapshot = runCatching { container.workspaceRepository.snapshot(tree) }.getOrNull()
            local.value = local.value.copy(
                analyzing = false,
                summary = snapshot?.let {
                    buildString {
                        appendLine("${it.fileCount} files \u00B7 ${it.directoryCount} folders")
                        val languages = it.languages.entries.joinToString(", ") { entry ->
                            "${entry.key} \u00D7 ${entry.value}"
                        }
                        if (languages.isNotBlank()) appendLine(languages)
                    }
                },
                message = if (snapshot == null) {
                    container.strings.get(R.string.files_cannot_open_folder)
                } else {
                    null
                }
            )
        }
    }

    /**
     * Opens one of the recently touched files straight into the editor.
     *
     * The stored document id can be stale after a rename or a move outside the
     * app, so the file is resolved by path and the row reports a real failure
     * instead of doing nothing when the file is gone.
     */
    fun openRecentFile(file: RecentFile, onOpened: () -> Unit) {
        viewModelScope.launch {
            val tree = container.projectRepository.get(projectId)?.treeUri
            if (tree == null) {
                local.value = local.value.copy(
                    message = container.strings.get(R.string.project_needs_workspace)
                )
                return@launch
            }
            val node = container.workspaceRepository.findByPath(tree, file.path)
            if (node == null) {
                local.value = local.value.copy(
                    message = container.strings.get(R.string.files_could_not_open, file.name)
                )
                return@launch
            }
            if (!CodeLanguages.isProbablyText(node.name, node.mimeType)) {
                local.value = local.value.copy(
                    message = container.strings.get(R.string.files_not_text, node.name)
                )
                return@launch
            }
            val content = container.workspaceRepository.readText(tree, node.documentId)
            container.editorSessionStore.open(
                node = node,
                content = content,
                readOnly = node.sizeBytes > LARGE_FILE_BYTES
            )
            container.projectRepository.rememberFile(
                file.copy(
                    documentId = node.documentId,
                    openedAt = System.currentTimeMillis()
                )
            )
            onOpened()
        }
    }

    fun consumeMessage() {
        local.value = local.value.copy(message = null)
    }

    fun attachWorkspace(treeUri: String) {
        viewModelScope.launch {
            container.attachWorkspace(projectId, treeUri)
            container.projectContextBuilder.invalidate()
        }
    }

    fun rename(name: String) {
        viewModelScope.launch {
            val project = container.projectRepository.get(projectId) ?: return@launch
            container.projectRepository.upsert(project.copy(name = name))
        }
    }

    /** Same empty-provider dead end as [com.sirius.chat.feature.chat.ChatListViewModel.newChat]. */
    fun startChat(onReady: (String) -> Unit, onNeedsProvider: () -> Unit = {}) {
        viewModelScope.launch {
            val settings = container.settingsRepository.current()
            val providers = container.providerRepository.providers()
            val provider = providers.firstOrNull { it.id == settings.activeProviderId }
                ?: providers.firstOrNull { it.hasKey }
                ?: providers.firstOrNull()
            if (provider == null) {
                local.value = local.value.copy(
                    message = container.strings.get(R.string.chats_needs_provider)
                )
                onNeedsProvider()
                return@launch
            }
            val session = container.createSession(
                providerId = provider.id,
                model = settings.activeModel.ifBlank { provider.defaultModel },
                projectId = projectId,
                title = container.strings.get(R.string.chats_untitled_agent)
            )
            onReady(session.id)
        }
    }

    private companion object {
        /** Above this size the editor opens read-only, matching the Files screen. */
        const val LARGE_FILE_BYTES = 512L * 1024
    }
}
