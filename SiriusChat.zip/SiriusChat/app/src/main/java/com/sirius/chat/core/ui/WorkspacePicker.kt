package com.sirius.chat.core.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState

/**
 * Storage Access Framework folder picker.
 *
 * Sirius never asks for broad storage permissions: the user grants exactly one
 * folder and the app takes a persistable grant for it.
 */
@Composable
fun rememberWorkspacePicker(
    onPicked: (String) -> Unit
): ManagedActivityResultLauncher<Uri?, Uri?> {
    val callback = rememberUpdatedState(onPicked)
    return rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) callback.value(uri.toString())
    }
}

/** Flags requested together with the tree so the grant survives reboots. */
const val WORKSPACE_GRANT_FLAGS =
    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
