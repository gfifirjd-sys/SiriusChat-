package com.sirius.chat.core.designsystem.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.domain.model.GlassLevel

/**
 * The page.
 *
 * This used to be an animated sheet of poured metal — three drifting molten
 * pools under an 80dp gaussian blur, with a specular band sweeping across the
 * screen on a 26s loop. It was the single most expensive thing the app drew, it
 * ran on every screen at all times, and once the accent became a real metal
 * shader it was also the thing that made that accent hard to see.
 *
 * So the page is now just the page: one opaque fill, plus an almost imperceptible
 * top-to-bottom lift that keeps a full-bleed dark screen from looking like a
 * dead panel on OLED. Nothing animates, nothing blurs, nothing recomposes.
 */
@Composable
fun SiriusBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val colors = SiriusTheme.colors
    val flat = SiriusTheme.glass == GlassLevel.Off

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                if (flat) {
                    // Effects off means literally one colour, no ramp at all.
                    Brush.verticalGradient(listOf(colors.background, colors.background))
                } else {
                    Brush.verticalGradient(
                        0.00f to colors.backgroundElevated,
                        0.55f to colors.background,
                        1.00f to colors.background
                    )
                }
            ),
        content = content
    )
}

/** Kept for call sites that only need the flat page colour without a Box. */
@Composable
fun siriusPageColor(): Color = SiriusTheme.colors.background
