package com.sirius.chat.feature.git.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sirius.chat.core.designsystem.components.sheetDragGuard
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.designsystem.components.InlineBusyRow
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.decorative
import com.sirius.chat.domain.model.DiffLineType
import com.sirius.chat.domain.model.FileDiff
import com.sirius.chat.feature.git.GitDiffTarget

/**
 * Read-only diff for one path.
 *
 * Nothing here can be accepted or rejected per hunk: git already has a place
 * for that decision — the index — so the sheet only shows what is different and
 * lets the user switch which pair of versions is being compared.
 */
@Composable
fun GitDiffSheet(
    target: GitDiffTarget,
    diff: FileDiff?,
    loading: Boolean,
    canToggleSide: Boolean,
    onToggleSide: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors

    SiriusBottomSheet(
        title = target.path.substringAfterLast('/'),
        subtitle = target.path,
        onDismiss = onDismiss,
        scrollable = false
    ) {
        Row(
            modifier = Modifier.padding(bottom = SiriusSpacing.xs),
            horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SiriusChip(
                text = if (target.staged) {
                    stringResource(R.string.git_diff_staged)
                } else {
                    stringResource(R.string.git_diff_unstaged)
                },
                selected = true,
                color = if (target.staged) colors.success else colors.primary,
                onClick = if (canToggleSide) onToggleSide else null
            )
            if (diff != null && !diff.isEmpty) {
                val counts = stringResource(R.string.review_counts, diff.added, diff.removed)
                Row(modifier = Modifier.semantics { contentDescription = counts }) {
                    Text(
                        text = "+${diff.added}",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.diffAddedText
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "\u2212${diff.removed}",
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.diffRemovedText
                    )
                }
            }
        }

        when {
            loading -> InlineBusyRow(label = stringResource(R.string.git_diff_loading))

            diff == null -> Text(
                text = stringResource(R.string.git_diff_unavailable),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary
            )

            diff.binary -> Text(
                text = stringResource(R.string.git_diff_binary),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary
            )

            diff.isEmpty -> Text(
                text = stringResource(R.string.git_diff_empty),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary
            )

            else -> LazyColumn(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .sheetDragGuard(),
                verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
            ) {
                items(diff.hunks.size, key = { diff.hunks[it].id }) { index ->
                    val hunk = diff.hunks[index]
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(SiriusRadius.sm))
                            .background(colors.codeBackground)
                    ) {
                        Text(
                            text = "@@ -${hunk.oldStart} +${hunk.newStart}",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textTertiary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                        val horizontal = rememberScrollState()
                        Column(modifier = Modifier.horizontalScroll(horizontal)) {
                            hunk.lines.forEach { line ->
                                val background = when (line.type) {
                                    DiffLineType.Added -> colors.diffAdded
                                    DiffLineType.Removed -> colors.diffRemoved
                                    DiffLineType.Context -> Color.Transparent
                                }
                                val textColor = when (line.type) {
                                    DiffLineType.Added -> colors.diffAddedText
                                    DiffLineType.Removed -> colors.diffRemovedText
                                    DiffLineType.Context -> colors.codePlain
                                }
                                Row(
                                    modifier = Modifier
                                        .background(background)
                                        .padding(horizontal = 8.dp, vertical = 1.dp)
                                ) {
                                    Box(modifier = Modifier.decorative()) {
                                        Text(
                                            text = (line.newLineNumber ?: line.oldLineNumber)
                                                ?.toString().orEmpty().padStart(4),
                                            style = codeTextStyle(11).copy(
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 11.sp
                                            ),
                                            color = colors.codeComment
                                        )
                                    }
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = line.text,
                                        style = codeTextStyle(11).copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp
                                        ),
                                        color = textColor
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
