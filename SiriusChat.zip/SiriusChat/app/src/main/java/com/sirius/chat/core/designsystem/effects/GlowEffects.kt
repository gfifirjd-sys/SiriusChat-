package com.sirius.chat.core.designsystem.effects

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.domain.model.GlassLevel
import kotlin.math.min

/**
 * A light beam that travels along the outline of a shape.
 *
 * The metal layer already tells you what a surface is *made of*; the beam tells
 * you what it is *doing*. It is the app's single "live" signal, so it is only
 * ever attached to something actually in progress — the composer while the model
 * answers, the streaming bubble, a focused field.
 *
 * Implementation is a literal beam rather than a rotating conic gradient: the
 * shape outline is measured once per size change, then a short arc-length
 * segment is cut from it every frame and stroked three times (wide + faint,
 * medium, then a tight bright core). Because the geometry is cached and only the
 * progress is read in the draw phase, an animating beam costs one draw pass and
 * zero recompositions.
 */
@Composable
fun Modifier.beamBorder(
    shape: Shape = RoundedCornerShape(SiriusRadius.lg),
    active: Boolean = true,
    strokeWidth: Dp = 1.5.dp,
    beamFraction: Float = 0.22f,
    head: Color? = null,
    tail: Color? = null,
    durationMillis: Int = SiriusMotion.AmbientBeam,
    rim: Boolean = true
): Modifier {
    val colors = SiriusTheme.colors
    val reduceMotion = SiriusTheme.reduceMotion
    val level = SiriusTheme.glass

    // Effects off is an explicit user setting, not a performance guess.
    if (!active || level == GlassLevel.Off) return this

    val headColor = head ?: colors.primary
    val tailColor = tail ?: colors.secondary

    // Reduced motion still gets the beam, parked at the top-left corner, so the
    // "this is live" affordance survives even without movement.
    val progress: State<Float> = if (reduceMotion) {
        rememberUpdatedState(0.06f)
    } else {
        val transition = rememberInfiniteTransition(label = "beam")
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "beamProgress"
        )
    }

    // Fades the beam in/out instead of popping it, so toggling `active`
    // (generating -> idle) does not snap.
    val intensity by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(if (reduceMotion) 0 else SiriusMotion.Base),
        label = "beamIntensity"
    )

    return drawWithCache {
        val path = shape.createOutline(size, layoutDirection, this).toPath()
        val measure = PathMeasure().apply { setPath(path, forceClosed = true) }
        val total = measure.length
        val core = strokeWidth.toPx()
        val segment = Path()

        onDrawWithContent {
            drawContent()

            if (rim) {
                drawPath(
                    path = path,
                    color = colors.metalRim.copy(alpha = colors.metalRim.alpha * 0.6f),
                    style = Stroke(width = core)
                )
            }
            if (total <= 0f) return@onDrawWithContent

            val beamLength = total * beamFraction
            val start = progress.value * total
            val end = start + beamLength

            segment.reset()
            measure.getSegment(start, min(end, total), segment, true)
            if (end > total) {
                // Wrap around the closed outline so the beam never blinks at the
                // seam.
                measure.getSegment(0f, end - total, segment, true)
            }

            val a = intensity
            // Outer bloom -> inner bloom -> bright core. Three strokes read as a
            // glow without ever touching a real blur.
            //
            // Clipped to the outline it travels along: the widest bloom is seven
            // times the hairline, and unclipped it hangs that far off the edge as
            // a loose arc that reads as a misdrawn border rather than a glow.
            clipPath(path) {
                drawPath(segment, color = headColor.copy(alpha = 0.10f * a), style = Stroke(core * 7f, cap = StrokeCap.Round))
                drawPath(segment, color = headColor.copy(alpha = 0.22f * a), style = Stroke(core * 3.5f, cap = StrokeCap.Round))
                drawPath(
                    path = segment,
                    brush = Brush.linearGradient(
                        0.00f to tailColor.copy(alpha = 0f),
                        0.45f to tailColor.copy(alpha = 0.55f * a),
                        1.00f to headColor.copy(alpha = 0.95f * a)
                    ),
                    style = Stroke(core * 1.7f, cap = StrokeCap.Round)
                )
            }
        }
    }
}

/**
 * Coloured outer bloom. Uses the platform's coloured elevation shadow, which is
 * GPU-composited, instead of a blurred sibling layer — so it is free even on the
 * lowest devices we support. Nothing is drawn when effects are off.
 */
@Composable
fun Modifier.ambientGlow(
    color: Color? = null,
    shape: Shape = RoundedCornerShape(SiriusRadius.lg),
    radius: Dp = 18.dp,
    alpha: Float = 0.55f
): Modifier {
    val colors = SiriusTheme.colors
    if (SiriusTheme.glass == GlassLevel.Off || radius <= 0.dp) return this
    val glow = (color ?: colors.primary).copy(alpha = alpha)
    return shadow(
        elevation = radius,
        shape = shape,
        clip = false,
        ambientColor = glow,
        spotColor = glow
    )
}

/**
 * Traveling highlight for placeholder / skeleton content. Static (a flat wash)
 * under reduced motion, because a looping sweep is exactly the kind of thing the
 * setting exists to stop.
 */
@Composable
fun Modifier.shimmer(
    active: Boolean = true,
    shape: Shape = RoundedCornerShape(SiriusRadius.sm),
    durationMillis: Int = 1_400
): Modifier {
    val colors = SiriusTheme.colors
    val reduceMotion = SiriusTheme.reduceMotion
    if (!active) return this

    val progress: State<Float> = if (reduceMotion) {
        rememberUpdatedState(0.5f)
    } else {
        rememberInfiniteTransition(label = "shimmer").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "shimmerProgress"
        )
    }
    val sheen = remember(colors.metalSpecular) { colors.metalSpecular }

    return drawWithCache {
        val path = shape.createOutline(size, layoutDirection, this).toPath()
        onDrawWithContent {
            drawContent()
            val band = size.width * 0.6f
            val x = -band + progress.value * (size.width + band * 2f)
            clipPath(path) {
                drawRect(
                    brush = Brush.horizontalGradient(
                        0f to Color.Transparent,
                        0.5f to sheen.copy(alpha = sheen.alpha * 0.7f),
                        1f to Color.Transparent,
                        startX = x,
                        endX = x + band
                    )
                )
            }
        }
    }
}

/** Shapes in this design system are all rounded rects, but stay generic. */
internal fun Outline.toPath(): Path = when (this) {
    is Outline.Rectangle -> Path().apply { addRect(rect) }
    is Outline.Rounded -> Path().apply { addRoundRect(roundRect) }
    is Outline.Generic -> path
}
