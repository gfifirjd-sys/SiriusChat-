package com.sirius.chat.core.designsystem

import android.app.Activity
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.sirius.chat.domain.model.GlassLevel
import com.sirius.chat.domain.model.ThemeMode

val LocalSiriusPalette = staticCompositionLocalOf { DarkSiriusPalette }
val LocalGlassLevel = staticCompositionLocalOf { GlassLevel.Full }
val LocalReduceMotion = staticCompositionLocalOf { false }

/** Shorthand accessor: `SiriusTheme.colors.primary`. */
object SiriusTheme {
    val colors: SiriusPalette
        @Composable get() = LocalSiriusPalette.current
    val glass: GlassLevel
        @Composable get() = LocalGlassLevel.current
    val reduceMotion: Boolean
        @Composable get() = LocalReduceMotion.current
}

private fun SiriusPalette.toColorScheme() = if (isDark) {
    darkColorScheme(
        primary = primary,
        onPrimary = onPrimary,
        primaryContainer = primarySoft,
        onPrimaryContainer = textPrimary,
        secondary = secondary,
        onSecondary = onPrimary,
        tertiary = accent,
        onTertiary = onPrimary,
        background = background,
        onBackground = textPrimary,
        surface = surface,
        onSurface = textPrimary,
        surfaceVariant = surfaceMuted,
        onSurfaceVariant = textSecondary,
        outline = outline,
        outlineVariant = outline,
        error = error,
        onError = Color.White,
        scrim = Color(0x99000000)
    )
} else {
    lightColorScheme(
        primary = primary,
        onPrimary = onPrimary,
        primaryContainer = primarySoft,
        onPrimaryContainer = textPrimary,
        secondary = secondary,
        onSecondary = onPrimary,
        tertiary = accent,
        onTertiary = onPrimary,
        background = background,
        onBackground = textPrimary,
        surface = surface,
        onSurface = textPrimary,
        surfaceVariant = surfaceMuted,
        onSurfaceVariant = textSecondary,
        outline = outline,
        outlineVariant = outline,
        error = error,
        onError = Color.White,
        scrim = Color(0x66000000)
    )
}

/**
 * Root theme. Palette colors are animated so switching Light/Dark cross-fades
 * instead of snapping.
 */
@Composable
fun SiriusTheme(
    themeMode: ThemeMode = ThemeMode.System,
    accentColor: Int = 0,
    glassLevel: GlassLevel = GlassLevel.Full,
    reduceMotion: Boolean = false,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (themeMode) {
        ThemeMode.System -> systemDark
        ThemeMode.Light -> false
        ThemeMode.Dark -> true
    }
    // The accent is folded in *before* the cross-fade, so changing colour animates
    // exactly like flipping Light/Dark instead of snapping to the new tint.
    val target = (if (dark) DarkSiriusPalette else LightSiriusPalette).withAccent(accentColor)
    val palette = if (reduceMotion) target else target.animated()

    val colorScheme = palette.toColorScheme()

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }

    CompositionLocalProvider(
        LocalSiriusPalette provides palette,
        LocalGlassLevel provides glassLevel,
        LocalReduceMotion provides reduceMotion
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = SiriusTypography,
            shapes = SiriusShapes,
            content = content
        )
    }
}

@Composable
private fun SiriusPalette.animated(): SiriusPalette {
    val spec = tween<Color>(durationMillis = 320)

    @Composable
    fun anim(color: Color, label: String): Color =
        animateColorAsState(targetValue = color, animationSpec = spec, label = label).value

    return copy(
        background = anim(background, "bg"),
        backgroundElevated = anim(backgroundElevated, "bgElev"),
        surface = anim(surface, "surface"),
        surfaceMuted = anim(surfaceMuted, "surfaceMuted"),
        metalCrown = anim(metalCrown, "metalCrown"),
        metalBody = anim(metalBody, "metalBody"),
        metalTrough = anim(metalTrough, "metalTrough"),
        metalBounce = anim(metalBounce, "metalBounce"),
        metalRim = anim(metalRim, "metalRim"),
        primary = anim(primary, "primary"),
        primarySoft = anim(primarySoft, "primarySoft"),
        accent = anim(accent, "accent"),
        onPrimary = anim(onPrimary, "onPrimary"),
        textPrimary = anim(textPrimary, "textPrimary"),
        textSecondary = anim(textSecondary, "textSecondary"),
        textTertiary = anim(textTertiary, "textTertiary"),
        outline = anim(outline, "outline")
    )
}
