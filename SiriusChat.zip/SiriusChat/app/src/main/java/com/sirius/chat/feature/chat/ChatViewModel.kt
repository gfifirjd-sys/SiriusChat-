package com.sirius.chat.feature.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.ai.agent.GenerationFailure
import com.sirius.chat.ai.agent.StreamingAnswer
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.FileNode
import com.sirius.chat.domain.model.MessageAttachment
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.ProviderConfig
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class ChatUiState(
    val session: ChatSession? = null,
    val messages: List<ChatMessage> = emptyList(),
    val project: Project? = null,
    val providers: List<ProviderConfig> = emptyList(),
    val input: String = "",
    val attachments: List<MessageAttachment> = emptyList(),
    val streaming: StreamingAnswer? = null,
    val error: String? = null,
    val retryable: Boolean = false,
    val pendingChanges: List<PendingChange> = emptyList(),
    val loading: Boolean = true
) {
    val isGenerating: Boolean get() = streaming != null
    val provider: ProviderConfig?
        get() = providers.firstOrNull { it.id == session?.providerId }
    val canSend: Boolean
        get() = !isGenerating && (input.isNotBlank() || attachments.isNotEmpty())
}

class ChatViewModel(
    private val container: AppContainer,
    private val sessionId: String
) : ViewModel() {

    private val _input = MutableStateFlow("")
    private val _attachments = MutableStateFlow<List<MessageAttachment>>(emptyList())
    private val _session = MutableStateFlow<ChatSession?>(null)
    private val _project = MutableStateFlow<Project?>(null)

    /**
     * The answer in flight, owned by [com.sirius.chat.ai.agent.GenerationManager].
     *
     * The ViewModel is an observer here, not the owner. That is the whole point of
     * background generation: this object is destroyed when the user leaves the
     * chat, and the answer has to outlive it.
     */
    private val generations = container.generations
    private val _streaming = generations.stream(sessionId)

    /**
     * Local, screen-level error: the session row could not be read at all.
     *
     * Kept apart from the manager's failures because it is not a generation
     * failure — there is nothing to retry, and it must not be cleared by the next
     * successful answer in another session.
     */
    private val sessionMissing = MutableStateFlow<String?>(null)

    private val _error = combine(
        generations.failure(sessionId),
        sessionMissing
    ) { failure, missing ->
        failure ?: missing?.let { GenerationFailure(it, retryable = false) }
    }

    private data class CoreState(
        val session: ChatSession?,
        val project: Project?,
        val input: String,
        val attachments: List<MessageAttachment>
    )

    private val core = combine(
        _session, _project, _input, _attachments
    ) { session, project, input, attachments ->
        CoreState(session, project, input, attachments)
    }

    private val errorsAndChanges = combine(
        _error, container.changeStore.changes
    ) { error, changes -> error to changes.filter { it.sessionId == sessionId } }

    val state: StateFlow<ChatUiState> = combine(
        core,
        container.chatRepository.observeMessages(sessionId),
        container.providerRepository.observeProviders(),
        _streaming,
        errorsAndChanges
    ) { coreState, messages, providers, streaming, extras ->
        ChatUiState(
            session = coreState.session,
            project = coreState.project,
            input = coreState.input,
            attachments = coreState.attachments,
            messages = messages,
            providers = providers,
            streaming = streaming,
            error = extras.first?.message,
            retryable = extras.first?.retryable ?: false,
            pendingChanges = extras.second,
            loading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ChatUiState())

    val streamingState: StateFlow<StreamingAnswer?> =
        _streaming.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /**
     * Code in a chat answer is the same kind of text as code in the editor, so it
     * follows the same size preference instead of a hardcoded 13sp that ignored the
     * setting entirely.
     */
    val codeFontSize: StateFlow<Int> = container.settingsRepository.settings
        .map { it.editorFontSize }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 14)

    init {
        viewModelScope.launch {
            val session = container.chatRepository.getSession(sessionId)
            _session.value = session
            _input.value = container.chatRepository.draft(sessionId)
            val projectId = session?.projectId ?: return@launch
            // A folder can be attached to the project while this chat is open, so
            // keep following it instead of caching one snapshot.
            container.projectRepository.observeProjects()
                .map { projects -> projects.firstOrNull { it.id == projectId } }
                .distinctUntilChanged()
                .collect { _project.value = it }
        }
    }

    // --------------------------------------------------------------- input

    fun onInputChange(value: String) {
        _input.value = value
    }

    fun persistDraft() {
        val draft = _input.value
        viewModelScope.launch { container.chatRepository.saveDraft(sessionId, draft) }
    }

    // ---------------------------------------------------------- attachments

    private val _attachmentQuery = MutableStateFlow("")
    val attachmentQuery: StateFlow<String> = _attachmentQuery.asStateFlow()

    private val _attachmentResults = MutableStateFlow<List<FileNode>>(emptyList())
    val attachmentResults: StateFlow<List<FileNode>> = _attachmentResults.asStateFlow()

    private var searchJob: Job? = null

    /** Debounced workspace search powering the attachment sheet. */
    fun searchAttachments(query: String) {
        _attachmentQuery.value = query
        val tree = _project.value?.treeUri
        searchJob?.cancel()
        if (tree == null) {
            _attachmentResults.value = emptyList()
            return
        }
        searchJob = viewModelScope.launch {
            kotlinx.coroutines.delay(220)
            _attachmentResults.value = if (query.isBlank()) {
                val root = container.workspaceRepository.rootNode(tree)
                if (root == null) emptyList()
                else container.workspaceRepository
                    .listChildren(tree, root.documentId, "")
                    .filterNot { it.isDirectory }
                    .take(30)
            } else {
                container.workspaceRepository.searchFiles(tree, query, limit = 40)
            }
        }
    }

    fun attach(node: FileNode) {
        if (_attachments.value.any { it.uri == node.documentId }) return
        _attachments.value = _attachments.value + MessageAttachment(
            id = UUID.randomUUID().toString(),
            name = node.name,
            uri = node.documentId,
            sizeBytes = node.sizeBytes
        )
    }

    fun removeAttachment(id: String) {
        _attachments.value = _attachments.value.filterNot { it.id == id }
    }

    fun dismissError() {
        generations.clearFailure(sessionId)
        sessionMissing.value = null
    }

    fun selectModel(providerId: String, model: String) {
        val session = _session.value ?: return
        val updated = session.copy(providerId = providerId, model = model)
        _session.value = updated
        viewModelScope.launch {
            container.chatRepository.updateSession(updated)
            container.settingsRepository.update { it.copy(activeProviderId = providerId, activeModel = model) }
        }
    }

    // ------------------------------------------------------------ generate

    fun send() {
        val text = _input.value.trim()
        val attachments = _attachments.value
        if (text.isEmpty() && attachments.isEmpty()) return
        if (generations.isRunning(sessionId)) return

        _input.value = ""
        _attachments.value = emptyList()
        generations.clearFailure(sessionId)

        viewModelScope.launch {
            val session = _session.value
                ?: container.chatRepository.getSession(sessionId)?.also { _session.value = it }
            if (session == null) {
                // Never swallow what the user typed if the session is not there yet.
                _input.value = text
                _attachments.value = attachments
                sessionMissing.value = container.strings.get(R.string.chat_error_session_missing)
                return@launch
            }
            val message = ChatMessage(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                role = MessageRole.User,
                content = text,
                createdAt = System.currentTimeMillis(),
                attachments = attachments
            )
            container.chatRepository.addMessage(message)
            container.chatRepository.saveDraft(sessionId, "")

            // Titles are stored in the language active at creation time, so the
            // placeholder check has to hold after the user switches languages.
            val isPlaceholderTitle =
                AppStrings.matchesAnyLanguage(R.string.chats_untitled, session.title) ||
                    AppStrings.matchesAnyLanguage(R.string.chats_untitled_agent, session.title)
            if (isPlaceholderTitle) {
                val title = container.deriveSessionTitle(text)
                val renamed = session.copy(title = title)
                _session.value = renamed
                container.chatRepository.updateSession(renamed)
            }
            generate()
        }
    }

    fun stop() = generations.stop(sessionId)

    fun regenerate() {
        viewModelScope.launch {
            val history = container.chatRepository.messages(sessionId)
            val lastAssistant = history.lastOrNull { it.role == MessageRole.Assistant } ?: return@launch
            container.rewindConversation(sessionId, lastAssistant.id)
            generate()
        }
    }

    /** Asks the model to keep going from where it stopped. */
    fun continueGeneration() {
        viewModelScope.launch {
            container.chatRepository.addMessage(
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    sessionId = sessionId,
                    role = MessageRole.User,
                    content = container.strings.get(R.string.chat_continue_prompt),
                    createdAt = System.currentTimeMillis()
                )
            )
            generate()
        }
    }

    fun retry() {
        generations.clearFailure(sessionId)
        generate()
    }

    /** Edits a user message and re-runs the conversation from that point. */
    fun editAndResend(messageId: String, newText: String) {
        viewModelScope.launch {
            val history = container.chatRepository.messages(sessionId)
            val target = history.firstOrNull { it.id == messageId } ?: return@launch
            container.rewindConversation(sessionId, messageId)
            container.chatRepository.addMessage(
                target.copy(
                    id = UUID.randomUUID().toString(),
                    content = newText,
                    createdAt = System.currentTimeMillis()
                )
            )
            generate()
        }
    }

    fun deleteMessage(messageId: String) {
        viewModelScope.launch { container.chatRepository.deleteMessage(messageId) }
    }

    /**
     * Hands the session to the generation manager.
     *
     * Everything that used to live here — prompt assembly, the agent loop, event
     * handling, persistence — moved to `GenerationManager` so it keeps running with
     * the chat closed. What is left is a request.
     */
    private fun generate() {
        // The foreground service is what keeps the process alive while the model
        // talks. Without it Android is free to kill the app the moment the user
        // leaves, which is exactly the case background generation is for.
        // Started before the generation, not after: if the user backgrounds the app
        // in that gap the process is already protected.
        GenerationService.ensureRunning(container.appContext)
        generations.start(sessionId)
    }

    override fun onCleared() {
        super.onCleared()
        // Nothing to cancel: the generation does not belong to this screen. Only
        // the draft is flushed, so reopening the chat finds what was typed.
        val draft = _input.value
        container.appScope.launch { container.chatRepository.saveDraft(sessionId, draft) }
    }
}
