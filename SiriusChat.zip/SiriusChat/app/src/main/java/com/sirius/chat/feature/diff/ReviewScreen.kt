package com.sirius.chat.feature.diff

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.CompareArrows
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.designsystem.components.EmptyState
import com.sirius.chat.core.designsystem.Reveal
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusConfirmSheet
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.pressable
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.decorative
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.domain.model.ChangeKind
import com.sirius.chat.domain.model.DiffHunk
import com.sirius.chat.domain.model.DiffLineType

/** Which irreversible action is waiting for a yes. */
private sealed interface ReviewPrompt {
    data class Reject(val id: String, val name: String) : ReviewPrompt
    data object RejectAll : ReviewPrompt
    data object ApplyAll : ReviewPrompt
}

@Composable
fun ReviewScreen(
    onBack: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: ReviewViewModel = siriusViewModel { ReviewViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors
    val listState = rememberLazyListState()
    val scrolled by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 4 }
    }
    var prompt by remember { mutableStateOf<ReviewPrompt?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.review_title),
            subtitle = if (state.changes.isEmpty()) {
                stringResource(R.string.review_nothing_pending)
            } else {
                pluralStringResource(
                    R.plurals.review_proposed,
                    state.changes.size,
                    state.changes.size
                )
            },
            scrolled = scrolled,
            onBack = onBack
        )

        if (state.changes.isEmpty()) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                EmptyState(
                    icon = Icons.AutoMirrored.Rounded.CompareArrows,
                    title = stringResource(R.string.review_empty_title),
                    message = stringResource(R.string.review_empty_message)
                )
            }
            return@Column
        }

        // The file switcher is a single-choice control, so each chip reports its
        // selected state instead of relying on the tint alone.
        LazyRow(
            modifier = Modifier.padding(horizontal = SiriusSpacing.sm, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(state.changes, key = { it.id }) { change ->
                val name = change.path.substringAfterLast('/')
                val isSelected = change.id == state.selectedId
                val label = stringResource(R.string.review_select_file, name)
                SiriusChip(
                    text = name,
                    selected = isSelected,
                    color = when (change.kind) {
                        ChangeKind.Create -> colors.success
                        ChangeKind.Delete -> colors.error
                        else -> colors.textSecondary
                    },
                    onClick = { viewModel.select(change.id) },
                    modifier = Modifier.semantics {
                        selected = isSelected
                        contentDescription = label
                    }
                )
            }
        }

        state.selected?.let { change ->
            val diff = state.diff
            GlassCard(
                modifier = Modifier.padding(horizontal = SiriusSpacing.sm),
                contentPadding = SiriusSpacing.sm
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = change.path,
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = when (change.kind) {
                                ChangeKind.Create -> stringResource(R.string.review_kind_create)
                                ChangeKind.Delete -> stringResource(R.string.review_kind_delete)
                                ChangeKind.Rename -> stringResource(R.string.review_kind_rename, change.newName ?: "")
                                ChangeKind.Move -> stringResource(R.string.review_kind_move)
                                ChangeKind.Modify -> stringResource(R.string.review_kind_modify)
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textTertiary
                        )
                        if (diff != null && !diff.isEmpty) {
                            Text(
                                text = pluralStringResource(
                                    R.plurals.review_hunks_selected,
                                    diff.hunks.size,
                                    state.acceptedHunks.count { id -> diff.hunks.any { it.id == id } },
                                    diff.hunks.size
                                ),
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.textTertiary
                            )
                        }
                    }
                    if (diff != null) {
                        // "+12 −3" is a glyph pair, not a sentence: the row carries
                        // the wording for screen readers and hides the symbols.
                        val counts = stringResource(R.string.review_counts, diff.added, diff.removed)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.semantics { contentDescription = counts }
                        ) {
                            Text(
                                text = "+${diff.added}",
                                style = MaterialTheme.typography.labelMedium,
                                color = colors.diffAddedText
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "\u2212${diff.removed}",
                                style = MaterialTheme.typography.labelMedium,
                                color = colors.diffRemovedText
                            )
                        }
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            state = listState,
            contentPadding = PaddingValues(
                start = SiriusSpacing.sm,
                end = SiriusSpacing.sm,
                top = SiriusSpacing.xs,
                bottom = SiriusSpacing.sm
            ),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
        ) {
            val diff = state.diff
            if (diff == null || diff.isEmpty) {
                item(key = "no-diff") {
                    Text(
                        text = stringResource(R.string.review_no_diff),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textTertiary
                    )
                }
            } else {
                itemsIndexed(diff.hunks, key = { _, hunk -> hunk.id }) { index, hunk ->
                    Reveal(index) {
                        HunkCard(
                            hunk = hunk,
                            accepted = hunk.id in state.acceptedHunks,
                            onToggle = { viewModel.toggleHunk(hunk.id) }
                        )
                    }
                }
            }
        }

        // One footer, one bottom inset. The per-file row is always present; the
        // all-files row only appears when there is more than one file to answer for.
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start = SiriusSpacing.sm,
                    end = SiriusSpacing.sm,
                    bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xs
                ),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
        ) {
            // Above the buttons, not below: it changes what the button on the
            // right will mean next time, and a control that modifies an action
            // should be read before it, not discovered after.
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .pressable(onClick = { viewModel.setAutoApply(!state.autoApply) })
            ) {
                Text(
                    text = stringResource(R.string.review_auto_apply_toggle),
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.textSecondary,
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = state.autoApply,
                    // Null so the row owns the gesture: two separate hit targets
                    // for one boolean is how a toggle ends up flipped twice.
                    onCheckedChange = null,
                    enabled = !state.applying,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = colors.onPrimary,
                        checkedTrackColor = colors.primary,
                        uncheckedTrackColor = colors.surfaceMuted
                    )
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                SiriusGhostButton(
                    text = stringResource(R.string.review_reject),
                    onClick = {
                        state.selected?.let { change ->
                            prompt = ReviewPrompt.Reject(
                                id = change.id,
                                name = change.path.substringAfterLast('/')
                            )
                        }
                    },
                    tint = colors.error,
                    enabled = !state.applying,
                    modifier = Modifier.weight(1f)
                )
                SiriusPrimaryButton(
                    text = if (state.changes.size > 1) stringResource(R.string.review_apply_file)
                    else stringResource(R.string.review_apply),
                    icon = Icons.Rounded.Check,
                    loading = state.applying,
                    onClick = viewModel::applySelected,
                    modifier = Modifier.weight(1f)
                )
            }

            if (state.changes.size > 1) {
                Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                    SiriusGhostButton(
                        text = stringResource(R.string.review_reject_all),
                        onClick = { prompt = ReviewPrompt.RejectAll },
                        enabled = !state.applying,
                        modifier = Modifier.weight(1f)
                    )
                    SiriusGhostButton(
                        text = stringResource(R.string.review_apply_all),
                        onClick = { prompt = ReviewPrompt.ApplyAll },
                        tint = colors.success,
                        enabled = !state.applying,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    // Rejecting throws away work the agent did and applying writes to real files;
    // both get named, explicit confirmation rather than a one-tap toast.
    when (val pending = prompt) {
        is ReviewPrompt.Reject -> SiriusConfirmSheet(
            title = stringResource(R.string.review_reject_title, pending.name),
            message = stringResource(R.string.review_reject_message),
            confirmLabel = stringResource(R.string.review_reject),
            icon = Icons.Rounded.DeleteOutline,
            onConfirm = {
                prompt = null
                viewModel.reject(pending.id)
            },
            onDismiss = { prompt = null }
        )

        ReviewPrompt.RejectAll -> SiriusConfirmSheet(
            title = stringResource(R.string.review_reject_all_title),
            message = pluralStringResource(
                R.plurals.review_reject_all_message,
                state.changes.size,
                state.changes.size
            ),
            confirmLabel = stringResource(R.string.review_reject_all),
            icon = Icons.Rounded.DeleteOutline,
            onConfirm = {
                prompt = null
                viewModel.rejectAll()
            },
            onDismiss = { prompt = null }
        )

        ReviewPrompt.ApplyAll -> SiriusConfirmSheet(
            title = stringResource(R.string.review_apply_all_title),
            message = pluralStringResource(
                R.plurals.review_apply_all_message,
                state.changes.size,
                state.changes.size
            ),
            confirmLabel = stringResource(R.string.review_apply_all),
            icon = Icons.Rounded.Check,
            destructive = false,
            onConfirm = {
                prompt = null
                viewModel.applyAll()
            },
            onDismiss = { prompt = null }
        )

        null -> Unit
    }

    MessageToast(
        message = state.message,
        bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.sm
    )

    LaunchedEffect(state.message) {
        if (state.message != null) {
            kotlinx.coroutines.delay(2400)
            viewModel.consumeMessage()
        }
    }
}

/**
 * One hunk, with its own in-or-out switch.
 *
 * The header is a real toggle: it takes [Role.Checkbox], reports its checked
 * state, and says what the hunk is (line, additions, removals) so a screen
 * reader user can decide without reading every line of code. The box keeps both
 * a tick and a cross, because "included" cannot be carried by green alone.
 */
@Composable
private fun HunkCard(
    hunk: DiffHunk,
    accepted: Boolean,
    onToggle: () -> Unit
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val horizontal = rememberScrollState()
    val position = stringResource(R.string.review_hunk_at_line, hunk.newStart)
    val counts = stringResource(R.string.review_counts, hunk.added, hunk.removed)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.md))
            .background(colors.codeBackground)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .softSurface(RoundedCornerShape(0.dp))
                .toggleable(
                    value = accepted,
                    role = Role.Checkbox,
                    onValueChange = {
                        haptics.light()
                        onToggle()
                    }
                )
                .semantics { contentDescription = "$position, $counts" }
                .heightIn(min = 48.dp)
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(RoundedCornerShape(SiriusRadius.xs))
                    .background(if (accepted) colors.success else colors.surfaceMuted),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (accepted) Icons.Rounded.Check else Icons.Rounded.Close,
                    contentDescription = null,
                    tint = if (accepted) colors.onPrimary else colors.textTertiary,
                    modifier = Modifier.size(13.dp)
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                text = "@@ -${hunk.oldStart} +${hunk.newStart}",
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "+${hunk.added} \u2212${hunk.removed}",
                style = MaterialTheme.typography.labelSmall,
                color = colors.textSecondary
            )
        }

        Column(modifier = Modifier.horizontalScroll(horizontal)) {
            hunk.lines.forEach { line ->
                val background = when (line.type) {
                    DiffLineType.Added -> colors.diffAdded
                    DiffLineType.Removed -> colors.diffRemoved
                    DiffLineType.Context -> Color.Transparent
                }
                val textColor = when (line.type) {
                    DiffLineType.Added -> colors.diffAddedText
                    DiffLineType.Removed -> colors.diffRemovedText
                    DiffLineType.Context -> colors.codePlain
                }
                Row(
                    modifier = Modifier
                        .background(background)
                        .padding(horizontal = 8.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = (line.newLineNumber ?: line.oldLineNumber)?.toString().orEmpty().padStart(4),
                        style = codeTextStyle(11).copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                        color = colors.codeComment,
                        // The gutter is orientation, not content: reading "1 2 3"
                        // before every line makes the diff unlistenable.
                        modifier = Modifier.decorative()
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = when (line.type) {
                            DiffLineType.Added -> "+ "
                            DiffLineType.Removed -> "\u2212 "
                            DiffLineType.Context -> "  "
                        } + line.text,
                        style = codeTextStyle(12),
                        color = textColor,
                        softWrap = false
                    )
                }
            }
        }
    }
}
