package com.sirius.chat.domain.model

/**
 * A project binds a name and AI configuration to a workspace folder that the
 * user granted access to through the Storage Access Framework.
 */
data class Project(
    val id: String,
    val name: String,
    val description: String = "",
    /** Persisted SAF tree uri, `null` when the project has no workspace yet. */
    val treeUri: String? = null,
    val workspaceLabel: String = "",
    val providerId: String? = null,
    val model: String? = null,
    val accentIndex: Int = 0,
    val favorite: Boolean = false,
    val createdAt: Long,
    val lastOpenedAt: Long
) {
    val hasWorkspace: Boolean get() = !treeUri.isNullOrBlank()
}

/** A file the user recently opened inside a project. */
data class RecentFile(
    val documentId: String,
    val projectId: String,
    val name: String,
    val path: String,
    val openedAt: Long,
    val caretOffset: Int = 0,
    val scrollLine: Int = 0
)
