package com.sirius.chat.data.terminal

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Receives command results from Termux.
 *
 * Termux runs the command in its own process and reports the outcome by calling
 * [android.app.PendingIntent.send] on a PendingIntent we supply. That send runs
 * with *our* identity, which decides what the callback is allowed to target:
 *
 *  - A **service** PendingIntent performs `startService` as this app. Since
 *    Android 8 that is refused whenever this app is not in a foreground state,
 *    and Termux's `ResultSender` only catches [android.app.PendingIntent.CanceledException] —
 *    the resulting `IllegalStateException` escapes, the result is never sent, and
 *    the coroutine waiting for it hangs forever. That is the bug this replaces.
 *  - A **broadcast** PendingIntent to a receiver registered at runtime has no
 *    such restriction: the process is alive precisely because a command is
 *    being awaited in it, and a registered receiver is reachable regardless of
 *    the app's process state.
 *
 * The receiver is registered with `RECEIVER_NOT_EXPORTED`, so it cannot be
 * reached from other apps at all — a manifest-exported receiver would let any
 * app on the device forge command output. Delivery is additionally matched on a
 * per-execution random token, so a result can only complete the execution it was
 * created for.
 */
object TermuxResultsBridge {

    /** Identifies which execution a delivered result belongs to. */
    const val EXTRA_EXECUTION_ID = "com.sirius.chat.termux.EXECUTION_ID"

    /** Random per-execution value; a result that does not carry it is ignored. */
    const val EXTRA_TOKEN = "com.sirius.chat.termux.TOKEN"

    /** Private to this app: the receiver is registered as not exported. */
    const val ACTION_RESULT = "com.sirius.chat.termux.COMMAND_RESULT"

    /** Termux's key for the bundle holding stdout, stderr and the exit code. */
    private const val EXTRA_RESULT_BUNDLE = "result"

    private class Pending(val token: String, val slot: CompletableDeferred<Bundle?>)

    /**
     * Pending executions, keyed by execution id.
     *
     * Entries are removed on completion, cancellation and timeout, so an
     * abandoned command leaves nothing that a late result could resume.
     */
    private val awaiting = ConcurrentHashMap<Int, Pending>()

    @Volatile
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_RESULT) return
            val executionId = intent.getIntExtra(EXTRA_EXECUTION_ID, 0)
            val pending = awaiting[executionId] ?: return
            if (intent.getStringExtra(EXTRA_TOKEN) != pending.token) return
            awaiting.remove(executionId)
            // Absent when Termux rejected the command before running it. The
            // backend reports that as "no result" rather than waiting on.
            pending.slot.complete(intent.getBundleExtra(EXTRA_RESULT_BUNDLE))
        }
    }

    /** A token to hand to Termux with the callback for [executionId]. */
    fun newToken(): String = UUID.randomUUID().toString()

    /**
     * Registers interest in [executionId]. Must be called before the command is
     * sent, so a command that finishes instantly cannot deliver into a void.
     */
    fun expect(
        context: Context,
        executionId: Int,
        token: String
    ): CompletableDeferred<Bundle?> {
        ensureReceiver(context)
        val slot = CompletableDeferred<Bundle?>()
        awaiting[executionId] = Pending(token, slot)
        return slot
    }

    /** Drops a registration whose command was cancelled, timed out or never started. */
    fun forget(executionId: Int) {
        awaiting.remove(executionId)
    }

    /**
     * Registers the receiver once per process.
     *
     * Never unregistered: it is a single application-scoped receiver with no
     * state of its own, and tearing it down between commands would reopen the
     * window where a result arrives with nothing listening.
     */
    private fun ensureReceiver(context: Context) {
        if (registered) return
        synchronized(this) {
            if (registered) return
            ContextCompat.registerReceiver(
                context.applicationContext,
                receiver,
                IntentFilter(ACTION_RESULT),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            registered = true
        }
    }
}
