package com.sirius.chat.feature.git.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.decorative
import com.sirius.chat.domain.model.GitChangeType
import com.sirius.chat.domain.model.GitFileStatus

/**
 * One changed path.
 *
 * The letter badge is the same shorthand git itself prints (`M`, `A`, `D`), and
 * it is decorative: the row's own description already says what the change is,
 * so a screen reader does not have to spell out a single capital letter. Colour
 * carries the same information a second time, never on its own.
 */
@Composable
fun GitFileRow(
    file: GitFileStatus,
    staged: Boolean,
    busy: Boolean,
    onOpen: () -> Unit,
    onStage: () -> Unit,
    onUnstage: () -> Unit,
    onDiscard: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    val type = if (staged) file.staged ?: file.displayType else file.displayType
    val tint = type.tint()
    val label = "${file.path}, ${stringResource(type.labelRes())}"

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.sm))
            .clickable(onClick = onOpen)
            .heightIn(min = 52.dp)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .semantics { contentDescription = label },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(SiriusRadius.xs))
                .background(tint.copy(alpha = 0.16f))
                .decorative(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = type.badge(),
                style = MaterialTheme.typography.labelMedium,
                color = tint
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = file.name,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val parent = file.path.substringBeforeLast('/', missingDelimiterValue = "")
            Text(
                text = parent.ifEmpty { stringResource(type.labelRes()) },
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (staged) {
            GlassIconButton(
                icon = Icons.Rounded.Remove,
                contentDescription = stringResource(R.string.git_unstage_file, file.name),
                onClick = onUnstage,
                enabled = !busy,
                size = 34.dp,
                iconSize = 18.dp
            )
        } else {
            if (onDiscard != null) {
                GlassIconButton(
                    icon = Icons.AutoMirrored.Rounded.Undo,
                    contentDescription = stringResource(R.string.git_discard_file, file.name),
                    onClick = onDiscard,
                    tint = colors.error,
                    enabled = !busy,
                    size = 34.dp,
                    iconSize = 18.dp
                )
            }
            GlassIconButton(
                icon = Icons.Rounded.Add,
                contentDescription = stringResource(R.string.git_stage_file, file.name),
                onClick = onStage,
                tint = colors.success,
                enabled = !busy,
                size = 34.dp,
                iconSize = 18.dp
            )
        }
    }
}

@Composable
fun GitChangeType.tint(): Color {
    val colors = SiriusTheme.colors
    return when (this) {
        GitChangeType.Added, GitChangeType.Untracked -> colors.success
        GitChangeType.Deleted -> colors.error
        GitChangeType.Conflicted -> colors.warning
        GitChangeType.Renamed, GitChangeType.Copied -> colors.info
        GitChangeType.Modified -> colors.primary
    }
}

fun GitChangeType.badge(): String = when (this) {
    GitChangeType.Added -> "A"
    GitChangeType.Modified -> "M"
    GitChangeType.Deleted -> "D"
    GitChangeType.Renamed -> "R"
    GitChangeType.Copied -> "C"
    GitChangeType.Untracked -> "?"
    GitChangeType.Conflicted -> "!"
}

fun GitChangeType.labelRes(): Int = when (this) {
    GitChangeType.Added -> R.string.git_change_added
    GitChangeType.Modified -> R.string.git_change_modified
    GitChangeType.Deleted -> R.string.git_change_deleted
    GitChangeType.Renamed -> R.string.git_change_renamed
    GitChangeType.Copied -> R.string.git_change_copied
    GitChangeType.Untracked -> R.string.git_change_untracked
    GitChangeType.Conflicted -> R.string.git_change_conflicted
}
