package com.sirius.chat.core.designsystem

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

/**
 * The Sirius palette is intentionally richer than a Material color scheme: code
 * tokens, diff states and the chrome ramp all need dedicated slots so the whole
 * product stays consistent.
 *
 * The surface ramp is flat and near-black on purpose. Chrome is expressed by
 * *value steps* — background -> elevated -> surface -> surfaceMuted, each one a
 * few percent lighter — plus a single hairline outline. Nothing is translucent
 * and nothing is gradient-filled, so the only decorated thing on any screen is
 * the liquid-metal accent (see `effects/LiquidMetal.kt`), which is what makes it
 * read as an accent at all.
 *
 * The `metal*` slots are what remains of the old gradient plates: they are kept
 * because the whole app addresses them, but they now describe that same flat
 * ramp — `metalCrown`/`metalBody`/`metalTrough`/`metalBounce` are one value step
 * apart instead of a lit-plate gradient, and `metalSpecular`/`metalRim*` are the
 * hairline and its pressed/hover variants.
 */
@Immutable
data class SiriusPalette(
    val background: Color,
    val backgroundElevated: Color,
    val surface: Color,
    val surfaceMuted: Color,
    val metalCrown: Color,
    val metalBody: Color,
    val metalTrough: Color,
    val metalBounce: Color,
    val metalSpecular: Color,
    val metalRim: Color,
    val metalRimLight: Color,
    val metalRimDark: Color,
    val metalShadow: Color,
    val primary: Color,
    val primarySoft: Color,
    val secondary: Color,
    val accent: Color,
    val onPrimary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val outline: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val info: Color,
    val codeBackground: Color,
    val codePlain: Color,
    val codeKeyword: Color,
    val codeString: Color,
    val codeNumber: Color,
    val codeComment: Color,
    val codeFunction: Color,
    val codeType: Color,
    val codeAnnotation: Color,
    val diffAdded: Color,
    val diffAddedText: Color,
    val diffRemoved: Color,
    val diffRemovedText: Color,
    val metalFlowOne: Color,
    val metalFlowTwo: Color,
    val metalFlowThree: Color,
    val isDark: Boolean
)

/** Accent colors used to visually separate projects. */
val ProjectAccents: List<Color> = listOf(
    Color(0xFF5B8DEF),
    Color(0xFF8B5CF6),
    Color(0xFF19B8A6),
    Color(0xFFF59E0B),
    Color(0xFFEC4899),
    Color(0xFF10B981)
)

/**
 * Ink that sits on top of a [ProjectAccents] plate.
 *
 * The accents are deliberately the same in both themes — a project keeps its
 * identity when the app flips to light — so their foreground is a constant too
 * rather than a per-theme palette slot. Every accent above is mid-tone or
 * darker, so this stays above the contrast floor on all of them.
 */
val ProjectAccentInk: Color = Color(0xFFFFFFFF)

/**
 * The twelve curated interface accents offered in Settings.
 *
 * They are chosen for one property: each one stays legible as a *fill under
 * text* on both the near-black and the near-white ramp, which is what the accent
 * is actually used for (primary buttons, the send action, selected chips). That
 * rules out the very light pastels and the very dark inks, which is why this is a
 * hand-picked list and not a generated hue wheel.
 */
val InterfaceAccents: List<Color> = listOf(
    Color(0xFFAAE8FF),
    Color(0xFF5B8DEF),
    Color(0xFF7C6CF6),
    Color(0xFFB07CF6),
    Color(0xFFEC6FA9),
    Color(0xFFF2696A),
    Color(0xFFF59E0B),
    Color(0xFFE0C341),
    Color(0xFF8BC34A),
    Color(0xFF19B8A6),
    Color(0xFF2CB1BC),
    Color(0xFFB9A48B)
)

/**
 * Repaints only the four accent-bearing slots.
 *
 * The surface ramp and the text ramp are left exactly as they are. That is the
 * whole reason an arbitrary colour — including a neon one the user picked with
 * the sliders — cannot make the app unreadable: the accent never becomes a page
 * background, and the ink on top of it is chosen by luminance rather than being
 * assumed to be white.
 *
 * [argb] of 0 means "monochrome", i.e. return the palette untouched.
 */
fun SiriusPalette.withAccent(argb: Int): SiriusPalette {
    if (argb == 0) return this
    val tint = Color(argb)
    val ink = if (tint.luminance() > 0.42f) Color(0xFF0A0A0A) else Color(0xFFFFFFFF)
    return copy(
        primary = tint,
        primarySoft = tint.copy(alpha = 0.18f),
        accent = tint,
        onPrimary = ink
    )
}

val DarkSiriusPalette = SiriusPalette(
    background = Color(0xFF0A0A0A),
    backgroundElevated = Color(0xFF101010),
    surface = Color(0xFF161616),
    surfaceMuted = Color(0xFF1E1E1E),
    metalCrown = Color(0xFF1F1F1F),
    metalBody = Color(0xFF161616),
    metalTrough = Color(0xFF131313),
    metalBounce = Color(0xFF1A1A1A),
    metalSpecular = Color(0x0FFFFFFF),
    metalRim = Color(0x14FFFFFF),
    metalRimLight = Color(0x1FFFFFFF),
    metalRimDark = Color(0x14000000),
    metalShadow = Color(0xFF000000),
    primary = Color(0xFFEDEDED),
    primarySoft = Color(0x14FFFFFF),
    secondary = Color(0xFFB4B4B4),
    accent = Color(0xFFAAE8FF),
    onPrimary = Color(0xFF0A0A0A),
    textPrimary = Color(0xFFF2F2F2),
    textSecondary = Color(0xFF9B9B9B),
    textTertiary = Color(0xFF6A6A6A),
    outline = Color(0x14FFFFFF),
    success = Color(0xFF4ADE80),
    warning = Color(0xFFFBBF24),
    error = Color(0xFFF87171),
    info = Color(0xFF7DD3FC),
    codeBackground = Color(0xFF0D0D0D),
    codePlain = Color(0xFFE4E4E4),
    codeKeyword = Color(0xFFC4B5FD),
    codeString = Color(0xFFA7F3D0),
    codeNumber = Color(0xFFFDBA74),
    codeComment = Color(0xFF6B6B6B),
    codeFunction = Color(0xFF93C5FD),
    codeType = Color(0xFF7FE7DA),
    codeAnnotation = Color(0xFFFCD34D),
    diffAdded = Color(0x1F4ADE80),
    diffAddedText = Color(0xFF6EE7B7),
    diffRemoved = Color(0x1FF87171),
    diffRemovedText = Color(0xFFFCA5A5),
    metalFlowOne = Color(0xFF121212),
    metalFlowTwo = Color(0xFF0E0E0E),
    metalFlowThree = Color(0xFF0A0A0A),
    isDark = true
)

val LightSiriusPalette = SiriusPalette(
    background = Color(0xFFF4F4F5),
    backgroundElevated = Color(0xFFFAFAFA),
    surface = Color(0xFFFFFFFF),
    surfaceMuted = Color(0xFFEDEDEE),
    metalCrown = Color(0xFFFFFFFF),
    metalBody = Color(0xFFFFFFFF),
    metalTrough = Color(0xFFF7F7F8),
    metalBounce = Color(0xFFFFFFFF),
    metalSpecular = Color(0x0F000000),
    metalRim = Color(0x14000000),
    metalRimLight = Color(0x0A000000),
    metalRimDark = Color(0x14000000),
    metalShadow = Color(0xFFBFBFC4),
    primary = Color(0xFF141414),
    primarySoft = Color(0x14000000),
    secondary = Color(0xFF4B4B4B),
    accent = Color(0xFF0E7490),
    onPrimary = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF111111),
    textSecondary = Color(0xFF5A5A5A),
    textTertiary = Color(0xFF8A8A8A),
    outline = Color(0x14000000),
    success = Color(0xFF15803D),
    warning = Color(0xFFB45309),
    error = Color(0xFFDC2626),
    info = Color(0xFF0369A1),
    codeBackground = Color(0xFF0D0D0D),
    codePlain = Color(0xFFE4E4E4),
    codeKeyword = Color(0xFFC4B5FD),
    codeString = Color(0xFFA7F3D0),
    codeNumber = Color(0xFFFDBA74),
    codeComment = Color(0xFF6B6B6B),
    codeFunction = Color(0xFF93C5FD),
    codeType = Color(0xFF7FE7DA),
    codeAnnotation = Color(0xFFFCD34D),
    diffAdded = Color(0x1F15803D),
    diffAddedText = Color(0xFF047857),
    diffRemoved = Color(0x1FDC2626),
    diffRemovedText = Color(0xFFB91C1C),
    metalFlowOne = Color(0xFFFFFFFF),
    metalFlowTwo = Color(0xFFF2F2F2),
    metalFlowThree = Color(0xFFEDEDED),
    isDark = false
)
