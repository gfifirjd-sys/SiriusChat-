package com.sirius.chat.data.attachment

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.sirius.chat.domain.model.AttachmentKind
import com.sirius.chat.domain.model.MessageAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/** What an attachment can contribute to a request. */
sealed interface AttachmentPayload {
    /**
     * Inlined text. [omittedChars] is non-zero when the file was longer than its
     * budget, and is reported to the model rather than hidden: a model that knows
     * it is looking at the first 60 000 characters of a file asks for the rest,
     * while a model handed a silent fragment answers as if it had the whole file.
     */
    data class Text(val text: String, val omittedChars: Int = 0) : AttachmentPayload

    /** Base64 for a native image or document block. */
    data class Binary(val base64: String, val mediaType: String) : AttachmentPayload

    /** Nothing can be sent, and this is the reason to tell the model. */
    data class Unavailable(val reason: String) : AttachmentPayload
}

/**
 * Resolves picked files into something a model can be given.
 *
 * Everything a `content://` uri does not tell you up front is settled here, once,
 * at pick time: the display name, the size, and — the part that matters — which
 * of the four possible fates the file has. A PNG becomes an image block, a PDF a
 * document block, a `.kt` file inlined text, and a `.zip` a description of
 * itself. Deciding this when the file is attached rather than when the request is
 * built is what lets the composer show the right icon and refuse an oversized
 * file while the user is still looking at it.
 */
class AttachmentReader(private val appContext: Context) {

    /**
     * Metadata for a picked uri, or null when the provider will not describe it.
     *
     * [anchor] is supplied by the caller because only the composer knows where
     * the caret was.
     */
    suspend fun describe(uri: Uri, anchor: Int): MessageAttachment? =
        withContext(Dispatchers.IO) {
            val resolver = appContext.contentResolver
            var name: String? = null
            var size = 0L
            runCatching {
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex >= 0 && !cursor.isNull(nameIndex)) {
                            name = cursor.getString(nameIndex)
                        }
                        val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                            size = cursor.getLong(sizeIndex)
                        }
                    }
                }
            }
            // Some providers answer neither name nor size. A last path segment is
            // still better than an opaque uri in the transcript.
            val resolved = name ?: uri.lastPathSegment?.substringAfterLast('/') ?: return@withContext null
            val mime = resolver.getType(uri) ?: guessMime(resolved)
            MessageAttachment(
                id = UUID.randomUUID().toString(),
                name = resolved,
                uri = uri.toString(),
                sizeBytes = size,
                mimeType = mime,
                kind = classify(resolved, mime),
                anchor = anchor
            )
        }

    /**
     * Reads the attachment for a request.
     *
     * [maxTextChars] is the caller's remaining budget for inlined text, so the
     * conversation as a whole cannot be pushed out of the context window by one
     * large file.
     */
    suspend fun payload(attachment: MessageAttachment, maxTextChars: Int): AttachmentPayload =
        withContext(Dispatchers.IO) {
            val uri = runCatching { Uri.parse(attachment.uri) }.getOrNull()
                ?: return@withContext AttachmentPayload.Unavailable("the file reference is invalid")
            try {
                when (attachment.kind) {
                    AttachmentKind.Image -> {
                        val bytes = read(uri, MAX_IMAGE_BYTES)
                            ?: return@withContext AttachmentPayload.Unavailable(
                                "the image is larger than ${MAX_IMAGE_BYTES / (1024 * 1024)} MB, " +
                                    "which is more than the model accepts"
                            )
                        AttachmentPayload.Binary(encode(bytes), normalizeImageType(attachment.mimeType))
                    }

                    AttachmentKind.Document -> {
                        val bytes = read(uri, MAX_DOCUMENT_BYTES)
                            ?: return@withContext AttachmentPayload.Unavailable(
                                "the document is larger than " +
                                    "${MAX_DOCUMENT_BYTES / (1024 * 1024)} MB"
                            )
                        AttachmentPayload.Binary(encode(bytes), "application/pdf")
                    }

                    AttachmentKind.TextFile -> {
                        val bytes = read(uri, MAX_TEXT_BYTES)
                            ?: return@withContext AttachmentPayload.Unavailable(
                                "the text file is larger than " +
                                    "${MAX_TEXT_BYTES / (1024 * 1024)} MB"
                            )
                        val full = bytes.toString(Charsets.UTF_8)
                        if (full.length <= maxTextChars) {
                            AttachmentPayload.Text(full)
                        } else {
                            AttachmentPayload.Text(
                                full.take(maxTextChars),
                                omittedChars = full.length - maxTextChars
                            )
                        }
                    }

                    AttachmentKind.Opaque -> AttachmentPayload.Unavailable(
                        "its type (${attachment.mimeType ?: "unknown"}) cannot be read by the model"
                    )

                    // Project files are read through the workspace tree, not here.
                    AttachmentKind.WorkspaceFile -> AttachmentPayload.Unavailable(
                        "it is a project file and is read from the workspace"
                    )
                }
            } catch (error: SecurityException) {
                // The persisted permission was revoked, or the app was reinstalled.
                AttachmentPayload.Unavailable("Sirius no longer has permission to read it")
            } catch (error: Exception) {
                AttachmentPayload.Unavailable(error.message ?: "it could not be read")
            }
        }

    /** Bytes, or null when the file exceeds [limit]. */
    private fun read(uri: Uri, limit: Long): ByteArray? =
        appContext.contentResolver.openInputStream(uri)?.use { stream ->
            // The size reported by the provider is advisory — some report none at
            // all — so the real length is checked here, after reading, and the
            // caller's limit is what decides. This is why MAX_FILE_BYTES is
            // enforced at pick time too: by then the size is usually known.
            val bytes = stream.readBytes()
            if (bytes.size > limit) null else bytes
        }

    private fun encode(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)

    companion object {
        /** Ceiling for any single attachment, enforced when it is picked. */
        const val MAX_FILE_BYTES = 20L * 1024 * 1024

        /** Attachments per message. */
        const val MAX_ATTACHMENTS = 10

        /** Anthropic rejects images above 5 MB outright. */
        const val MAX_IMAGE_BYTES = 5L * 1024 * 1024
        const val MAX_DOCUMENT_BYTES = 20L * 1024 * 1024
        const val MAX_TEXT_BYTES = 8L * 1024 * 1024

        /** Image media types the API accepts. Anything else is treated as opaque. */
        private val IMAGE_TYPES = setOf("image/png", "image/jpeg", "image/gif", "image/webp")

        private val TEXT_EXTENSIONS = setOf(
            "txt", "md", "markdown", "rst", "log", "csv", "tsv", "json", "xml", "yaml", "yml",
            "toml", "ini", "cfg", "conf", "properties", "env", "gitignore", "dockerfile",
            "gradle", "kts", "kt", "java", "scala", "groovy", "py", "rb", "php", "pl", "lua",
            "js", "mjs", "cjs", "ts", "tsx", "jsx", "vue", "svelte", "html", "htm", "css",
            "scss", "sass", "less", "c", "h", "cc", "cpp", "hpp", "cs", "go", "rs", "swift",
            "m", "mm", "sh", "bash", "zsh", "fish", "bat", "ps1", "sql", "graphql", "proto",
            "pro", "cmake", "mk", "srt", "vtt", "tex", "diff", "patch"
        )

        private val TEXT_MIME_PREFIXES = listOf("text/")

        private val TEXT_MIME_TYPES = setOf(
            "application/json", "application/xml", "application/javascript",
            "application/x-yaml", "application/yaml", "application/x-sh",
            "application/x-httpd-php", "application/sql", "application/toml",
            "application/x-ndjson", "application/graphql"
        )

        /** Where a name and a mime type disagree, both get a vote. */
        fun classify(name: String, mime: String?): AttachmentKind {
            val extension = name.substringAfterLast('.', "").lowercase()
            val type = mime?.lowercase().orEmpty()
            return when {
                normalizeImageType(type) in IMAGE_TYPES -> AttachmentKind.Image
                extension in setOf("png", "jpg", "jpeg", "gif", "webp") -> AttachmentKind.Image
                type == "application/pdf" || extension == "pdf" -> AttachmentKind.Document
                TEXT_MIME_PREFIXES.any { type.startsWith(it) } -> AttachmentKind.TextFile
                type in TEXT_MIME_TYPES -> AttachmentKind.TextFile
                extension in TEXT_EXTENSIONS -> AttachmentKind.TextFile
                // An extensionless file with an unhelpful mime type is usually a
                // dotfile or a script, and reading it as text is recoverable;
                // guessing "binary" for a real config file is not.
                extension.isEmpty() && (type.isEmpty() || type == "application/octet-stream") ->
                    AttachmentKind.TextFile
                else -> AttachmentKind.Opaque
            }
        }

        /** `image/jpg` is common in the wild and is not a real media type. */
        fun normalizeImageType(mime: String?): String = when (val type = mime?.lowercase()) {
            null, "" -> "image/png"
            "image/jpg" -> "image/jpeg"
            else -> type
        }

        private fun guessMime(name: String): String? = when (name.substringAfterLast('.', "").lowercase()) {
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "pdf" -> "application/pdf"
            "json" -> "application/json"
            "md" -> "text/markdown"
            "txt", "log" -> "text/plain"
            else -> null
        }
    }
}
