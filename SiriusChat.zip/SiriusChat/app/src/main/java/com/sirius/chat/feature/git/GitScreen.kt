package com.sirius.chat.feature.git

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountTree
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Difference
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.EmptyState
import com.sirius.chat.core.designsystem.Reveal
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.InlineBusyRow
import com.sirius.chat.core.designsystem.components.ListSkeleton
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.SectionHeader
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusConfirmSheet
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.ui.rememberAllFilesAccessRequest
import com.sirius.chat.core.ui.rememberWorkspacePicker
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.relativeTimeText
import com.sirius.chat.domain.model.GitBranch
import com.sirius.chat.domain.model.GitFileStatus
import com.sirius.chat.domain.model.GitUnavailable
import com.sirius.chat.domain.repository.GitAvailability
import com.sirius.chat.feature.git.components.GitCommitRow
import com.sirius.chat.feature.git.components.GitCommitSheet
import com.sirius.chat.feature.git.components.GitDiffSheet
import com.sirius.chat.feature.git.components.GitFileRow

/** Discarding work and initialising a repository both need an explicit yes. */
private sealed interface GitPrompt {
    data class Discard(val file: GitFileStatus) : GitPrompt
    data object DiscardAll : GitPrompt
    data object Init : GitPrompt
}

/**
 * Local git for the attached workspace.
 *
 * The screen is built around git's own three views of a file, so the index is
 * visible rather than hidden behind a single "commit everything" button: staged
 * and unstaged rows are separate sections that stage, unstage or discard one
 * path at a time. Nothing here talks to a remote.
 */
@Composable
fun GitScreen(
    onBack: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: GitViewModel = siriusViewModel { GitViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors

    val picker = rememberWorkspacePicker { viewModel.attachWorkspace(it) }
    // Coming back from the system settings page is the only signal that access
    // may now be granted, so the whole screen is re-read on return.
    val requestAllFiles = rememberAllFilesAccessRequest { viewModel.refresh() }

    var prompt by remember { mutableStateOf<GitPrompt?>(null) }
    var creatingBranch by remember { mutableStateOf(false) }
    var branchName by remember { mutableStateOf("") }

    // Files can change under git while this screen sits in the background: the
    // editor writes, the agent applies a diff, the terminal runs a command.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refresh() }

    val listState = rememberLazyListState()
    val scrolled by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 4 }
    }

    val status = state.status

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.git_title),
            subtitle = when {
                status == null -> state.project?.name ?: stringResource(R.string.git_no_workspace_subtitle)
                status.detachedHead -> stringResource(R.string.git_detached_head)
                else -> stringResource(R.string.git_on_branch, status.branch)
            },
            scrolled = scrolled,
            onBack = onBack,
            actions = {
                GlassIconButton(
                    icon = Icons.Rounded.Refresh,
                    contentDescription = stringResource(R.string.git_refresh),
                    onClick = viewModel::refresh,
                    enabled = !state.busy,
                    busy = state.loading
                )
            }
        )

        if (state.loading && status == null) {
            ListSkeleton(
                modifier = Modifier.padding(horizontal = SiriusSpacing.sm),
                rows = 4
            )
            return@Column
        }

        val availability = state.availability
        if (availability is GitAvailability.Unavailable) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                GitUnavailableState(
                    reason = availability.reason,
                    onPickFolder = { picker.launch(null) },
                    onGrantAccess = requestAllFiles,
                    onInit = { prompt = GitPrompt.Init },
                    onRetry = viewModel::refresh
                )
            }
            GitToast(state.message, contentPadding, viewModel::consumeMessage)
            GitPromptSheets(
                prompt = prompt,
                onDismiss = { prompt = null },
                viewModel = viewModel
            )
            return@Column
        }

        if (status == null) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                EmptyState(
                    icon = Icons.Rounded.Difference,
                    title = stringResource(R.string.git_unreadable_title),
                    message = stringResource(R.string.git_unreadable_message),
                    actionLabel = stringResource(R.string.action_retry),
                    onAction = viewModel::refresh
                )
            }
            GitToast(state.message, contentPadding, viewModel::consumeMessage)
            return@Column
        }

        // Single-choice control: each tab reports its own selected state, since
        // the tint alone cannot say which view is open.
        Row(
            modifier = Modifier.padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xxs),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            GitTab.entries.forEach { tab ->
                val selected = tab == state.tab
                SiriusChip(
                    text = stringResource(tab.labelRes()),
                    selected = selected,
                    color = if (selected) colors.primary else colors.textSecondary,
                    onClick = { viewModel.selectTab(tab) },
                    modifier = Modifier.semantics { this.selected = selected }
                )
            }
        }

        if (state.busy) {
            InlineBusyRow(
                label = stringResource(R.string.git_working),
                modifier = Modifier.padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xxs)
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            state = listState,
            contentPadding = PaddingValues(
                start = SiriusSpacing.sm,
                end = SiriusSpacing.sm,
                top = SiriusSpacing.xs,
                bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
            ),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
        ) {
            when (state.tab) {
                GitTab.Changes -> {
                    if (status.conflicted.isNotEmpty()) {
                        item(key = "conflicts-header") {
                            SectionHeader(
                                title = stringResource(R.string.git_section_conflicts),
                                subtitle = stringResource(R.string.git_conflicts_hint)
                            )
                        }
                        itemsIndexed(
                            status.conflicted,
                            key = { _, file -> "conflict-${file.path}" }
                        ) { index, file ->
                            Reveal(index) {
                                GitFileRow(
                                    file = file,
                                    staged = false,
                                    busy = state.busy,
                                    onOpen = { viewModel.openDiff(file) },
                                    onStage = { viewModel.stage(file) },
                                    onUnstage = { viewModel.unstage(file) }
                                )
                            }
                        }
                    }

                    if (status.stagedFiles.isNotEmpty()) {
                        item(key = "staged-header") {
                            SectionHeader(
                                title = stringResource(R.string.git_section_staged),
                                subtitle = pluralStringResource(
                                    R.plurals.git_files_count,
                                    status.stagedFiles.size,
                                    status.stagedFiles.size
                                ),
                                actionLabel = stringResource(R.string.git_unstage_all),
                                onAction = viewModel::unstageAll
                            )
                        }
                        itemsIndexed(
                            status.stagedFiles,
                            key = { _, file -> "staged-${file.path}" }
                        ) { index, file ->
                            Reveal(index) {
                                GitFileRow(
                                    file = file,
                                    staged = true,
                                    busy = state.busy,
                                    onOpen = { viewModel.openDiff(GitDiffTarget(file.path, staged = true)) },
                                    onStage = { viewModel.stage(file) },
                                    onUnstage = { viewModel.unstage(file) }
                                )
                            }
                        }
                    }

                    if (status.unstagedFiles.isNotEmpty()) {
                        item(key = "unstaged-header") {
                            SectionHeader(
                                title = stringResource(R.string.git_section_unstaged),
                                subtitle = pluralStringResource(
                                    R.plurals.git_files_count,
                                    status.unstagedFiles.size,
                                    status.unstagedFiles.size
                                ),
                                actionLabel = stringResource(R.string.git_stage_all),
                                onAction = viewModel::stageAll
                            )
                        }
                        itemsIndexed(
                            status.unstagedFiles,
                            key = { _, file -> "unstaged-${file.path}" }
                        ) { index, file ->
                            Reveal(index) {
                                GitFileRow(
                                    file = file,
                                    staged = false,
                                    busy = state.busy,
                                    onOpen = { viewModel.openDiff(GitDiffTarget(file.path, staged = false)) },
                                    onStage = { viewModel.stage(file) },
                                    onUnstage = { viewModel.unstage(file) },
                                    onDiscard = { prompt = GitPrompt.Discard(file) }
                                )
                            }
                        }
                        item(key = "discard-all") {
                            SiriusGhostButton(
                                text = stringResource(R.string.git_discard_all),
                                icon = Icons.Rounded.DeleteOutline,
                                tint = colors.error,
                                enabled = !state.busy,
                                onClick = { prompt = GitPrompt.DiscardAll },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    if (status.isClean) {
                        item(key = "clean") {
                            EmptyState(
                                icon = Icons.Rounded.Check,
                                title = stringResource(R.string.git_clean_title),
                                message = stringResource(R.string.git_clean_message)
                            )
                        }
                    }

                    item(key = "commit") {
                        CommitCard(
                            message = state.commitMessage,
                            onMessageChange = viewModel::setCommitMessage,
                            canCommit = state.canCommit,
                            canAmend = !status.unborn && status.commits.isNotEmpty(),
                            busy = state.busy,
                            onCommit = { viewModel.commit() },
                            onAmend = { viewModel.commit(amend = true) }
                        )
                    }
                }

                GitTab.History -> {
                    if (status.commits.isEmpty()) {
                        item(key = "no-history") {
                            EmptyState(
                                icon = Icons.Rounded.History,
                                title = stringResource(R.string.git_history_empty_title),
                                message = stringResource(R.string.git_history_empty_message)
                            )
                        }
                    } else {
                        itemsIndexed(
                            status.commits,
                            key = { _, commit -> commit.id }
                        ) { index, commit ->
                            Reveal(index) {
                                GitCommitRow(
                                    commit = commit,
                                    onClick = { viewModel.openCommit(commit) }
                                )
                            }
                        }
                    }
                }

                GitTab.Branches -> {
                    item(key = "new-branch") {
                        SiriusGhostButton(
                            text = stringResource(R.string.git_new_branch),
                            icon = Icons.Rounded.Add,
                            enabled = !state.busy && !status.unborn,
                            onClick = {
                                branchName = ""
                                creatingBranch = true
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (status.unborn) {
                        item(key = "unborn") {
                            Text(
                                text = stringResource(R.string.git_unborn_hint),
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textTertiary
                            )
                        }
                    }
                    itemsIndexed(
                        status.branches,
                        key = { _, branch -> branch.name }
                    ) { index, branch ->
                        Reveal(index) {
                            BranchRow(
                                branch = branch,
                                busy = state.busy,
                                onCheckout = { viewModel.checkout(branch.name) }
                            )
                        }
                    }
                }
            }
        }
    }

    state.diffTarget?.let { target ->
        GitDiffSheet(
            target = target,
            diff = state.diff,
            loading = state.diffLoading,
            // Flipping sides is only meaningful for a path git holds in both.
            canToggleSide = status?.files
                ?.firstOrNull { it.path == target.path }
                ?.let { it.isStaged && it.isDirty } == true,
            onToggleSide = viewModel::toggleDiffSide,
            onDismiss = viewModel::closeDiff
        )
    }

    state.commitDetail?.let { detail ->
        GitCommitSheet(
            detail = detail,
            onOpenFile = { path ->
                viewModel.closeCommit()
                viewModel.openDiff(GitDiffTarget(path, staged = false))
            },
            onDismiss = viewModel::closeCommit
        )
    }

    if (creatingBranch) {
        SiriusBottomSheet(
            title = stringResource(R.string.git_new_branch),
            subtitle = status?.branch?.let { stringResource(R.string.git_branch_from, it) },
            onDismiss = { creatingBranch = false }
        ) {
            SiriusTextField(
                value = branchName,
                onValueChange = { branchName = it },
                placeholder = stringResource(R.string.git_branch_name_placeholder),
                imeAction = ImeAction.Done,
                onImeAction = {
                    viewModel.createBranch(branchName)
                    creatingBranch = false
                },
                modifier = Modifier.fillMaxWidth()
            )
            VSpace(SiriusSpacing.xs)
            SiriusPrimaryButton(
                text = stringResource(R.string.git_create_branch),
                icon = Icons.Rounded.AccountTree,
                enabled = branchName.isNotBlank() && !state.busy,
                onClick = {
                    viewModel.createBranch(branchName)
                    creatingBranch = false
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    GitPromptSheets(prompt = prompt, onDismiss = { prompt = null }, viewModel = viewModel)

    GitToast(state.message, contentPadding, viewModel::consumeMessage)
}

/** Commit message and the two ways to land it. */
@Composable
private fun CommitCard(
    message: String,
    onMessageChange: (String) -> Unit,
    canCommit: Boolean,
    canAmend: Boolean,
    busy: Boolean,
    onCommit: () -> Unit,
    onAmend: () -> Unit
) {
    GlassCard(contentPadding = SiriusSpacing.sm) {
        SiriusTextField(
            value = message,
            onValueChange = onMessageChange,
            label = stringResource(R.string.git_commit_message),
            placeholder = stringResource(R.string.git_commit_placeholder),
            singleLine = false,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        )
        VSpace(SiriusSpacing.xs)
        Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
            if (canAmend) {
                SiriusGhostButton(
                    text = stringResource(R.string.git_amend),
                    // Amend rewrites the last commit, so it needs a message but
                    // not a staged file.
                    enabled = message.isNotBlank() && !busy,
                    onClick = onAmend,
                    modifier = Modifier.weight(1f)
                )
            }
            SiriusPrimaryButton(
                text = stringResource(R.string.git_commit),
                icon = Icons.Rounded.Check,
                enabled = canCommit,
                loading = busy,
                onClick = onCommit,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

/** One branch, with the current one marked rather than merely tinted. */
@Composable
private fun BranchRow(
    branch: GitBranch,
    busy: Boolean,
    onCheckout: () -> Unit
) {
    val colors = SiriusTheme.colors
    val label = if (branch.isCurrent) {
        stringResource(R.string.git_branch_current_a11y, branch.name)
    } else {
        stringResource(R.string.git_switch_to, branch.name)
    }

    GlassCard(
        contentPadding = SiriusSpacing.sm,
        active = branch.isCurrent,
        onClick = if (branch.isCurrent || busy) null else onCheckout,
        onClickLabel = label
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = branch.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val subtitle = branch.lastCommitMessage
                    ?.lineSequence()?.firstOrNull()?.trim()
                    ?.takeIf { it.isNotEmpty() }
                Text(
                    text = when {
                        subtitle != null && branch.lastCommitAt > 0L ->
                            "$subtitle \u00B7 ${relativeTimeText(branch.lastCommitAt)}"

                        subtitle != null -> subtitle
                        else -> stringResource(R.string.git_branch_no_commits)
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (branch.isCurrent) {
                SiriusChip(
                    text = stringResource(R.string.git_branch_current),
                    icon = Icons.Rounded.Check,
                    color = colors.success,
                    selected = true
                )
            }
        }
    }
}

/**
 * One remedy per reason.
 *
 * Each of these is a different problem with a different fix, so the state offers
 * exactly the one action that can resolve it instead of a generic retry.
 */
@Composable
private fun GitUnavailableState(
    reason: GitUnavailable,
    onPickFolder: () -> Unit,
    onGrantAccess: () -> Unit,
    onInit: () -> Unit,
    onRetry: () -> Unit
) {
    when (reason) {
        GitUnavailable.NoWorkspace -> EmptyState(
            icon = Icons.Rounded.FolderOpen,
            title = stringResource(R.string.git_no_workspace_title),
            message = stringResource(R.string.git_no_workspace_message),
            actionLabel = stringResource(R.string.git_attach_folder),
            onAction = onPickFolder
        )

        is GitUnavailable.NotOnFilesystem -> EmptyState(
            icon = Icons.Rounded.FolderOpen,
            title = stringResource(R.string.git_not_on_filesystem_title),
            message = stringResource(R.string.git_not_on_filesystem_message, reason.label),
            actionLabel = stringResource(R.string.git_pick_another_folder),
            onAction = onPickFolder
        )

        GitUnavailable.NeedsPermission -> EmptyState(
            icon = Icons.Rounded.Lock,
            title = stringResource(R.string.git_permission_title),
            message = stringResource(R.string.git_permission_message),
            actionLabel = stringResource(R.string.git_grant_access),
            onAction = onGrantAccess
        )

        is GitUnavailable.NotARepository -> EmptyState(
            icon = Icons.Rounded.AccountTree,
            title = stringResource(R.string.git_not_a_repository_title),
            message = stringResource(R.string.git_not_a_repository_message, reason.path),
            actionLabel = stringResource(R.string.git_init),
            onAction = onInit
        )

        is GitUnavailable.Broken -> EmptyState(
            icon = Icons.Rounded.Difference,
            title = stringResource(R.string.git_broken_title),
            message = stringResource(R.string.git_broken_message, reason.reason),
            actionLabel = stringResource(R.string.action_retry),
            onAction = onRetry
        )
    }
}

@Composable
private fun GitPromptSheets(
    prompt: GitPrompt?,
    onDismiss: () -> Unit,
    viewModel: GitViewModel
) {
    when (prompt) {
        is GitPrompt.Discard -> SiriusConfirmSheet(
            title = stringResource(R.string.git_discard_title, prompt.file.name),
            message = if (prompt.file.isUntracked) {
                stringResource(R.string.git_discard_untracked_message)
            } else {
                stringResource(R.string.git_discard_message)
            },
            confirmLabel = stringResource(R.string.git_discard),
            icon = Icons.Rounded.DeleteOutline,
            onConfirm = {
                onDismiss()
                viewModel.discard(prompt.file)
            },
            onDismiss = onDismiss
        )

        GitPrompt.DiscardAll -> SiriusConfirmSheet(
            title = stringResource(R.string.git_discard_all_title),
            message = stringResource(R.string.git_discard_all_message),
            confirmLabel = stringResource(R.string.git_discard_all),
            icon = Icons.Rounded.DeleteOutline,
            onConfirm = {
                onDismiss()
                viewModel.discardAll()
            },
            onDismiss = onDismiss
        )

        GitPrompt.Init -> SiriusConfirmSheet(
            title = stringResource(R.string.git_init_title),
            message = stringResource(R.string.git_init_message),
            confirmLabel = stringResource(R.string.git_init),
            icon = Icons.Rounded.AccountTree,
            destructive = false,
            onConfirm = {
                onDismiss()
                viewModel.initRepository()
            },
            onDismiss = onDismiss
        )

        null -> Unit
    }
}

@Composable
private fun GitToast(
    message: String?,
    contentPadding: PaddingValues,
    onConsumed: () -> Unit
) {
    MessageToast(
        message = message,
        bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.sm
    )
    LaunchedEffect(message) {
        if (message != null) {
            kotlinx.coroutines.delay(2400)
            onConsumed()
        }
    }
}

private fun GitTab.labelRes(): Int = when (this) {
    GitTab.Changes -> R.string.git_tab_changes
    GitTab.History -> R.string.git_tab_history
    GitTab.Branches -> R.string.git_tab_branches
}
