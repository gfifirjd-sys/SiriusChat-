package com.sirius.chat.core.common

/** One-shot UI signals (snackbars, navigation) delivered through a Channel. */
sealed interface UiEvent {
    data class Message(val text: String, val isError: Boolean = false) : UiEvent
    data class Navigate(val route: String) : UiEvent
    data object Back : UiEvent
}
