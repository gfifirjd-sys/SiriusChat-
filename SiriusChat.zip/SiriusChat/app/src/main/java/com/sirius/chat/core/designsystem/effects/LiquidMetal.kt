package com.sirius.chat.core.designsystem.effects

import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.withInfiniteAnimationFrameMillis
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.domain.model.GlassLevel

/**
 * Liquid metal — the one ornamental effect Sirius is allowed to spend GPU on.
 *
 * Everything else in the app is flat, near-black chrome; this is the accent that
 * marks the primary action (the send button ring), a live surface (the streaming
 * bubble) and the assistant's own avatar. Because it is the *only* decorated
 * element on screen, it reads as a material rather than as noise — which is
 * exactly why the flat pass and this file landed together.
 *
 * The effect is a real fragment shader, not a gradient impression of one:
 * four sine bands warped by a simplex FBM field, resolved through a five-stop
 * palette, softened with a five-tap cross blur, then gamma-punched and
 * vignetted. On API 33+ it runs as AGSL through [RuntimeShader]. Below that
 * there is no runtime shader support, so [metalFallbackBrush] approximates the
 * same palette with a rotating sweep gradient — visually simpler, but the same
 * colours moving in the same direction, which is all the accent has to convey.
 */
enum class LiquidMetalPreset { Chromatic, Silver, Gold }

/**
 * One resolved look. Ported 1:1 from the reference WebGL engine (see
 * `docs/liquid-metal-reference.md`) with the per-stop alphas dropped: every
 * shipped preset used alpha = 1 on all five stops, which collapses the palette
 * weighting and the per-pixel alpha maths into a plain weighted sum.
 */
@Immutable
data class LiquidMetalParams(
    val c1: Color,
    val c2: Color,
    val c3: Color,
    val c4: Color,
    val c5: Color,
    val direction: Float = 80f,
    val speed: Float = 1.2f,
    val intensity: Float = 2f,
    val scale: Float = 2.5f,
    val distortion: Float = 0.3f,
    val complexity: Float = 0.68f,
    val vignette: Float = 0.26f,
    val vigOpacity: Float = 0.6f,
    val blur: Float = 1f,
    val opacity: Float = 1f
)

/**
 * Preset values for both themes. The light variants are not the dark ones
 * lightened: a bright plate needs its darkest stop to carry the shading, so the
 * ramps are ordered differently.
 */
fun liquidMetalParams(preset: LiquidMetalPreset, dark: Boolean): LiquidMetalParams = when (preset) {
    LiquidMetalPreset.Chromatic -> if (dark) {
        LiquidMetalParams(
            c1 = Color(0xFF000000),
            c2 = Color(0xFFAAE8FF),
            c3 = Color(0xFFC5FE9E),
            c4 = Color(0xFFF7888D),
            c5 = Color(0xFF0D0D0D),
            scale = 1.6f,
            vignette = 0.26f,
            vigOpacity = 0.6f
        )
    } else {
        LiquidMetalParams(
            c1 = Color(0xFFFFFFFF),
            c2 = Color(0xFFFFFFFF),
            c3 = Color(0xFFFFFFFF),
            c4 = Color(0xFFFFB3B3),
            c5 = Color(0xFFADADAD),
            vignette = 0.24f,
            vigOpacity = 0.16f
        )
    }

    LiquidMetalPreset.Silver -> if (dark) {
        LiquidMetalParams(
            c1 = Color(0xFF000000),
            c2 = Color(0xFFDEDEDE),
            c3 = Color(0xFF747270),
            c4 = Color(0xFFE5E5E5),
            c5 = Color(0xFF0D0D0D),
            opacity = 0.88f
        )
    } else {
        LiquidMetalParams(
            c1 = Color(0xFFF6F6F6),
            c2 = Color(0xFFFFFFFF),
            c3 = Color(0xFFFFFFFF),
            c4 = Color(0xFFF7F7F7),
            c5 = Color(0xFFC9C9C9),
            vignette = 0.2f,
            vigOpacity = 0.26f
        )
    }

    LiquidMetalPreset.Gold -> if (dark) {
        LiquidMetalParams(
            c1 = Color(0xFF000000),
            c2 = Color(0xFFFFFFFF),
            c3 = Color(0xFFFFFFFF),
            c4 = Color(0xFFF7D488),
            c5 = Color(0xFF0D0D0D),
            speed = 1f,
            opacity = 0.92f
        )
    } else {
        LiquidMetalParams(
            c1 = Color(0xFFFFF8E1),
            c2 = Color(0xFFFFFBE0),
            c3 = Color(0xFFFFFFFF),
            c4 = Color(0xFFFFF6D6),
            c5 = Color(0xFFD2C7A7),
            vignette = 0.22f,
            vigOpacity = 0.24f
        )
    }
}

/**
 * A metal ring around [shape]: the send button, the armed primary action, a live
 * bubble. Drawn *over* the content so the stroke is never clipped by the fill.
 */
@Composable
fun Modifier.liquidMetalRing(
    shape: Shape = CircleShape,
    width: Dp = 1.5.dp,
    preset: LiquidMetalPreset = LiquidMetalPreset.Chromatic,
    active: Boolean = true,
    opacity: Float = 1f
): Modifier = liquidMetal(shape, preset, active, width, opacity, overContent = true)

/** Metal as a fill — the assistant avatar, the orb, small badges. */
@Composable
fun Modifier.liquidMetalFill(
    shape: Shape = CircleShape,
    preset: LiquidMetalPreset = LiquidMetalPreset.Chromatic,
    active: Boolean = true,
    opacity: Float = 1f
): Modifier = liquidMetal(shape, preset, active, null, opacity, overContent = false)

@Composable
private fun Modifier.liquidMetal(
    shape: Shape,
    preset: LiquidMetalPreset,
    active: Boolean,
    strokeWidth: Dp?,
    opacity: Float,
    overContent: Boolean
): Modifier {
    val dark = SiriusTheme.colors.isDark
    val effectsOff = SiriusTheme.glass == GlassLevel.Off
    val params = remember(preset, dark, opacity) {
        liquidMetalParams(preset, dark).let { it.copy(opacity = it.opacity * opacity) }
    }
    // Effects off still shows the accent, it just stops moving: the ring is load
    // bearing (it marks the primary action) and must not disappear with a
    // preference that is about motion and cost, not about meaning.
    val time = rememberMetalTime(active = active && !effectsOff, speed = params.speed)
    val shader = rememberMetalShader(params)
    val fallback = remember(params) { metalFallbackBrush(params) }

    return drawWithCache {
        val path = shape.createOutline(size, layoutDirection, this).toPath()
        val stroke = strokeWidth?.let { Stroke(width = it.toPx()) }
        // The shader and the brush that wraps it are one decision, so they travel
        // as one nullable: a non-null pair *is* the AGSL path, and the fallback
        // needs no null checks of its own.
        val agsl = if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && shader != null
        ) {
            shader.setFloatUniform("uResolution", size.width, size.height)
            shader to ShaderBrush(shader)
        } else {
            null
        }

        fun DrawScope.paint() {
            if (agsl != null) {
                val (metal, brush) = agsl
                metal.setFloatUniform("uTime", time.value)
                if (stroke != null) drawPath(path, brush, style = stroke) else drawPath(path, brush)
            } else {
                // Sweep gradients have no notion of time, so the rotation *is*
                // the animation. 26s per turn matches the shader's drift.
                rotate(degrees = time.value * 13.8f) {
                    if (stroke != null) {
                        drawPath(path, fallback, alpha = params.opacity, style = stroke)
                    } else {
                        drawPath(path, fallback, alpha = params.opacity)
                    }
                }
            }
        }

        if (overContent) {
            onDrawWithContent {
                drawContent()
                paint()
            }
        } else {
            onDrawBehind { paint() }
        }
    }
}

/**
 * Frame-driven clock. Written as a frame loop rather than an
 * `infiniteRepeatable` float because the shader needs a monotonically growing
 * seconds value, not a 0..1 ramp that would visibly reset the noise field every
 * cycle.
 */
@Composable
private fun rememberMetalTime(active: Boolean, speed: Float): State<Float> {
    // A parked value, not zero: at t = 0 the plasma sits on a symmetric seam and
    // the static ring would look like a flat grey line.
    val state = remember { mutableFloatStateOf(0.42f) }
    val reduceMotion = SiriusTheme.reduceMotion
    LaunchedEffect(active, reduceMotion, speed) {
        if (!active || reduceMotion) return@LaunchedEffect
        var origin = -1L
        while (true) {
            withInfiniteAnimationFrameMillis { frame ->
                if (origin < 0L) origin = frame
                state.floatValue = (frame - origin) / 1000f * speed
            }
        }
    }
    return state
}

@Composable
private fun rememberMetalShader(params: LiquidMetalParams): RuntimeShader? = remember(params) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) buildMetalShader(params) else null
}

/**
 * Builds the shader, or returns null if the driver rejects it.
 *
 * AGSL is compiled at runtime, so a bad shader is an exception on a UI frame
 * rather than a build error — and an ornament must never be able to take the
 * screen down with it. Anything that goes wrong here falls through to
 * [metalFallbackBrush].
 */
@RequiresApi(Build.VERSION_CODES.TIRAMISU)
private fun buildMetalShader(params: LiquidMetalParams): RuntimeShader? =
    runCatching { compileMetalShader(params) }.getOrNull()

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
private fun RuntimeShader.setColorComponents(name: String, color: Color) {
    setFloatUniform(name, color.red, color.green, color.blue)
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
private fun compileMetalShader(params: LiquidMetalParams): RuntimeShader =
    RuntimeShader(LiquidMetalAgsl).apply {
        setColorComponents("uC1", params.c1)
        setColorComponents("uC2", params.c2)
        setColorComponents("uC3", params.c3)
        setColorComponents("uC4", params.c4)
        setColorComponents("uC5", params.c5)
        setFloatUniform("uIntensity", params.intensity)
        setFloatUniform("uScale", params.scale)
        setFloatUniform("uDirection", Math.toRadians(params.direction.toDouble()).toFloat())
        setFloatUniform("uDistortion", params.distortion)
        setFloatUniform("uComplexity", params.complexity)
        setFloatUniform("uVignette", params.vignette)
        setFloatUniform("uVigOpacity", params.vigOpacity)
        setFloatUniform("uBlur", params.blur)
        setFloatUniform("uOpacity", params.opacity)
        setFloatUniform("uTime", 0.42f)
        setFloatUniform("uResolution", 1f, 1f)
    }

/**
 * API < 33 stand-in: the five palette stops mirrored into a full turn so the
 * sweep has no visible seam where it wraps.
 */
private fun metalFallbackBrush(params: LiquidMetalParams): Brush = Brush.sweepGradient(
    listOf(
        params.c2, params.c3, params.c4, params.c5,
        params.c4, params.c3, params.c2, params.c3, params.c2
    )
)

/**
 * AGSL is SkSL, so this is the reference GLSL with `vecN` -> `floatN`,
 * `gl_FragCoord` -> the `main` parameter, and premultiplied `half4` out.
 *
 * Two deliberate simplifications: the FBM octave count is fixed at five (the
 * reference computed `3 + complexity * 4`, which is 5.72 -> 5 for every shipped
 * preset, and a constant trip count keeps the loop unrollable), and the
 * per-stop alpha maths is gone because all shipped alphas were 1.
 */
private const val LiquidMetalAgsl = """
uniform float2 uResolution;
uniform float uTime;
uniform float3 uC1;
uniform float3 uC2;
uniform float3 uC3;
uniform float3 uC4;
uniform float3 uC5;
uniform float uIntensity;
uniform float uScale;
uniform float uDirection;
uniform float uDistortion;
uniform float uComplexity;
uniform float uVignette;
uniform float uVigOpacity;
uniform float uBlur;
uniform float uOpacity;

float3 mod289(float3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
float2 mod289v2(float2 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
float3 permute(float3 x) { return mod289((x * 34.0 + 1.0) * x); }

float snoise(float2 v) {
    float4 C = float4(0.211324865405187, 0.366025403784439,
                      -0.577350269189626, 0.024390243902439);
    float2 i = floor(v + dot(v, C.yy));
    float2 x0 = v - i + dot(i, C.xx);
    float2 i1 = (x0.x > x0.y) ? float2(1.0, 0.0) : float2(0.0, 1.0);
    float4 x12 = x0.xyxy + C.xxzz;
    x12.xy -= i1;
    i = mod289v2(i);
    float3 p = permute(permute(i.y + float3(0.0, i1.y, 1.0)) + i.x + float3(0.0, i1.x, 1.0));
    float3 m = max(0.5 - float3(dot(x0, x0), dot(x12.xy, x12.xy), dot(x12.zw, x12.zw)), 0.0);
    m = m * m;
    m = m * m;
    float3 xf = 2.0 * fract(p * C.www) - 1.0;
    float3 h = abs(xf) - 0.5;
    float3 ox = floor(xf + 0.5);
    float3 a0 = xf - ox;
    m *= 1.79284291400159 - 0.85373472095314 * (a0 * a0 + h * h);
    float3 g;
    g.x = a0.x * x0.x + h.x * x0.y;
    g.yz = a0.yz * x12.xz + h.yz * x12.yw;
    return 130.0 * dot(m, g);
}

float nfbm(float2 p) {
    float val = 0.0;
    float amp = 0.5;
    for (int i = 0; i < 5; i++) {
        val += amp * snoise(p);
        p *= 2.0;
        amp *= 0.5;
    }
    return val;
}

float3 palette(float t) {
    t = clamp(t, 0.0, 1.0);
    t = t * t * (3.0 - 2.0 * t);
    float k = 64.0;
    float w1 = exp(-k * t * t);
    float w2 = exp(-k * (t - 0.25) * (t - 0.25));
    float w3 = exp(-k * (t - 0.5) * (t - 0.5));
    float w4 = exp(-k * (t - 0.75) * (t - 0.75));
    float w5 = exp(-k * (t - 1.0) * (t - 1.0));
    float total = w1 + w2 + w3 + w4 + w5 + 0.0001;
    float3 sum = uC1 * w1 + uC2 * w2 + uC3 * w3 + uC4 * w4 + uC5 * w5;
    return sum / total;
}

float2 warp(float2 p, float t) {
    float str = uDistortion * 2.0;
    return float2(nfbm(p + float2(t * 0.1, 0.0)),
                  nfbm(p + float2(0.0, t * 0.12) + 5.0)) * str;
}

float3 computeEffect(float2 uv, float aspect, float t) {
    float2 p = (uv - 0.5) * uScale;
    p.x *= aspect;
    p += float2(cos(uDirection), sin(uDirection)) * t * 0.15;

    float freq = 3.0 + uComplexity * 8.0;
    float val = 0.0;
    val += sin(p.x * freq + t);
    val += sin(p.y * freq + t * 1.3);
    val += sin((p.x + p.y) * freq * 0.7 + t * 0.7);
    val += sin(length(p) * freq * 0.8 - t * 1.5);
    float2 w = warp(p, t);
    val += (w.x + w.y) * uDistortion;
    val = val * 0.2 * uIntensity + 0.5;
    return palette(clamp(val, 0.0, 1.0));
}

half4 main(float2 fragCoord) {
    float2 res = max(uResolution, float2(1.0, 1.0));
    float2 uv = fragCoord / res;
    float aspect = res.x / res.y;
    float t = uTime;

    float3 col;
    if (uBlur < 0.01) {
        col = computeEffect(uv, aspect, t);
    } else {
        float r = uBlur * 0.02;
        col  = computeEffect(uv, aspect, t) * 0.4;
        col += computeEffect(uv + float2(r, 0.0), aspect, t) * 0.15;
        col += computeEffect(uv + float2(-r, 0.0), aspect, t) * 0.15;
        col += computeEffect(uv + float2(0.0, r), aspect, t) * 0.15;
        col += computeEffect(uv + float2(0.0, -r), aspect, t) * 0.15;
    }

    col = pow(col, float3(1.3));

    float edge = min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y));
    float vigPx = 40.0 / min(res.x, res.y);
    float vigRange = vigPx * (1.0 + uVignette * 3.0);
    float vig = smoothstep(0.0, 1.0, edge * edge / (vigRange * vigRange));
    col *= mix(1.0, vig, uVignette * uVigOpacity);

    return half4(half3(col * uOpacity), half(uOpacity));
}
"""
