package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentQuestion
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.string
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.jsonPrimitive
import java.util.UUID

/**
 * Lets the agent ask a question mid-run instead of guessing.
 *
 * Without this the only way to answer a model's question is to let the run finish
 * on a wrong assumption and correct it afterwards, which throws away every step
 * that followed the guess. A build that has already written six files against the
 * wrong package name is not cheaper to fix than one that paused to ask.
 *
 * The tool is read-only in the sense that matters: it proposes no change and
 * touches no file. It only suspends.
 *
 * ### Bounds
 * Options are capped and truncated because they are rendered as buttons — a model
 * that offers twelve paragraph-long choices produces a sheet nobody can use. The
 * cap is enforced here rather than in the UI so the limit is part of the contract
 * the model is held to, not a layout accident.
 */
class AskUserTool : AgentTool {
    override val name = "ask_user"
    override val description =
        "Ask the user a question and wait for their answer. Use when a choice " +
            "would change what you build and you cannot infer it. Do not use for " +
            "confirmation of work already described."
    override val usage =
        """{"question": "Which features?", "options": ["auth", "sync"], "multi_select": true}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val question = args.string("question")
            ?: return AgentToolResult("Missing 'question'.", success = false)

        val ask = context.askUser
            ?: return AgentToolResult(
                "Cannot ask the user in this run. Continue with your best " +
                    "judgement and state the assumption you made.",
                success = false
            )

        val options = (args["options"] as? JsonArray)
            ?.mapNotNull { runCatching { it.jsonPrimitive.content }.getOrNull() }
            ?.map { it.trim() }
            ?.filter { it.isNotEmpty() }
            ?.distinct()
            ?.take(MAX_OPTIONS)
            ?.map { it.take(MAX_OPTION_CHARS) }
            .orEmpty()

        // Multi select without options would render a confirm button over an
        // empty list, so it is ignored unless there is something to select.
        val multi = (args["multi_select"] ?: args["multiSelect"])
            ?.let { runCatching { it.jsonPrimitive.boolean }.getOrNull() } ?: false

        val answer = ask(
            AgentQuestion(
                id = UUID.randomUUID().toString(),
                question = question.take(MAX_QUESTION_CHARS),
                options = options,
                multiSelect = multi && options.isNotEmpty()
            )
        )

        // A dismissed sheet is a real answer, not an error: the user chose not to
        // steer. Reporting it as a failure would make the model apologise and ask
        // again, which is the loop this branch exists to avoid.
        return if (answer.isBlank()) {
            AgentToolResult(
                "The user skipped the question. Proceed with your best judgement " +
                    "and say which assumption you made."
            )
        } else {
            AgentToolResult("The user answered: $answer")
        }
    }

    private companion object {
        const val MAX_OPTIONS = 5
        const val MAX_OPTION_CHARS = 80
        const val MAX_QUESTION_CHARS = 400
    }
}
