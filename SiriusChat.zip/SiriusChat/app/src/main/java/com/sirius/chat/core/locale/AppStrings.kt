package com.sirius.chat.core.locale

import androidx.annotation.StringRes
import com.sirius.chat.domain.model.AppLanguage

/**
 * Process-wide bridge to [StringProvider] for the few layers that produce
 * user-facing text without a Context or an AppContainer: transport error
 * mapping, use cases and the terminal backend.
 *
 * ViewModels should keep using `container.strings`; this exists only where
 * threading a dependency through would mean rewriting a constructor chain.
 */
object AppStrings {

    @Volatile
    private var provider: StringProvider? = null

    fun install(provider: StringProvider) {
        this.provider = provider
    }

    /** [fallback] only applies before [install] runs (unit tests, early startup). */
    fun get(@StringRes id: Int, fallback: String): String = provider?.get(id) ?: fallback

    fun format(@StringRes id: Int, vararg args: Any, fallback: String): String =
        provider?.get(id, *args) ?: fallback

    /**
     * True when [value] equals resource [id] in any supported language.
     *
     * Titles are stored in whatever language was active when they were created,
     * so a plain comparison against the current locale would stop recognising
     * placeholders after the user switches languages.
     */
    fun matchesAnyLanguage(@StringRes id: Int, value: String): Boolean {
        val current = provider ?: return false
        return AppLanguage.entries.any { language ->
            current.forLanguage(language).getString(id) == value
        }
    }
}
