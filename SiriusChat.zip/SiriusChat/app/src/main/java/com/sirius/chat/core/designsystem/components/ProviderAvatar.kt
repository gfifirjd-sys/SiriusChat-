package com.sirius.chat.core.designsystem.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Diamond
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Waves
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/**
 * A generic mark, for endpoints that have no logo of their own.
 *
 * Real services get their real logo from [ProviderBrand]; these abstract marks
 * are what a self-hosted or private endpoint wears, and they resolve against
 * the palette so they stay correct in both themes.
 */
enum class ProviderIcon(
    val key: String,
    val icon: ImageVector,
    @StringRes val labelRes: Int,
    private val tone: Tone
) {
    Spark("spark", Icons.Rounded.AutoAwesome, R.string.provider_icon_spark, Tone.Primary),
    Layers("layers", Icons.Rounded.Layers, R.string.provider_icon_layers, Tone.Accent),
    Diamond("diamond", Icons.Rounded.Diamond, R.string.provider_icon_diamond, Tone.Info),
    Bolt("bolt", Icons.Rounded.Bolt, R.string.provider_icon_bolt, Tone.Warning),
    Waves("waves", Icons.Rounded.Waves, R.string.provider_icon_waves, Tone.Info),
    Wind("wind", Icons.Rounded.Air, R.string.provider_icon_wind, Tone.Secondary),
    Flame("flame", Icons.Rounded.LocalFireDepartment, R.string.provider_icon_flame, Tone.Error),
    Hub("hub", Icons.Rounded.Hub, R.string.provider_icon_hub, Tone.Primary),
    Atom("atom", Icons.Rounded.Science, R.string.provider_icon_atom, Tone.Accent),
    Star("star", Icons.Rounded.Star, R.string.provider_icon_star, Tone.Warning),
    Compass("compass", Icons.Rounded.Explore, R.string.provider_icon_compass, Tone.Success),
    Shield("shield", Icons.Rounded.Shield, R.string.provider_icon_shield, Tone.Success),
    Brain("brain", Icons.Rounded.Psychology, R.string.provider_icon_brain, Tone.Accent),
    Robot("robot", Icons.Rounded.SmartToy, R.string.provider_icon_robot, Tone.Secondary),
    Rocket("rocket", Icons.Rounded.RocketLaunch, R.string.provider_icon_rocket, Tone.Primary),
    Memory("memory", Icons.Rounded.Memory, R.string.provider_icon_memory, Tone.Info),
    Cloud("cloud", Icons.Rounded.Cloud, R.string.provider_icon_cloud, Tone.Secondary),
    Terminal("terminal", Icons.Rounded.Terminal, R.string.provider_icon_terminal, Tone.Success),
    Device("device", Icons.Rounded.PhoneAndroid, R.string.provider_icon_device, Tone.Secondary),
    Server("server", Icons.Rounded.Dns, R.string.provider_icon_server, Tone.Info);

    enum class Tone { Primary, Secondary, Accent, Info, Success, Warning, Error }

    /** Resolved against the live palette, so the mark follows light/dark. */
    val color: Color
        @Composable get() = with(SiriusTheme.colors) {
            when (tone) {
                Tone.Primary -> primary
                Tone.Secondary -> secondary
                Tone.Accent -> accent
                Tone.Info -> info
                Tone.Success -> success
                Tone.Warning -> warning
                Tone.Error -> error
            }
        }

    companion object {
        fun fromKey(key: String?): ProviderIcon? = entries.firstOrNull { it.key == key }

        /** What an endpoint without a chosen mark falls back to. */
        fun forType(type: ProviderType): ProviderIcon = when (type) {
            ProviderType.OpenAiCompatible -> Spark
            ProviderType.AnthropicCompatible -> Layers
            ProviderType.Custom -> Server
        }
    }
}

/**
 * The square plate in front of a provider's name.
 *
 * A user-supplied image wins over the built-in mark, and it is drawn clipped to
 * the same plate so a photo from the gallery cannot break the row's rhythm.
 */
@Composable
fun ProviderAvatar(
    provider: ProviderConfig,
    modifier: Modifier = Modifier,
    size: Dp = 38.dp
) {
    ProviderAvatar(
        iconKey = provider.iconKey,
        imagePath = provider.iconImagePath,
        type = provider.type,
        modifier = modifier,
        size = size
    )
}

@Composable
fun ProviderAvatar(
    iconKey: String?,
    imagePath: String?,
    type: ProviderType,
    modifier: Modifier = Modifier,
    size: Dp = 38.dp
) {
    val shape = RoundedCornerShape(if (size >= 32.dp) SiriusRadius.sm else SiriusRadius.xs)
    // A real service's own logo wins over the abstract marks; those are the
    // fallback for endpoints that have no logo to show.
    val brand = ProviderBrand.fromKey(iconKey)
    val mark = ProviderIcon.fromKey(iconKey) ?: ProviderIcon.forType(type)
    val bitmap = rememberProviderIconImage(imagePath)

    Box(
        modifier = modifier
            .size(size)
            .softSurface(shape),
        contentAlignment = Alignment.Center
    ) {
        when {
            bitmap != null -> Image(
                bitmap = bitmap,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(size)
                    .softSurface(shape)
            )

            brand != null -> {
                val painter = painterResource(brand.drawable)
                val tint = brand.tint
                // Marks that carry their own palette are drawn untouched; a
                // single-shape mark is tinted so it survives both themes.
                if (tint == null) {
                    Image(
                        painter = painter,
                        contentDescription = null,
                        modifier = Modifier.size(size * 0.56f)
                    )
                } else {
                    Icon(
                        painter = painter,
                        contentDescription = null,
                        tint = tint,
                        modifier = Modifier.size(size * 0.56f)
                    )
                }
            }

            else -> Icon(
                imageVector = mark.icon,
                contentDescription = null,
                tint = mark.color,
                modifier = Modifier.size(size * 0.52f)
            )
        }
    }
}

/**
 * Decodes a stored icon once per path, off the main thread.
 *
 * The file is small (downsampled to 256px by [saveProviderIcon]), but decoding
 * it inside `remember` meant disk I/O plus a PNG decode ran during composition —
 * on a list of providers that is one stall per avatar, on the frame that is
 * trying to show them.
 */
@Composable
private fun rememberProviderIconImage(path: String?): ImageBitmap? {
    val target = path?.takeIf { it.isNotBlank() }
    return produceState<ImageBitmap?>(initialValue = null, key1 = target) {
        value = target?.let { candidate ->
            withContext(Dispatchers.IO) {
                runCatching {
                    File(candidate)
                        .takeIf { it.exists() }
                        ?.let { BitmapFactory.decodeFile(it.absolutePath)?.asImageBitmap() }
                }.getOrNull()
            }
        }
    }.value
}

private const val ICON_DIR = "provider_icons"
private const val ICON_MAX_PX = 256

/**
 * Copies a picked image into the app's own storage, downsampled to a plate-sized
 * PNG. The gallery Uri itself is not stored: its read permission is scoped to
 * the picker session and would be dead the next time the screen opened.
 *
 * Runs blocking I/O, so callers must be off the main thread. Returns the
 * absolute path, or `null` if the image could not be read.
 */
fun saveProviderIcon(context: Context, uri: Uri): String? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    val largest = maxOf(bounds.outWidth, bounds.outHeight).takeIf { it > 0 } ?: return null

    var sample = 1
    while (largest / sample > ICON_MAX_PX * 2) sample *= 2

    val decoded = context.contentResolver.openInputStream(uri)?.use { stream ->
        BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply { inSampleSize = sample })
    } ?: return null

    val scale = ICON_MAX_PX.toFloat() / maxOf(decoded.width, decoded.height)
    val scaled = if (scale < 1f) {
        Bitmap.createScaledBitmap(
            decoded,
            (decoded.width * scale).toInt().coerceAtLeast(1),
            (decoded.height * scale).toInt().coerceAtLeast(1),
            true
        )
    } else {
        decoded
    }

    val dir = File(context.filesDir, ICON_DIR).apply { mkdirs() }
    val file = File(dir, "icon-${UUID.randomUUID().toString().take(8)}.png")
    file.outputStream().use { out -> scaled.compress(Bitmap.CompressFormat.PNG, 100, out) }
    if (scaled !== decoded) scaled.recycle()
    decoded.recycle()
    file.absolutePath
}.getOrNull()

/** Removes a custom icon file once nothing points at it any more. */
fun deleteProviderIcon(path: String?) {
    if (path.isNullOrBlank()) return
    runCatching { File(path).takeIf { it.exists() }?.delete() }
}
