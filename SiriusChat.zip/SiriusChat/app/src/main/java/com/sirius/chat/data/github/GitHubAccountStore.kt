package com.sirius.chat.data.github

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sirius.chat.data.local.security.KeystoreCipher
import com.sirius.chat.domain.model.GitHubAccount
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.githubDataStore: DataStore<Preferences> by
    preferencesDataStore(name = "sirius_github")

/**
 * The connected GitHub account and its token.
 *
 * The token is a credential with write access to someone's source code, so it is
 * treated exactly like a provider API key: encrypted with the hardware-backed
 * keystore key, decrypted only for the duration of one request, and never handed
 * to the UI layer. The profile fields sit in the clear next to it because they
 * are public information and the account header has to render before any network
 * call happens.
 *
 * This is a separate store from `SecureCredentialStore` on purpose. That one
 * keys everything by provider id and publishes the set of ids that have keys;
 * dropping a `github` entry into it would leak a fake provider into the model
 * picker.
 */
class GitHubAccountStore(context: Context) {

    private val dataStore = context.githubDataStore
    private val cipher = KeystoreCipher(alias = "sirius_github_token_v1")

    private object Keys {
        val token = stringPreferencesKey("token")
        val login = stringPreferencesKey("login")
        val name = stringPreferencesKey("name")
        val avatar = stringPreferencesKey("avatar_url")
        val scopes = stringPreferencesKey("scopes")
    }

    /** Null when no account is connected. */
    val account: Flow<GitHubAccount?> = dataStore.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { prefs ->
            val login = prefs[Keys.login] ?: return@map null
            if (prefs[Keys.token] == null) return@map null
            GitHubAccount(
                login = login,
                name = prefs[Keys.name].orEmpty(),
                avatarUrl = prefs[Keys.avatar].orEmpty(),
                scopes = prefs[Keys.scopes]
                    .orEmpty()
                    .split(',')
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
            )
        }

    suspend fun save(account: GitHubAccount, token: String) {
        val encrypted = runCatching { cipher.encrypt(token) }.getOrNull() ?: return
        dataStore.edit { prefs ->
            prefs[Keys.token] = encrypted
            prefs[Keys.login] = account.login
            prefs[Keys.name] = account.name
            prefs[Keys.avatar] = account.avatarUrl
            prefs[Keys.scopes] = account.scopes.joinToString(",")
        }
    }

    suspend fun token(): String? {
        val stored = dataStore.data.first()[Keys.token] ?: return null
        return cipher.decrypt(stored)
    }

    suspend fun connected(): Boolean = token() != null

    suspend fun disconnect() {
        dataStore.edit { it.clear() }
    }
}
