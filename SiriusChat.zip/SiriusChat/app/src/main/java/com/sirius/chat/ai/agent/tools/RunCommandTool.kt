package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.CommandOutcome
import com.sirius.chat.ai.agent.string
import kotlinx.serialization.json.JsonObject

/**
 * Runs a shell command and waits for it to finish.
 *
 * Until this existed the agent had no way to run anything: it could write a
 * `build.gradle.kts` but never find out whether it compiled, so "build the APK"
 * ended with the agent confidently reporting success it had not observed. Worse,
 * it could not see its own mistakes — a missing plugin or a Kotlin syntax error
 * only surfaces when something executes.
 *
 * ### Waiting is the point
 * The tool blocks until the process exits and returns the exit code with it. A
 * fire-and-forget version would be actively harmful here: a Gradle build prints
 * nothing useful for the first thirty seconds and then fails on line 400, so an
 * agent that moved on immediately would plan its next three steps against a build
 * that was still running, or already broken.
 *
 * That means a single call can occupy the whole turn for minutes. This is why
 * [timeoutMs] exists and why the step budget auto-extends: a build is one step
 * that costs as much wall clock as thirty file writes.
 *
 * ### Output budget
 * Only the tail is returned. Gradle emits megabytes on failure and the part that
 * says what broke is at the end, so keeping the head would spend the entire
 * context window on download progress. Stderr is kept separately and in full
 * priority, because that is where the error is.
 */
class RunCommandTool : AgentTool {
    override val name = "run_command"
    override val description =
        "Run a shell command in the terminal and wait for it to finish. Returns " +
            "the exit code and output. Use for builds, tests, git and package " +
            "managers. Blocking: expect it to take a while for a build."
    override val usage =
        """{"command": "./gradlew assembleDebug", "timeout_ms": 600000}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val command = args.string("command")?.trim()
            ?: return AgentToolResult("Missing 'command'.", success = false)
        if (command.isEmpty()) {
            return AgentToolResult("Command is empty.", success = false)
        }

        val run = context.runCommand
            ?: return AgentToolResult(
                "No terminal is available in this run. Do not claim a command " +
                    "succeeded; tell the user it could not be executed.",
                success = false
            )

        val timeout = args.string("timeout_ms")?.toLongOrNull()
            ?: DEFAULT_TIMEOUT_MS

        val outcome = run(command, timeout.coerceIn(MIN_TIMEOUT_MS, MAX_TIMEOUT_MS))
        return format(command, outcome)
    }

    private fun format(command: String, outcome: CommandOutcome): AgentToolResult {
        val body = StringBuilder()
        if (outcome.workingDirectory.isNotEmpty()) {
            body.append("cwd: ").append(outcome.workingDirectory).append('\n')
        }
        body.append("$ ").append(command).append('\n')

        if (outcome.timedOut) {
            body.append("TIMED OUT after ").append(outcome.durationMs).append("ms.\n")
        } else {
            body.append("exit=").append(outcome.exitCode)
                .append(" in ").append(outcome.durationMs).append("ms\n")
        }

        if (outcome.stderr.isNotEmpty()) {
            body.append("\n--- stderr ---\n").append(tail(outcome.stderr, STDERR_BUDGET))
        }
        if (outcome.stdout.isNotEmpty()) {
            body.append("\n--- stdout ---\n").append(tail(outcome.stdout, STDOUT_BUDGET))
        }
        if (outcome.stdout.isEmpty() && outcome.stderr.isEmpty()) {
            body.append("\n(no output)")
        }

        // A non-zero exit is reported as a *failed* tool call so the engine's own
        // error handling kicks in and the model cannot skim past it. The text
        // still carries the full diagnostics, so it has what it needs to fix it.
        val ok = !outcome.timedOut && outcome.exitCode == 0
        return AgentToolResult(body.toString(), success = ok)
    }

    /** Keeps the end of [text], which is where a build failure explains itself. */
    private fun tail(text: String, budget: Int): String =
        if (text.length <= budget) text
        else "\u2026 (" + (text.length - budget) + " earlier chars omitted)\n" +
            text.takeLast(budget)

    private companion object {
        const val DEFAULT_TIMEOUT_MS = 300_000L
        const val MIN_TIMEOUT_MS = 1_000L
        const val MAX_TIMEOUT_MS = 1_800_000L
        const val STDERR_BUDGET = 6_000
        const val STDOUT_BUDGET = 4_000
    }
}
