package com.sirius.chat.feature.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.core.util.CodeFolding
import com.sirius.chat.core.util.FoldRegion
import com.sirius.chat.data.repository.EditorTab
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.Project
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SearchState(
    val visible: Boolean = false,
    val query: String = "",
    val replacement: String = "",
    val matches: List<Int> = emptyList(),
    val currentIndex: Int = 0
) {
    val hasMatches: Boolean get() = matches.isNotEmpty()
}

data class EditorUiState(
    val tabs: List<EditorTab> = emptyList(),
    val activeId: String? = null,
    val settings: AppSettings = AppSettings(),
    val search: SearchState = SearchState(),
    val folds: List<FoldRegion> = emptyList(),
    val collapsed: Set<Int> = emptySet(),
    val problems: List<String> = emptyList(),
    val saving: Boolean = false,
    val message: String? = null,
    val project: Project? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false
) {
    val active: EditorTab? get() = tabs.firstOrNull { it.documentId == activeId }
}

/** Bounded per-tab undo history. */
private class UndoHistory(private val limit: Int = 60) {
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()

    fun record(previous: String) {
        if (undoStack.lastOrNull() == previous) return
        undoStack.addLast(previous)
        if (undoStack.size > limit) undoStack.removeFirst()
        redoStack.clear()
    }

    fun undo(current: String): String? {
        val value = undoStack.removeLastOrNull() ?: return null
        redoStack.addLast(current)
        return value
    }

    fun redo(current: String): String? {
        val value = redoStack.removeLastOrNull() ?: return null
        undoStack.addLast(current)
        return value
    }

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()
}

class EditorViewModel(private val container: AppContainer) : ViewModel() {

    private val histories = HashMap<String, UndoHistory>()

    private val _search = MutableStateFlow(SearchState())
    private val _collapsed = MutableStateFlow<Set<Int>>(emptySet())
    private val _message = MutableStateFlow<String?>(null)
    private val _saving = MutableStateFlow(false)
    private val _project = MutableStateFlow<Project?>(null)

    /** Bumped whenever an undo stack changes so the toolbar can react to it. */
    private val _historyRevision = MutableStateFlow(0)

    private data class Extras(
        val message: String?,
        val saving: Boolean,
        val project: Project?,
        val historyRevision: Int
    )

    val state: StateFlow<EditorUiState> = combine(
        combine(container.editorSessionStore.tabs, container.editorSessionStore.activeId) { tabs, id ->
            tabs to id
        },
        container.settingsRepository.settings,
        _search,
        _collapsed,
        combine(_message, _saving, _project, _historyRevision) { message, saving, project, revision ->
            Extras(message, saving, project, revision)
        }
    ) { tabsAndId, settings, search, collapsed, extras ->
        val (tabs, activeId) = tabsAndId
        val active = tabs.firstOrNull { it.documentId == activeId }
        EditorUiState(
            tabs = tabs,
            activeId = activeId,
            settings = settings,
            search = search,
            folds = active?.let { CodeFolding.regions(it.content.lines(), it.language) }.orEmpty(),
            collapsed = collapsed,
            problems = active?.let { detectProblems(it) }.orEmpty(),
            saving = extras.saving,
            message = extras.message,
            project = extras.project,
            canUndo = histories[activeId]?.canUndo == true,
            canRedo = histories[activeId]?.canRedo == true
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), EditorUiState())

    init {
        // The workspace can be attached or swapped from Projects while this
        // screen is alive; reading it once left saving broken with
        // "no workspace" until the app was restarted.
        viewModelScope.launch {
            combine(
                container.settingsRepository.settings,
                container.projectRepository.observeProjects()
            ) { settings, projects ->
                projects.firstOrNull { it.id == settings.activeProjectId }
                    ?: projects.firstOrNull { it.hasWorkspace }
            }.distinctUntilChanged().collect { project ->
                val previousTree = _project.value?.treeUri
                _project.value = project
                // Tabs hold document ids of one tree only, so they can never be
                // saved back into a different workspace.
                if (previousTree != null && project?.treeUri != previousTree) {
                    histories.clear()
                    container.editorSessionStore.closeAll()
                    _search.value = SearchState()
                    _collapsed.value = emptySet()
                    _historyRevision.value++
                }
            }
        }
    }

    private fun history(documentId: String): UndoHistory =
        histories.getOrPut(documentId) { UndoHistory() }

    // ----------------------------------------------------------------- tabs

    fun activate(documentId: String) = container.editorSessionStore.activate(documentId)

    fun close(documentId: String) {
        histories.remove(documentId)
        _historyRevision.value++
        container.editorSessionStore.close(documentId)
    }

    // -------------------------------------------------------------- editing

    fun onContentChange(documentId: String, newContent: String, caret: Int) {
        val tab = container.editorSessionStore.tab(documentId) ?: return
        if (tab.readOnly) return
        if (tab.content != newContent) {
            history(documentId).record(tab.content)
            _historyRevision.value++
            // Offsets collected for the old text no longer point at anything.
            if (_search.value.query.isNotEmpty()) {
                _search.value = _search.value.copy(
                    matches = findAll(newContent, _search.value.query),
                    currentIndex = 0
                )
            }
        }
        container.editorSessionStore.update(documentId) { it.copy(content = newContent, caret = caret) }
    }

    fun undo(documentId: String) {
        val tab = container.editorSessionStore.tab(documentId) ?: return
        val previous = histories[documentId]?.undo(tab.content) ?: return
        _historyRevision.value++
        container.editorSessionStore.update(documentId) {
            it.copy(content = previous, caret = it.caret.coerceIn(0, previous.length))
        }
    }

    fun redo(documentId: String) {
        val tab = container.editorSessionStore.tab(documentId) ?: return
        val next = histories[documentId]?.redo(tab.content) ?: return
        _historyRevision.value++
        container.editorSessionStore.update(documentId) {
            it.copy(content = next, caret = it.caret.coerceIn(0, next.length))
        }
    }

    fun save(documentId: String) {
        val tree = _project.value?.treeUri ?: run {
            _message.value = container.strings.get(R.string.editor_no_workspace)
            return
        }
        val tab = container.editorSessionStore.tab(documentId) ?: return
        viewModelScope.launch {
            _saving.value = true
            val ok = container.workspaceRepository.writeText(tree, documentId, tab.content)
            _saving.value = false
            if (ok) {
                container.editorSessionStore.update(documentId) { it.copy(savedContent = it.content) }
                _message.value = container.strings.get(R.string.editor_saved, tab.name)
                container.projectContextBuilder.invalidate()
            } else {
                _message.value = container.strings.get(R.string.editor_could_not_save, tab.name)
            }
        }
    }

    /** Light formatter: normalises indentation width and trims trailing space. */
    fun format(documentId: String) {
        val tab = container.editorSessionStore.tab(documentId) ?: return
        if (tab.readOnly) return
        val tabSize = state.value.settings.editorTabSize
        val formatted = tab.content.lines().joinToString("\n") { line ->
            line.replace("\t", " ".repeat(tabSize)).trimEnd()
        }.trimEnd() + "\n"
        if (formatted != tab.content) {
            history(documentId).record(tab.content)
            _historyRevision.value++
            container.editorSessionStore.update(documentId) {
                it.copy(content = formatted, caret = it.caret.coerceIn(0, formatted.length))
            }
            _message.value = container.strings.get(R.string.editor_formatted)
        }
    }

    // --------------------------------------------------------------- search

    fun toggleSearch() {
        _search.value = _search.value.copy(visible = !_search.value.visible)
        if (!_search.value.visible) _search.value = SearchState()
    }

    fun onQueryChange(query: String) {
        val content = container.editorSessionStore.tab(state.value.activeId)?.content.orEmpty()
        val matches = if (query.isBlank()) emptyList() else findAll(content, query)
        _search.value = _search.value.copy(query = query, matches = matches, currentIndex = 0)
    }

    fun onReplacementChange(value: String) {
        _search.value = _search.value.copy(replacement = value)
    }

    fun nextMatch() {
        val search = _search.value
        if (search.matches.isEmpty()) return
        _search.value = search.copy(currentIndex = (search.currentIndex + 1) % search.matches.size)
    }

    fun previousMatch() {
        val search = _search.value
        if (search.matches.isEmpty()) return
        val index = if (search.currentIndex == 0) search.matches.lastIndex else search.currentIndex - 1
        _search.value = search.copy(currentIndex = index)
    }

    fun replaceCurrent() {
        val documentId = state.value.activeId ?: return
        val tab = container.editorSessionStore.tab(documentId) ?: return
        if (tab.readOnly) return
        val search = _search.value
        if (!search.hasMatches) return
        val start = search.matches.getOrNull(search.currentIndex) ?: return
        val end = start + search.query.length
        // Guard against offsets that went stale while the document changed.
        if (start < 0 || end > tab.content.length) {
            onQueryChange(search.query)
            return
        }
        val updated = tab.content.replaceRange(start, end, search.replacement)
        history(documentId).record(tab.content)
        _historyRevision.value++
        container.editorSessionStore.update(documentId) {
            it.copy(content = updated, caret = (start + search.replacement.length).coerceIn(0, updated.length))
        }
        val matches = findAll(updated, search.query)
        _search.value = search.copy(
            matches = matches,
            // Stay where the user was instead of jumping back to the first hit.
            currentIndex = search.currentIndex.coerceIn(0, maxOf(matches.lastIndex, 0))
        )
    }

    fun replaceAll() {
        val documentId = state.value.activeId ?: return
        val tab = container.editorSessionStore.tab(documentId) ?: return
        if (tab.readOnly) return
        val search = _search.value
        if (search.query.isBlank()) return
        val replaced = search.matches.size
        // Search is case-insensitive, so the replacement has to be too, or the
        // reported count never matches what actually changed.
        val updated = tab.content.replace(search.query, search.replacement, ignoreCase = true)
        if (updated != tab.content) {
            history(documentId).record(tab.content)
            _historyRevision.value++
            container.editorSessionStore.update(documentId) {
                it.copy(content = updated, caret = it.caret.coerceIn(0, updated.length))
            }
            _message.value = container.strings.plural(R.plurals.editor_replaced, replaced)
            _search.value = search.copy(matches = findAll(updated, search.query), currentIndex = 0)
        }
    }

    private fun findAll(content: String, query: String): List<Int> {
        val result = ArrayList<Int>()
        var index = content.indexOf(query, ignoreCase = true)
        while (index >= 0 && result.size < 500) {
            result += index
            index = content.indexOf(query, index + query.length, ignoreCase = true)
        }
        return result
    }

    // --------------------------------------------------------------- folding

    fun toggleFold(startLine: Int) {
        val current = _collapsed.value
        _collapsed.value = if (startLine in current) current - startLine else current + startLine
    }

    fun consumeMessage() {
        _message.value = null
    }

    /** Cheap structural checks that catch the most common editing mistakes. */
    private fun detectProblems(tab: EditorTab): List<String> {
        if (tab.content.length > 200_000) return emptyList()
        val problems = ArrayList<String>(2)
        if (tab.language.isBraceLanguage) {
            var braces = 0
            var parens = 0
            tab.content.forEach { ch ->
                when (ch) {
                    '{' -> braces++
                    '}' -> braces--
                    '(' -> parens++
                    ')' -> parens--
                }
            }
            if (braces != 0) problems += if (braces > 0) {
                container.strings.get(R.string.editor_issue_unclosed_brace, braces)
            } else {
                container.strings.get(R.string.editor_issue_extra_brace, -braces)
            }
            if (parens != 0) problems += if (parens > 0) {
                container.strings.get(R.string.editor_issue_unclosed_paren, parens)
            } else {
                container.strings.get(R.string.editor_issue_extra_paren, -parens)
            }
        }
        return problems
    }
}
