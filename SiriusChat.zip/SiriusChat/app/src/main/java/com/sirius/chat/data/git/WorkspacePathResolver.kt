package com.sirius.chat.data.git

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Turns a SAF tree uri into a real filesystem path.
 *
 * The rest of the app never needs this: reading, writing and browsing all go
 * through `DocumentsContract`, which is both sufficient and permission-free.
 * Git is the exception — a repository is a directory of lock files, packfiles
 * and reflogs that JGit opens by path — so this is the one place that leaves
 * SAF behind.
 *
 * The mapping is only attempted for the two document ids that are actually
 * defined: `primary:relative/path` on the shared volume, and `<uuid>:path` on a
 * removable one. Anything else (a cloud provider, Downloads, a virtual tree) is
 * reported as unresolvable rather than guessed at, because a wrong path is
 * indistinguishable from an empty repository.
 */
class WorkspacePathResolver(context: Context) {

    private val appContext: Context = context.applicationContext

    /**
     * True when the process may read and write arbitrary paths in shared
     * storage. Below Android 11 the legacy write permission is enough; from 11
     * on only the all-files role can reach a `.git` directory.
     */
    fun hasFileAccess(): Boolean = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> Environment.isExternalStorageManager()
        else -> ContextCompat.checkSelfPermission(
            appContext,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    /**
     * Resolves [treeUri] to a directory, or returns null when the volume has no
     * path this process can name.
     *
     * The returned file is not checked for readability: distinguishing "not on
     * the filesystem" from "no permission yet" is the caller's decision, and
     * they need the path to explain either one.
     */
    fun resolve(treeUri: String): File? {
        val uri = runCatching { Uri.parse(treeUri) }.getOrNull() ?: return null
        val documentId = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull()
            ?: return null
        val volume = documentId.substringBefore(':', missingDelimiterValue = "")
        val relative = documentId.substringAfter(':', missingDelimiterValue = "")
        if (volume.isEmpty()) return null

        val root = when {
            volume.equals(PRIMARY, ignoreCase = true) ->
                @Suppress("DEPRECATION") Environment.getExternalStorageDirectory()

            // A removable volume is addressed by its uuid. /storage/<uuid> is
            // the mount point on every Android version that supports SAF.
            volume.matches(VOLUME_ID) -> File(STORAGE_ROOT, volume)

            else -> null
        } ?: return null

        val resolved = if (relative.isEmpty()) root else File(root, relative)
        // A document id is provider input: a traversal in it would otherwise let
        // a crafted uri point the repository outside the granted tree.
        val canonical = runCatching { resolved.canonicalFile }.getOrDefault(resolved)
        val rootCanonical = runCatching { root.canonicalFile }.getOrDefault(root)
        if (!canonical.path.startsWith(rootCanonical.path)) return null
        return canonical
    }

    private companion object {
        const val PRIMARY = "primary"
        const val STORAGE_ROOT = "/storage"

        /** Removable volume uuids look like `1234-ABCD` or a full uuid. */
        val VOLUME_ID = Regex("^[A-Za-z0-9-]{4,36}$")
    }
}
