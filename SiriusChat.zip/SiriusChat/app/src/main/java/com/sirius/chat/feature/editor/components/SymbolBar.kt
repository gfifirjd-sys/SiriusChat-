package com.sirius.chat.feature.editor.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.automirrored.rounded.KeyboardTab
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.util.rememberHaptics

/**
 * One key of the symbol bar.
 *
 * [insert] is what lands in the document and [caretOffset] where the caret ends
 * up inside it, which is how a bracket key can insert the pair and still leave
 * you typing in the middle of it.
 */
private data class SymbolKey(
    val label: String,
    val insert: String,
    val caretOffset: Int = insert.length,
    val description: String = insert
)

/**
 * The order is by reach, not by ASCII.
 *
 * Everything a phone keyboard buries two layers deep and code needs constantly
 * comes first: brackets as pairs, then the punctuation that ends a statement,
 * then operators, then the shell and template characters. A soft keyboard has no
 * Tab key at all, which is why that one is a key here rather than a setting.
 */
private val SymbolKeys: List<SymbolKey> = listOf(
    SymbolKey("()", "()", 1, "( )"),
    SymbolKey("{}", "{}", 1, "{ }"),
    SymbolKey("[]", "[]", 1, "[ ]"),
    SymbolKey("<>", "<>", 1, "< >"),
    SymbolKey("\"\"", "\"\"", 1, "\" \""),
    SymbolKey("''", "''", 1, "' '"),
    SymbolKey("(", "("),
    SymbolKey(")", ")"),
    SymbolKey("{", "{"),
    SymbolKey("}", "}"),
    SymbolKey(":", ":"),
    SymbolKey(";", ";"),
    SymbolKey(",", ","),
    SymbolKey(".", "."),
    SymbolKey("=", "="),
    SymbolKey("->", " -> "),
    SymbolKey("==", " == "),
    SymbolKey("!", "!"),
    SymbolKey("?", "?"),
    SymbolKey("&", "&"),
    SymbolKey("|", "|"),
    SymbolKey("+", "+"),
    SymbolKey("-", "-"),
    SymbolKey("*", "*"),
    SymbolKey("/", "/"),
    SymbolKey("%", "%"),
    SymbolKey("_", "_"),
    SymbolKey("$", "$"),
    SymbolKey("#", "#"),
    SymbolKey("@", "@"),
    SymbolKey("\\", "\\"),
    SymbolKey("~", "~"),
    SymbolKey("^", "^"),
    SymbolKey("`", "`")
)

/**
 * Quick symbols, docked above the keyboard.
 *
 * It sits under [imePadding] so it rides the keyboard rather than being covered
 * by it — a symbol row hidden behind the IME is worse than no symbol row, because
 * it also steals the space the document needed. Tab inserts the project's own
 * indent width instead of a literal tab: the formatter normalises tabs to spaces
 * anyway, so inserting one would only create a diff that the next save undoes.
 */
@Composable
fun SymbolBar(
    onInsert: (String, Int) -> Unit,
    onBackspace: () -> Unit,
    tabSize: Int,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()

    LazyRow(
        modifier = modifier
            .fillMaxWidth()
            .imePadding()
            .padding(horizontal = SiriusSpacing.sm)
            .glassSurface(shape = RoundedCornerShape(SiriusRadius.md), elevation = 8.dp),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        item(key = "tab") {
            SymbolIconKey(
                description = stringResource(R.string.editor_symbol_tab),
                onClick = {
                    haptics.light()
                    val indent = " ".repeat(tabSize.coerceIn(2, 8))
                    onInsert(indent, indent.length)
                }
            ) {
                Icon(
                    Icons.AutoMirrored.Rounded.KeyboardTab,
                    contentDescription = null,
                    tint = colors.textSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        items(SymbolKeys, key = { it.label }) { key ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(SiriusRadius.sm))
                    .softSurface(shape = RoundedCornerShape(SiriusRadius.sm))
                    // 40dp of target under a 14dp glyph: a mis-tapped symbol in an
                    // editor is a syntax error the user has to hunt for later.
                    .sizeIn(minWidth = 40.dp, minHeight = 40.dp)
                    .clickable(
                        role = Role.Button,
                        onClickLabel = key.description
                    ) {
                        haptics.light()
                        onInsert(key.insert, key.caretOffset)
                    }
                    .padding(horizontal = 8.dp)
                    .semantics { contentDescription = key.description },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = key.label,
                    style = codeTextStyle(14),
                    color = colors.textPrimary
                )
            }
        }

        item(key = "backspace") {
            SymbolIconKey(
                description = stringResource(R.string.editor_symbol_backspace),
                onClick = {
                    haptics.light()
                    onBackspace()
                }
            ) {
                Icon(
                    Icons.AutoMirrored.Rounded.Backspace,
                    contentDescription = null,
                    tint = colors.textSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun SymbolIconKey(
    description: String,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(SiriusRadius.sm))
            .softSurface(shape = RoundedCornerShape(SiriusRadius.sm))
            .sizeIn(minWidth = 44.dp, minHeight = 40.dp)
            .clickable(role = Role.Button, onClickLabel = description, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
