package com.sirius.chat.core.util

/** Structural pieces the chat renderer understands. */
sealed interface MarkdownBlock {
    data class Paragraph(val text: String) : MarkdownBlock
    data class Heading(val level: Int, val text: String) : MarkdownBlock
    data class Code(val language: CodeLanguage, val tag: String, val code: String, val complete: Boolean) : MarkdownBlock
    data class ListBlock(val items: List<ListItem>, val ordered: Boolean) : MarkdownBlock
    data class Quote(val text: String) : MarkdownBlock
    data class Table(val header: List<String>, val rows: List<List<String>>, val aligns: List<ColumnAlign>) : MarkdownBlock
    data class Math(val latex: String) : MarkdownBlock
    data class Progress(val rows: List<ProgressRow>) : MarkdownBlock
    data class Tree(val lines: List<TreeLine>) : MarkdownBlock
    data object Divider : MarkdownBlock
}

/**
 * A list row. [depth] is the nesting level and [ordinal] the number to print for
 * ordered lists — kept from the source rather than recomputed, so `1. 1. 1.` and
 * `1. 2. 3.` both render the way the author wrote them. [checked] is null for a
 * plain bullet and non-null for a task list, which is what lets one list mix
 * prose items and checkboxes.
 */
data class ListItem(
    val text: String,
    val depth: Int,
    val ordinal: Int? = null,
    val checked: Boolean? = null
)

enum class ColumnAlign { Start, Center, End }

/** One bar in a ```progress block. [fraction] is already clamped to 0..1. */
data class ProgressRow(val label: String, val fraction: Float, val caption: String)

/**
 * One line of a ```tree block. [last] drives the box-drawing glyph, and
 * [ancestorsLast] tells the renderer which vertical guides to keep drawing at
 * shallower depths — without it, deep trees lose their connecting lines.
 */
data class TreeLine(
    val depth: Int,
    val name: String,
    val directory: Boolean,
    val last: Boolean,
    val ancestorsLast: List<Boolean>
)

/**
 * Streaming-friendly markdown splitter: an unterminated code fence is still
 * emitted (marked incomplete) so tokens appear as they arrive instead of the
 * block popping into existence at the end. The same tolerance applies to the
 * richer blocks — a half-typed table renders as far as its rows go.
 *
 * Beyond CommonMark this understands three things the assistant is told about in
 * the system prompt: `$$…$$` math, ```progress bars and ```tree listings. They
 * exist because an agent that edits projects constantly reports *proportions*
 * and *file layouts*, and both are unreadable as plain text in a chat bubble.
 */
object MarkdownParser {

    fun parse(markdown: String): List<MarkdownBlock> {
        val blocks = ArrayList<MarkdownBlock>()
        val lines = markdown.lines()
        var index = 0
        val paragraph = StringBuilder()

        fun flushParagraph() {
            val text = paragraph.toString().trim()
            if (text.isNotEmpty()) blocks += MarkdownBlock.Paragraph(text)
            paragraph.setLength(0)
        }

        while (index < lines.size) {
            val line = lines[index]
            val trimmed = line.trimStart()

            when {
                trimmed.startsWith("```") -> {
                    flushParagraph()
                    val tag = trimmed.removePrefix("```").trim()
                    val body = ArrayList<String>()
                    index++
                    var complete = false
                    while (index < lines.size) {
                        if (lines[index].trimStart().startsWith("```")) {
                            complete = true
                            index++
                            break
                        }
                        body += lines[index]
                        index++
                    }
                    blocks += when (tag.lowercase()) {
                        "progress" -> MarkdownBlock.Progress(parseProgress(body))
                        "tree" -> MarkdownBlock.Tree(parseTree(body))
                        else -> MarkdownBlock.Code(
                            language = CodeLanguages.fromTag(tag),
                            tag = tag,
                            code = body.joinToString("\n").trimEnd('\n'),
                            complete = complete
                        )
                    }
                }

                // Display math. Either fully inline on one line ($$x$$) or fenced
                // across several, which is how anything with a fraction arrives.
                trimmed.startsWith("$$") -> {
                    flushParagraph()
                    val single = trimmed.length > 4 && trimmed.endsWith("$$")
                    if (single) {
                        blocks += MarkdownBlock.Math(trimmed.removeSurrounding("$$").trim())
                        index++
                    } else {
                        val latex = StringBuilder()
                        index++
                        while (index < lines.size && !lines[index].trimStart().startsWith("$$")) {
                            latex.appendLine(lines[index])
                            index++
                        }
                        if (index < lines.size) index++
                        blocks += MarkdownBlock.Math(latex.toString().trim())
                    }
                }

                trimmed.startsWith("#") && trimmed.takeWhile { it == '#' }.length <= 6 &&
                    trimmed.dropWhile { it == '#' }.startsWith(" ") -> {
                    flushParagraph()
                    val level = trimmed.takeWhile { it == '#' }.length
                    blocks += MarkdownBlock.Heading(level, trimmed.drop(level).trim())
                    index++
                }

                trimmed.startsWith("> ") -> {
                    flushParagraph()
                    val quote = StringBuilder()
                    while (index < lines.size && lines[index].trimStart().startsWith(">")) {
                        quote.appendLine(lines[index].trimStart().removePrefix(">").trim())
                        index++
                    }
                    blocks += MarkdownBlock.Quote(quote.toString().trim())
                }

                trimmed == "---" || trimmed == "***" || trimmed == "___" -> {
                    flushParagraph()
                    blocks += MarkdownBlock.Divider
                    index++
                }

                // A table is only a table once the delimiter row confirms it;
                // otherwise a sentence containing a pipe would become one.
                isTableRow(trimmed) && index + 1 < lines.size && isTableDelimiter(lines[index + 1]) -> {
                    flushParagraph()
                    val header = splitRow(trimmed)
                    val aligns = parseAligns(lines[index + 1])
                    index += 2
                    val rows = ArrayList<List<String>>()
                    while (index < lines.size && isTableRow(lines[index].trimStart())) {
                        rows += splitRow(lines[index].trimStart())
                        index++
                    }
                    blocks += MarkdownBlock.Table(header, rows, aligns)
                }

                isBullet(trimmed) || isOrdered(trimmed) -> {
                    flushParagraph()
                    val ordered = isOrdered(trimmed)
                    val items = ArrayList<ListItem>()
                    while (index < lines.size) {
                        val raw = lines[index]
                        val candidate = raw.trimStart()
                        // A nested ordered list inside a bulleted one (and the
                        // reverse) stays in the same block: splitting them would
                        // reset the indent and break the visual hierarchy.
                        if (!isBullet(candidate) && !isOrdered(candidate)) break
                        val depth = indentDepth(raw)
                        if (isOrdered(candidate)) {
                            val number = candidate.substringBefore('.').trim().toIntOrNull()
                            items += ListItem(
                                text = candidate.substringAfter('.').trim(),
                                depth = depth,
                                ordinal = number
                            )
                        } else {
                            val content = candidate.drop(2).trim()
                            val task = taskState(content)
                            items += ListItem(
                                text = if (task == null) content else content.drop(3).trim(),
                                depth = depth,
                                checked = task
                            )
                        }
                        index++
                    }
                    blocks += MarkdownBlock.ListBlock(items, ordered)
                }

                trimmed.isEmpty() -> {
                    flushParagraph()
                    index++
                }

                else -> {
                    paragraph.appendLine(line)
                    index++
                }
            }
        }
        flushParagraph()
        return blocks
    }

    private fun isBullet(line: String): Boolean =
        line.startsWith("- ") || line.startsWith("* ") || line.startsWith("+ ")

    private fun isOrdered(line: String): Boolean = Regex("^\\d+\\.\\s").containsMatchIn(line)

    /** `- [x] ` / `- [ ] ` -> true / false, anything else -> null. */
    private fun taskState(content: String): Boolean? = when {
        content.startsWith("[x] ", ignoreCase = true) -> true
        content.startsWith("[ ] ") -> false
        else -> null
    }

    /** Two spaces or one tab per level, capped so pathological input can't run off screen. */
    private fun indentDepth(raw: String): Int {
        var spaces = 0
        for (ch in raw) {
            when (ch) {
                ' ' -> spaces++
                '\t' -> spaces += 2
                else -> return (spaces / 2).coerceAtMost(4)
            }
        }
        return 0
    }

    private fun isTableRow(line: String): Boolean = line.startsWith("|") && line.count { it == '|' } >= 2

    private fun isTableDelimiter(line: String): Boolean {
        val body = line.trim()
        if (!body.startsWith("|")) return false
        val cells = splitRow(body)
        return cells.isNotEmpty() && cells.all { cell ->
            val c = cell.trim()
            c.length >= 3 && c.all { it == '-' || it == ':' } && c.contains('-')
        }
    }

    private fun splitRow(line: String): List<String> =
        line.trim().trim('|').split('|').map { it.trim() }

    private fun parseAligns(delimiter: String): List<ColumnAlign> =
        splitRow(delimiter).map { cell ->
            val c = cell.trim()
            when {
                c.startsWith(':') && c.endsWith(':') -> ColumnAlign.Center
                c.endsWith(':') -> ColumnAlign.End
                else -> ColumnAlign.Start
            }
        }

    /**
     * `label: 62%`, `label 0.62` or a bare `62%`. Percent and fraction are both
     * accepted because models write both, and guessing wrong turns a 62% bar
     * into a full one.
     */
    private fun parseProgress(body: List<String>): List<ProgressRow> = body
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .map { raw ->
            val label = raw.substringBeforeLast(' ', "").trim().trimEnd(':').trim()
            val value = raw.substringAfterLast(' ').trim()
            val percent = value.endsWith("%")
            val number = value.trimEnd('%').toFloatOrNull()
            val fraction = when {
                number == null -> 0f
                percent -> number / 100f
                number > 1f -> number / 100f
                else -> number
            }
            ProgressRow(
                label = label,
                fraction = fraction.coerceIn(0f, 1f),
                caption = if (number == null) "" else "${(fraction * 100).toInt()}%"
            )
        }

    /**
     * Indented listing -> tree lines. The last-child flags are resolved in a
     * second pass, because whether a node is last is only knowable once the
     * following lines have been read.
     */
    private fun parseTree(body: List<String>): List<TreeLine> {
        data class Raw(val depth: Int, val name: String)

        val raws = body
            .filter { it.isNotBlank() }
            .map { line ->
                val depth = indentDepth(line)
                Raw(depth, line.trim().trimStart('|', '-', '`').trim())
            }
            .filter { it.name.isNotEmpty() }

        val lastAtDepth = BooleanArray(6)
        val result = ArrayList<TreeLine>(raws.size)
        raws.forEachIndexed { i, raw ->
            val next = raws.drop(i + 1).firstOrNull { it.depth <= raw.depth }
            val isLast = next == null || next.depth < raw.depth
            if (raw.depth < lastAtDepth.size) lastAtDepth[raw.depth] = isLast
            result += TreeLine(
                depth = raw.depth,
                name = raw.name.trimEnd('/'),
                directory = raw.name.endsWith("/"),
                last = isLast,
                ancestorsLast = (0 until raw.depth).map { lastAtDepth.getOrElse(it) { true } }
            )
        }
        return result
    }
}
