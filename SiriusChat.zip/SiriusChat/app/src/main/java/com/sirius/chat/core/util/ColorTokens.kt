package com.sirius.chat.core.util

import androidx.compose.ui.graphics.Color
import kotlin.math.abs
import kotlin.math.pow

/**
 * Recognises colour literals in assistant text so the renderer can put a real
 * swatch next to them.
 *
 * A hex triplet in a chat bubble is unreadable — `#3B82F6` and `#3B82F9` look
 * identical, and no amount of syntax highlighting fixes that. Since Sirius is
 * used to build interfaces, colours come up constantly, so every literal it
 * knows how to parse gets a 14dp chip rendered inline.
 *
 * All four CSS-era notations are supported, including `oklch()`, because that is
 * what current design tooling emits and it is the one notation a human cannot
 * eyeball at all.
 */
object ColorTokens {

    data class Match(val range: IntRange, val color: Color, val text: String)

    private val hex = Regex("#([0-9a-fA-F]{3,8})\\b")
    private val functional = Regex(
        "\\b(rgba?|hsla?|oklch)\\(\\s*([^)]{3,64})\\)",
        RegexOption.IGNORE_CASE
    )

    /** Every colour literal in [text], in source order, non-overlapping. */
    fun findAll(text: String): List<Match> {
        val found = ArrayList<Match>()
        hex.findAll(text).forEach { m ->
            parse(m.value)?.let { found += Match(m.range, it, m.value) }
        }
        functional.findAll(text).forEach { m ->
            parse(m.value)?.let { found += Match(m.range, it, m.value) }
        }
        found.sortBy { it.range.first }
        // Guard against a hex literal sitting inside an rgb() argument list.
        val result = ArrayList<Match>(found.size)
        var cursor = -1
        for (match in found) {
            if (match.range.first > cursor) {
                result += match
                cursor = match.range.last
            }
        }
        return result
    }

    /** Parses a single literal, or returns null if it is not a colour. */
    fun parse(raw: String): Color? {
        val token = raw.trim()
        return when {
            token.startsWith("#") -> parseHex(token)
            else -> parseFunctional(token)
        }
    }

    private fun parseHex(token: String): Color? {
        val body = token.removePrefix("#")
        if (body.any { !it.isHexDigit() }) return null
        return when (body.length) {
            3, 4 -> {
                // #abc and #abcd expand by digit duplication, not by zero padding.
                val expanded = body.map { "$it$it" }.joinToString("")
                parseHex("#$expanded")
            }
            6 -> Color(0xFF000000L.toInt() or body.toLong(16).toInt())
            8 -> {
                val value = body.toLong(16)
                // CSS writes #RRGGBBAA; Compose wants alpha first.
                val alpha = (value and 0xFF).toInt()
                val rgb = (value ushr 8).toInt()
                Color((alpha shl 24) or rgb)
            }
            else -> null
        }
    }

    private fun parseFunctional(token: String): Color? {
        val open = token.indexOf('(')
        if (open <= 0 || !token.endsWith(")")) return null
        val name = token.substring(0, open).trim().lowercase()
        val args = token.substring(open + 1, token.length - 1)
            .replace(',', ' ')
            .replace("/", " ")
            .split(' ')
            .filter { it.isNotBlank() }
        if (args.size < 3) return null

        fun channel(index: Int, scale: Float): Float? {
            val a = args.getOrNull(index)?.trim() ?: return null
            val percent = a.endsWith("%")
            val v = a.trimEnd('%').toFloatOrNull() ?: return null
            return if (percent) v / 100f else v / scale
        }

        val alpha = args.getOrNull(3)?.let { a ->
            val percent = a.endsWith("%")
            a.trimEnd('%').toFloatOrNull()?.let { if (percent) it / 100f else it }
        } ?: 1f

        return when (name) {
            "rgb", "rgba" -> {
                val r = channel(0, 255f) ?: return null
                val g = channel(1, 255f) ?: return null
                val b = channel(2, 255f) ?: return null
                Color(r.coerceIn(0f, 1f), g.coerceIn(0f, 1f), b.coerceIn(0f, 1f), alpha.coerceIn(0f, 1f))
            }
            "hsl", "hsla" -> {
                val h = args[0].trimEnd('%').removeSuffix("deg").toFloatOrNull() ?: return null
                val s = channel(1, 100f) ?: return null
                val l = channel(2, 100f) ?: return null
                hslToColor(h, s.coerceIn(0f, 1f), l.coerceIn(0f, 1f), alpha.coerceIn(0f, 1f))
            }
            "oklch" -> {
                val l = channel(0, 1f) ?: return null
                val c = args[1].toFloatOrNull() ?: return null
                val h = args[2].removeSuffix("deg").toFloatOrNull() ?: return null
                oklchToColor(l, c, h, alpha.coerceIn(0f, 1f))
            }
            else -> null
        }
    }

    private fun hslToColor(hue: Float, s: Float, l: Float, alpha: Float): Color {
        val h = ((hue % 360f) + 360f) % 360f
        val c = (1f - abs(2f * l - 1f)) * s
        val x = c * (1f - abs((h / 60f) % 2f - 1f))
        val m = l - c / 2f
        val (r, g, b) = when {
            h < 60f -> Triple(c, x, 0f)
            h < 120f -> Triple(x, c, 0f)
            h < 180f -> Triple(0f, c, x)
            h < 240f -> Triple(0f, x, c)
            h < 300f -> Triple(x, 0f, c)
            else -> Triple(c, 0f, x)
        }
        return Color(
            (r + m).coerceIn(0f, 1f),
            (g + m).coerceIn(0f, 1f),
            (b + m).coerceIn(0f, 1f),
            alpha
        )
    }

    /** OKLCh -> Oklab -> linear sRGB -> gamma-encoded sRGB. */
    private fun oklchToColor(lightness: Float, chroma: Float, hue: Float, alpha: Float): Color {
        val hRad = hue * Math.PI.toFloat() / 180f
        val a = chroma * kotlin.math.cos(hRad)
        val bb = chroma * kotlin.math.sin(hRad)

        val lp = lightness + 0.3963377774f * a + 0.2158037573f * bb
        val mp = lightness - 0.1055613458f * a - 0.0638541728f * bb
        val sp = lightness - 0.0894841775f * a - 1.2914855480f * bb

        val l3 = lp * lp * lp
        val m3 = mp * mp * mp
        val s3 = sp * sp * sp

        val r = 4.0767416621f * l3 - 3.3077115913f * m3 + 0.2309699292f * s3
        val g = -1.2684380046f * l3 + 2.6097574011f * m3 - 0.3413193965f * s3
        val b = -0.0041960863f * l3 - 0.7034186147f * m3 + 1.7076147010f * s3

        return Color(
            gamma(r).coerceIn(0f, 1f),
            gamma(g).coerceIn(0f, 1f),
            gamma(b).coerceIn(0f, 1f),
            alpha
        )
    }

    private fun gamma(linear: Float): Float =
        if (linear <= 0.0031308f) 12.92f * linear else 1.055f * linear.pow(1f / 2.4f) - 0.055f

    private fun Char.isHexDigit(): Boolean =
        this in '0'..'9' || this in 'a'..'f' || this in 'A'..'F'
}
