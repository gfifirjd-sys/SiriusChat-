package com.sirius.chat.ai.provider

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.streaming.SseParser
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.ProviderConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.job
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Anthropic Messages API. The wire format differs enough from OpenAI (system
 * prompt is a top level field, deltas arrive as typed events) to justify its
 * own implementation rather than a shared adapter full of conditionals.
 */
class AnthropicProvider(
    private val config: ProviderConfig,
    private val apiKey: String?,
    private val client: OkHttpClient = HttpClientProvider.client
) : AiProvider {

    override val id: String = config.id
    override val label: String = config.label
    override val models: List<AiModel> = config.models

    private val json = Json { ignoreUnknownKeys = true }

    override fun chat(request: ChatRequest): Flow<ChatStreamEvent> = flow {
        emit(ChatStreamEvent.Started)

        // Anthropic requires alternating user/assistant turns starting with user.
        val normalised = normaliseTurns(request)

        val payload = buildJsonObject {
            put("model", request.model)
            put("max_tokens", request.params.maxTokens)
            put("temperature", request.params.temperature)
            put("stream", request.stream)
            request.systemPrompt?.takeIf { it.isNotBlank() }?.let { put("system", it) }
            putJsonArray("messages") {
                normalised.forEach { message ->
                    add(buildJsonObject {
                        put("role", if (message.role == AiRole.Assistant) "assistant" else "user")
                        putJsonArray("content") {
                            add(buildJsonObject {
                                put("type", "text")
                                put("text", message.content)
                            })
                        }
                    })
                }
            }
        }

        val httpRequest = Request.Builder()
            .url(config.baseUrl.trimEnd('/') + "/messages")
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .apply {
                header("Content-Type", "application/json")
                header("anthropic-version", ANTHROPIC_VERSION)
                if (!apiKey.isNullOrBlank()) header("x-api-key", apiKey)
                if (request.stream) header("Accept", "text/event-stream")
            }
            .build()

        val call = client.newCall(httpRequest)
        currentCoroutineContext().job.invokeOnCompletion { if (!call.isCanceled()) call.cancel() }

        val response = runCatching { call.execute() }.getOrElse { error ->
            emit(ChatStreamEvent.Failure(error.toAiError()))
            return@flow
        }

        response.use { httpResponse ->
            if (!httpResponse.isSuccessful) {
                val body = runCatching { httpResponse.body?.string() }.getOrNull().orEmpty()
                emit(ChatStreamEvent.Failure(httpError(httpResponse.code, body)))
                return@flow
            }
            val source = httpResponse.body?.source()
            if (source == null) {
                emit(
                    ChatStreamEvent.Failure(
                        AiError(
                            AiError.Kind.Server,
                            AppStrings.get(R.string.error_empty_body, fallback = "Empty response body")
                        )
                    )
                )
                return@flow
            }

            val builder = StringBuilder()
            var stopReason: String? = null

            if (!request.stream) {
                val text = source.readUtf8()
                val root = runCatching { json.parseToJsonElement(text).jsonObject }.getOrNull()
                val content = (root?.get("content") as? JsonArray)
                    ?.mapNotNull { it.jsonObject["text"]?.jsonPrimitive?.contentOrNull }
                    ?.joinToString("")
                    .orEmpty()
                stopReason = root?.get("stop_reason")?.jsonPrimitive?.contentOrNull
                if (content.isNotEmpty()) {
                    builder.append(content)
                    emit(ChatStreamEvent.Delta(content))
                }
            } else {
                SseParser.read(source) { event ->
                    val parsed = runCatching { json.parseToJsonElement(event.data).jsonObject }.getOrNull()
                    when (parsed?.get("type")?.jsonPrimitive?.contentOrNull) {
                        "content_block_delta" -> {
                            val chunk = parsed["delta"]?.jsonObject
                                ?.get("text")?.jsonPrimitive?.contentOrNull
                            if (!chunk.isNullOrEmpty()) {
                                builder.append(chunk)
                                emit(ChatStreamEvent.Delta(chunk))
                            }
                        }
                        "message_delta" -> {
                            stopReason = parsed["delta"]?.jsonObject
                                ?.get("stop_reason")?.jsonPrimitive?.contentOrNull ?: stopReason
                        }
                        "error" -> {
                            val message = parsed["error"]?.jsonObject
                                ?.get("message")?.jsonPrimitive?.contentOrNull
                            emit(
                                ChatStreamEvent.Failure(
                                    AiError(
                                        AiError.Kind.Server,
                                        message ?: AppStrings.get(
                                            R.string.error_provider,
                                            fallback = "Provider error"
                                        )
                                    )
                                )
                            )
                            return@read false
                        }
                    }
                    true
                }
            }

            emit(ChatStreamEvent.Completed(stopReason, builder.toString()))
        }
    }.flowOn(Dispatchers.IO)

    private fun normaliseTurns(request: ChatRequest): List<AiMessage> = buildList<AiMessage> {
        var expectUser = true
        request.messages.filter { it.role != AiRole.System }.forEach { message ->
            val isUser = message.role == AiRole.User
            if (isUser == expectUser) {
                add(message)
                expectUser = !expectUser
            } else if (isNotEmpty()) {
                // Merge consecutive same-role turns instead of dropping content.
                val last = removeAt(lastIndex)
                add(last.copy(content = last.content + "\n\n" + message.content))
            } else if (isUser) {
                add(message)
                expectUser = false
            }
        }
        if (isEmpty() || last().role == AiRole.Assistant) {
            // The API requires the conversation to end with a user turn.
            if (isNotEmpty()) removeAt(lastIndex)
        }
    }

    private companion object {
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        const val ANTHROPIC_VERSION = "2023-06-01"
    }
}
