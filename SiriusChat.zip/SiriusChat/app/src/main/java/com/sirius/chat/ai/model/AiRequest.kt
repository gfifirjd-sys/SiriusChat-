package com.sirius.chat.ai.model

import com.sirius.chat.domain.model.GenerationParams

/** Provider-neutral message. */
data class AiMessage(
    val role: AiRole,
    val content: String
)

enum class AiRole { System, User, Assistant }

data class ChatRequest(
    val model: String,
    val messages: List<AiMessage>,
    val systemPrompt: String? = null,
    val params: GenerationParams = GenerationParams(),
    val stream: Boolean = true
)

/** Everything a provider can emit while answering. */
sealed interface ChatStreamEvent {
    data object Started : ChatStreamEvent
    data class Delta(val text: String) : ChatStreamEvent
    data class Completed(val finishReason: String?, val fullText: String) : ChatStreamEvent
    data class Failure(val error: AiError) : ChatStreamEvent
}

/** Normalised error so the UI can react without knowing the provider. */
data class AiError(
    val kind: Kind,
    val message: String,
    val statusCode: Int? = null
) {
    enum class Kind { Network, Unauthorized, RateLimited, BadRequest, Server, Cancelled, Unknown }

    val isRetryable: Boolean
        get() = kind == Kind.Network || kind == Kind.RateLimited || kind == Kind.Server
}
