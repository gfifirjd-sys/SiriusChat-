package com.sirius.chat.core.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext

/**
 * Sends the user to the all-files access page and reports back when they return.
 *
 * There is no permission dialog for `MANAGE_EXTERNAL_STORAGE`: the only way to
 * get it is a settings screen the user has to toggle themselves. The result of
 * the launch says nothing about the outcome — the system returns
 * `RESULT_CANCELED` either way — so the caller re-checks the permission instead
 * of trusting a result code.
 *
 * On Android 10 and below the role does not exist and the legacy write
 * permission is requested instead.
 */
@Composable
fun rememberAllFilesAccessRequest(onReturned: () -> Unit): () -> Unit {
    val context = LocalContext.current
    val callback = rememberUpdatedState(onReturned)

    val settingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { callback.value() }

    val legacyLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { callback.value() }

    val packageName = remember(context) { context.packageName }

    return remember(packageName) {
        {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // The per-app page is missing on some builds. Package visibility
                // rules make `resolveActivity` unreliable for settings intents,
                // so the fallback is driven by the launch actually failing.
                val direct = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                runCatching { settingsLauncher.launch(direct) }.onFailure {
                    runCatching {
                        settingsLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                    }
                }
            } else {
                legacyLauncher.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
            Unit
        }
    }
}
