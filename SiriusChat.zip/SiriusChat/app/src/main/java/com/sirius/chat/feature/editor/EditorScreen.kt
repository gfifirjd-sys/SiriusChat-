package com.sirius.chat.feature.editor

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.FormatAlignLeft
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.automirrored.rounded.WrapText
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.EmptyState
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.designsystem.touchTarget
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.data.repository.EditorTab
import com.sirius.chat.feature.editor.components.CodeEditorField
import com.sirius.chat.feature.editor.components.EditorMatches
import com.sirius.chat.feature.editor.components.SymbolBar
import com.sirius.chat.feature.editor.components.rememberCodeEditorController
import com.sirius.chat.feature.editor.components.CodeViewer

@Composable
fun EditorScreen(
    onBack: () -> Unit,
    onOpenFiles: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: EditorViewModel = siriusViewModel { EditorViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    var viewMode by remember { mutableStateOf(false) }
    var wrapOverride by remember { mutableStateOf<Boolean?>(null) }
    // Remembered across tab switches on purpose: a user who wants brackets in
    // reach wants them in every file, not in the one they happened to open.
    var symbolsVisible by rememberSaveable { mutableStateOf(true) }

    val active = state.active
    val wordWrap = wrapOverride ?: state.settings.editorWordWrap

    // Keyed on the document: switching tabs must not carry a caret from the file
    // that was open before into the one that just became active.
    val controller = rememberCodeEditorController(active?.documentId.orEmpty())

    // Huge files open in the fast read-only viewer by default. Per-tab overrides must
    // not leak into the next tab the user opens.
    LaunchedEffect(active?.documentId, active?.readOnly) {
        viewMode = active?.readOnly == true
        wrapOverride = null
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = active?.name ?: stringResource(R.string.editor_title),
            subtitle = active?.let {
                val dirtyLabel = stringResource(R.string.editor_unsaved)
                // "Plain text" is a real word; every other language name is a proper noun.
                val languageLabel = it.language.labelRes
                    ?.let { res -> stringResource(res) }
                    ?: it.language.displayName
                buildString {
                    append(languageLabel)
                    append(" \u00B7 ")
                    append(Formatters.fileSize(it.sizeBytes))
                    if (it.dirty) append(" \u00B7 $dirtyLabel")
                }
            },
            // Code runs edge to edge under the chrome, so the bar keeps its seam
            // whenever there is a document behind it.
            scrolled = state.tabs.isNotEmpty(),
            onBack = onBack,
            actions = {
                GlassIconButton(
                    icon = if (viewMode) Icons.Rounded.Edit else Icons.Rounded.Visibility,
                    contentDescription = if (viewMode) stringResource(R.string.chat_action_edit)
                    else stringResource(R.string.editor_read_mode),
                    // Read-only tabs can never leave the viewer.
                    enabled = active != null && !active.readOnly,
                    onClick = { viewMode = !viewMode }
                )
                GlassIconButton(
                    icon = Icons.Rounded.Search,
                    contentDescription = stringResource(R.string.editor_find),
                    highlighted = state.search.visible,
                    enabled = active != null,
                    onClick = viewModel::toggleSearch
                )
                GlassIconButton(
                    icon = Icons.Rounded.Save,
                    contentDescription = stringResource(R.string.action_save),
                    highlighted = active?.dirty == true,
                    busy = state.saving,
                    enabled = active != null && active.dirty && !state.saving,
                    onClick = { active?.let { viewModel.save(it.documentId) } }
                )
            }
        )

        if (state.tabs.isEmpty()) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                EmptyState(
                    icon = Icons.Rounded.Code,
                    title = stringResource(R.string.editor_empty_title),
                    message = stringResource(R.string.editor_empty_message),
                    actionLabel = stringResource(R.string.editor_browse_files),
                    onAction = onOpenFiles
                )
            }
        } else {
            EditorTabStrip(
                tabs = state.tabs,
                activeId = state.activeId,
                onSelect = viewModel::activate,
                onClose = viewModel::close
            )

            AnimatedVisibility(visible = state.search.visible) {
                FindReplaceBar(
                    query = state.search.query,
                    replacement = state.search.replacement,
                    currentIndex = state.search.currentIndex,
                    matchCount = state.search.matches.size,
                    onQueryChange = viewModel::onQueryChange,
                    onReplacementChange = viewModel::onReplacementChange,
                    onNext = viewModel::nextMatch,
                    onPrevious = viewModel::previousMatch,
                    onReplace = viewModel::replaceCurrent,
                    onReplaceAll = viewModel::replaceAll
                )
            }

            Box(modifier = Modifier.weight(1f)) {
                active?.let { tab ->
                    if (viewMode || tab.readOnly) {
                        CodeViewer(
                            content = tab.content,
                            language = tab.language,
                            fontSize = state.settings.editorFontSize,
                            showLineNumbers = state.settings.editorLineNumbers,
                            folds = state.folds,
                            collapsed = state.collapsed,
                            onToggleFold = viewModel::toggleFold
                        )
                    } else {
                        CodeEditorField(
                            documentId = tab.documentId,
                            content = tab.content,
                            language = tab.language,
                            fontSize = state.settings.editorFontSize,
                            showLineNumbers = state.settings.editorLineNumbers,
                            wordWrap = wordWrap,
                            readOnly = tab.readOnly,
                            onContentChange = { text, caret ->
                                viewModel.onContentChange(tab.documentId, text, caret)
                            },
                            controller = controller,
                            // Highlighting every hit and selecting the current one is
                            // what turns the find bar from a counter into navigation.
                            matches = EditorMatches(
                                offsets = state.search.matches,
                                length = state.search.query.length,
                                current = if (state.search.visible) state.search.currentIndex else -1
                            )
                        )
                    }
                }
            }

            // Only in edit mode: a symbol row above a read-only viewer would be a
            // keyboard for a document that cannot take one.
            val editing = active != null && !viewMode && active.readOnly.not()
            AnimatedVisibility(visible = editing && symbolsVisible) {
                SymbolBar(
                    onInsert = { text, caretOffset -> controller.insert(text, caretOffset) },
                    onBackspace = controller::backspace,
                    tabSize = state.settings.editorTabSize
                )
            }

            EditorToolbar(
                canUndo = state.canUndo,
                canRedo = state.canRedo,
                wordWrap = wordWrap,
                symbolsVisible = symbolsVisible,
                symbolsEnabled = editing,
                problems = state.problems,
                onUndo = { state.activeId?.let(viewModel::undo) },
                onRedo = { state.activeId?.let(viewModel::redo) },
                onFormat = { state.activeId?.let(viewModel::format) },
                onToggleWrap = { wrapOverride = !wordWrap },
                onToggleSymbols = { symbolsVisible = !symbolsVisible },
                modifier = Modifier.padding(bottom = contentPadding.calculateBottomPadding())
            )
        }
    }

    MessageToast(
        message = state.message,
        bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
    )

    LaunchedEffect(state.message) {
        if (state.message != null) {
            kotlinx.coroutines.delay(2200)
            viewModel.consumeMessage()
        }
    }
}

/**
 * The open documents, as a row of milled tabs.
 *
 * Three things make this strip work on a phone: the active tab is scrolled into
 * view whenever it changes (opening a file from Files used to select a tab that
 * was off-screen), each tab reports itself as a selected tab to assistive tech,
 * and the close affordance keeps a real 40dp target even though its ink is
 * 14dp — a mis-tapped close in an editor costs the user their place.
 */
@Composable
private fun EditorTabStrip(
    tabs: List<EditorTab>,
    activeId: String?,
    onSelect: (String) -> Unit,
    onClose: (String) -> Unit
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val listState = rememberLazyListState()
    val unsavedLabel = stringResource(R.string.editor_tab_unsaved)

    LaunchedEffect(activeId, tabs.size) {
        val index = tabs.indexOfFirst { it.documentId == activeId }
        if (index >= 0) listState.animateScrollToItem(index)
    }

    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SiriusSpacing.sm),
        state = listState,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(tabs, key = { it.documentId }) { tab ->
            val selected = tab.documentId == activeId
            val shape = RoundedCornerShape(SiriusRadius.sm)
            val labelColor by animateColorAsState(
                targetValue = if (selected) colors.primary else colors.textSecondary,
                animationSpec = siriusTween(SiriusMotion.Quick),
                label = "tabTint"
            )
            val scale by animateFloatAsState(
                targetValue = if (selected) 1f else 0.97f,
                animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
                label = "tabScale"
            )
            // A tab that has just been opened should slide into the strip rather
            // than have the whole row jump a slot.
            Row(
                modifier = Modifier
                    .animateItem()
                    .scale(scale)
                    .then(
                        if (selected) {
                            Modifier
                                .clip(shape)
                                .background(colors.primarySoft, shape)
                        } else {
                            Modifier.softSurface(shape)
                        }
                    )
                    .clickable(
                        role = Role.Tab,
                        onClickLabel = stringResource(R.string.editor_open_tab, tab.name)
                    ) {
                        haptics.light()
                        onSelect(tab.documentId)
                    }
                    .semantics { this.selected = selected }
                    .heightIn(min = 40.dp)
                    .padding(start = 10.dp, end = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (tab.dirty) {
                    // The dot is the only unsaved signal on an unselected tab, so
                    // it carries the words as well as the colour.
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(colors.warning)
                            .semantics { contentDescription = unsavedLabel }
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    text = tab.name,
                    style = MaterialTheme.typography.labelMedium,
                    color = labelColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Box(
                    modifier = Modifier
                        .clickable(
                            role = Role.Button,
                            onClickLabel = stringResource(R.string.editor_close_named_tab, tab.name)
                        ) {
                            haptics.light()
                            onClose(tab.documentId)
                        }
                        .touchTarget(min = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = stringResource(
                            R.string.editor_close_named_tab,
                            tab.name
                        ),
                        tint = colors.textTertiary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

/**
 * Find and replace, sized for a thumb.
 *
 * The match counter is a polite live region: typing a query is the one moment a
 * screen reader user has no other way to learn whether anything was found. Every
 * control that cannot do anything yet is genuinely disabled rather than left
 * tappable, and the step arrows point up and down instead of borrowing the
 * undo/redo glyphs they used to share with the toolbar below.
 */
@Composable
private fun FindReplaceBar(
    query: String,
    replacement: String,
    currentIndex: Int,
    matchCount: Int,
    onQueryChange: (String) -> Unit,
    onReplacementChange: (String) -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onReplace: () -> Unit,
    onReplaceAll: () -> Unit
) {
    val colors = SiriusTheme.colors
    val hasMatches = matchCount > 0
    val counter = if (hasMatches) {
        stringResource(R.string.editor_search_position, currentIndex + 1, matchCount)
    } else {
        stringResource(R.string.editor_no_matches)
    }
    val counterAnnouncement = if (hasMatches) {
        stringResource(R.string.editor_matches_found, currentIndex + 1, matchCount)
    } else {
        stringResource(R.string.editor_no_matches)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SiriusSpacing.sm, vertical = 6.dp)
            .glassSurface(shape = RoundedCornerShape(SiriusRadius.md), elevation = 6.dp)
            .padding(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SiriusTextField(
                value = query,
                onValueChange = onQueryChange,
                placeholder = stringResource(R.string.editor_find),
                modifier = Modifier.weight(1f),
                onImeAction = { if (hasMatches) onNext() }
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = counter,
                style = MaterialTheme.typography.labelSmall,
                color = if (hasMatches) colors.textSecondary else colors.textTertiary,
                modifier = Modifier.semantics {
                    liveRegion = LiveRegionMode.Polite
                    contentDescription = counterAnnouncement
                }
            )
            Spacer(Modifier.width(6.dp))
            GlassIconButton(
                icon = Icons.Rounded.ExpandLess,
                contentDescription = stringResource(R.string.editor_previous_match),
                size = 32.dp,
                iconSize = 16.dp,
                enabled = hasMatches,
                onClick = onPrevious
            )
            GlassIconButton(
                icon = Icons.Rounded.ExpandMore,
                contentDescription = stringResource(R.string.editor_next_match),
                size = 32.dp,
                iconSize = 16.dp,
                enabled = hasMatches,
                onClick = onNext
            )
        }
        Spacer(Modifier.size(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            SiriusTextField(
                value = replacement,
                onValueChange = onReplacementChange,
                placeholder = stringResource(R.string.editor_replace_with),
                modifier = Modifier.weight(1f),
                onImeAction = { if (hasMatches) onReplace() }
            )
            Spacer(Modifier.width(6.dp))
            TextAction(
                label = stringResource(R.string.action_replace),
                enabled = hasMatches,
                onClick = onReplace
            )
            TextAction(
                label = stringResource(R.string.editor_replace_all),
                shortLabel = stringResource(R.string.action_all),
                enabled = hasMatches,
                onClick = onReplaceAll
            )
        }
    }
}

/**
 * A word used as a button. [shortLabel] lets the strip stay narrow while the
 * accessibility layer still hears "Replace all" rather than "All".
 */
@Composable
private fun TextAction(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    shortLabel: String? = null
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    Text(
        text = shortLabel ?: label,
        style = MaterialTheme.typography.labelMedium,
        color = colors.primary,
        modifier = Modifier
            .clip(RoundedCornerShape(SiriusRadius.pill))
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) {
                haptics.light()
                onClick()
            }
            .heightIn(min = 44.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .padding(horizontal = 10.dp, vertical = 12.dp)
            .semantics { contentDescription = label }
    )
}

@Composable
private fun EditorToolbar(
    canUndo: Boolean,
    canRedo: Boolean,
    wordWrap: Boolean,
    symbolsVisible: Boolean,
    symbolsEnabled: Boolean,
    problems: List<String>,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onFormat: () -> Unit,
    onToggleWrap: () -> Unit,
    onToggleSymbols: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    Row(
        modifier = modifier
            .fillMaxWidth()
            .imePadding()
            .padding(horizontal = SiriusSpacing.sm, vertical = 6.dp)
            .glassSurface(shape = RoundedCornerShape(SiriusRadius.pill), elevation = 10.dp)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        GlassIconButton(
            icon = Icons.AutoMirrored.Rounded.Undo,
            contentDescription = stringResource(R.string.editor_undo),
            enabled = canUndo,
            size = 34.dp,
            iconSize = 16.dp,
            onClick = onUndo
        )
        GlassIconButton(
            icon = Icons.AutoMirrored.Rounded.Redo,
            contentDescription = stringResource(R.string.editor_redo),
            enabled = canRedo,
            size = 34.dp,
            iconSize = 16.dp,
            onClick = onRedo
        )
        GlassIconButton(
            icon = Icons.AutoMirrored.Rounded.FormatAlignLeft,
            contentDescription = stringResource(R.string.editor_format),
            size = 34.dp,
            iconSize = 16.dp,
            onClick = onFormat
        )
        GlassIconButton(
            icon = Icons.AutoMirrored.Rounded.WrapText,
            contentDescription = stringResource(R.string.editor_word_wrap),
            highlighted = wordWrap,
            size = 34.dp,
            iconSize = 16.dp,
            onClick = onToggleWrap
        )
        GlassIconButton(
            icon = Icons.Rounded.Keyboard,
            contentDescription = stringResource(R.string.editor_symbols),
            highlighted = symbolsVisible,
            enabled = symbolsEnabled,
            size = 34.dp,
            iconSize = 16.dp,
            onClick = onToggleSymbols
        )
        Spacer(Modifier.weight(1f))
        if (problems.isEmpty()) {
            SiriusChip(text = stringResource(R.string.editor_no_issues), color = colors.success)
        } else {
            // One problem reads as itself; several would truncate to nonsense, so
            // the chip counts them and the first one keeps the detail.
            val label = if (problems.size == 1) {
                problems.first()
            } else {
                pluralStringResource(R.plurals.editor_issue_count, problems.size, problems.size)
            }
            SiriusChip(
                text = label,
                color = colors.warning,
                modifier = Modifier.semantics {
                    contentDescription = problems.joinToString(separator = ", ")
                }
            )
        }
    }
}
