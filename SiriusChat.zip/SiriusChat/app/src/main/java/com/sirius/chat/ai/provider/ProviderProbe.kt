package com.sirius.chat.ai.provider

import com.sirius.chat.R
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request

/** What asking an endpoint for its catalogue produced. */
sealed interface ProbeResult {
    /**
     * The endpoint answered. [models] can still be empty: some gateways accept
     * the key and expose no listing, which is a working key all the same.
     */
    data class Ok(val models: List<AiModel>) : ProbeResult

    data class Failure(val error: AiError) : ProbeResult
}

/**
 * Asks an endpoint who it is and what it serves, without generating anything.
 *
 * `GET /models` is the cheapest question in both protocols: it is free, it
 * returns instantly, and it fails loudly on a bad key or a wrong base URL. That
 * is why the screen checks a connection this way instead of sending a throwaway
 * "hi" and burning tokens to learn the same thing.
 */
class ProviderProbe(private val client: OkHttpClient = HttpClientProvider.client) {

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun listModels(config: ProviderConfig, apiKey: String?): ProbeResult =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(config.baseUrl.trim().trimEnd('/') + "/models")
                .get()
                .apply {
                    header("Accept", "application/json")
                    if (!apiKey.isNullOrBlank()) {
                        // Anthropic authenticates on its own header and refuses a
                        // request without a version pin.
                        if (config.type == ProviderType.AnthropicCompatible) {
                            header("x-api-key", apiKey)
                            header("anthropic-version", ANTHROPIC_MODELS_VERSION)
                        } else {
                            header("Authorization", "Bearer $apiKey")
                        }
                    } else if (config.type == ProviderType.AnthropicCompatible) {
                        header("anthropic-version", ANTHROPIC_MODELS_VERSION)
                    }
                }
                .build()

            val response = runCatching { client.newCall(request).execute() }
                .getOrElse { return@withContext ProbeResult.Failure(it.toAiError()) }

            response.use { httpResponse ->
                val body = runCatching { httpResponse.body?.string() }.getOrNull().orEmpty()
                if (!httpResponse.isSuccessful) {
                    return@withContext ProbeResult.Failure(httpError(httpResponse.code, body))
                }
                val models = runCatching { parse(body) }.getOrElse {
                    return@withContext ProbeResult.Failure(
                        AiError(
                            AiError.Kind.Server,
                            AppStrings.get(
                                R.string.providers_probe_unreadable,
                                fallback = "The endpoint answered with a catalogue this app could not read."
                            )
                        )
                    )
                }
                ProbeResult.Ok(models)
            }
        }

    /**
     * Both protocols answer with `{ "data": [ { "id": ... } ] }`, and a few
     * OpenAI-compatible gateways answer with a bare array instead. Anything with
     * an id is kept; ids are what a request actually needs.
     */
    private fun parse(body: String): List<AiModel> {
        val root = json.parseToJsonElement(body)
        val array = when {
            root is kotlinx.serialization.json.JsonArray -> root
            else -> root.jsonObject["data"]?.jsonArray
                ?: root.jsonObject["models"]?.jsonArray
                ?: return emptyList()
        }
        return array.mapNotNull { element ->
            val entry = element.jsonObject
            val id = entry["id"]?.jsonPrimitive?.contentOrNull
                ?: entry["name"]?.jsonPrimitive?.contentOrNull
                ?: return@mapNotNull null
            if (id.isBlank()) return@mapNotNull null
            val label = entry["display_name"]?.jsonPrimitive?.contentOrNull
                ?: entry["name"]?.jsonPrimitive?.contentOrNull?.takeIf { it != id }
            val context = entry["context_length"]?.jsonPrimitive?.intOrNull
                ?: entry["max_context_length"]?.jsonPrimitive?.intOrNull
                ?: 0
            AiModel(id = id, label = label?.takeIf { it.isNotBlank() } ?: id, contextWindow = context)
        }
            .distinctBy { it.id }
            .sortedBy { it.id.lowercase() }
    }

    private companion object {
        const val ANTHROPIC_MODELS_VERSION = "2023-06-01"
    }
}
