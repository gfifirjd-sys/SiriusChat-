package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.designsystem.touchTarget
import com.sirius.chat.core.util.CodeLanguage
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.core.util.rememberHighlighted
import kotlinx.coroutines.delay

/**
 * Code block with language chip, copy button and horizontal scrolling.
 *
 * Long blocks are clamped and expanded on demand rather than given their own
 * vertical scroll: a scrollable box inside the scrolling transcript swallowed
 * drags meant for the conversation, so a long snippet became a trap.
 */
@Composable
fun CodeBlockView(
    code: String,
    language: CodeLanguage,
    tag: String,
    modifier: Modifier = Modifier,
    fontSize: Int = 13,
    collapsedLines: Int = 18
) {
    val colors = SiriusTheme.colors
    val clipboard = LocalClipboardManager.current
    val haptics = rememberHaptics()
    var copied by remember { mutableStateOf(false) }
    var expanded by remember(code) { mutableStateOf(false) }
    val highlighted = rememberHighlighted(code, language)
    val horizontal = rememberScrollState()
    val lineCount = remember(code) { code.count { it == '\n' } + 1 }
    val clamped = lineCount > collapsedLines
    val copyLabel = stringResource(R.string.chat_copy_code)

    LaunchedEffect(copied) {
        if (copied) {
            delay(1600)
            copied = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(SiriusRadius.sm))
            .background(colors.codeBackground)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(colors.codeBackground)
                .padding(start = 12.dp, end = 6.dp, top = 6.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = tag.ifBlank { language.displayName }.lowercase(),
                style = MaterialTheme.typography.labelSmall,
                color = colors.codeComment,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(SiriusRadius.pill))
                    // The icon and the label used to be announced separately, so
                    // TalkBack read "Copy code, Copy". One button, one label.
                    .clickable(role = Role.Button, onClickLabel = copyLabel) {
                        clipboard.setText(AnnotatedString(code))
                        haptics.light()
                        copied = true
                    }
                    .touchTarget(44.dp)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .semantics(mergeDescendants = true) {}
            ) {
                Icon(
                    imageVector = if (copied) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                    contentDescription = null,
                    tint = if (copied) colors.success else colors.codeComment,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = if (copied) stringResource(R.string.chat_copied) else stringResource(R.string.action_copy),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (copied) colors.success else colors.codeComment,
                    maxLines = 1,
                    softWrap = false
                )
            }
        }

        Text(
            text = highlighted,
            style = codeTextStyle(fontSize),
            color = colors.codePlain,
            softWrap = false,
            maxLines = if (clamped && !expanded) collapsedLines else Int.MAX_VALUE,
            overflow = TextOverflow.Clip,
            modifier = Modifier
                .horizontalScroll(horizontal)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )

        if (clamped) {
            val toggleLabel = if (expanded) {
                stringResource(R.string.chat_code_collapse)
            } else {
                pluralStringResource(R.plurals.chat_code_show_all, lineCount, lineCount)
            }
            val expandedState = stringResource(R.string.a11y_expanded)
            val collapsedState = stringResource(R.string.a11y_collapsed)
            // A clamped block ends mid-statement, so the fold gets a hairline to
            // read as a seam rather than as the last line of the snippet.
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(colors.codeComment.copy(alpha = 0.18f))
            )
            Text(
                text = toggleLabel,
                style = MaterialTheme.typography.labelMedium,
                color = colors.primary,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(role = Role.Button) {
                        haptics.light()
                        expanded = !expanded
                    }
                    .semantics {
                        stateDescription = if (expanded) expandedState else collapsedState
                    }
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            )
        }
    }
}
