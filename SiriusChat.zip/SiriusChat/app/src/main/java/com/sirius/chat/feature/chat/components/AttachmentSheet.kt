package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import com.sirius.chat.core.designsystem.components.sheetDragGuard
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.domain.model.FileNode

/** Picks workspace files to send along with the prompt. */
@Composable
fun AttachmentSheet(
    results: List<FileNode>,
    query: String,
    onQueryChange: (String) -> Unit,
    onPick: (FileNode) -> Unit,
    onDismiss: () -> Unit,
    hasWorkspace: Boolean
) {
    val colors = SiriusTheme.colors
    val attachLabel = stringResource(R.string.chat_attach_file)

    SiriusBottomSheet(
        title = stringResource(R.string.chat_attach_title),
        subtitle = stringResource(
            if (hasWorkspace) {
                R.string.chat_attach_subtitle_workspace
            } else {
                R.string.chat_attach_subtitle_none
            }
        ),
        scrollable = false,
        onDismiss = onDismiss
    ) {
        SiriusTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = stringResource(R.string.chat_search_files),
            leadingIcon = Icons.Rounded.Search,
            enabled = hasWorkspace,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.size(SiriusSpacing.sm))
        // A blank sheet used to be the answer to a search that matched nothing,
        // which reads as a broken list rather than an empty one.
        if (hasWorkspace && results.isEmpty()) {
            Text(
                text = stringResource(
                    if (query.isBlank()) R.string.files_empty_folder else R.string.files_nothing_found
                ),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary,
                modifier = Modifier.padding(vertical = SiriusSpacing.sm)
            )
        }

        LazyColumn(
            modifier = Modifier
                .heightIn(max = 360.dp)
                .sheetDragGuard(),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
        ) {
            items(results, key = { it.documentId }) { node ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .softSurface(RoundedCornerShape(SiriusRadius.md))
                        // One focusable row that says what tapping it does, instead of
                        // three separate labels the user has to assemble.
                        .clickable(role = Role.Button, onClickLabel = attachLabel) {
                            onPick(node)
                        }
                        .semantics(mergeDescendants = true) {}
                        .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.AutoMirrored.Rounded.InsertDriveFile,
                        contentDescription = null,
                        tint = colors.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(SiriusSpacing.xs))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = node.name,
                            style = MaterialTheme.typography.titleSmall,
                            color = colors.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            // A deep path is identified by its tail, so the root
                            // is what gets sacrificed when it will not fit.
                            text = Formatters.shortPath(node.path),
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textTertiary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.width(SiriusSpacing.xs))
                    Text(
                        text = Formatters.fileSize(node.sizeBytes),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textTertiary,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
