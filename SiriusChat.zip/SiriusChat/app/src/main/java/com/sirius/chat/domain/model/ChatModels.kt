package com.sirius.chat.domain.model

/** Who produced a message inside a conversation. */
enum class MessageRole { User, Assistant, System, Tool }

/** Lifecycle of a single message. */
enum class MessageStatus { Pending, Streaming, Complete, Failed, Cancelled }

/**
 * A single chat message. [content] holds raw markdown as produced by the model,
 * rendering happens in the UI layer.
 */
data class ChatMessage(
    val id: String,
    val sessionId: String,
    val role: MessageRole,
    val content: String,
    val createdAt: Long,
    val model: String? = null,
    val providerId: String? = null,
    val status: MessageStatus = MessageStatus.Complete,
    val error: String? = null,
    val attachments: List<MessageAttachment> = emptyList(),
    val toolRuns: List<ToolRun> = emptyList()
) {
    val isFromUser: Boolean get() = role == MessageRole.User
}

/** A workspace file (or snippet) attached to a user message. */
data class MessageAttachment(
    val id: String,
    val name: String,
    /** Workspace document id, or a persisted `content://` uri for a picked file. */
    val uri: String,
    val sizeBytes: Long = 0L,
    val language: String? = null,
    val mimeType: String? = null,
    val kind: AttachmentKind = AttachmentKind.WorkspaceFile,
    /**
     * Caret offset in the message text where this attachment was inserted.
     *
     * This is what lets the prompt interleave text and files in the order the
     * user built them, instead of dumping every file after the message. Without
     * it, "look at this screenshot, and compare it with this log" arrives as two
     * files in an arbitrary order and the model cannot tell which sentence
     * belongs to which attachment.
     */
    val anchor: Int = 0
)

/**
 * How an attachment can be given to a model.
 *
 * Classified once, when the file is picked, because the answer decides both the
 * icon in the composer and the content block in the request — and because a
 * user who attaches a 40 MB archive should be told immediately, not after the
 * request fails.
 */
enum class AttachmentKind {
    /** A file inside the opened project, read through the workspace tree. */
    WorkspaceFile,

    /** PNG, JPEG, GIF or WebP: the four formats Anthropic accepts as images. */
    Image,

    /** PDF, sent as a native document block. */
    Document,

    /** Text or source code: inlined, labelled with its name. */
    TextFile,

    /** Archive, binary, executable: only its metadata can be described. */
    Opaque
}

/** Result of one agent tool invocation, surfaced inline in the transcript. */
data class ToolRun(
    val id: String,
    val toolName: String,
    val argumentsPreview: String,
    val output: String,
    val success: Boolean,
    val durationMs: Long = 0L
)

/** A conversation, optionally bound to a project workspace. */
data class ChatSession(
    val id: String,
    val title: String,
    val projectId: String? = null,
    val providerId: String,
    val model: String,
    // Legacy column. Sirius is agent-only: there is no plain-chat path left to
    // switch to, so this stays `true` for every session and is kept purely so
    // existing databases still map without a destructive migration.
    val agentMode: Boolean = true,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean = false,
    val messageCount: Int = 0,
    val lastMessagePreview: String = ""
)
