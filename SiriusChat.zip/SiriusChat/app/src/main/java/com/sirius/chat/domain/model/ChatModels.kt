package com.sirius.chat.domain.model

/** Who produced a message inside a conversation. */
enum class MessageRole { User, Assistant, System, Tool }

/** Lifecycle of a single message. */
enum class MessageStatus { Pending, Streaming, Complete, Failed, Cancelled }

/**
 * A single chat message. [content] holds raw markdown as produced by the model,
 * rendering happens in the UI layer.
 */
data class ChatMessage(
    val id: String,
    val sessionId: String,
    val role: MessageRole,
    val content: String,
    val createdAt: Long,
    val model: String? = null,
    val providerId: String? = null,
    val status: MessageStatus = MessageStatus.Complete,
    val error: String? = null,
    val attachments: List<MessageAttachment> = emptyList(),
    val toolRuns: List<ToolRun> = emptyList()
) {
    val isFromUser: Boolean get() = role == MessageRole.User
}

/** A workspace file (or snippet) attached to a user message. */
data class MessageAttachment(
    val id: String,
    val name: String,
    val uri: String,
    val sizeBytes: Long = 0L,
    val language: String? = null
)

/** Result of one agent tool invocation, surfaced inline in the transcript. */
data class ToolRun(
    val id: String,
    val toolName: String,
    val argumentsPreview: String,
    val output: String,
    val success: Boolean,
    val durationMs: Long = 0L
)

/** A conversation, optionally bound to a project workspace. */
data class ChatSession(
    val id: String,
    val title: String,
    val projectId: String? = null,
    val providerId: String,
    val model: String,
    // Legacy column. Sirius is agent-only: there is no plain-chat path left to
    // switch to, so this stays `true` for every session and is kept purely so
    // existing databases still map without a destructive migration.
    val agentMode: Boolean = true,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean = false,
    val messageCount: Int = 0,
    val lastMessagePreview: String = ""
)
