package com.sirius.chat.ai.provider

import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import com.sirius.chat.domain.repository.ProviderRepository

/**
 * Turns a stored [ProviderConfig] plus its secret into a live [AiProvider].
 * Instances are cheap and short-lived; only the HTTP client is shared.
 */
class ProviderFactory(private val providerRepository: ProviderRepository) {

    suspend fun create(providerId: String): AiProvider? {
        val config = providerRepository.get(providerId) ?: return null
        return create(config, providerRepository.apiKey(providerId))
    }

    fun create(config: ProviderConfig, apiKey: String?): AiProvider = when (config.type) {
        ProviderType.AnthropicCompatible -> AnthropicProvider(config, apiKey)
        ProviderType.OpenAiCompatible, ProviderType.Custom -> OpenAiCompatibleProvider(config, apiKey)
    }

    /** Local endpoints (Ollama, LM Studio) legitimately need no key. */
    fun requiresApiKey(config: ProviderConfig): Boolean {
        val host = config.baseUrl.substringAfter("://").substringBefore('/')
        val isLocal = host.startsWith("127.0.0.1") || host.startsWith("localhost") ||
            host.startsWith("10.") || host.startsWith("192.168.")
        return !isLocal
    }
}
