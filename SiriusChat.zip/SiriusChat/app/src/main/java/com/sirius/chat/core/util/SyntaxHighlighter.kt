package com.sirius.chat.core.util

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import com.sirius.chat.core.designsystem.SiriusPalette
import com.sirius.chat.core.designsystem.SiriusTheme

/**
 * Regex based highlighter. It is deliberately simple: a real parser would be
 * overkill on a phone, while token regexes over an already-visible chunk of
 * text are fast and never block scrolling.
 */
object SyntaxHighlighter {

    /** Above this size we stop colouring and just render plain monospaced text. */
    const val MAX_HIGHLIGHT_CHARS = 120_000

    private val kotlinKeywords = setOf(
        "as", "break", "class", "continue", "do", "else", "false", "for", "fun", "if", "in", "interface",
        "is", "null", "object", "package", "return", "super", "this", "throw", "true", "try", "typealias",
        "typeof", "val", "var", "when", "while", "by", "catch", "constructor", "delegate", "dynamic",
        "field", "file", "finally", "get", "import", "init", "param", "property", "receiver", "set",
        "setparam", "where", "actual", "abstract", "annotation", "companion", "const", "crossinline",
        "data", "enum", "expect", "external", "final", "infix", "inline", "inner", "internal", "lateinit",
        "noinline", "open", "operator", "out", "override", "private", "protected", "public", "reified",
        "sealed", "suspend", "tailrec", "vararg"
    )

    private val javaKeywords = setOf(
        "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
        "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
        "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
        "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
        "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
        "volatile", "while", "true", "false", "null", "var", "record", "sealed"
    )

    private val pythonKeywords = setOf(
        "and", "as", "assert", "async", "await", "break", "class", "continue", "def", "del", "elif",
        "else", "except", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda",
        "None", "nonlocal", "not", "or", "pass", "raise", "return", "True", "False", "try", "while",
        "with", "yield", "self"
    )

    private val jsKeywords = setOf(
        "async", "await", "break", "case", "catch", "class", "const", "continue", "debugger", "default",
        "delete", "do", "else", "export", "extends", "finally", "for", "function", "if", "import", "in",
        "instanceof", "let", "new", "null", "return", "super", "switch", "this", "throw", "true", "false",
        "try", "typeof", "var", "void", "while", "yield", "interface", "type", "enum", "implements",
        "readonly", "declare", "namespace", "public", "private", "protected", "static"
    )

    private val shellKeywords = setOf(
        "if", "then", "else", "elif", "fi", "for", "in", "do", "done", "while", "case", "esac",
        "function", "return", "export", "local", "echo", "cd", "ls", "cat", "grep", "sudo", "set"
    )

    private val sqlKeywords = setOf(
        "select", "from", "where", "insert", "into", "values", "update", "set", "delete", "create",
        "table", "drop", "alter", "join", "left", "right", "inner", "outer", "on", "group", "by",
        "order", "having", "limit", "as", "and", "or", "not", "null", "primary", "key", "foreign",
        "index", "distinct", "count", "sum", "avg", "min", "max"
    )

    private val identifierRegex = Regex("[A-Za-z_][A-Za-z0-9_]*")
    private val numberRegex = Regex("\\b(0[xX][0-9a-fA-F_]+|\\d[\\d_]*\\.?[\\d_]*([eE][+-]?\\d+)?[fFlLdD]?)\\b")
    private val annotationRegex = Regex("@[A-Za-z_][A-Za-z0-9_.]*")
    private val functionCallRegex = Regex("\\b([A-Za-z_][A-Za-z0-9_]*)\\s*\\(")
    private val typeRegex = Regex("\\b([A-Z][A-Za-z0-9_]*)\\b")
    private val xmlTagRegex = Regex("</?[A-Za-z_][A-Za-z0-9_:.-]*|/?>")
    private val xmlAttrRegex = Regex("\\b([A-Za-z_][A-Za-z0-9_:.-]*)\\s*=")
    private val jsonKeyRegex = Regex("\"([^\"\\\\]|\\\\.)*\"\\s*:")
    private val stringRegex = Regex("\"([^\"\\\\\\n]|\\\\.)*\"|'([^'\\\\\\n]|\\\\.)*'|\"\"\"[\\s\\S]*?\"\"\"")
    private val lineCommentRegex = Regex("//[^\\n]*|#[^\\n]*")
    private val blockCommentRegex = Regex("/\\*[\\s\\S]*?\\*/|<!--[\\s\\S]*?-->")

    fun highlight(code: String, language: CodeLanguage, palette: SiriusPalette): AnnotatedString {
        if (code.length > MAX_HIGHLIGHT_CHARS || language == CodeLanguage.PlainText) {
            return AnnotatedString(code)
        }
        val spans = HashMap<Int, Pair<Int, SpanStyle>>() // start -> end + style
        val claimed = BooleanArray(code.length)

        fun claim(range: IntRange, style: SpanStyle) {
            val start = range.first.coerceIn(0, code.length)
            val end = (range.last + 1).coerceIn(0, code.length)
            if (start >= end) return
            for (i in start until end) if (claimed[i]) return
            for (i in start until end) claimed[i] = true
            spans[start] = end to style
        }

        fun apply(regex: Regex, color: Color, weight: FontWeight? = null, group: Int = 0) {
            regex.findAll(code).forEach { match ->
                val target = match.groups[group] ?: return@forEach
                claim(target.range, SpanStyle(color = color, fontWeight = weight))
            }
        }

        // Comments and strings win over everything else.
        apply(blockCommentRegex, palette.codeComment)
        if (language != CodeLanguage.Xml) apply(lineCommentRegex, palette.codeComment)
        apply(stringRegex, palette.codeString)

        when (language) {
            CodeLanguage.Xml -> {
                apply(xmlTagRegex, palette.codeKeyword, FontWeight.Medium)
                apply(xmlAttrRegex, palette.codeFunction, group = 1)
            }
            CodeLanguage.Json -> {
                apply(jsonKeyRegex, palette.codeFunction)
                apply(numberRegex, palette.codeNumber)
                apply(Regex("\\b(true|false|null)\\b"), palette.codeKeyword)
            }
            CodeLanguage.Markdown -> {
                apply(Regex("^#{1,6} [^\\n]*", RegexOption.MULTILINE), palette.codeFunction, FontWeight.Bold)
                apply(Regex("\\*\\*[^*\\n]+\\*\\*"), palette.codeType, FontWeight.Bold)
                apply(Regex("`[^`\\n]+`"), palette.codeString)
            }
            CodeLanguage.Properties -> {
                apply(Regex("^[^=:#\\n]+(?=[=:])", RegexOption.MULTILINE), palette.codeFunction)
            }
            CodeLanguage.Yaml -> {
                apply(Regex("^\\s*[A-Za-z0-9_.-]+(?=:)", RegexOption.MULTILINE), palette.codeFunction)
                apply(numberRegex, palette.codeNumber)
            }
            else -> {
                apply(annotationRegex, palette.codeAnnotation)
                apply(numberRegex, palette.codeNumber)
                apply(functionCallRegex, palette.codeFunction, group = 1)
                apply(typeRegex, palette.codeType, group = 1)

                val keywords = keywordsFor(language)
                identifierRegex.findAll(code).forEach { match ->
                    if (match.value in keywords) {
                        claim(match.range, SpanStyle(color = palette.codeKeyword, fontWeight = FontWeight.Medium))
                    }
                }
            }
        }

        return buildAnnotatedString {
            append(code)
            spans.forEach { (start, value) ->
                addStyle(value.second, start, value.first)
            }
        }
    }

    private fun keywordsFor(language: CodeLanguage): Set<String> = when (language) {
        CodeLanguage.Kotlin, CodeLanguage.Gradle -> kotlinKeywords
        CodeLanguage.Java -> javaKeywords
        CodeLanguage.Python -> pythonKeywords
        CodeLanguage.JavaScript, CodeLanguage.TypeScript -> jsKeywords
        CodeLanguage.Shell -> shellKeywords
        CodeLanguage.Sql -> sqlKeywords
        CodeLanguage.C -> javaKeywords
        else -> emptySet()
    }
}

/** Caches the highlight result for a given text + language pair. */
@Composable
fun rememberHighlighted(code: String, language: CodeLanguage): AnnotatedString {
    val palette = SiriusTheme.colors
    return remember(code, language, palette.isDark) {
        SyntaxHighlighter.highlight(code, language, palette)
    }
}
