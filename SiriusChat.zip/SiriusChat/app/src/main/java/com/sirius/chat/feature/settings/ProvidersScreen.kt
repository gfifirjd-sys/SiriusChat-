package com.sirius.chat.feature.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudSync
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.HideImage
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.KeyOff
import androidx.compose.material.icons.rounded.LibraryAdd
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.EmptyState
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.ProviderAvatar
import com.sirius.chat.core.designsystem.components.ProviderBrand
import com.sirius.chat.core.designsystem.components.ProviderIcon
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusConfirmSheet
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.ToastTone
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.components.saveProviderIcon
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.locale.displayLabel
import com.sirius.chat.core.locale.providerDisplayLabel
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.data.local.preferences.ProviderPreset
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Confirmation the screen is waiting on, if any. */
private sealed interface ProviderPrompt {
    data class Delete(val config: ProviderConfig) : ProviderPrompt
    data class RemoveKey(val config: ProviderConfig) : ProviderPrompt
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProvidersScreen(
    onBack: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: ProvidersViewModel = siriusViewModel { ProvidersViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors

    val listState = rememberLazyListState()
    val scrolled by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 4
        }
    }
    var prompt by remember { mutableStateOf<ProviderPrompt?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.providers_title),
            subtitle = stringResource(R.string.providers_subtitle),
            scrolled = scrolled,
            onBack = onBack,
            actions = {
                // Two ways in, because they are different jobs: pick a known
                // service, or type an endpoint nobody shipped.
                GlassIconButton(
                    icon = Icons.Rounded.Storefront,
                    contentDescription = stringResource(R.string.providers_catalog_open),
                    onClick = viewModel::openCatalog
                )
                Spacer(Modifier.width(4.dp))
                GlassIconButton(
                    icon = Icons.Rounded.Add,
                    contentDescription = stringResource(R.string.providers_add),
                    highlighted = true,
                    onClick = viewModel::startCreate
                )
            }
        )

        if (state.providers.isEmpty()) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    EmptyState(
                        icon = Icons.Rounded.Key,
                        title = stringResource(R.string.providers_empty_title),
                        message = stringResource(R.string.providers_empty_message),
                        // The catalogue leads: picking OpenAI from a list beats
                        // typing its base URL from memory.
                        actionLabel = stringResource(R.string.providers_catalog_action),
                        onAction = viewModel::openCatalog
                    )
                    VSpace(SiriusSpacing.xs)
                    SiriusGhostButton(
                        text = stringResource(R.string.providers_add_manual),
                        onClick = viewModel::startCreate
                    )
                }
            }
        } else {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(
                    start = SiriusSpacing.sm,
                    end = SiriusSpacing.sm,
                    bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
                ),
                verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs),
                modifier = Modifier.weight(1f)
            ) {
                if (state.providers.isNotEmpty()) item(key = "notice") {
                    GlassCard(contentPadding = SiriusSpacing.sm) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Rounded.Lock,
                                contentDescription = null,
                                tint = colors.success,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(SiriusSpacing.xs))
                            Text(
                                text = stringResource(R.string.providers_notice),
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                    }
                }

                items(state.providers, key = { it.id }) { provider ->
                    val active = provider.id == state.settings.activeProviderId
                    val label = provider.displayLabel()
                    GlassCard(
                        onClick = { viewModel.activate(provider) },
                        onClickLabel = stringResource(R.string.providers_activate, label),
                        // The endpoint every request goes to is the one thing on this
                        // screen worth lighting up.
                        active = active
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ProviderAvatar(provider = provider)
                            Spacer(Modifier.width(SiriusSpacing.xs))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = colors.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    if (active) {
                                        Spacer(Modifier.width(6.dp))
                                        Icon(
                                            Icons.Rounded.CheckCircle,
                                            contentDescription = stringResource(R.string.label_active),
                                            tint = colors.primary,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = provider.baseUrl,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.textTertiary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            GlassIconButton(
                                icon = Icons.Rounded.Edit,
                                contentDescription = stringResource(R.string.providers_edit, label),
                                size = 34.dp,
                                iconSize = 15.dp,
                                onClick = { viewModel.startEdit(provider) }
                            )
                            if (provider.hasKey) {
                                Spacer(Modifier.width(4.dp))
                                GlassIconButton(
                                    icon = Icons.Rounded.KeyOff,
                                    contentDescription = stringResource(R.string.providers_remove_key),
                                    size = 34.dp,
                                    iconSize = 15.dp,
                                    onClick = { prompt = ProviderPrompt.RemoveKey(provider) }
                                )
                            }
                            // Shipped templates are removable too: they come back
                            // from the restore section, so the list stays the
                            // user's own and not a fixed roster.
                            Spacer(Modifier.width(4.dp))
                            GlassIconButton(
                                icon = Icons.Rounded.DeleteOutline,
                                contentDescription = stringResource(
                                    R.string.providers_delete,
                                    label
                                ),
                                size = 34.dp,
                                iconSize = 15.dp,
                                tint = colors.error,
                                onClick = { prompt = ProviderPrompt.Delete(provider) }
                            )
                        }
                        VSpace(SiriusSpacing.xs)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            SiriusChip(
                                text = stringResource(
                                    if (provider.hasKey) R.string.providers_key_stored
                                    else R.string.providers_no_key
                                ),
                                icon = Icons.Rounded.Key,
                                color = if (provider.hasKey) colors.success else colors.warning
                            )
                            SiriusChip(text = stringResource(provider.type.labelRes()))
                        }
                        VSpace(SiriusSpacing.xs)
                        if (provider.models.isEmpty()) {
                            Text(
                                text = stringResource(R.string.providers_no_models),
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.warning
                            )
                        } else {
                            // A gateway can carry a hundred model ids. Showing them all
                            // turns one row into a wall, so the card shows a handful and
                            // offers the rest behind a "+N" chip.
                            var expanded by remember(provider.id) { mutableStateOf(false) }
                            val collapsedCount = MODEL_CHIP_LIMIT
                            val selectedIndex = provider.models.indexOfFirst {
                                active && state.settings.activeModel == it.id
                            }
                            // The model in use is never the one that gets hidden.
                            val shown = when {
                                expanded || provider.models.size <= collapsedCount ->
                                    provider.models

                                selectedIndex >= collapsedCount ->
                                    provider.models.take(collapsedCount - 1) +
                                        provider.models[selectedIndex]

                                else -> provider.models.take(collapsedCount)
                            }
                            val hidden = provider.models.size - shown.size

                            FlowRow(
                                modifier = Modifier.selectableGroup(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                shown.forEach { model ->
                                    val modelLabel =
                                        stringResource(R.string.providers_select_model, model.label)
                                    SiriusChip(
                                        text = model.label,
                                        selected = active && state.settings.activeModel == model.id,
                                        onClick = { viewModel.selectModel(provider, model.id) },
                                        modifier = Modifier.semantics {
                                            contentDescription = modelLabel
                                        }
                                    )
                                }
                                if (hidden > 0) {
                                    val moreLabel = stringResource(
                                        R.string.providers_models_more_action,
                                        provider.models.size
                                    )
                                    SiriusChip(
                                        text = stringResource(
                                            R.string.providers_models_more,
                                            hidden
                                        ),
                                        color = colors.primary,
                                        onClick = { expanded = true },
                                        modifier = Modifier.semantics {
                                            contentDescription = moreLabel
                                        }
                                    )
                                } else if (expanded && provider.models.size > collapsedCount) {
                                    SiriusChip(
                                        text = stringResource(R.string.providers_models_less),
                                        color = colors.textTertiary,
                                        onClick = { expanded = false }
                                    )
                                }
                            }
                        }
                    }
                }

                // The catalogue is reachable from the list too, not only from the
                // empty state, so adding a second provider is the same one tap.
                if (state.catalog.isNotEmpty()) item(key = "catalog-cta") {
                    VSpace(SiriusSpacing.xxs)
                    GlassCard(
                        onClick = viewModel::openCatalog,
                        onClickLabel = stringResource(R.string.providers_catalog_open),
                        contentPadding = SiriusSpacing.sm
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Rounded.Storefront,
                                contentDescription = null,
                                tint = colors.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(SiriusSpacing.xs))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.providers_catalog_title),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = colors.textPrimary
                                )
                                Text(
                                    text = stringResource(
                                        R.string.providers_catalog_count,
                                        state.catalog.size
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.textTertiary
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (state.catalogOpen) {
        SiriusBottomSheet(
            title = stringResource(R.string.providers_catalog_title),
            subtitle = stringResource(R.string.providers_catalog_subtitle),
            onDismiss = viewModel::closeCatalog
        ) {
            if (state.catalog.isEmpty()) {
                Text(
                    text = stringResource(R.string.providers_catalog_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )
            } else {
                // One scroll container only: the sheet itself scrolls. A LazyColumn
                // here fought the sheet for the gesture and turned the first flick
                // into a dismissal.
                Column(
                    verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
                ) {
                    state.catalog.forEach { preset ->
                        key(preset.config.id) {
                            CatalogRow(preset = preset, onAdd = { viewModel.addPreset(preset) })
                        }
                    }
                }
            }
            VSpace(SiriusSpacing.sm)
            SiriusGhostButton(
                text = stringResource(R.string.providers_add_manual),
                onClick = {
                    viewModel.closeCatalog()
                    viewModel.startCreate()
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    state.editor?.let { editor ->
        // Templates with a labelKey display a localized name, so the field must stay
        // read-only: writing the translated text back would overwrite the raw label.
        val editorLabel = providerDisplayLabel(editor.labelKey, editor.label)
        // Every provider is the user's own now, so only a legacy row still carrying
        // a localized labelKey stays read-only.
        val labelEditable = editor.labelKey == null
        val urlLooksUsable = editor.baseUrl.trim().startsWith("http") &&
            editor.baseUrl.trim().length > "https://".length
        val hasModels = editor.models.isNotBlank()

        SiriusBottomSheet(
            title = if (editor.id == null) stringResource(R.string.providers_new) else editorLabel,
            subtitle = stringResource(R.string.providers_editor_subtitle),
            onDismiss = viewModel::cancelEdit
        ) {
            ProviderIconPicker(
                iconKey = editor.iconKey,
                imagePath = editor.iconImagePath,
                type = editor.type,
                onSelectIcon = viewModel::selectIcon,
                onSelectImage = viewModel::selectIconImage,
                onClearImage = viewModel::clearIconImage
            )
            VSpace(SiriusSpacing.sm)
            SiriusTextField(
                value = editorLabel,
                onValueChange = { value -> viewModel.updateEditor { it.copy(label = value) } },
                placeholder = stringResource(R.string.providers_display_name),
                enabled = labelEditable,
                imeAction = ImeAction.Next,
                modifier = Modifier.fillMaxWidth()
            )
            VSpace(SiriusSpacing.xs)
            SiriusTextField(
                value = editor.baseUrl,
                onValueChange = { value -> viewModel.updateEditor { it.copy(baseUrl = value) } },
                placeholder = stringResource(R.string.providers_base_url),
                // A URL field that autocapitalizes and autocorrects is a trap.
                keyboardType = KeyboardType.Uri,
                imeAction = ImeAction.Next,
                isError = editor.baseUrl.isNotBlank() && !urlLooksUsable,
                modifier = Modifier.fillMaxWidth()
            )
            VSpace(SiriusSpacing.xs)
            FlowRow(
                modifier = Modifier.selectableGroup(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ProviderType.entries.forEach { type ->
                    SiriusChip(
                        text = stringResource(type.labelRes()),
                        selected = editor.type == type,
                        onClick = { viewModel.updateEditor { it.copy(type = type) } }
                    )
                }
            }
            VSpace(SiriusSpacing.xs)
            SiriusTextField(
                value = editor.models,
                onValueChange = { value -> viewModel.updateEditor { it.copy(models = value) } },
                placeholder = stringResource(R.string.providers_models),
                singleLine = false,
                modifier = Modifier.fillMaxWidth()
            )
            VSpace(SiriusSpacing.xs)
            SiriusTextField(
                value = editor.apiKey,
                onValueChange = { value -> viewModel.updateEditor { it.copy(apiKey = value) } },
                placeholder = stringResource(R.string.providers_api_key),
                leadingIcon = Icons.Rounded.Key,
                isPassword = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (editor.id != null) {
                VSpace(SiriusSpacing.xxs)
                Text(
                    text = stringResource(R.string.providers_key_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary
                )
            }

            VSpace(SiriusSpacing.sm)
            ConnectionSection(
                probe = state.probe,
                query = state.modelQuery,
                chosen = editor.modelIds().toSet(),
                enabled = urlLooksUsable,
                onCheck = viewModel::checkConnection,
                onQueryChange = viewModel::updateModelQuery,
                onToggleModel = viewModel::toggleModel,
                onAddAll = viewModel::addAllModels
            )

            VSpace(SiriusSpacing.md)
            Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                SiriusGhostButton(
                    text = stringResource(R.string.action_cancel),
                    onClick = viewModel::cancelEdit,
                    modifier = Modifier.weight(1f)
                )
                SiriusPrimaryButton(
                    text = stringResource(R.string.action_save),
                    // Saving an endpoint with no host or no model produces a provider
                    // that can only fail at request time.
                    enabled = urlLooksUsable && hasModels,
                    onClick = viewModel::saveEditor,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    // Both of these lose something the user typed and cannot be undone from here.
    when (val pending = prompt) {
        is ProviderPrompt.Delete -> SiriusConfirmSheet(
            title = stringResource(R.string.providers_delete_title, pending.config.displayLabel()),
            message = stringResource(R.string.providers_delete_message),
            confirmLabel = stringResource(R.string.action_delete),
            icon = Icons.Rounded.DeleteOutline,
            onConfirm = {
                prompt = null
                viewModel.delete(pending.config)
            },
            onDismiss = { prompt = null }
        )

        is ProviderPrompt.RemoveKey -> SiriusConfirmSheet(
            title = stringResource(
                R.string.providers_remove_key_title,
                pending.config.displayLabel()
            ),
            message = stringResource(R.string.providers_remove_key_message),
            confirmLabel = stringResource(R.string.providers_remove_key),
            icon = Icons.Rounded.KeyOff,
            onConfirm = {
                prompt = null
                viewModel.removeKey(pending.config)
            },
            onDismiss = { prompt = null }
        )

        null -> Unit
    }

    MessageToast(
        message = state.message,
        // Everything this screen reports is a success; failures surface as field errors.
        tone = ToastTone.Success,
        bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.sm,
        durationMillis = 2_600
    )

    LaunchedEffect(state.message) {
        if (state.message != null) {
            delay(2_600)
            viewModel.consumeMessage()
        }
    }
}

/** How many model chips a card shows before the rest go behind a "+N". */
private const val MODEL_CHIP_LIMIT = 5

/** How many discovered models the picker lists before it asks for a search. */
private const val MODEL_PICKER_LIMIT = 40

/**
 * Connection check and model finder inside the editor sheet.
 *
 * The check costs nothing: it asks the endpoint for `/models`, which is free and
 * instant, instead of generating a throwaway reply to prove the key works. What
 * comes back doubles as the model picker, so nobody has to type
 * `accounts/fireworks/models/llama-v3p3-70b-instruct` by hand.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ConnectionSection(
    probe: ProbeState,
    query: String,
    chosen: Set<String>,
    enabled: Boolean,
    onCheck: () -> Unit,
    onQueryChange: (String) -> Unit,
    onToggleModel: (String) -> Unit,
    onAddAll: (List<AiModel>) -> Unit
) {
    val colors = SiriusTheme.colors
    val running = probe is ProbeState.Running

    Row(verticalAlignment = Alignment.CenterVertically) {
        SiriusGhostButton(
            // The label follows what the tap will do: before a result it is a
            // connection test, after one it is how you refresh the list.
            text = stringResource(
                when {
                    running -> R.string.providers_checking
                    probe is ProbeState.Success -> R.string.providers_find_models
                    else -> R.string.providers_check_connection
                }
            ),
            icon = if (probe is ProbeState.Success) Icons.Rounded.Search else Icons.Rounded.CloudSync,
            enabled = enabled && !running,
            onClick = onCheck,
            modifier = Modifier.weight(1f)
        )
    }
    VSpace(SiriusSpacing.xxs)
    Text(
        text = stringResource(R.string.providers_probe_hint),
        style = MaterialTheme.typography.bodySmall,
        color = colors.textTertiary
    )

    when (probe) {
        is ProbeState.Failure -> {
            VSpace(SiriusSpacing.xs)
            ProbeBanner(text = probe.message, tone = colors.error, icon = Icons.Rounded.ErrorOutline)
        }

        is ProbeState.Success -> {
            VSpace(SiriusSpacing.xs)
            ProbeBanner(
                text = probe.message,
                tone = colors.success,
                icon = Icons.Rounded.CheckCircle
            )
            if (probe.models.isNotEmpty()) {
                val filtered = remember(probe.models, query) {
                    val needle = query.trim()
                    if (needle.isEmpty()) probe.models
                    else probe.models.filter { it.matches(needle) }
                }
                val missing = remember(filtered, chosen) {
                    filtered.filterNot { it.id in chosen }
                }

                VSpace(SiriusSpacing.xs)
                SiriusTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    placeholder = stringResource(R.string.providers_model_search),
                    leadingIcon = Icons.Rounded.Search,
                    modifier = Modifier.fillMaxWidth()
                )
                VSpace(SiriusSpacing.xs)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.providers_model_found, filtered.size),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textTertiary,
                        modifier = Modifier.weight(1f)
                    )
                    // "Add all" takes what the filter shows, so a search for
                    // "claude" adds the Claude models and nothing else.
                    if (missing.isNotEmpty()) {
                        SiriusChip(
                            text = stringResource(
                                R.string.providers_model_add_all,
                                missing.size
                            ),
                            icon = Icons.Rounded.LibraryAdd,
                            color = colors.primary,
                            onClick = { onAddAll(missing) }
                        )
                    }
                }
                VSpace(SiriusSpacing.xs)
                if (filtered.isEmpty()) {
                    Text(
                        text = stringResource(R.string.providers_model_no_match, query.trim()),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.warning
                    )
                } else {
                    // A registry of hundreds is capped: the search box is the way
                    // through it, and an endless chip wall inside a sheet is not.
                    FlowRow(
                        modifier = Modifier.selectableGroup(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        filtered.take(MODEL_PICKER_LIMIT).forEach { model ->
                            val toggleLabel =
                                stringResource(R.string.providers_model_toggle, model.id)
                            SiriusChip(
                                text = model.label,
                                selected = model.id in chosen,
                                onClick = { onToggleModel(model.id) },
                                modifier = Modifier.semantics {
                                    contentDescription = toggleLabel
                                }
                            )
                        }
                        val overflow = filtered.size - MODEL_PICKER_LIMIT
                        if (overflow > 0) {
                            SiriusChip(
                                text = stringResource(
                                    R.string.providers_models_more,
                                    overflow
                                ),
                                color = colors.textTertiary
                            )
                        }
                    }
                }
            }
        }

        else -> Unit
    }
}

/** Matches an id or a display name, so "sonnet" and "claude-3-5" both work. */
private fun AiModel.matches(needle: String): Boolean =
    id.contains(needle, ignoreCase = true) || label.contains(needle, ignoreCase = true)

/** Result line for the connection check: one colour, one icon, the raw message. */
@Composable
private fun ProbeBanner(text: String, tone: Color, icon: ImageVector) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tone,
            modifier = Modifier.size(16.dp)
        )
        Spacer(Modifier.width(SiriusSpacing.xs))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = tone,
            modifier = Modifier.weight(1f)
        )
    }
}

/**
 * One service in the catalogue.
 *
 * The whole row is the button: a separate "add" control next to a name that does
 * nothing when tapped is a smaller target for no reason. The chip says whether a
 * key is needed, because that is the only thing the user has to prepare.
 */
@Composable
private fun CatalogRow(preset: ProviderPreset, onAdd: () -> Unit) {
    val colors = SiriusTheme.colors
    val label = preset.config.label
    GlassCard(
        onClick = onAdd,
        onClickLabel = stringResource(R.string.providers_catalog_add, label),
        contentPadding = SiriusSpacing.sm
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ProviderAvatar(
                iconKey = preset.config.iconKey,
                imagePath = null,
                type = preset.config.type,
                size = 34.dp
            )
            Spacer(Modifier.width(SiriusSpacing.xs))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyLarge,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = preset.config.baseUrl,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(SiriusSpacing.xs))
            SiriusChip(
                text = stringResource(
                    if (preset.requiresKey) R.string.providers_catalog_needs_key
                    else R.string.providers_catalog_local
                ),
                color = if (preset.requiresKey) colors.warning else colors.success
            )
            Spacer(Modifier.width(6.dp))
            Icon(
                Icons.Rounded.Add,
                contentDescription = null,
                tint = colors.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * Mark picker for the editor sheet.
 *
 * The preview plate is the point: it shows exactly what the list row will show,
 * including a gallery image, so the choice is never made blind. Picking from the
 * gallery goes through the photo picker, which needs no storage permission and
 * hands back one image without exposing the rest of the library.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProviderIconPicker(
    iconKey: String?,
    imagePath: String?,
    type: ProviderType,
    onSelectIcon: (String) -> Unit,
    onSelectImage: (String) -> Unit,
    onClearImage: () -> Unit
) {
    val colors = SiriusTheme.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var working by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        working = true
        scope.launch {
            // Decoding and rescaling a gallery photo is not main-thread work.
            val path = withContext(Dispatchers.IO) { saveProviderIcon(context, uri) }
            working = false
            if (path != null) onSelectImage(path)
        }
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        ProviderAvatar(
            iconKey = iconKey,
            imagePath = imagePath,
            type = type,
            size = 52.dp
        )
        Spacer(Modifier.width(SiriusSpacing.sm))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.providers_icon),
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary
            )
            Text(
                text = stringResource(R.string.providers_icon_hint),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary
            )
        }
        if (imagePath != null) {
            Spacer(Modifier.width(SiriusSpacing.xs))
            GlassIconButton(
                icon = Icons.Rounded.HideImage,
                contentDescription = stringResource(R.string.providers_icon_remove_image),
                size = 34.dp,
                iconSize = 15.dp,
                tint = colors.error,
                onClick = onClearImage
            )
        }
    }
    VSpace(SiriusSpacing.xs)
    FlowRow(
        modifier = Modifier.selectableGroup(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // The gallery tile leads: it is the one option that is not in the grid.
        IconTile(
            isSelected = imagePath != null,
            enabled = !working,
            label = stringResource(R.string.providers_icon_from_gallery),
            onClick = {
                picker.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            }
        ) {
            Icon(
                imageVector = Icons.Rounded.PhotoLibrary,
                contentDescription = null,
                tint = if (imagePath != null) colors.primary else colors.textSecondary,
                modifier = Modifier.size(19.dp)
            )
        }
        // Real logos come first: someone renaming a row to "Work OpenAI" wants the
        // OpenAI mark on it, not an abstract one.
        ProviderBrand.entries.forEach { brand ->
            val painter = painterResource(brand.drawable)
            val brandTint = brand.tint
            IconTile(
                isSelected = imagePath == null && iconKey == brand.key,
                label = stringResource(R.string.providers_icon_option, brand.label),
                onClick = { onSelectIcon(brand.key) }
            ) {
                if (brandTint == null) {
                    Image(
                        painter = painter,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                } else {
                    Icon(
                        painter = painter,
                        contentDescription = null,
                        tint = brandTint,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
        ProviderIcon.entries.forEach { mark ->
            IconTile(
                isSelected = imagePath == null && iconKey == mark.key,
                label = stringResource(R.string.providers_icon_option, stringResource(mark.labelRes)),
                onClick = { onSelectIcon(mark.key) }
            ) {
                Icon(
                    imageVector = mark.icon,
                    contentDescription = null,
                    tint = mark.color,
                    modifier = Modifier.size(19.dp)
                )
            }
        }
    }
}

/** One square in the mark grid; selection is a filled plate, not a border. */
@Composable
private fun IconTile(
    isSelected: Boolean,
    label: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    content: @Composable () -> Unit
) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.sm)
    Box(
        modifier = Modifier
            .size(42.dp)
            .then(
                if (isSelected) {
                    Modifier
                        .background(colors.primarySoft, shape)
                        .softSurface(shape, alpha = 0.4f)
                } else {
                    Modifier.softSurface(shape)
                }
            )
            .clickable(enabled = enabled, role = Role.RadioButton, onClick = onClick)
            .semantics(mergeDescendants = true) {
                selected = isSelected
                contentDescription = label
            },
        contentAlignment = Alignment.Center,
        content = { content() }
    )
}

/** Localized name of the wire protocol, so chips never show enum names. */
@StringRes
private fun ProviderType.labelRes(): Int = when (this) {
    ProviderType.OpenAiCompatible -> R.string.provider_type_openai
    ProviderType.AnthropicCompatible -> R.string.provider_type_anthropic
    ProviderType.Custom -> R.string.provider_type_custom
}
