package com.sirius.chat.data.repository

import com.sirius.chat.core.common.AppDispatchers
import com.sirius.chat.data.local.db.dao.ChatDao
import com.sirius.chat.data.local.db.entity.ChatMessageEntity
import com.sirius.chat.data.local.db.entity.ChatSessionEntity
import com.sirius.chat.data.local.db.entity.SessionWithStats
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.ChatSession
import com.sirius.chat.domain.model.MessageAttachment
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.model.MessageStatus
import com.sirius.chat.domain.model.ToolRun
import com.sirius.chat.domain.repository.ChatRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
private data class AttachmentDto(
    val id: String,
    val name: String,
    val uri: String,
    val sizeBytes: Long = 0L,
    val language: String? = null
)

@Serializable
private data class ToolRunDto(
    val id: String,
    val toolName: String,
    val argumentsPreview: String,
    val output: String,
    val success: Boolean,
    val durationMs: Long = 0L
)

class ChatRepositoryImpl(
    private val dao: ChatDao,
    private val dispatchers: AppDispatchers
) : ChatRepository {

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    override fun observeSessions(projectId: String?): Flow<List<ChatSession>> {
        val source = if (projectId == null) dao.observeSessions() else dao.observeSessionsForProject(projectId)
        return source.map { list -> list.map { it.toDomain() } }
    }

    override fun observeMessages(sessionId: String): Flow<List<ChatMessage>> =
        dao.observeMessages(sessionId).map { list -> list.map { it.toDomain() } }

    override suspend fun getSession(id: String): ChatSession? = withContext(dispatchers.io) {
        dao.getSession(id)?.toDomain()
    }

    override suspend fun createSession(session: ChatSession): ChatSession = withContext(dispatchers.io) {
        dao.upsertSession(session.toEntity())
        session
    }

    /**
     * Updates the session's metadata only.
     *
     * A targeted UPDATE rather than rewriting the row: the old read-draft-then-upsert
     * round-trip could lose a draft saved in between, and any full-row rewrite of a
     * parent that children cascade from is a way to delete a conversation by
     * accident.
     */
    override suspend fun updateSession(session: ChatSession) = withContext(dispatchers.io) {
        dao.updateSessionMeta(
            id = session.id,
            title = session.title,
            projectId = session.projectId,
            providerId = session.providerId,
            model = session.model,
            agentMode = session.agentMode,
            pinned = session.pinned,
            updatedAt = System.currentTimeMillis()
        )
    }

    override suspend fun deleteSession(id: String) = withContext(dispatchers.io) {
        dao.deleteSession(id)
    }

    override suspend fun setPinned(id: String, pinned: Boolean) = withContext(dispatchers.io) {
        dao.setPinned(id, pinned)
    }

    override suspend fun messages(sessionId: String): List<ChatMessage> = withContext(dispatchers.io) {
        dao.messages(sessionId).map { it.toDomain() }
    }

    override suspend fun addMessage(message: ChatMessage) = withContext(dispatchers.io) {
        dao.insertMessageAndTouch(message.toEntity(), System.currentTimeMillis())
    }

    override suspend fun updateMessage(message: ChatMessage) = withContext(dispatchers.io) {
        dao.upsertMessage(message.toEntity())
    }

    override suspend fun deleteMessage(id: String) = withContext(dispatchers.io) {
        dao.deleteMessage(id)
    }

    /**
     * Deletes [messageId] and everything after it.
     *
     * By position, not by timestamp. The old `createdAt >= t` deleted every message
     * sharing that millisecond, so regenerating an answer that arrived in the same
     * millisecond as the question deleted the question as well -- the user watched
     * part of the conversation vanish.
     */
    override suspend fun truncateFrom(sessionId: String, messageId: String) = withContext(dispatchers.io) {
        val ordered = dao.messageIdsOrdered(sessionId)
        val from = ordered.indexOf(messageId)
        if (from < 0) return@withContext
        // Chunked: SQLite caps the number of bound parameters in one statement.
        ordered.drop(from).chunked(400).forEach { dao.deleteByIds(it) }
    }

    override suspend fun saveDraft(sessionId: String, draft: String) = withContext(dispatchers.io) {
        dao.setDraft(sessionId, draft)
    }

    override suspend fun draft(sessionId: String): String = withContext(dispatchers.io) {
        dao.draft(sessionId).orEmpty()
    }

    private fun SessionWithStats.toDomain() = ChatSession(
        id = id,
        title = title,
        projectId = projectId,
        providerId = providerId,
        model = model,
        agentMode = agentMode,
        createdAt = createdAt,
        updatedAt = updatedAt,
        pinned = pinned,
        messageCount = messageCount,
        lastMessagePreview = lastMessagePreview.orEmpty().lineSequence().firstOrNull().orEmpty().take(120)
    )

    private fun ChatSessionEntity.toDomain() = ChatSession(
        id = id,
        title = title,
        projectId = projectId,
        providerId = providerId,
        model = model,
        agentMode = agentMode,
        createdAt = createdAt,
        updatedAt = updatedAt,
        pinned = pinned
    )

    private fun ChatSession.toEntity(keepDraft: String = "") = ChatSessionEntity(
        id = id,
        title = title,
        projectId = projectId,
        providerId = providerId,
        model = model,
        agentMode = agentMode,
        createdAt = createdAt,
        updatedAt = updatedAt,
        pinned = pinned,
        draft = keepDraft
    )

    private fun ChatMessageEntity.toDomain() = ChatMessage(
        id = id,
        sessionId = sessionId,
        role = MessageRole.entries.firstOrNull { it.name == role } ?: MessageRole.Assistant,
        content = content,
        createdAt = createdAt,
        model = model,
        providerId = providerId,
        status = MessageStatus.entries.firstOrNull { it.name == status } ?: MessageStatus.Complete,
        error = error,
        attachments = decodeAttachments(attachmentsJson),
        toolRuns = decodeToolRuns(toolRunsJson)
    )

    private fun ChatMessage.toEntity() = ChatMessageEntity(
        id = id,
        sessionId = sessionId,
        role = role.name,
        content = content,
        createdAt = createdAt,
        model = model,
        providerId = providerId,
        status = status.name,
        error = error,
        attachmentsJson = json.encodeToString(
            attachments.map { AttachmentDto(it.id, it.name, it.uri, it.sizeBytes, it.language) }
        ),
        toolRunsJson = json.encodeToString(
            toolRuns.map { ToolRunDto(it.id, it.toolName, it.argumentsPreview, it.output, it.success, it.durationMs) }
        )
    )

    private fun decodeAttachments(raw: String): List<MessageAttachment> = runCatching {
        json.decodeFromString<List<AttachmentDto>>(raw)
            .map { MessageAttachment(it.id, it.name, it.uri, it.sizeBytes, it.language) }
    }.getOrDefault(emptyList())

    private fun decodeToolRuns(raw: String): List<ToolRun> = runCatching {
        json.decodeFromString<List<ToolRunDto>>(raw)
            .map { ToolRun(it.id, it.toolName, it.argumentsPreview, it.output, it.success, it.durationMs) }
    }.getOrDefault(emptyList())
}
