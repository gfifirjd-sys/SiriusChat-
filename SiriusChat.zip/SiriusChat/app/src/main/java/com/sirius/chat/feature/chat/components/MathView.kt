package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.util.MathNode
import com.sirius.chat.core.util.MathParser

/**
 * A LaTeX subset, rendered with layout instead of a font.
 *
 * There is no maths renderer available to the project and pulling one in for a
 * chat bubble is not worth the size, so this covers what actually shows up in
 * assistant answers: fractions, powers, indices, roots, greek letters and the
 * common operators. A fraction is a `Column` with a rule between two rows, a
 * power is a smaller `Text` raised by layout — no glyph tricks, so it stays
 * readable at any font scale.
 *
 * Anything unrecognised degrades to its own source text rather than vanishing:
 * seeing `\oint` beats seeing nothing where an integral should be.
 */
@Composable
fun MathView(
    latex: String,
    modifier: Modifier = Modifier,
    baseStyle: TextStyle
) {
    val colors = SiriusTheme.colors
    val lines = remember(latex) { MathParser.parse(latex) }
    val scroll = rememberScrollState()

    Column(
        modifier = modifier
            .padding(vertical = SiriusSpacing.xxs)
            .horizontalScroll(scroll),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
    ) {
        lines.forEach { line ->
            MathRow(nodes = line, style = baseStyle, color = colors.textPrimary, size = baseStyle.fontSize)
        }
    }
}

/** Inline-sized variant for maths inside a sentence. */
@Composable
fun MathInline(latex: String, baseStyle: TextStyle) {
    val colors = SiriusTheme.colors
    val lines = remember(latex) { MathParser.parse(latex) }
    MathRow(
        nodes = lines.firstOrNull().orEmpty(),
        style = baseStyle,
        color = colors.textPrimary,
        size = baseStyle.fontSize
    )
}

@Composable
private fun MathRow(
    nodes: List<MathNode>,
    style: TextStyle,
    color: androidx.compose.ui.graphics.Color,
    size: TextUnit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        nodes.forEach { node -> MathNodeView(node, style, color, size) }
    }
}

@Composable
private fun MathNodeView(
    node: MathNode,
    style: TextStyle,
    color: androidx.compose.ui.graphics.Color,
    size: TextUnit
) {
    val colors = SiriusTheme.colors
    when (node) {
        is MathNode.Sym -> Text(
            text = node.text,
            style = style.copy(
                fontSize = size,
                // Variables are italic serif and operators are upright: that
                // contrast is how a reader tells `d` the variable from `d` the
                // differential without any extra markup.
                fontFamily = FontFamily.Serif,
                fontStyle = if (node.italic) FontStyle.Italic else FontStyle.Normal
            ),
            color = color
        )

        is MathNode.TextRun -> Text(
            text = node.text,
            style = style.copy(fontSize = size, fontFamily = FontFamily.Default),
            color = color
        )

        is MathNode.Group -> MathRow(node.body, style, color, size)

        is MathNode.Frac -> Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 3.dp)
        ) {
            MathRow(node.numerator, style, color, size * 0.92f)
            Spacer(
                Modifier
                    .padding(vertical = 2.dp)
                    .height(1.dp)
                    .width(fracRuleWidth(node))
                    .background(color)
            )
            MathRow(node.denominator, style, color, size * 0.92f)
        }

        is MathNode.Script -> Row(verticalAlignment = Alignment.CenterVertically) {
            MathNodeView(node.base, style, color, size)
            Column(horizontalAlignment = Alignment.Start) {
                if (node.superscript.isNotEmpty()) {
                    Box(modifier = Modifier.padding(bottom = if (node.subscript.isEmpty()) 0.dp else 1.dp)) {
                        MathRow(node.superscript, style, color, size * 0.68f)
                    }
                }
                if (node.subscript.isNotEmpty()) {
                    MathRow(node.subscript, style, color, size * 0.68f)
                }
            }
        }

        is MathNode.Sqrt -> Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "\u221A",
                style = style.copy(fontSize = size * 1.15f, fontFamily = FontFamily.Serif),
                color = color
            )
            Column {
                Spacer(
                    Modifier
                        .height(1.dp)
                        .width(sqrtRuleWidth(node))
                        .background(color)
                )
                MathRow(node.body, style, color, size)
            }
        }

        is MathNode.Fenced -> Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = node.open,
                style = style.copy(fontSize = size * 1.1f, fontFamily = FontFamily.Serif),
                color = colors.textSecondary
            )
            MathRow(node.body, style, color, size)
            Text(
                text = node.close,
                style = style.copy(fontSize = size * 1.1f, fontFamily = FontFamily.Serif),
                color = colors.textSecondary
            )
        }
    }
}

/**
 * Fraction rules are sized from the character count of the wider side. Measuring
 * the real text would be exact but needs a second layout pass per fraction; at
 * these sizes the estimate is within a pixel or two and never leaves the rule
 * shorter than the digits above it.
 */
private fun fracRuleWidth(frac: MathNode.Frac): androidx.compose.ui.unit.Dp {
    val chars = maxOf(MathParser.widthOf(frac.numerator), MathParser.widthOf(frac.denominator))
    return (chars * 7 + 4).dp
}

private fun sqrtRuleWidth(sqrt: MathNode.Sqrt): androidx.compose.ui.unit.Dp =
    (MathParser.widthOf(sqrt.body) * 7 + 2).dp
