package com.sirius.chat.ai.context

import com.sirius.chat.domain.model.MessageAttachment
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.repository.WorkspaceRepository

/**
 * Turns the workspace and any attached files into a compact prompt fragment.
 * The snapshot is cached per project because walking a tree is the single most
 * expensive thing the app does.
 */
class ProjectContextBuilder(private val workspace: WorkspaceRepository) {

    private data class CacheEntry(val treeUri: String, val summary: String, val createdAt: Long)

    private var cache: CacheEntry? = null

    suspend fun projectSummary(project: Project?, forceRefresh: Boolean = false): String? {
        val tree = project?.treeUri ?: return null
        val cached = cache
        val fresh = cached != null &&
            cached.treeUri == tree &&
            System.currentTimeMillis() - cached.createdAt < CACHE_TTL_MS
        if (fresh && !forceRefresh) return cached?.summary

        val snapshot = workspace.snapshot(tree, maxEntries = 300)
        val summary = SystemPrompts.snapshotSummary(snapshot)
        cache = CacheEntry(tree, summary, System.currentTimeMillis())
        return summary
    }

    fun invalidate() {
        cache = null
    }

    /** Inlines attached files, budget-limited so a big file cannot blow the context. */
    suspend fun attachmentsBlock(
        treeUri: String?,
        attachments: List<MessageAttachment>,
        budgetChars: Int = 20_000
    ): String {
        if (treeUri == null || attachments.isEmpty()) return ""
        var remaining = budgetChars
        return buildString {
            attachments.forEach { attachment ->
                if (remaining <= 0) return@forEach
                val content = workspace.readText(treeUri, attachment.uri, maxBytes = remaining.toLong())
                if (content.isBlank()) return@forEach
                val trimmed = content.take(remaining)
                remaining -= trimmed.length
                appendLine("--- ${attachment.name} ---")
                appendLine(trimmed)
                appendLine()
            }
        }
    }

    private companion object {
        const val CACHE_TTL_MS = 60_000L
    }
}
