package com.sirius.chat.domain.model

/**
 * A node of the workspace tree. Backed by SAF, identified by its document id so
 * it can be re-resolved cheaply without keeping heavyweight objects in memory.
 */
data class FileNode(
    val documentId: String,
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val sizeBytes: Long = 0L,
    val lastModified: Long = 0L,
    val mimeType: String = ""
) {
    val extension: String
        get() = name.substringAfterLast('.', "").lowercase()
}

/** A single hit of a workspace-wide text search. */
data class TextMatch(
    val documentId: String,
    val path: String,
    val lineNumber: Int,
    val line: String
)

enum class FileSort { Name, Modified, Size, Type }

/** Aggregated snapshot used by the agent to reason about a project. */
data class ProjectSnapshot(
    val rootName: String,
    val fileCount: Int,
    val directoryCount: Int,
    val totalBytes: Long,
    val languages: Map<String, Int>,
    val tree: String,
    val truncated: Boolean
)
