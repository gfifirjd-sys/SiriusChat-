package com.sirius.chat.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.sirius.chat.data.local.db.dao.ChatDao
import com.sirius.chat.data.local.db.dao.ProjectDao
import com.sirius.chat.data.local.db.entity.ChatMessageEntity
import com.sirius.chat.data.local.db.entity.ChatSessionEntity
import com.sirius.chat.data.local.db.entity.ProjectEntity
import com.sirius.chat.data.local.db.entity.RecentFileEntity

@Database(
    entities = [
        ProjectEntity::class,
        RecentFileEntity::class,
        ChatSessionEntity::class,
        ChatMessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SiriusDatabase : RoomDatabase() {

    abstract fun projectDao(): ProjectDao
    abstract fun chatDao(): ChatDao

    companion object {
        fun build(context: Context): SiriusDatabase = Room
            .databaseBuilder(context.applicationContext, SiriusDatabase::class.java, "sirius.db")
            .fallbackToDestructiveMigration()
            .build()
    }
}
