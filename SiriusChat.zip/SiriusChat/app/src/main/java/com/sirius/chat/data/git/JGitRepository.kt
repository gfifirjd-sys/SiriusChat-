package com.sirius.chat.data.git

import com.sirius.chat.R
import com.sirius.chat.core.common.AppDispatchers
import com.sirius.chat.core.common.Outcome
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.core.util.DiffEngine
import com.sirius.chat.domain.model.FileDiff
import com.sirius.chat.domain.model.GitBranch
import com.sirius.chat.domain.model.GitChangeType
import com.sirius.chat.domain.model.GitCommit
import com.sirius.chat.domain.model.GitFileStatus
import com.sirius.chat.domain.model.GitStatus
import com.sirius.chat.domain.model.GitUnavailable
import com.sirius.chat.domain.repository.GitAvailability
import com.sirius.chat.domain.repository.GitRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.eclipse.jgit.api.Git
import org.eclipse.jgit.diff.DiffEntry
import org.eclipse.jgit.diff.DiffFormatter
import org.eclipse.jgit.lib.Constants
import org.eclipse.jgit.lib.ObjectId
import org.eclipse.jgit.lib.PersonIdent
import org.eclipse.jgit.lib.Repository
import org.eclipse.jgit.revwalk.RevCommit
import org.eclipse.jgit.revwalk.RevWalk
import org.eclipse.jgit.storage.file.WindowCacheConfig
import org.eclipse.jgit.treewalk.CanonicalTreeParser
import org.eclipse.jgit.treewalk.EmptyTreeIterator
import org.eclipse.jgit.util.io.DisabledOutputStream
import java.io.File

/**
 * Local git through JGit, addressed by SAF tree uri.
 *
 * Three things shape this class:
 *
 * 1. JGit is a desktop library. It expects `~/.gitconfig`, `/etc/gitconfig` and
 *    a hostname, none of which exist meaningfully on Android, so a
 *    [SystemReader] replacement is installed once before any repository opens.
 * 2. A repository is opened per call and closed again. Holding one open across
 *    the screen's lifetime would keep packfile windows and index locks alive
 *    while the user is somewhere else in the app, and reopening costs a stat.
 * 3. Every call is serialised. Git's index is a single file guarded by
 *    `index.lock`; two concurrent stages would make one of them fail with a
 *    lock error that the user can do nothing about.
 *
 * Diffs are computed with the app's own [DiffEngine] over blob contents rather
 * than JGit's formatter, so git diffs render through the same hunk model as
 * agent changes and the review screen.
 */
class JGitRepository(
    private val resolver: WorkspacePathResolver,
    private val dispatchers: AppDispatchers
) : GitRepository {

    private val lock = Mutex()

    override suspend fun availability(treeUri: String?): GitAvailability =
        withContext(dispatchers.io) {
            AndroidGitEnvironment.install()
            if (treeUri.isNullOrBlank()) return@withContext GitAvailability.Unavailable(GitUnavailable.NoWorkspace)
            val dir = resolver.resolve(treeUri)
                ?: return@withContext GitAvailability.Unavailable(
                    GitUnavailable.NotOnFilesystem(treeUri.substringAfterLast('/'))
                )
            if (!resolver.hasFileAccess()) {
                return@withContext GitAvailability.Unavailable(GitUnavailable.NeedsPermission)
            }
            if (!dir.isDirectory) {
                return@withContext GitAvailability.Unavailable(GitUnavailable.NotOnFilesystem(dir.name))
            }
            if (!File(dir, Constants.DOT_GIT).exists()) {
                return@withContext GitAvailability.Unavailable(GitUnavailable.NotARepository(dir.path))
            }
            try {
                Git.open(dir).use { it.repository.objectDatabase.exists() }
                GitAvailability.Ready(dir.path)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                GitAvailability.Unavailable(GitUnavailable.Broken(t.reason()))
            }
        }

    override suspend fun status(treeUri: String, historyLimit: Int): Outcome<GitStatus> =
        withGit(treeUri) { git ->
            val repo = git.repository
            val jgitStatus = git.status().call()
            val files = collectFiles(jgitStatus)
            val head = repo.resolve(Constants.HEAD)
            val detached = repo.exactRef(Constants.HEAD)?.isSymbolic == false
            GitStatus(
                branch = repo.branch.orEmpty(),
                detachedHead = detached,
                files = files,
                commits = if (head == null) emptyList() else history(git, historyLimit),
                branches = branches(git),
                unborn = head == null
            )
        }

    override suspend fun init(treeUri: String): Outcome<Unit> = withDir(treeUri) { dir ->
        Git.init().setDirectory(dir).call().use { git ->
            // Shared storage is usually exFAT or a fuse mount with no exec bit,
            // where mode tracking would report every file as modified.
            git.repository.config.apply {
                setBoolean("core", null, "fileMode", false)
                save()
            }
        }
    }

    override suspend fun stage(treeUri: String, paths: List<String>): Outcome<Unit> =
        withGit(treeUri) { git ->
            val workTree = git.repository.workTree
            // A path deleted from disk cannot be staged with `add`: the deletion
            // is recorded by removing the entry from the index instead.
            val (gone, present) = paths.partition { !File(workTree, it).exists() }
            if (present.isNotEmpty()) {
                git.add().apply { present.forEach { addFilepattern(it) } }.call()
            }
            if (gone.isNotEmpty()) {
                git.rm().setCached(true).apply { gone.forEach { addFilepattern(it) } }.call()
            }
        }

    override suspend fun unstage(treeUri: String, paths: List<String>): Outcome<Unit> =
        withGit(treeUri) { git ->
            if (git.repository.resolve(Constants.HEAD) == null) {
                // Nothing to reset to before the first commit; dropping the
                // index entry returns the file to untracked, which is what
                // unstaging means here.
                git.rm().setCached(true).apply { paths.forEach { addFilepattern(it) } }.call()
            } else {
                git.reset()
                    .setRef(Constants.HEAD)
                    .apply { paths.forEach { addPath(it) } }
                    .call()
            }
        }

    override suspend fun discard(treeUri: String, paths: List<String>): Outcome<Unit> =
        withGit(treeUri) { git ->
            val repo = git.repository
            val index = repo.readDirCache()
            val tracked = paths.filter { index.findEntry(it) >= 0 }
            val untracked = paths - tracked.toSet()
            if (tracked.isNotEmpty()) {
                git.checkout().apply { tracked.forEach { addPath(it) } }.call()
            }
            // `checkout` has nothing to restore an untracked file from, so the
            // only way to discard it is to remove it.
            untracked.forEach { path ->
                val file = File(repo.workTree, path)
                if (file.isFile) file.delete()
            }
        }

    override suspend fun commit(treeUri: String, message: String, amend: Boolean): Outcome<GitCommit> =
        withGit(treeUri) { git ->
            require(message.isNotBlank()) {
                AppStrings.get(R.string.git_error_empty_message, fallback = "Commit message is empty")
            }
            val repo = git.repository
            require(!(amend && repo.resolve(Constants.HEAD) == null)) {
                AppStrings.get(R.string.git_error_nothing_to_amend, fallback = "Nothing to amend")
            }
            val commit = git.commit()
                .setMessage(message)
                .setAmend(amend)
                .setAuthor(identity(repo))
                .setCommitter(identity(repo))
                .call()
            commit.toModel()
        }

    override suspend fun diff(treeUri: String, path: String, staged: Boolean): Outcome<FileDiff> =
        withGit(treeUri) { git ->
            val repo = git.repository
            val headBytes = repo.blobAt("${Constants.HEAD}:$path")
            val indexBytes = repo.indexBlob(path)
            val old: ByteArray?
            val new: ByteArray?
            if (staged) {
                old = headBytes
                new = indexBytes
            } else {
                old = indexBytes ?: headBytes
                new = File(repo.workTree, path).takeIf { it.isFile }?.let { file ->
                    if (file.length() > MAX_DIFF_BYTES) BINARY_MARKER else file.readBytes()
                }
            }
            if (old.isBinary() || new.isBinary()) {
                FileDiff(path = path, hunks = emptyList(), added = 0, removed = 0, binary = true)
            } else {
                DiffEngine.diff(path, old?.decode(), new?.decode())
            }
        }

    override suspend fun createBranch(treeUri: String, name: String): Outcome<Unit> =
        withGit(treeUri) { git ->
            require(Repository.isValidRefName("${Constants.R_HEADS}$name")) {
                AppStrings.get(R.string.git_error_invalid_branch_name, fallback = "Invalid branch name")
            }
            require(git.repository.resolve(Constants.HEAD) != null) {
                AppStrings.get(R.string.git_error_commit_first, fallback = "Commit something first")
            }
            git.checkout().setCreateBranch(true).setName(name).call()
        }

    override suspend fun checkout(treeUri: String, name: String): Outcome<Unit> =
        withGit(treeUri) { git -> git.checkout().setName(name).call() }

    override suspend fun commitDetail(treeUri: String, id: String): Outcome<GitCommit> =
        withGit(treeUri) { git ->
            val repo = git.repository
            val objectId = repo.resolve(id) ?: error(
                AppStrings.format(
                    R.string.git_error_unknown_commit,
                    id,
                    fallback = "Unknown commit $id"
                )
            )
            RevWalk(repo).use { walk -> walk.parseCommit(objectId).toModel() }
        }

    override suspend fun commitFiles(treeUri: String, id: String): Outcome<List<String>> =
        withGit(treeUri) { git ->
            val repo = git.repository
            val objectId = repo.resolve(id) ?: error(
                AppStrings.format(
                    R.string.git_error_unknown_commit,
                    id,
                    fallback = "Unknown commit $id"
                )
            )
            RevWalk(repo).use { walk ->
                val commit = walk.parseCommit(objectId)
                repo.newObjectReader().use { reader ->
                    val newTree = CanonicalTreeParser(null, reader, commit.tree)
                    val oldTree = if (commit.parentCount > 0) {
                        CanonicalTreeParser(null, reader, walk.parseCommit(commit.getParent(0)).tree)
                    } else {
                        EmptyTreeIterator()
                    }
                    DiffFormatter(DisabledOutputStream.INSTANCE).use { formatter ->
                        formatter.setRepository(repo)
                        formatter.scan(oldTree, newTree).map { entry ->
                            if (entry.changeType == DiffEntry.ChangeType.DELETE) entry.oldPath else entry.newPath
                        }
                    }
                }
            }
        }

    // ------------------------------------------------------------------ status

    private fun collectFiles(status: org.eclipse.jgit.api.Status): List<GitFileStatus> {
        val staged = mutableMapOf<String, GitChangeType>()
        status.added.forEach { staged[it] = GitChangeType.Added }
        status.changed.forEach { staged[it] = GitChangeType.Modified }
        status.removed.forEach { staged[it] = GitChangeType.Deleted }

        val unstaged = mutableMapOf<String, GitChangeType>()
        status.modified.forEach { unstaged[it] = GitChangeType.Modified }
        status.missing.forEach { unstaged[it] = GitChangeType.Deleted }
        status.untracked.forEach { unstaged[it] = GitChangeType.Untracked }

        status.conflicting.forEach {
            staged[it] = GitChangeType.Conflicted
            unstaged[it] = GitChangeType.Conflicted
        }

        return (staged.keys + unstaged.keys)
            .sorted()
            .map { path ->
                GitFileStatus(path = path, staged = staged[path], unstaged = unstaged[path])
            }
    }

    private fun history(git: Git, limit: Int): List<GitCommit> =
        git.log().setMaxCount(limit).call().map { it.toModel() }

    private fun branches(git: Git): List<GitBranch> {
        val repo = git.repository
        val current = repo.fullBranch
        return RevWalk(repo).use { walk ->
            git.branchList().call().take(MAX_BRANCHES).map { ref ->
                val tip = runCatching { walk.parseCommit(ref.objectId) }.getOrNull()
                GitBranch(
                    name = Repository.shortenRefName(ref.name),
                    isCurrent = ref.name == current,
                    lastCommitMessage = tip?.shortMessage,
                    lastCommitAt = tip?.commitTime?.toLong()?.times(1000L) ?: 0L
                )
            }.sortedWith(compareByDescending<GitBranch> { it.isCurrent }.thenBy { it.name })
        }
    }

    private fun identity(repo: Repository): PersonIdent {
        val config = repo.config
        val name = config.getString("user", null, "name")?.takeIf { it.isNotBlank() } ?: FALLBACK_NAME
        val email = config.getString("user", null, "email")?.takeIf { it.isNotBlank() } ?: FALLBACK_EMAIL
        return PersonIdent(name, email)
    }

    // ------------------------------------------------------------- plumbing

    private fun RevCommit.toModel() = GitCommit(
        id = name,
        shortId = abbreviate(SHORT_ID_LENGTH).name(),
        message = fullMessage.trim(),
        authorName = authorIdent?.name.orEmpty(),
        authorEmail = authorIdent?.emailAddress.orEmpty(),
        // JGit reports commit time in seconds; the app formats milliseconds.
        timestamp = commitTime.toLong() * 1000L,
        parentCount = parentCount
    )

    private fun Repository.blobAt(revision: String): ByteArray? {
        val id: ObjectId = runCatching { resolve(revision) }.getOrNull() ?: return null
        return readBlob(id)
    }

    private fun Repository.indexBlob(path: String): ByteArray? {
        val cache = runCatching { readDirCache() }.getOrNull() ?: return null
        val entry = cache.getEntry(path) ?: return null
        return readBlob(entry.objectId)
    }

    /**
     * Loads a blob, or the binary marker when it is too large to hold in memory.
     * Loading it anyway is how a diff of a bundled apk turns into an OOM.
     */
    private fun Repository.readBlob(id: ObjectId): ByteArray? = runCatching {
        val loader = open(id, Constants.OBJ_BLOB)
        if (loader.size > MAX_DIFF_BYTES) BINARY_MARKER else loader.bytes
    }.getOrDefault(BINARY_MARKER)

    /** Git's own heuristic: a NUL byte early in the content means binary. */
    private fun ByteArray?.isBinary(): Boolean {
        if (this == null) return false
        if (size > MAX_DIFF_BYTES) return true
        val window = minOf(size, BINARY_SNIFF)
        for (i in 0 until window) if (this[i] == 0.toByte()) return true
        return false
    }

    private fun ByteArray.decode(): String = toString(Charsets.UTF_8)

    /**
     * Runs [block] with an open repository, serialised against other calls and
     * with failures turned into [Outcome.Failure].
     */
    private suspend fun <T> withGit(treeUri: String, block: (Git) -> T): Outcome<T> =
        withContext(dispatchers.io) {
            lock.withLock {
                try {
                    AndroidGitEnvironment.install()
                    val dir = resolver.resolve(treeUri) ?: error(
                        AppStrings.get(
                            R.string.git_error_not_on_filesystem,
                            fallback = "Folder is not on the filesystem"
                        )
                    )
                    Git.open(dir).use { Outcome.Success(block(it)) }
                } catch (t: Throwable) {
                    if (t is CancellationException) throw t
                    Outcome.Failure(t.reason(), t)
                }
            }
        }

    private suspend fun withDir(treeUri: String, block: (File) -> Unit): Outcome<Unit> =
        withContext(dispatchers.io) {
            lock.withLock {
                try {
                    AndroidGitEnvironment.install()
                    val dir = resolver.resolve(treeUri) ?: error(
                        AppStrings.get(
                            R.string.git_error_not_on_filesystem,
                            fallback = "Folder is not on the filesystem"
                        )
                    )
                    Outcome.Success(block(dir))
                } catch (t: Throwable) {
                    if (t is CancellationException) throw t
                    Outcome.Failure(t.reason(), t)
                }
            }
        }

    private fun Throwable.reason(): String =
        message?.takeIf { it.isNotBlank() } ?: this::class.java.simpleName

    private companion object {
        const val SHORT_ID_LENGTH = 7
        const val MAX_BRANCHES = 60
        const val MAX_DIFF_BYTES = 1L * 1024 * 1024
        const val BINARY_SNIFF = 8000
        const val FALLBACK_NAME = "Sirius Chat"
        const val FALLBACK_EMAIL = "sirius@localhost"

        /** Stand-in content for a file too large to diff. */
        val BINARY_MARKER = ByteArray(1) { 0 }
    }
}

/**
 * One-time JGit setup for Android.
 *
 * Left alone, JGit looks for `/etc/gitconfig`, `$HOME/.gitconfig` and a
 * resolvable hostname on first use. On Android the first two are unreadable
 * paths and the third is a DNS lookup, which would either throw or block a
 * thread on the network. Redirecting configuration to app-private files also
 * means the device's global git settings cannot change how this app commits.
 */
private object AndroidGitEnvironment {

    @Volatile
    private var installed = false

    @Synchronized
    fun install() {
        if (installed) return
        installed = true
        runCatching {
            org.eclipse.jgit.util.SystemReader.setInstance(
                AndroidSystemReader(org.eclipse.jgit.util.SystemReader.getInstance())
            )
            // A phone has far less memory to spare than the desktop defaults
            // assume; these caps keep packfile windows modest.
            val cache = WindowCacheConfig()
            cache.packedGitLimit = 8L * 1024 * 1024
            cache.packedGitWindowSize = 8 * 1024
            cache.isPackedGitMMAP = false
            cache.deltaBaseCacheLimit = 2 * 1024 * 1024
            cache.streamFileThreshold = 2 * 1024 * 1024
            cache.install()
        }
    }

    private class AndroidSystemReader(
        private val delegate: org.eclipse.jgit.util.SystemReader
    ) : org.eclipse.jgit.util.SystemReader() {

        override fun getHostname(): String = "localhost"
        override fun getenv(variable: String?): String? = runCatching { delegate.getenv(variable) }.getOrNull()
        override fun getProperty(key: String?): String? = runCatching { delegate.getProperty(key) }.getOrNull()
        override fun getCurrentTime(): Long = System.currentTimeMillis()
        override fun getTimezone(whenTime: Long): Int = delegate.getTimezone(whenTime)

        override fun openUserConfig(
            parent: org.eclipse.jgit.lib.Config?,
            fs: org.eclipse.jgit.util.FS?
        ): org.eclipse.jgit.storage.file.FileBasedConfig = empty(parent, fs, "user")

        override fun openSystemConfig(
            parent: org.eclipse.jgit.lib.Config?,
            fs: org.eclipse.jgit.util.FS?
        ): org.eclipse.jgit.storage.file.FileBasedConfig = empty(parent, fs, "system")

        override fun openJGitConfig(
            parent: org.eclipse.jgit.lib.Config?,
            fs: org.eclipse.jgit.util.FS?
        ): org.eclipse.jgit.storage.file.FileBasedConfig = empty(parent, fs, "jgit")

        /**
         * A config pointing at a file that will never exist. JGit treats a
         * missing file as an empty configuration, which is exactly the desired
         * "no global git settings" state, and it never writes here.
         */
        private fun empty(
            parent: org.eclipse.jgit.lib.Config?,
            fs: org.eclipse.jgit.util.FS?,
            name: String
        ) = org.eclipse.jgit.storage.file.FileBasedConfig(
            parent,
            File(System.getProperty("java.io.tmpdir") ?: "/data/local/tmp", "jgit-$name.config"),
            fs ?: org.eclipse.jgit.util.FS.DETECTED
        )
    }
}
