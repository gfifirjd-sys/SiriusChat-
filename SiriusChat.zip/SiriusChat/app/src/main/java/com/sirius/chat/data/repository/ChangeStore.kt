package com.sirius.chat.data.repository

import com.sirius.chat.domain.model.ChangeStatus
import com.sirius.chat.domain.model.PendingChange
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

/**
 * In-memory queue of agent proposals awaiting review.
 *
 * Deliberately not persisted: a proposal is only meaningful against the exact
 * file content it was computed from, so surviving a process death would risk
 * applying a stale diff.
 */
class ChangeStore {

    private val _changes = MutableStateFlow<List<PendingChange>>(emptyList())
    val changes: StateFlow<List<PendingChange>> = _changes.asStateFlow()

    val pendingCount = changes.map { list -> list.count { it.status == ChangeStatus.Pending } }

    fun submit(newChanges: List<PendingChange>) {
        if (newChanges.isEmpty()) return
        _changes.value = _changes.value.filterNot { existing ->
            newChanges.any { it.path == existing.path && existing.status == ChangeStatus.Pending }
        } + newChanges
    }

    fun pendingFor(sessionId: String): List<PendingChange> =
        _changes.value.filter { it.sessionId == sessionId && it.status == ChangeStatus.Pending }

    fun byId(id: String): PendingChange? = _changes.value.firstOrNull { it.id == id }

    fun update(change: PendingChange) {
        _changes.value = _changes.value.map { if (it.id == change.id) change else it }
    }

    fun replaceContent(id: String, newContent: String) {
        _changes.value = _changes.value.map {
            if (it.id == id) it.copy(newContent = newContent) else it
        }
    }

    fun remove(id: String) {
        _changes.value = _changes.value.filterNot { it.id == id }
    }

    fun clearResolved() {
        _changes.value = _changes.value.filter { it.status == ChangeStatus.Pending }
    }

    fun clearAll() {
        _changes.value = emptyList()
    }
}
