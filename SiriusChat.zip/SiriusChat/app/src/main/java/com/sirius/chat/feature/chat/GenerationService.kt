package com.sirius.chat.feature.chat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.sirius.chat.MainActivity
import com.sirius.chat.R
import com.sirius.chat.SiriusApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Keeps the process alive while the model is answering.
 *
 * Moving generation to the application scope stops a *screen* from killing an
 * answer, but it does not stop Android from killing the *process*: a backgrounded
 * app with no foreground component is a candidate the moment memory gets tight,
 * and on many OEM builds it is killed within seconds of leaving the app. A
 * foreground service with a visible notification is the only supported way to say
 * "there is work in progress here".
 *
 * The service starts itself when the first generation begins and stops itself when
 * the last one ends — it is a lifetime marker, not a place where logic lives. All
 * the work stays in `GenerationManager`.
 */
class GenerationService : Service() {

    private val scope = CoroutineScope(SupervisorJob())
    private var watcher: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Post the notification before anything else: Android gives a foreground
        // service a few seconds to show one and crashes the process otherwise.
        startForeground(NOTIFICATION_ID, buildNotification(title = null, count = 0))

        if (watcher == null) {
            val container = (applicationContext as SiriusApplication).container
            watcher = scope.launch {
                // `start()` registers the session asynchronously, so the map is still
                // empty for a moment after the service is asked to run. Stopping on
                // that first empty value killed the service immediately -- and with it
                // the process protection -- right at the start of every generation.
                // Only an empty map that arrives *after* work was seen means "done".
                var sawWork = false
                // Counterpart to the grace period above: if no generation ever shows
                // up (it failed before registering, say) the service must not sit
                // there forever showing a "working" notification.
                launch {
                    delay(STARTUP_GRACE_MS)
                    if (!sawWork && container.generations.streams.value.isEmpty()) stopSelf()
                }
                container.generations.streams.collectLatest { streams ->
                    if (streams.isEmpty()) {
                        if (sawWork) {
                            // Nothing left to protect. stopSelf() rather than lingering:
                            // an idle notification that says "working" is a lie.
                            stopSelf()
                        }
                        return@collectLatest
                    }
                    sawWork = true
                    val first = streams.values.firstOrNull()
                    notificationManager().notify(
                        NOTIFICATION_ID,
                        buildNotification(
                            title = first?.sessionTitle?.takeIf { it.isNotBlank() },
                            count = streams.size
                        )
                    )
                }
            }
        }
        // Not sticky: a restart after a process death has no generation to resume,
        // so it would only show a notification for work that no longer exists.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        watcher = null
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(title: String?, count: Int): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = when {
            count > 1 -> getString(R.string.generation_notice_many, count)
            title != null -> title
            else -> getString(R.string.generation_notice_body)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.generation_notice_title))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            // Low priority and silent: this is a status marker, not an event. It
            // must never buzz mid-answer.
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSilent(true)
            .setContentIntent(open)
            .build()
    }

    private fun notificationManager(): NotificationManager =
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val existing = notificationManager().getNotificationChannel(CHANNEL_ID)
        if (existing != null) return
        notificationManager().createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                getString(R.string.generation_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.generation_channel_description)
                setShowBadge(false)
            }
        )
    }

    companion object {
        private const val CHANNEL_ID = "sirius_generation"
        private const val NOTIFICATION_ID = 4201

        /** How long to wait for the first generation to register before giving up. */
        private const val STARTUP_GRACE_MS = 10_000L

        /**
         * Starts the service unless it is already up.
         *
         * Failures are swallowed on purpose: a denied notification permission or an
         * OEM background restriction must not take the answer down with it. Without
         * the service the generation still runs, it is just no longer protected from
         * being killed — degraded, not broken.
         */
        fun ensureRunning(context: Context) {
            runCatching {
                val intent = Intent(context, GenerationService::class.java)
                context.startForegroundService(intent)
            }
        }
    }
}
