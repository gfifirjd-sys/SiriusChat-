package com.sirius.chat.data.local.security

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.secureDataStore: DataStore<Preferences> by preferencesDataStore(name = "sirius_secure")

/**
 * Stores user API keys encrypted at rest. Values are only ever decrypted for
 * the duration of a request; the UI only ever learns whether a key exists.
 */
class SecureCredentialStore(context: Context) {

    private val dataStore = context.secureDataStore
    private val cipher = KeystoreCipher()

    private fun keyFor(providerId: String) = stringPreferencesKey("api_key_$providerId")
    private val idsKey = stringSetPreferencesKey("provider_ids_with_keys")

    /** Ids of providers that currently have a stored key. */
    val providersWithKeys: Flow<Set<String>> = dataStore.data
        .catch { error -> if (error is IOException) emit(emptyPreferences()) else throw error }
        .map { it[idsKey] ?: emptySet() }

    suspend fun put(providerId: String, apiKey: String) {
        val encrypted = runCatching { cipher.encrypt(apiKey) }.getOrNull() ?: return
        dataStore.edit { prefs ->
            prefs[keyFor(providerId)] = encrypted
            prefs[idsKey] = (prefs[idsKey] ?: emptySet()) + providerId
        }
    }

    suspend fun get(providerId: String): String? {
        val stored = dataStore.data.first()[keyFor(providerId)] ?: return null
        return cipher.decrypt(stored)
    }

    suspend fun has(providerId: String): Boolean = providersWithKeys.first().contains(providerId)

    suspend fun remove(providerId: String) {
        dataStore.edit { prefs ->
            prefs.remove(keyFor(providerId))
            prefs[idsKey] = (prefs[idsKey] ?: emptySet()) - providerId
        }
    }

    suspend fun clearAll() {
        dataStore.edit { it.clear() }
    }
}
