package com.sirius.chat.data.terminal

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.sirius.chat.R
import com.sirius.chat.core.locale.AppStrings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withTimeout
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

/**
 * Runs commands in a real Termux installation over its RUN_COMMAND service.
 *
 * This is the engine that makes the terminal useful for actual work: Termux has
 * a package manager, a compiler toolchain, git and a writable prefix, none of
 * which our own sandbox can offer. The price is that we are a guest — Termux
 * owns the process, so:
 *
 *  - output arrives once, when the command finishes, not as a stream;
 *  - the working directory has to be a path Termux's uid can actually read;
 *  - a running command cannot be killed from here.
 *
 * The bridge is honest about each of those instead of faking a live shell.
 *
 * Requires Termux installed and `allow-external-apps=true` in
 * `~/.termux/termux.properties`; the latter is only detectable from the error
 * Termux replies with, so it is surfaced as command output.
 */
class TermuxShellBackend(context: Context) : TerminalBackend {

    private val appContext: Context = context.applicationContext

    /** Distinguishes concurrent result broadcasts and PendingIntents. */
    private val requests = AtomicInteger(0)

    override val id: String = "termux"

    // Read on every access so the banner follows the in-app language switch.
    override val displayName: String
        get() = AppStrings.get(R.string.terminal_backend_termux_name, fallback = "Termux")

    override val description: String
        get() = AppStrings.get(
            R.string.terminal_backend_termux_description,
            fallback = "Runs commands in your Termux installation. Output arrives when the command finishes."
        )

    override val home: File = File(TERMUX_HOME)

    /** Termux runs under its own uid, so its paths are opaque to this process. */
    override val filesystemVisible: Boolean = false

    override val stopNotice: String
        get() = AppStrings.get(
            R.string.terminal_termux_stop_notice,
            fallback = "Termux keeps the command running; stop it from the Termux session."
        )

    /**
     * Whether Termux is present.
     *
     * Requires the `<queries>` entry for `com.termux` in the manifest: from
     * Android 11 package visibility hides other apps, and without the
     * declaration this returns false on a device where Termux is installed.
     */
    fun isInstalled(): Boolean = runCatching {
        appContext.packageManager.getPackageInfo(TERMUX_PACKAGE, 0)
    }.isSuccess

    /**
     * Whether this app may send commands to Termux.
     *
     * `RUN_COMMAND` is defined by Termux, not the platform, so it can only exist
     * once Termux is installed. When it is absent the permission is unknown to
     * the package manager and reports as denied, which says nothing about the
     * user's choice — hence [isInstalled] is what distinguishes the two states
     * in [unavailableReason].
     */
    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(appContext, RUN_COMMAND_PERMISSION) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * Whether this Termux build actually exposes the RUN_COMMAND service.
     *
     * The abandoned Play Store build of Termux, and any build with the plugin
     * disabled, installs as `com.termux` but has no `RunCommandService`. Sending
     * to it fails at the `startForegroundService` call, which used to surface as
     * a generic "cannot reach Termux", so it is checked up front instead — this
     * is the one Termux misconfiguration that is detectable without running a
     * command.
     */
    fun hasRunCommandService(): Boolean = runCatching {
        val probe = Intent().apply {
            setClassName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
            action = ACTION_RUN_COMMAND
        }
        appContext.packageManager.resolveService(probe, 0) != null
    }.getOrDefault(false)

    override fun isAvailable(): Boolean =
        isInstalled() && hasPermission() && hasRunCommandService()

    /**
     * Intent that takes the user to where this permission can actually be granted.
     *
     * `RUN_COMMAND` is a normal-protection permission belonging to another app,
     * so [android.app.Activity.requestPermissions] never shows a dialog for it —
     * the system returns "denied" immediately and the request looks like a
     * no-op button. The only place it can be toggled is this app's own App Info
     * screen, under Additional permissions, so that is where we send the user.
     *
     * The settings screen is guaranteed present, but the caller still needs the
     * launch guarded: [android.content.ActivityNotFoundException] is possible on
     * devices with a stripped-down Settings app.
     */
    fun permissionSettingsIntent(): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", appContext.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

    /**
     * Intent that opens Termux itself, so the user can create the properties file.
     *
     * `allow-external-apps=true` cannot be set from outside Termux, and its
     * absence is only visible in the error Termux returns, so the fix has to be
     * performed by hand in a Termux session. Null when Termux is absent.
     */
    fun launchTermuxIntent(): Intent? =
        appContext.packageManager.getLaunchIntentForPackage(TERMUX_PACKAGE)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /**
     * Intent that opens a page where Termux can be installed.
     *
     * F-Droid rather than Play: the Play build was abandoned in 2020 and cannot
     * run the RUN_COMMAND service the bridge depends on, so sending the user
     * there would produce an install that still does not work.
     */
    fun installTermuxIntent(): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse(TERMUX_INSTALL_URL))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    override fun unavailableReason(): String? = when {
        !isInstalled() -> AppStrings.get(
            R.string.terminal_termux_not_installed,
            fallback = "Termux is not installed on this device."
        )

        !hasPermission() -> AppStrings.get(
            R.string.terminal_termux_permission_missing,
            fallback = "Sirius needs the Termux RUN_COMMAND permission to send commands."
        )

        !hasRunCommandService() -> AppStrings.get(
            R.string.terminal_termux_no_run_command,
            fallback = "This Termux build cannot accept external commands. " +
                "Install Termux from F-Droid or GitHub."
        )

        else -> null
    }

    override fun execute(command: String, workingDirectory: File): Flow<TerminalEvent> = flow {
        val startedAt = System.currentTimeMillis()

        unavailableReason()?.let { reason ->
            emit(TerminalEvent.Failed(reason))
            return@flow
        }

        // Termux requires a unique request code per PendingIntent: reusing one
        // lets Android hand back the earlier instance, and only the first
        // command of the session would ever report a result.
        val executionId = requests.incrementAndGet()
        val token = TermuxResultsBridge.newToken()

        // Registered before the command is sent, so a command that finishes
        // instantly cannot deliver its result into a void.
        val pending = TermuxResultsBridge.expect(appContext, executionId, token)

        val workdir = termuxWorkdir(workingDirectory)
        if (workdir != workingDirectory.absolutePath) {
            emit(
                TerminalEvent.Notice(
                    AppStrings.format(
                        R.string.terminal_termux_workdir_substituted,
                        workdir,
                        fallback = "Termux cannot read the app sandbox; running in $workdir."
                    )
                )
            )
        }

        val callback = runCatching { resultCallback(executionId, token) }.getOrNull()
        if (callback == null) {
            TermuxResultsBridge.forget(executionId)
            emit(TerminalEvent.Failed(bridgeFailure()))
            return@flow
        }

        val request = Intent().apply {
            setClassName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
            action = ACTION_RUN_COMMAND
            // bash rather than the command itself: the input is a shell line
            // with pipes, quoting and variables, not a bare executable path.
            putExtra(EXTRA_COMMAND_PATH, "$TERMUX_PREFIX/bin/bash")
            putExtra(EXTRA_ARGUMENTS, arrayOf("-c", command))
            putExtra(EXTRA_WORKDIR, workdir)
            // "app-shell" runs the command headless and reports stdout and stderr
            // back separately. A terminal session would open Termux in the
            // foreground and return one interleaved transcript with prompts in it
            // — and on current builds it never reports a result at all, because a
            // session has no completion to report.
            //
            // Both extras are sent: EXTRA_RUNNER is what current Termux reads,
            // EXTRA_BACKGROUND is the older equivalent it falls back to. Sending
            // only the legacy flag is fine today but silently degrades to a
            // foreground session on a build that dropped it.
            putExtra(EXTRA_RUNNER, RUNNER_APP_SHELL)
            putExtra(EXTRA_BACKGROUND, true)
            putExtra(EXTRA_PENDING_INTENT, callback)
            // Shown to the user by Termux if it has to report a problem.
            putExtra(EXTRA_COMMAND_LABEL, COMMAND_LABEL)
        }

        val started = runCatching {
            // RunCommandService calls startForeground() in onCreate, so on API 26+
            // it must be started as a foreground service. A plain startService is
            // rejected outright once this app is not itself in the foreground,
            // which is exactly the case while a command is running.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(request)
            } else {
                appContext.startService(request)
            }
        }

        if (started.isFailure) {
            TermuxResultsBridge.forget(executionId)
            callback.cancel()
            emit(TerminalEvent.Failed(startFailure(started.exceptionOrNull())))
            return@flow
        }

        emit(TerminalEvent.Started(command, null))

        // Termux reports only when the command finishes, so this suspends for as
        // long as the command runs. Cancelling the flow drops the registration
        // rather than leaving a slot that a later result could resume.
        //
        // The wait is bounded. Termux gives no progress signal, so a result that
        // never arrives — Termux killed mid-command, or the callback refused by
        // the system — is indistinguishable from a command still running, and an
        // unbounded await left the terminal on "running" with no way back. The
        // cap is deliberately generous because a package install or a build
        // legitimately takes minutes.
        val result = try {
            withTimeout(RESULT_TIMEOUT_MS) { pending.await() }
        } catch (timeout: TimeoutCancellationException) {
            TermuxResultsBridge.forget(executionId)
            callback.cancel()
            emit(TerminalEvent.Failed(timeoutFailure()))
            return@flow
        } catch (cancellation: CancellationException) {
            TermuxResultsBridge.forget(executionId)
            callback.cancel()
            throw cancellation
        }

        eventsFrom(result, startedAt).forEach { emit(it) }
    }.flowOn(Dispatchers.IO)

    /**
     * PendingIntent Termux uses to hand the result back.
     *
     * A **broadcast**, not a service. Termux calls `send()` on this from its own
     * process, but the send runs with our identity, so a service PendingIntent
     * means `startService` by this app — refused since Android 8 whenever this
     * app is not in a foreground state. Termux's `ResultSender` only catches
     * `CanceledException`, so that refusal escapes as an `IllegalStateException`,
     * the result is never delivered and the await below never returns. A
     * broadcast to the receiver registered in [TermuxResultsBridge] has no such
     * restriction.
     *
     * Explicitly limited to our own package so the broadcast cannot be observed
     * by another app. Mutable because Termux writes the result bundle into it;
     * one-shot because it carries exactly one result.
     */
    private fun resultCallback(executionId: Int, token: String): PendingIntent {
        val delivery = Intent(TermuxResultsBridge.ACTION_RESULT)
            .setPackage(appContext.packageName)
            .putExtra(TermuxResultsBridge.EXTRA_EXECUTION_ID, executionId)
            .putExtra(TermuxResultsBridge.EXTRA_TOKEN, token)
        val mutable =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        return PendingIntent.getBroadcast(
            appContext,
            executionId,
            delivery,
            PendingIntent.FLAG_ONE_SHOT or mutable
        )
    }

    /**
     * States the two causes the user can act on: the properties flag, and Termux
     * having been killed by the system while the command ran.
     */
    private fun timeoutFailure(): String = AppStrings.format(
        R.string.terminal_termux_timeout,
        RESULT_TIMEOUT_MS / 60_000,
        fallback = "Termux never reported a result. Check that " +
            "allow-external-apps=true is set in ~/.termux/termux.properties and " +
            "that Termux was not stopped while the command ran."
    )

    private fun bridgeFailure(): String = AppStrings.get(
        R.string.terminal_termux_bridge_failed,
        fallback = "Cannot reach Termux. Check that allow-external-apps=true is set."
    )

    /**
     * Termux refusing the request is the common first-run failure, and the raw
     * exception ("Not allowed to start service Intent") explains nothing, so the
     * actionable cause is stated with it rather than instead of it.
     */
    private fun startFailure(error: Throwable?): String {
        val detail = error?.message?.takeIf { it.isNotBlank() }
        return if (detail == null) bridgeFailure() else "${bridgeFailure()} ($detail)"
    }

    /**
     * Termux runs as a different uid and cannot read this app's private files,
     * so a sandbox path is replaced with the Termux home rather than handed
     * over to fail. Shared storage is passed through untouched.
     */
    private fun termuxWorkdir(requested: File): String {
        val path = runCatching { requested.canonicalPath }.getOrDefault(requested.absolutePath)
        val reachable = path.startsWith(TERMUX_FILES) ||
            path.startsWith("/sdcard") ||
            path.startsWith("/storage")
        return if (reachable) path else TERMUX_HOME
    }

    /**
     * Termux replies with one bundle holding the whole run. Output is split back
     * into lines so the log renders and scrolls like streamed output would.
     */
    private fun eventsFrom(result: Bundle?, startedAt: Long): List<TerminalEvent> {
        val duration = System.currentTimeMillis() - startedAt

        if (result == null) {
            return listOf(
                TerminalEvent.Failed(
                    AppStrings.get(
                        R.string.terminal_termux_no_result,
                        fallback = "Termux returned no result for this command."
                    )
                )
            )
        }

        val events = mutableListOf<TerminalEvent>()
        val stdout = result.getString(KEY_STDOUT).orEmpty()
        val stderr = result.getString(KEY_STDERR).orEmpty()

        stdout.lineSequence().dropTrailingBlank().forEach { events += TerminalEvent.Stdout(it) }
        stderr.lineSequence().dropTrailingBlank().forEach { events += TerminalEvent.Stderr(it) }

        // Termux caps what fits in a single binder transaction; a build log that
        // lost its tail must say so, or the user debugs a phantom.
        truncationNotice(stdout, result.getString(KEY_STDOUT_ORIGINAL_LENGTH))?.let {
            events += TerminalEvent.Notice(it)
        }

        // Plugin-level failures (allow-external-apps off, bad path) come back
        // here rather than on stderr, and are the most common first-run problem.
        val errno = result.getInt(KEY_ERR, ERRNO_SUCCESS)
        val errmsg = result.getString(KEY_ERRMSG).orEmpty()
        if (errno != ERRNO_SUCCESS && errmsg.isNotBlank()) {
            errmsg.lineSequence().dropTrailingBlank().forEach { events += TerminalEvent.Stderr(it) }
        }

        events += TerminalEvent.Exited(result.getInt(KEY_EXIT_CODE, -1), duration)
        return events
    }

    private fun truncationNotice(received: String, originalLength: String?): String? {
        val original = originalLength?.toIntOrNull() ?: return null
        if (original <= received.length) return null
        return AppStrings.format(
            R.string.terminal_termux_output_truncated,
            original - received.length,
            fallback = "Output truncated by Termux: ${original - received.length} characters dropped."
        )
    }

    /** A trailing newline would otherwise render as an empty line after every command. */
    private fun Sequence<String>.dropTrailingBlank(): List<String> =
        toList().dropLastWhile { it.isBlank() }

    companion object {
        const val RUN_COMMAND_PERMISSION = "com.termux.permission.RUN_COMMAND"

        private const val TERMUX_PACKAGE = "com.termux"
        private const val TERMUX_INSTALL_URL = "https://f-droid.org/packages/com.termux/"
        private const val RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
        private const val ACTION_RUN_COMMAND = "com.termux.RUN_COMMAND"

        private const val TERMUX_FILES = "/data/data/com.termux/files"
        private const val TERMUX_PREFIX = "$TERMUX_FILES/usr"
        private const val TERMUX_HOME = "$TERMUX_FILES/home"

        private const val EXTRA_COMMAND_PATH = "com.termux.RUN_COMMAND_PATH"
        private const val EXTRA_ARGUMENTS = "com.termux.RUN_COMMAND_ARGUMENTS"
        private const val EXTRA_WORKDIR = "com.termux.RUN_COMMAND_WORKDIR"
        private const val EXTRA_BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND"
        private const val EXTRA_RUNNER = "com.termux.RUN_COMMAND_RUNNER"

        /** Termux's headless runner; the one that reports a result when done. */
        private const val RUNNER_APP_SHELL = "app-shell"
        private const val EXTRA_PENDING_INTENT = "com.termux.RUN_COMMAND_PENDING_INTENT"
        private const val EXTRA_COMMAND_LABEL = "com.termux.RUN_COMMAND_COMMAND_LABEL"

        /** Identifies this app in Termux's own error popups and logs. */
        private const val COMMAND_LABEL = "Sirius Chat terminal"

        private const val KEY_STDOUT = "stdout"
        private const val KEY_STDOUT_ORIGINAL_LENGTH = "stdout_original_length"
        private const val KEY_STDERR = "stderr"
        private const val KEY_EXIT_CODE = "exitCode"
        private const val KEY_ERR = "err"
        private const val KEY_ERRMSG = "errmsg"

        /** termux-shared reports success as -1, not 0. */
        private const val ERRNO_SUCCESS = -1

        /**
         * How long to wait for Termux to report a result before giving up.
         *
         * Long enough for `pkg upgrade` or a compile, short enough that a command
         * whose result will never arrive does not hold the terminal forever.
         */
        private const val RESULT_TIMEOUT_MS = 15L * 60_000L
    }
}
