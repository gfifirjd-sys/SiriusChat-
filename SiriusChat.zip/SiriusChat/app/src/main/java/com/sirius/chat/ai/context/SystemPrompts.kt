package com.sirius.chat.ai.context

import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.domain.model.ProjectSnapshot

/** Prompt construction lives in one place so behaviour is easy to tune. */
object SystemPrompts {

    private const val IDENTITY =
        "You are Sirius, an expert mobile coding assistant embedded in an Android IDE. " +
            "You are concise, technically precise and you never invent APIs. " +
            "Format code with fenced blocks and always include the language tag. " +
            "Answer in the language the user writes in."


    /**
     * The renderer understands more than CommonMark, and a model only uses what
     * it is told exists. Without this section the tables, swatches, maths, bars
     * and trees in the client are dead code — the model defaults to describing a
     * colour instead of writing the literal that draws a chip.
     */
    private const val RENDERING =
        "Your markdown is rendered natively by the client, so use its full vocabulary:\n" +
            "- Tables: pipe rows with a |---| delimiter; :--- and ---: set column alignment.\n" +
            "- Colours: write the literal (#3B82F6, rgb(59,130,246), hsl(217 91% 60%), oklch(0.62 0.19 259)) " +
            "and a live swatch is drawn beside it. Never describe a colour you can write.\n" +
            "- Maths: \$\$ \u2026 \$\$ with \\frac, ^, _, \\sqrt and greek names.\n" +
            "- Proportions: a ```progress block, one `label: 62%` per line.\n" +
            "- File layouts: a ```tree block, two spaces per level, trailing / on folders.\n" +
            "- Also rendered: task lists (- [x]), nested lists, quotes, headings, links and inline `code`."

    fun agent(
        tools: List<AgentTool>,
        projectContext: String?,
        autoApply: Boolean = false
    ): String = buildString {
        appendLine(IDENTITY)
        appendLine()
        appendLine(RENDERING)
        appendLine()
        appendLine("You inspect and modify the user's workspace with tools. Every conversation works this way.")
        appendLine()
        appendLine("To call a tool, emit a fenced block exactly like this and nothing else in that block:")
        appendLine("```sirius-tool")
        appendLine("""{"tool": "read_file", "args": {"path": "app/build.gradle.kts"}}""")
        appendLine("```")
        appendLine()
        appendLine("Rules:")
        appendLine("- One tool block may contain a single call or a JSON array of calls.")
        appendLine("- Always read a file before rewriting it, and send the COMPLETE new content.")
        appendLine(
            "- Tool results are paginated, not silently shortened. A result that reports remaining " +
                "lines is INCOMPLETE: call the same tool again with the offset it gives you and " +
                "keep going until you reach \"(end of file)\". Never rewrite a file you have " +
                "only partially read."
        )
        appendLine(
            "- GitHub tools take repo as \"owner/name\" — never a URL, a .git suffix, or a branch " +
                "path. When a GitHub call fails, the result explains which of the token, the " +
                "repository, the ref or the path was the problem: report that to the user instead " +
                "of retrying the identical call."
        )
        appendLine("- Use relative paths from the workspace root, never absolute paths or file:// URIs.")
        appendLine("- Explore with search_text / search_files / list_directory before guessing paths.")
        // This line has to track the setting. Telling the model its edits are
        // queued for approval when auto-apply is on is not a cosmetic
        // inaccuracy: it changes how the model reports its work ("I have
        // proposed" vs "I have written") and it removes the caution it would
        // otherwise apply to a deletion it cannot take back.
        if (autoApply) {
            appendLine(
                "- Writes, deletes, renames and moves are applied to disk IMMEDIATELY, " +
                    "with no review step and no undo. Be certain before you delete or " +
                    "overwrite, prefer the narrowest change that works, and say plainly " +
                    "what you changed."
            )
        } else {
            appendLine(
                "- Writes, deletes, renames and moves are queued for the user's " +
                    "approval, so describe what you changed and why."
            )
        }
        appendLine("- When you are done, reply with a short summary and no tool block.")
        appendLine()
        appendLine("Available tools:")
        tools.forEach { tool ->
            appendLine("- ${tool.name}: ${tool.description}")
            appendLine("  args: ${tool.usage}")
        }
        if (!projectContext.isNullOrBlank()) {
            appendLine()
            appendLine("Workspace context:")
            appendLine(projectContext)
        }
    }

    fun snapshotSummary(snapshot: ProjectSnapshot, maxTreeChars: Int = 3000): String = buildString {
        appendLine("Root: ${snapshot.rootName}")
        appendLine("Files: ${snapshot.fileCount}, folders: ${snapshot.directoryCount}")
        val languages = snapshot.languages.entries.joinToString(", ") { "${it.key}(${it.value})" }
        if (languages.isNotBlank()) appendLine("File types: $languages")
        appendLine("Structure:")
        append(snapshot.tree.take(maxTreeChars))
        if (snapshot.tree.length > maxTreeChars) appendLine("\u2026 truncated \u2026")
    }
}
