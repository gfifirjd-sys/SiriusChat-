package com.sirius.chat.feature.chat.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.labelled
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.siriusRise
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.core.util.clockTimeText
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.MessageStatus
import com.sirius.chat.domain.model.ToolRun

/**
 * A message. User turns are a compact gradient pill aligned right, assistant
 * turns are full-width glass so code and diffs get all the room they need.
 */
// combinedClickable is still an opt-in foundation API; the bubble needs it because
// tap and long press must both open the action row.
// FlowRow is likewise opt-in, and the action row needs it so the buttons wrap
// instead of the last one being squeezed to a few pixels wide.
@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
fun MessageBubble(
    message: ChatMessage,
    modifier: Modifier = Modifier,
    codeFontSize: Int = 13,
    /**
     * True the first time this message is shown, false when it is merely being
     * scrolled back into view. Only a genuinely new message rises in; replaying
     * the animation on every recycle is what makes a list feel unstable.
     */
    animateEntry: Boolean = false,
    onEdit: (String) -> Unit = {},
    onRegenerate: () -> Unit = {},
    onDelete: () -> Unit = {}
) {
    // Text selection is a mode, not an action: while it is on, the bubble must stop
    // consuming taps or every attempt to place a selection handle would just
    // toggle the action row instead.
    var selecting by remember(message.id) { mutableStateOf(false) }
    val colors = SiriusTheme.colors
    val clipboard = LocalClipboardManager.current
    val haptics = rememberHaptics()
    var actionsVisible by remember { mutableStateOf(false) }

    // Arrival: a sent message and a finished answer both slide the last few
    // pixels into place instead of popping into the transcript. Reduce motion
    // collapses the tween to a single frame, which leaves a plain insert.
    var arrived by remember(message.id) { mutableStateOf(!animateEntry) }
    LaunchedEffect(message.id) { arrived = true }
    val entry by animateFloatAsState(
        targetValue = if (arrived) 1f else 0f,
        animationSpec = siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized),
        label = "messageEntry"
    )

    // Tapping a bubble reveals copy/edit/delete. Without a click label that gesture
    // is invisible to TalkBack, and without a state description there is no way to
    // tell whether the row below is already open.
    val actionsLabel = stringResource(R.string.chat_message_actions)
    val expandedLabel = stringResource(R.string.a11y_expanded)
    val collapsedLabel = stringResource(R.string.a11y_collapsed)
    val toggleActions = if (selecting) {
        // Selection wins: no click handler at all, so the native long-press-drag
        // gesture reaches the text.
        Modifier
    } else {
        Modifier
            .combinedClickable(
                role = Role.Button,
                onClickLabel = actionsLabel,
                // Long press does the same thing as a tap. Both gestures are
                // muscle memory from other chat apps, and having one of them do
                // nothing reads as the app being unresponsive.
                onLongClick = {
                    haptics.light()
                    actionsVisible = true
                },
                onClick = {
                    // Revealing the actions is the one gesture on a bubble, so it
                    // gets a tick to confirm the tap landed on the message and not
                    // the list.
                    haptics.light()
                    actionsVisible = !actionsVisible
                }
            )
            .semantics {
                stateDescription = if (actionsVisible) expandedLabel else collapsedLabel
            }
    }

    SelectionScope(enabled = selecting) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = entry
                translationY = (1f - entry) * 14.dp.toPx()
            }
            .padding(vertical = SiriusSpacing.xxs),
        horizontalAlignment = if (message.isFromUser) Alignment.End else Alignment.Start
    ) {
        if (message.isFromUser) {
            Column(
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .clip(
                        RoundedCornerShape(
                            topStart = SiriusRadius.lg,
                            topEnd = SiriusRadius.lg,
                            bottomStart = SiriusRadius.lg,
                            bottomEnd = SiriusRadius.xs
                        )
                    )
                    // The user's own turn is the one filled bubble in the
                    // thread: solid `primary`, no gradient, so it separates from
                    // the assistant's flat surface by contrast alone.
                    .background(colors.primary)
                    .then(toggleActions)
                    .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
            ) {
                if (message.attachments.isNotEmpty()) {
                    // Sorted by anchor so the chips read in the order they were
                    // attached — the same order the model received them in.
                    message.attachments.sortedBy { it.anchor }.forEach { attachment ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = attachmentIcon(attachment.kind),
                                contentDescription = null,
                                tint = colors.onPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(Modifier.width(SiriusSpacing.xxs))
                            Text(
                                text = attachment.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.onPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (attachment.sizeBytes > 0) {
                                Spacer(Modifier.width(SiriusSpacing.xxs))
                                Text(
                                    text = Formatters.fileSize(attachment.sizeBytes),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colors.onPrimary.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(SiriusSpacing.xxs))
                }
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.onPrimary
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassSurface(shape = RoundedCornerShape(SiriusRadius.lg), elevation = 6.dp)
                    .then(toggleActions)
                    .padding(SiriusSpacing.sm)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = colors.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(SiriusSpacing.xxs))
                    Text(
                        text = message.model ?: stringResource(R.string.chat_assistant_name),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textTertiary
                    )
                    if (message.status == MessageStatus.Cancelled) {
                        Spacer(Modifier.width(SiriusSpacing.xxs))
                        Text(
                            text = stringResource(R.string.chat_message_stopped),
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.warning
                        )
                    }
                }
                Spacer(Modifier.height(SiriusSpacing.xxs))

                if (message.toolRuns.isNotEmpty()) {
                    ToolRunList(message.toolRuns)
                    Spacer(Modifier.height(SiriusSpacing.xs))
                }

                if (message.content.isNotBlank()) {
                    MarkdownText(markdown = message.content, codeFontSize = codeFontSize)
                }

                if (message.status == MessageStatus.Failed && message.error != null) {
                    Spacer(Modifier.height(SiriusSpacing.xxs))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.ErrorOutline,
                            contentDescription = null,
                            tint = colors.error,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(SiriusSpacing.xxs))
                        Text(
                            text = message.error,
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.error
                        )
                    }
                }
            }
        }

        // The row used a hand-rolled tween that ignored "Reduce motion" and never
        // animated out. The shared rise handles both directions and honours it.
        val (actionsEnter, actionsExit) = siriusRise(distancePx = 8)
        AnimatedVisibility(
            visible = actionsVisible,
            enter = actionsEnter,
            exit = actionsExit
        ) {
            // FlowRow, not Row: four unweighted buttons plus a timestamp overflow a
            // narrow screen (and any large font scale), and a plain Row answers that
            // by squeezing the last child to a sliver — which is how "Regenerate"
            // ended up rendered one letter per line. Wrapping is the only layout
            // that degrades gracefully here.
            FlowRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = SiriusSpacing.xxs),
                horizontalArrangement = Arrangement.spacedBy(
                    SiriusSpacing.xxs,
                    if (message.isFromUser) Alignment.End else Alignment.Start
                ),
                verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
            ) {
                // Every other item in the row is a 36dp circle, so the timestamp is
                // centred inside the same height instead of hanging from the top
                // edge, which is where FlowRow would otherwise put it.
                Box(
                    modifier = Modifier.height(36.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = clockTimeText(message.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textTertiary,
                        maxLines = 1,
                        softWrap = false
                    )
                }
                MessageAction(Icons.Rounded.ContentCopy, stringResource(R.string.action_copy)) {
                    // Text only. Attachments are not re-copied: the clipboard
                    // cannot hold them usefully, and pasting a message back would
                    // otherwise duplicate every file it carried.
                    clipboard.setText(AnnotatedString(message.content))
                    actionsVisible = false
                }
                MessageAction(
                    icon = Icons.Rounded.TextFields,
                    label = stringResource(
                        if (selecting) R.string.chat_action_select_done else R.string.chat_action_select
                    ),
                    // Selection is a mode, and an icon with no label needs the tinted
                    // well to say it is currently on.
                    highlighted = selecting
                ) {
                    selecting = !selecting
                    actionsVisible = false
                }
                if (message.isFromUser) {
                    MessageAction(Icons.Rounded.Edit, stringResource(R.string.chat_action_edit)) {
                        onEdit(message.content)
                        actionsVisible = false
                    }
                } else {
                    MessageAction(Icons.Rounded.Refresh, stringResource(R.string.chat_action_regenerate)) {
                        onRegenerate()
                        actionsVisible = false
                    }
                }
                MessageAction(Icons.Rounded.DeleteOutline, stringResource(R.string.action_delete)) {
                    onDelete()
                    actionsVisible = false
                }
            }
        }
    }
    }
}

/**
 * Makes the bubble's text selectable, on demand.
 *
 * Compose text is not selectable unless it sits in a [SelectionContainer], and a
 * container that is always on would swallow the tap that opens the action row.
 * So it is switched on by the "select text" action and off again afterwards,
 * which is also why the enabled branch has to re-emit the same content rather
 * than wrap it permanently.
 */
@Composable
private fun SelectionScope(enabled: Boolean, content: @Composable () -> Unit) {
    if (enabled) {
        SelectionContainer { content() }
    } else {
        content()
    }
}

/**
 * One action on a message: an icon, and nothing else.
 *
 * Labels were dropped on purpose. Four labelled pills never fit the width of a
 * phone once translated ("Сгенерировать заново" alone is wider than a third of
 * the screen), and the label is not what makes the button readable at this size
 * — the glyph is. It stays available to TalkBack through the content
 * description, which is also the click label, so nothing is lost to a screen
 * reader.
 */
@Composable
private fun MessageAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    highlighted: Boolean = false,
    onClick: () -> Unit
) {
    GlassIconButton(
        icon = icon,
        contentDescription = label,
        onClick = onClick,
        size = 36.dp,
        iconSize = 18.dp,
        highlighted = highlighted
    )
}

/** Compact transcript of what the agent actually did. */
@Composable
fun ToolRunList(
    runs: List<ToolRun>,
    modifier: Modifier = Modifier,
    codeFontSize: Int = 12
) {
    val colors = SiriusTheme.colors
    val outputLabel = stringResource(R.string.chat_tool_output)
    val expandedLabel = stringResource(R.string.a11y_expanded)
    val collapsedLabel = stringResource(R.string.a11y_collapsed)
    val succeededLabel = stringResource(R.string.chat_tool_succeeded)
    val failedLabel = stringResource(R.string.chat_tool_failed)

    // What the reader wants first is "did it work and how long did it take"; the
    // individual calls are detail below that. Summing the runs avoids storing a
    // separate duration on the message.
    val totalMs = runs.sumOf { it.durationMs }
    val anyFailed = runs.any { !it.success }
    var stepsExpanded by remember(runs.size) { mutableStateOf(true) }
    val (stepsEnter, stepsExit) = siriusRise(distancePx = 8)

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(SiriusRadius.sm))
                .clickable(role = Role.Button, onClickLabel = outputLabel) {
                    stepsExpanded = !stepsExpanded
                }
                .semantics {
                    stateDescription = if (stepsExpanded) expandedLabel else collapsedLabel
                }
                .padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (stepsExpanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                contentDescription = null,
                tint = colors.textTertiary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(SiriusSpacing.xxs))
            Text(
                text = stringResource(R.string.chat_agent_worked_for, Formatters.duration(totalMs)),
                style = MaterialTheme.typography.labelMedium,
                color = if (anyFailed) colors.warning else colors.textSecondary
            )
            Spacer(Modifier.width(SiriusSpacing.xxs))
            Text(
                text = stringResource(R.string.chat_agent_step_count, runs.size),
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary
            )
        }

        AnimatedVisibility(visible = stepsExpanded, enter = stepsEnter, exit = stepsExit) {
        Column(verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)) {
        runs.forEach { run ->
            // A failure starts open. Collapsed-by-default is right for output the
            // user does not need, but for a failed call it hid the only thing that
            // explains the red cross, and "github_list_files ✗" with no reason is
            // what made this bug unreportable in the first place.
            var expanded by remember(run.id) { mutableStateOf(!run.success) }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .softSurface(RoundedCornerShape(SiriusRadius.sm))
                    .clickable(role = Role.Button, onClickLabel = outputLabel) {
                        expanded = !expanded
                    }
                    .semantics {
                        stateDescription = if (expanded) expandedLabel else collapsedLabel
                    }
                    .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xxs)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // A tick reads as "done" at a glance where a coloured dot only
                    // reads as "something"; it still carries the spoken label,
                    // because shape and colour alone are not an announcement.
                    Icon(
                        imageVector = if (run.success) Icons.Rounded.Check else Icons.Rounded.Close,
                        contentDescription = null,
                        tint = if (run.success) colors.success else colors.error,
                        modifier = Modifier
                            .size(14.dp)
                            .labelled(if (run.success) succeededLabel else failedLabel)
                    )
                    Spacer(Modifier.width(SiriusSpacing.xxs))
                    Text(
                        text = run.toolName,
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.textSecondary
                    )
                    Spacer(Modifier.width(SiriusSpacing.xxs))
                    Text(
                        text = run.argumentsPreview,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textTertiary,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = Formatters.duration(run.durationMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textTertiary
                    )
                }
                val (outputEnter, outputExit) = siriusRise(distancePx = 8)
                AnimatedVisibility(
                    visible = expanded,
                    enter = outputEnter,
                    exit = outputExit
                ) {
                    // Tool output is shell and file text: proportional type mangles the
                    // alignment it depends on.
                    Text(
                        // Errors are shown at length and in the error colour: they
                        // now carry the request, the status, GitHub's own body and
                        // the token state, and clipping that to 3000 characters
                        // would cut the part that names the cause.
                        text = run.output.take(if (run.success) 3000 else 8000),
                        style = codeTextStyle(codeFontSize),
                        color = if (run.success) colors.textTertiary else colors.error,
                        modifier = Modifier.padding(top = SiriusSpacing.xxs)
                    )
                }
            }
        }
        }
        }
    }
}
