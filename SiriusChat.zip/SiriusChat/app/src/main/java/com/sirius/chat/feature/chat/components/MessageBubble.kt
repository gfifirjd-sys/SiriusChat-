package com.sirius.chat.feature.chat.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.designsystem.touchTarget
import com.sirius.chat.core.designsystem.components.labelled
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.siriusRise
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.core.util.clockTimeText
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.MessageStatus
import com.sirius.chat.domain.model.ToolRun

/**
 * A message. User turns are a compact gradient pill aligned right, assistant
 * turns are full-width glass so code and diffs get all the room they need.
 */
@Composable
fun MessageBubble(
    message: ChatMessage,
    modifier: Modifier = Modifier,
    codeFontSize: Int = 13,
    onEdit: (String) -> Unit = {},
    onRegenerate: () -> Unit = {},
    onDelete: () -> Unit = {}
) {
    val colors = SiriusTheme.colors
    val clipboard = LocalClipboardManager.current
    val haptics = rememberHaptics()
    var actionsVisible by remember { mutableStateOf(false) }

    // Tapping a bubble reveals copy/edit/delete. Without a click label that gesture
    // is invisible to TalkBack, and without a state description there is no way to
    // tell whether the row below is already open.
    val actionsLabel = stringResource(R.string.chat_message_actions)
    val expandedLabel = stringResource(R.string.a11y_expanded)
    val collapsedLabel = stringResource(R.string.a11y_collapsed)
    val toggleActions = Modifier
        .clickable(role = Role.Button, onClickLabel = actionsLabel) {
            // Revealing the actions is the one gesture on a bubble, so it gets a
            // tick to confirm the tap landed on the message and not the list.
            haptics.light()
            actionsVisible = !actionsVisible
        }
        .semantics {
            stateDescription = if (actionsVisible) expandedLabel else collapsedLabel
        }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = SiriusSpacing.xxs),
        horizontalAlignment = if (message.isFromUser) Alignment.End else Alignment.Start
    ) {
        if (message.isFromUser) {
            Column(
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .clip(
                        RoundedCornerShape(
                            topStart = SiriusRadius.lg,
                            topEnd = SiriusRadius.lg,
                            bottomStart = SiriusRadius.lg,
                            bottomEnd = SiriusRadius.xs
                        )
                    )
                    // The user's own turn is the one filled bubble in the
                    // thread: solid `primary`, no gradient, so it separates from
                    // the assistant's flat surface by contrast alone.
                    .background(colors.primary)
                    .then(toggleActions)
                    .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
            ) {
                if (message.attachments.isNotEmpty()) {
                    message.attachments.forEach { attachment ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.AutoMirrored.Rounded.InsertDriveFile,
                                contentDescription = null,
                                tint = colors.onPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(Modifier.width(SiriusSpacing.xxs))
                            Text(
                                text = attachment.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.onPrimary
                            )
                        }
                    }
                    Spacer(Modifier.height(SiriusSpacing.xxs))
                }
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.onPrimary
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassSurface(shape = RoundedCornerShape(SiriusRadius.lg), elevation = 6.dp)
                    .then(toggleActions)
                    .padding(SiriusSpacing.sm)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = colors.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(SiriusSpacing.xxs))
                    Text(
                        text = message.model ?: stringResource(R.string.chat_assistant_name),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textTertiary
                    )
                    if (message.status == MessageStatus.Cancelled) {
                        Spacer(Modifier.width(SiriusSpacing.xxs))
                        Text(
                            text = stringResource(R.string.chat_message_stopped),
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.warning
                        )
                    }
                }
                Spacer(Modifier.height(SiriusSpacing.xxs))

                if (message.toolRuns.isNotEmpty()) {
                    ToolRunList(message.toolRuns)
                    Spacer(Modifier.height(SiriusSpacing.xs))
                }

                if (message.content.isNotBlank()) {
                    MarkdownText(markdown = message.content, codeFontSize = codeFontSize)
                }

                if (message.status == MessageStatus.Failed && message.error != null) {
                    Spacer(Modifier.height(SiriusSpacing.xxs))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.ErrorOutline,
                            contentDescription = null,
                            tint = colors.error,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(SiriusSpacing.xxs))
                        Text(
                            text = message.error,
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.error
                        )
                    }
                }
            }
        }

        // The row used a hand-rolled tween that ignored "Reduce motion" and never
        // animated out. The shared rise handles both directions and honours it.
        val (actionsEnter, actionsExit) = siriusRise(distancePx = 8)
        AnimatedVisibility(
            visible = actionsVisible,
            enter = actionsEnter,
            exit = actionsExit
        ) {
            Row(
                modifier = Modifier.padding(top = SiriusSpacing.xxs),
                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = clockTimeText(message.createdAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.textTertiary
                )
                MessageAction(Icons.Rounded.ContentCopy, stringResource(R.string.action_copy)) {
                    clipboard.setText(AnnotatedString(message.content))
                    actionsVisible = false
                }
                if (message.isFromUser) {
                    MessageAction(Icons.Rounded.Edit, stringResource(R.string.chat_action_edit)) {
                        onEdit(message.content)
                        actionsVisible = false
                    }
                } else {
                    MessageAction(Icons.Rounded.Refresh, stringResource(R.string.chat_action_regenerate)) {
                        onRegenerate()
                        actionsVisible = false
                    }
                }
                MessageAction(Icons.Rounded.DeleteOutline, stringResource(R.string.action_delete)) {
                    onDelete()
                    actionsVisible = false
                }
            }
        }
    }
}

@Composable
private fun MessageAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    Row(
        modifier = Modifier
            .clickable(role = Role.Button) {
                haptics.light()
                onClick()
            }
            // The pill is only ~22dp tall, so on its own it is a miss-prone
            // target sitting next to two others. touchTarget sits inside the
            // clickable so the hit box grows to 40dp while the chip stays small.
            .touchTarget(40.dp)
            .softSurface(RoundedCornerShape(SiriusRadius.pill))
            .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xxs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
    ) {
        Icon(icon, contentDescription = label, tint = colors.textTertiary, modifier = Modifier.size(13.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = colors.textTertiary)
    }
}

/** Compact transcript of what the agent actually did. */
@Composable
fun ToolRunList(
    runs: List<ToolRun>,
    modifier: Modifier = Modifier,
    codeFontSize: Int = 12
) {
    val colors = SiriusTheme.colors
    val outputLabel = stringResource(R.string.chat_tool_output)
    val expandedLabel = stringResource(R.string.a11y_expanded)
    val collapsedLabel = stringResource(R.string.a11y_collapsed)
    val succeededLabel = stringResource(R.string.chat_tool_succeeded)
    val failedLabel = stringResource(R.string.chat_tool_failed)

    // What the reader wants first is "did it work and how long did it take"; the
    // individual calls are detail below that. Summing the runs avoids storing a
    // separate duration on the message.
    val totalMs = runs.sumOf { it.durationMs }
    val anyFailed = runs.any { !it.success }
    var stepsExpanded by remember(runs.size) { mutableStateOf(true) }
    val (stepsEnter, stepsExit) = siriusRise(distancePx = 8)

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(SiriusRadius.sm))
                .clickable(role = Role.Button, onClickLabel = outputLabel) {
                    stepsExpanded = !stepsExpanded
                }
                .semantics {
                    stateDescription = if (stepsExpanded) expandedLabel else collapsedLabel
                }
                .padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (stepsExpanded) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                contentDescription = null,
                tint = colors.textTertiary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(SiriusSpacing.xxs))
            Text(
                text = stringResource(R.string.chat_agent_worked_for, Formatters.duration(totalMs)),
                style = MaterialTheme.typography.labelMedium,
                color = if (anyFailed) colors.warning else colors.textSecondary
            )
            Spacer(Modifier.width(SiriusSpacing.xxs))
            Text(
                text = stringResource(R.string.chat_agent_step_count, runs.size),
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary
            )
        }

        AnimatedVisibility(visible = stepsExpanded, enter = stepsEnter, exit = stepsExit) {
        Column(verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)) {
        runs.forEach { run ->
            var expanded by remember(run.id) { mutableStateOf(false) }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .softSurface(RoundedCornerShape(SiriusRadius.sm))
                    .clickable(role = Role.Button, onClickLabel = outputLabel) {
                        expanded = !expanded
                    }
                    .semantics {
                        stateDescription = if (expanded) expandedLabel else collapsedLabel
                    }
                    .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xxs)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // A tick reads as "done" at a glance where a coloured dot only
                    // reads as "something"; it still carries the spoken label,
                    // because shape and colour alone are not an announcement.
                    Icon(
                        imageVector = if (run.success) Icons.Rounded.Check else Icons.Rounded.Close,
                        contentDescription = null,
                        tint = if (run.success) colors.success else colors.error,
                        modifier = Modifier
                            .size(14.dp)
                            .labelled(if (run.success) succeededLabel else failedLabel)
                    )
                    Spacer(Modifier.width(SiriusSpacing.xxs))
                    Text(
                        text = run.toolName,
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.textSecondary
                    )
                    Spacer(Modifier.width(SiriusSpacing.xxs))
                    Text(
                        text = run.argumentsPreview,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textTertiary,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = Formatters.duration(run.durationMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textTertiary
                    )
                }
                val (outputEnter, outputExit) = siriusRise(distancePx = 8)
                AnimatedVisibility(
                    visible = expanded,
                    enter = outputEnter,
                    exit = outputExit
                ) {
                    // Tool output is shell and file text: proportional type mangles the
                    // alignment it depends on.
                    Text(
                        text = run.output.take(3000),
                        style = codeTextStyle(codeFontSize),
                        color = colors.textTertiary,
                        modifier = Modifier.padding(top = SiriusSpacing.xxs)
                    )
                }
            }
        }
        }
        }
    }
}
