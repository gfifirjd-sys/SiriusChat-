package com.sirius.chat.ai.agent

import com.sirius.chat.R
import com.sirius.chat.ai.agent.tools.AnalyzeProjectTool
import com.sirius.chat.ai.agent.tools.AskUserTool
import com.sirius.chat.ai.agent.tools.CreateFileTool
import com.sirius.chat.ai.agent.tools.DeleteFileTool
import com.sirius.chat.ai.agent.tools.ListDirectoryTool
import com.sirius.chat.ai.agent.tools.MoveFileTool
import com.sirius.chat.ai.agent.tools.ReadFileTool
import com.sirius.chat.ai.agent.tools.RenameFileTool
import com.sirius.chat.ai.agent.tools.RunCommandTool
import com.sirius.chat.ai.agent.tools.SearchFilesTool
import com.sirius.chat.ai.agent.tools.SearchTextTool
import com.sirius.chat.ai.agent.tools.WriteFileTool
import com.sirius.chat.ai.context.SystemPrompts
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.provider.AiProvider
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.model.ToolRun
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import java.util.UUID
import java.util.Locale

/** Events the chat layer renders while the agent works. */
sealed interface AgentEvent {
    data class StepStarted(val step: Int) : AgentEvent
    data class Delta(val text: String) : AgentEvent
    data class ToolStarted(val toolName: String, val preview: String) : AgentEvent
    data class ToolFinished(val run: ToolRun) : AgentEvent
    data class Proposals(val changes: List<PendingChange>) : AgentEvent
    data class Completed(val text: String) : AgentEvent
    data class Failure(val error: AiError) : AgentEvent
}

/**
 * The agent loop: ask the model, run the tools it requested, feed the results
 * back, repeat until it stops asking for tools or the step budget runs out.
 *
 * Mutating tools do not write anything; their proposals are collected and
 * emitted so the UI can show a diff and ask for approval.
 */
class AgentEngine(
    private val tools: List<AgentTool> = defaultTools()
) {

    fun toolList(): List<AgentTool> = tools

    fun run(
        provider: AiProvider,
        model: String,
        history: List<AiMessage>,
        context: AgentContext,
        projectContext: String?,
        params: com.sirius.chat.domain.model.GenerationParams,
        maxSteps: Int,
        /** Mirrors the user setting, purely so the system prompt can be honest. */
        autoApply: Boolean = false
    ): Flow<AgentEvent> = channelFlow {
        val systemPrompt = SystemPrompts.agent(tools, projectContext, autoApply)
        val known = tools.mapTo(HashSet()) { it.name }
        val conversation = history.toMutableList()
        val proposals = ArrayList<PendingChange>()
        // Prose from *every* step, in order. The chat bubble shows the whole run
        // as it streams, so the stored message has to be the whole run too --
        // keeping only the last step silently dropped everything the model said
        // before its first tool call.
        val transcript = StringBuilder()
        var nudges = 0

        // `params` is re-read every step because a blank turn caused by an
        // exhausted token budget is fixed by raising the budget, not by asking
        // again with the same one.
        var activeParams = params
        var tokenBumps = 0

        // Why the last blank turn was blank, so the final message can say
        // something the user can act on instead of "empty response".
        var blankFinish: String? = null
        var blankReasoning = 0

        // The budget extends itself instead of stopping. `maxSteps` used to be a
        // wall: the run ended mid-task and left "ask me to continue if more work
        // is needed", so the user had to type "продолжай" to get work they had
        // already asked for. Worse with `run_command` in the registry, where one
        // Gradle build is a single step and a six-step budget cannot finish
        // anything real.
        //
        // So the budget grows in `maxSteps`-sized increments for as long as the
        // agent is still calling tools, up to [hardCap]. Reaching the end of the
        // loop body already proves it is working — a step with no tool calls
        // breaks out above — so no extra "is it done" guess is needed.
        var step = 0
        var toolsRun = 0
        var budget = maxSteps
        val hardCap = (maxSteps.toLong() * BUDGET_EXTENSIONS)
            .coerceAtMost(ABSOLUTE_MAX_STEPS.toLong()).toInt()

        while (step < budget) {
            step++
            send(AgentEvent.StepStarted(step))

            val builder = StringBuilder()
            var failed: AiError? = null
            var finishReason: String? = null
            var reasoningChars = 0

            provider.chat(
                ChatRequest(
                    model = model,
                    messages = conversation.toList(),
                    systemPrompt = systemPrompt,
                    params = activeParams,
                    stream = true
                )
            ).collect { event ->
                when (event) {
                    is ChatStreamEvent.Delta -> {
                        builder.append(event.text)
                        send(AgentEvent.Delta(event.text))
                    }
                    is ChatStreamEvent.Failure -> failed = event.error
                    // Completed used to be swallowed by `else`, which threw away
                    // the finish reason -- the single most diagnostic field in
                    // the response -- and left every blank turn looking the same.
                    is ChatStreamEvent.Completed -> {
                        finishReason = event.finishReason
                        reasoningChars = event.reasoningChars
                    }
                    else -> Unit
                }
            }

            val error = failed
            if (error != null) {
                send(AgentEvent.Failure(error))
                return@channelFlow
            }

            val answer = builder.toString()

            // A blank turn is handled before anything else because it is the one
            // failure the user always reads as the app being broken.
            //
            // `finish_reason == "length"` means the model hit `max_tokens`. On a
            // reasoning model that happens *inside the thinking phase*, so not a
            // character of the answer is ever emitted -- asking again with the
            // same budget produces the same nothing, which is exactly what the
            // two nudges below were doing before this existed. Doubling the
            // budget and retrying the step fixes it without the user having to
            // know what a token is.
            if (answer.isBlank()) {
                blankFinish = finishReason
                blankReasoning = reasoningChars
                val truncated = finishReason == "length"
                if (truncated && tokenBumps < MAX_TOKEN_BUMPS && activeParams.maxTokens < MAX_TOKENS_CEILING) {
                    tokenBumps++
                    activeParams = activeParams.copy(
                        maxTokens = (activeParams.maxTokens * 2).coerceAtMost(MAX_TOKENS_CEILING)
                    )
                    // Deliberately not appended to the conversation: the model
                    // said nothing, and an empty assistant turn is rejected
                    // outright by some gateways.
                    continue
                }
                if (truncated) break
            } else {
                // Keep the diagnosis about the *last* turn: a run that recovers
                // must not end with a message blaming a token limit it already
                // worked around.
                blankFinish = null
                blankReasoning = 0
            }

            val calls = ToolCallParser.parse(answer, known)

            // Append this step's prose instead of replacing the total. A step whose
            // entire output was a tool call contributes nothing and must not erase
            // what came before it.
            val prose = ToolCallParser.stripToolBlocks(answer, known)
            if (prose.isNotBlank()) {
                if (transcript.isNotEmpty()) transcript.append("\n\n")
                transcript.append(prose)
            }

            if (calls.isEmpty()) {
                // A step with no tool call used to end the entire run, which is
                // how "I forgot to call the tools. Let me check now." became a
                // dead turn the user had to poke with "you stopped".
                //
                // A turn that ends in prose is usually correct — it is how the
                // agent answers a question — so this does not retry blindly. It
                // retries only when the prose *promised* something, and only
                // twice, after which the original break stands and the run ends
                // rather than looping.
                if (nudges < MAX_NUDGES && announcesAction(prose)) {
                    nudges++
                    // An empty assistant message is not merely useless context:
                    // several OpenAI-compatible gateways reject
                    // {"role":"assistant","content":""} with a 400, turning a
                    // recoverable blank turn into a failed request.
                    if (answer.isNotBlank()) conversation += AiMessage(AiRole.Assistant, answer)
                    conversation += AiMessage(
                        AiRole.User,
                        if (answer.isBlank()) BLANK_PROMPT else NUDGE_PROMPT
                    )
                    continue
                }
                break
            }

            conversation += AiMessage(AiRole.Assistant, answer)
            val results = StringBuilder("Tool results:\n")

            for (call in calls) {
                val tool = tools.firstOrNull { it.name == call.tool }
                val preview = call.args.toString().take(160)
                send(AgentEvent.ToolStarted(call.tool, preview))

                val startedAt = System.currentTimeMillis()
                val result = if (tool == null) {
                    AgentToolResult("Unknown tool '${call.tool}'.", success = false)
                } else {
                    // `runCatching` also catches CancellationException, which
                    // turned pressing Stop mid-tool into a fake tool failure and
                    // let the loop start another step. Cancellation has to win.
                    try {
                        tool.execute(call.args, context)
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (t: Throwable) {
                        AgentToolResult("Tool failed: ${t.message}", success = false)
                    }
                }
                val duration = System.currentTimeMillis() - startedAt

                result.proposal?.let { proposals += it }

                val run = ToolRun(
                    id = UUID.randomUUID().toString(),
                    toolName = call.tool,
                    argumentsPreview = preview,
                    // What the user can expand under the tool row. Larger than it
                    // was: a 4000-char cap hid the tail of exactly the reads that
                    // needed checking, and the transcript is where a user
                    // verifies what the model actually saw.
                    output = result.output.take(MAX_STORED_OUTPUT_CHARS),
                    success = result.success,
                    durationMs = duration
                )
                send(AgentEvent.ToolFinished(run))
                toolsRun++

                results.appendLine("[${call.tool}] ${if (result.success) "ok" else "error"}")
                results.appendLine(clipForModel(result.output))
                results.appendLine()
            }

            conversation += AiMessage(AiRole.User, results.toString())

            if (step >= budget) {
                if (budget < hardCap) {
                    budget = (budget + maxSteps).coerceAtMost(hardCap)
                    // Telling the model its budget grew keeps it from padding the
                    // remaining steps: without this it tends to rush a summary at
                    // what it believes is the last step.
                    conversation += AiMessage(
                        AiRole.User,
                        "Continue. You have more steps available. Keep working " +
                            "until the task is done, then give your final answer."
                    )
                } else if (transcript.isBlank()) {
                    // The hard cap is the one place the old message still belongs:
                    // stopping here is a real limit, not a mid-task pause.
                    transcript.append(
                        "Stopped after $hardCap steps without finishing. " +
                            "Tell me how to narrow this down, or raise the step " +
                            "limit in Settings."
                    )
                }
            }
        }

        if (proposals.isNotEmpty()) send(AgentEvent.Proposals(proposals))

        // A run that called tools and produced no prose used to complete with an
        // empty string, which the chat rendered as nothing at all: the user saw a
        // tool card, no message, and an agent that had apparently given up
        // without a word. It is the most confusing possible failure because there
        // is nothing on screen to react to.
        //
        // Empty is only reported as empty when nothing happened either.
        val finalText = transcript.toString().trim().ifBlank {
            when {
                blankFinish == "length" -> AppStrings.format(
                    R.string.error_model_truncated,
                    activeParams.maxTokens,
                    fallback = "The model used its entire ${activeParams.maxTokens}-token " +
                        "budget before writing an answer. Raise \"Max tokens\" in Settings, " +
                        "or use a model that does not spend the budget on reasoning."
                )
                blankReasoning > 0 -> AppStrings.format(
                    R.string.error_model_reasoning_only,
                    blankReasoning,
                    fallback = "The model produced $blankReasoning characters of reasoning " +
                        "and no answer. Try again, or switch model."
                )
                toolsRun == 0 -> AppStrings.get(
                    R.string.error_model_empty,
                    fallback = "The model returned an empty response. Try again, or switch model."
                )
                else -> AppStrings.format(
                    R.string.error_agent_no_answer,
                    toolsRun,
                    fallback = "Ran $toolsRun tool call(s) but produced no answer. " +
                        "This usually means the model stopped early."
                )
            }
        }
        send(AgentEvent.Completed(finalText))
    }

    /**
     * Did this prose promise an action it then failed to take?
     *
     * The strongest signal is language independent: prose that ends in a colon
     * is introducing something. Every stuck turn in the reported transcript
     * ended exactly that way — "Начну с файлов:", "Создам их через временные
     * файлы:" — with nothing after the colon.
     *
     * The phrase list is a second net for announcements that end in a full stop,
     * and covers both interface languages. It is matched case-insensitively
     * against the tail of the message, because an opening "Let me check the
     * repository first" followed by a *completed* answer is not stuck; it is only
     * the last thing said that indicates an unfulfilled promise.
     *
     * False positives cost one wasted round trip. False negatives cost the user
     * a dead turn, so this errs toward retrying.
     *
     * Folded with an explicit [Locale.ROOT]. Kotlin's `lowercase()` is already
     * invariant, so this only guards against someone swapping in Java's
     * locale-sensitive `toLowerCase()`, under which the English markers starting
     * with `i` would fold to a dotless `ı` on a Turkish device and never match.
     */
    private fun announcesAction(prose: String): Boolean {
        val text = prose.trim()
        if (text.isEmpty()) return true
        if (text.endsWith(":") || text.endsWith("—") || text.endsWith("...")) return true
        val tail = text.takeLast(160).lowercase(Locale.ROOT)
        return INTENT_MARKERS.any { it in tail }
    }

    /**
     * Bounds one tool result before it is handed back to the model.
     *
     * The cut itself is unavoidable — a tool can return more than a context
     * window holds — but a *silent* cut is a correctness bug, not a limit: this
     * is what made `read_file` stop at line 277 of a longer file while looking
     * like a complete read, after which the model rewrote the file from the part
     * it had. So the clip now ends on a line boundary and says, in the output the
     * model reads, that data is missing and how to ask for the rest.
     *
     * Tools that page their own output (read_file, github_read_file) stay well
     * under this cap and are never touched here.
     */
    private fun clipForModel(output: String): String {
        if (output.length <= MAX_TOOL_OUTPUT_CHARS) return output
        val head = output.take(MAX_TOOL_OUTPUT_CHARS)
        // Prefer the last newline so a truncated line never reads as a real one.
        val boundary = head.lastIndexOf('\n').takeIf { it > MAX_TOOL_OUTPUT_CHARS / 2 }
            ?: head.length
        val kept = head.substring(0, boundary)
        val dropped = output.length - kept.length
        return buildString {
            append(kept)
            appendLine()
            append(
                "\u2026 [Sirius cut this tool result after ${kept.length} characters; " +
                    "$dropped characters were NOT shown. The data above is incomplete. " +
                    "Re-run the tool with a narrower request, or with pagination arguments " +
                    "(read_file and github_read_file accept \"offset\" and \"limit\") " +
                    "until you have read everything. Do not rewrite a file you have only " +
                    "partially read.]"
            )
        }
    }

    companion object {
        /**
         * Characters of one tool result that reach the model.
         *
         * Raised from 8000, which was under a single page of a real source file:
         * a 300-line HTML file with line numbers already exceeded it. Kept finite
         * because several results accumulate in one conversation turn.
         */
        private const val MAX_TOOL_OUTPUT_CHARS = 24_000

        /** Characters of one tool result kept in the transcript for the user. */
        private const val MAX_STORED_OUTPUT_CHARS = 16_000

        /** Retries per run for a turn that promised work and did none. */
        private const val MAX_NUDGES = 2

        /**
         * How many times the step budget may refill. Four is enough for a build,
         * a fix and a rebuild; unbounded would let one bad prompt spend the
         * user's API credit until the app is killed.
         */
        private const val BUDGET_EXTENSIONS = 4

        /** Ceiling regardless of the configured limit, for the same reason. */
        private const val ABSOLUTE_MAX_STEPS = 40

        /**
         * How many times one run may double `max_tokens` after a truncated,
         * answerless turn. Two takes 4096 to 16000, which is the top of the
         * settings slider, so a third would be a promise the UI cannot keep.
         */
        private const val MAX_TOKEN_BUMPS = 2

        /** Matches the ceiling of the Max tokens slider in Settings. */
        private const val MAX_TOKENS_CEILING = 16_000

        private val NUDGE_PROMPT = """
            You described an action but issued no tool call, so nothing ran.
            Emit the tool call now as a ```sirius-tool fenced JSON block, or, if
            no tool is needed, give your final answer directly.
        """.trimIndent()

        /**
         * Sent after a turn that returned nothing at all.
         *
         * Different from [NUDGE_PROMPT] on purpose: there is no prose to refer
         * back to, and the usual cause on a reasoning model is a thinking phase
         * that never converged, so the instruction is to be brief rather than to
         * finish a sentence it never started.
         */
        private val BLANK_PROMPT = """
            Your previous reply arrived empty. Do not think at length: answer
            directly, or issue one tool call as a ```sirius-tool fenced JSON
            block. Keep it short.
        """.trimIndent()

        private val INTENT_MARKERS = listOf(
            // Russian
            "сейчас", "проверю", "посмотрю", "создам", "создаю", "начну",
            "сделаю", "прочитаю", "исправлю", "добавлю", "запущу", "вызову",
            // English
            "let me", "i'll ", "i will ", "i am going to", "i'm going to",
            "now i", "checking", "creating", "reading", "next step"
        )

        fun defaultTools(): List<AgentTool> = listOf(
            ReadFileTool(),
            ListDirectoryTool(),
            SearchFilesTool(),
            SearchTextTool(),
            AnalyzeProjectTool(),
            AskUserTool(),
            RunCommandTool(),
            CreateFileTool(),
            WriteFileTool(),
            DeleteFileTool(),
            RenameFileTool(),
            MoveFileTool()
        )
    }
}
