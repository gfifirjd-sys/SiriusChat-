package com.sirius.chat.ai.agent

import com.sirius.chat.ai.agent.tools.AnalyzeProjectTool
import com.sirius.chat.ai.agent.tools.CreateFileTool
import com.sirius.chat.ai.agent.tools.DeleteFileTool
import com.sirius.chat.ai.agent.tools.ListDirectoryTool
import com.sirius.chat.ai.agent.tools.MoveFileTool
import com.sirius.chat.ai.agent.tools.ReadFileTool
import com.sirius.chat.ai.agent.tools.RenameFileTool
import com.sirius.chat.ai.agent.tools.SearchFilesTool
import com.sirius.chat.ai.agent.tools.SearchTextTool
import com.sirius.chat.ai.agent.tools.WriteFileTool
import com.sirius.chat.ai.context.SystemPrompts
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.AiMessage
import com.sirius.chat.ai.model.AiRole
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.provider.AiProvider
import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.model.ToolRun
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import java.util.UUID

/** Events the chat layer renders while the agent works. */
sealed interface AgentEvent {
    data class StepStarted(val step: Int) : AgentEvent
    data class Delta(val text: String) : AgentEvent
    data class ToolStarted(val toolName: String, val preview: String) : AgentEvent
    data class ToolFinished(val run: ToolRun) : AgentEvent
    data class Proposals(val changes: List<PendingChange>) : AgentEvent
    data class Completed(val text: String) : AgentEvent
    data class Failure(val error: AiError) : AgentEvent
}

/**
 * The agent loop: ask the model, run the tools it requested, feed the results
 * back, repeat until it stops asking for tools or the step budget runs out.
 *
 * Mutating tools do not write anything; their proposals are collected and
 * emitted so the UI can show a diff and ask for approval.
 */
class AgentEngine(
    private val tools: List<AgentTool> = defaultTools()
) {

    fun toolList(): List<AgentTool> = tools

    fun run(
        provider: AiProvider,
        model: String,
        history: List<AiMessage>,
        context: AgentContext,
        projectContext: String?,
        params: com.sirius.chat.domain.model.GenerationParams,
        maxSteps: Int
    ): Flow<AgentEvent> = channelFlow {
        val systemPrompt = SystemPrompts.agent(tools, projectContext)
        val conversation = history.toMutableList()
        val proposals = ArrayList<PendingChange>()
        // Prose from *every* step, in order. The chat bubble shows the whole run
        // as it streams, so the stored message has to be the whole run too --
        // keeping only the last step silently dropped everything the model said
        // before its first tool call.
        val transcript = StringBuilder()

        for (step in 1..maxSteps) {
            send(AgentEvent.StepStarted(step))

            val builder = StringBuilder()
            var failed: AiError? = null

            provider.chat(
                ChatRequest(
                    model = model,
                    messages = conversation.toList(),
                    systemPrompt = systemPrompt,
                    params = params,
                    stream = true
                )
            ).collect { event ->
                when (event) {
                    is ChatStreamEvent.Delta -> {
                        builder.append(event.text)
                        send(AgentEvent.Delta(event.text))
                    }
                    is ChatStreamEvent.Failure -> failed = event.error
                    else -> Unit
                }
            }

            val error = failed
            if (error != null) {
                send(AgentEvent.Failure(error))
                return@channelFlow
            }

            val answer = builder.toString()
            val calls = ToolCallParser.parse(answer)

            // Append this step's prose instead of replacing the total. A step whose
            // entire output was a tool call contributes nothing and must not erase
            // what came before it.
            val prose = ToolCallParser.stripToolBlocks(answer)
            if (prose.isNotBlank()) {
                if (transcript.isNotEmpty()) transcript.append("\n\n")
                transcript.append(prose)
            }

            if (calls.isEmpty()) break

            conversation += AiMessage(AiRole.Assistant, answer)
            val results = StringBuilder("Tool results:\n")

            for (call in calls) {
                val tool = tools.firstOrNull { it.name == call.tool }
                val preview = call.args.toString().take(160)
                send(AgentEvent.ToolStarted(call.tool, preview))

                val startedAt = System.currentTimeMillis()
                val result = if (tool == null) {
                    AgentToolResult("Unknown tool '${call.tool}'.", success = false)
                } else {
                    // `runCatching` also catches CancellationException, which
                    // turned pressing Stop mid-tool into a fake tool failure and
                    // let the loop start another step. Cancellation has to win.
                    try {
                        tool.execute(call.args, context)
                    } catch (cancellation: CancellationException) {
                        throw cancellation
                    } catch (t: Throwable) {
                        AgentToolResult("Tool failed: ${t.message}", success = false)
                    }
                }
                val duration = System.currentTimeMillis() - startedAt

                result.proposal?.let { proposals += it }

                val run = ToolRun(
                    id = UUID.randomUUID().toString(),
                    toolName = call.tool,
                    argumentsPreview = preview,
                    output = result.output.take(4000),
                    success = result.success,
                    durationMs = duration
                )
                send(AgentEvent.ToolFinished(run))

                results.appendLine("[${call.tool}] ${if (result.success) "ok" else "error"}")
                results.appendLine(result.output.take(MAX_TOOL_OUTPUT_CHARS))
                results.appendLine()
            }

            conversation += AiMessage(AiRole.User, results.toString())

            if (step == maxSteps && transcript.isBlank()) {
                transcript.append(
                    "Reached the step limit ($maxSteps). Ask me to continue if more work is needed."
                )
            }
        }

        if (proposals.isNotEmpty()) send(AgentEvent.Proposals(proposals))
        send(AgentEvent.Completed(transcript.toString().trim()))
    }

    companion object {
        private const val MAX_TOOL_OUTPUT_CHARS = 8000

        fun defaultTools(): List<AgentTool> = listOf(
            ReadFileTool(),
            ListDirectoryTool(),
            SearchFilesTool(),
            SearchTextTool(),
            AnalyzeProjectTool(),
            CreateFileTool(),
            WriteFileTool(),
            DeleteFileTool(),
            RenameFileTool(),
            MoveFileTool()
        )
    }
}
