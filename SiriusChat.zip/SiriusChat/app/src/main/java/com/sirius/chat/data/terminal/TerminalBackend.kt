package com.sirius.chat.data.terminal

import kotlinx.coroutines.flow.Flow
import java.io.File

/** A line of terminal output or a lifecycle signal. */
sealed interface TerminalEvent {
    data class Started(val command: String, val pid: Int?) : TerminalEvent
    data class Stdout(val line: String) : TerminalEvent
    data class Stderr(val line: String) : TerminalEvent

    /**
     * A remark from the engine itself rather than from the command: a
     * substituted working directory, truncated output, a missing capability.
     * Not stderr, because the command did not write it.
     */
    data class Notice(val message: String) : TerminalEvent
    data class Exited(val code: Int, val durationMs: Long) : TerminalEvent
    data class Failed(val reason: String) : TerminalEvent
}

/**
 * Pluggable terminal engine.
 *
 * Android's app sandbox limits what a process launched by an ordinary app can
 * do, so the engine is an interface rather than a hardcoded implementation:
 * [LocalShellBackend] runs commands inside the app sandbox, [TermuxShellBackend]
 * hands them to a real Termux installation with a package manager and a
 * toolchain, and a remote engine (ADB bridge, SSH) can be added later without
 * touching the UI.
 */
interface TerminalBackend {
    val id: String
    val displayName: String
    val description: String

    /**
     * Directory commands start in, or null to use the app's scratch directory.
     * Each engine lives on its own filesystem, so switching engines has to
     * move the prompt with it.
     */
    val home: File? get() = null

    /**
     * Whether [java.io.File] can inspect this engine's paths from our process.
     *
     * False for an engine that runs under a different uid: `/data/data/com.termux`
     * is unreadable to us, so `cd` cannot be validated locally and has to be
     * taken on trust, with the engine reporting the error instead.
     */
    val filesystemVisible: Boolean get() = true

    /** Extra note for the stop button on engines where stopping cannot kill the process. */
    val stopNotice: String? get() = null

    /** Whether this engine can run on the current device, right now. */
    fun isAvailable(): Boolean

    /** Why it cannot run, in the user's language, or null when it can. */
    fun unavailableReason(): String? = null

    fun execute(command: String, workingDirectory: File): Flow<TerminalEvent>

    /** Kills whatever is running. No-op on engines that cannot reach the process. */
    fun stop() {}
}
