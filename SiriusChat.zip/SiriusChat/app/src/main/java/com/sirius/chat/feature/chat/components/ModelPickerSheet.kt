package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.components.sheetDragGuard
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.ProviderAvatar
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.locale.displayLabel
import com.sirius.chat.domain.model.ProviderConfig

/** Above this many models across all providers, the sheet shows a search field. */
private const val SEARCH_THRESHOLD = 12

/** Provider + model selection in one compact sheet. */
@Composable
fun ModelPickerSheet(
    providers: List<ProviderConfig>,
    activeProviderId: String?,
    activeModel: String?,
    onSelect: (String, String) -> Unit,
    onManageProviders: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = SiriusTheme.colors

    SiriusBottomSheet(
        title = stringResource(R.string.chat_model_title),
        subtitle = stringResource(R.string.chat_model_subtitle),
        onDismiss = onDismiss,
        scrollable = false
    ) {
        val enabled = providers.filter { it.enabled }
        // With nothing configured the sheet was a title above a lone button; say
        // why the list is empty before pointing at the fix.
        if (enabled.isEmpty()) {
            Text(
                text = stringResource(R.string.home_no_provider),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary,
                modifier = Modifier.padding(vertical = SiriusSpacing.sm)
            )
        }

        // Adding a gateway's whole catalogue can leave hundreds of rows here, so
        // past a screenful the sheet gets a filter instead of an endless scroll.
        var query by remember { mutableStateOf("") }
        val searchable = enabled.sumOf { it.models.size } > SEARCH_THRESHOLD
        val shown = remember(enabled, query, searchable) {
            val needle = query.trim()
            if (!searchable || needle.isEmpty()) enabled
            else enabled.mapNotNull { provider ->
                // Typing a provider's name keeps everything it serves; typing a
                // model name narrows each provider to its matches.
                if (provider.label.contains(needle, ignoreCase = true)) provider
                else {
                    val models = provider.models.filter {
                        it.id.contains(needle, ignoreCase = true) ||
                            it.label.contains(needle, ignoreCase = true)
                    }
                    if (models.isEmpty()) null else provider.copy(models = models)
                }
            }
        }

        if (searchable) {
            VSpace(SiriusSpacing.xs)
            SiriusTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = stringResource(R.string.providers_model_search),
                leadingIcon = Icons.Rounded.Search,
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (shown.isEmpty() && enabled.isNotEmpty()) {
            VSpace(SiriusSpacing.xs)
            Text(
                text = stringResource(R.string.providers_model_no_match, query.trim()),
                style = MaterialTheme.typography.bodySmall,
                color = colors.warning
            )
        }

        LazyColumn(
            modifier = Modifier
                .heightIn(max = 420.dp)
                .sheetDragGuard(),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
        ) {
            shown.forEach { provider ->
                item(key = "header-${provider.id}") {
                    Row(
                        modifier = Modifier.padding(top = SiriusSpacing.xs),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Same mark as the providers screen, so the two lists read
                        // as the same set of endpoints.
                        ProviderAvatar(provider = provider, size = 24.dp)
                        Spacer(Modifier.width(SiriusSpacing.xs))
                        Text(
                            text = provider.displayLabel(),
                            style = MaterialTheme.typography.labelLarge,
                            color = colors.textSecondary
                        )
                        Spacer(Modifier.width(6.dp))
                        if (!provider.hasKey) {
                            Icon(
                                Icons.Rounded.Key,
                                contentDescription = stringResource(R.string.chat_no_api_key),
                                tint = colors.warning,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }
                }
                items(provider.models.size, key = { index -> "${provider.id}-${provider.models[index].id}" }) { index ->
                    val model = provider.models[index]
                    val isSelected = provider.id == activeProviderId && model.id == activeModel
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .softSurface(RoundedCornerShape(SiriusRadius.md))
                            // This is a single-choice list, so the rows have to say so:
                            // the tick alone left the current model unannounced.
                            .clickable(role = Role.RadioButton) { onSelect(provider.id, model.id) }
                            .semantics(mergeDescendants = true) { selected = isSelected }
                            .padding(horizontal = 12.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = model.label,
                                style = MaterialTheme.typography.titleSmall,
                                color = colors.textPrimary
                            )
                            if (model.contextWindow > 0) {
                                Text(
                                    text = stringResource(
                                        R.string.chat_context_window,
                                        model.contextWindow / 1000
                                    ),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colors.textTertiary
                                )
                            }
                        }
                        if (isSelected) {
                            Icon(
                                Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = colors.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.size(SiriusSpacing.sm))
        SiriusGhostButton(
            text = stringResource(R.string.chat_manage_providers),
            onClick = onManageProviders,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
