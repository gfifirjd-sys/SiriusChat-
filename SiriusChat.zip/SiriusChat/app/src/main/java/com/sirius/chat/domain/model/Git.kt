package com.sirius.chat.domain.model

/**
 * What happened to one path between two of git's three views of a file: HEAD,
 * the index and the working tree.
 */
enum class GitChangeType { Added, Modified, Deleted, Renamed, Copied, Untracked, Conflicted }

/**
 * One entry of `git status`.
 *
 * Git tracks a path in two places at once, so a single file can be both staged
 * and dirty (edited, added, then edited again). Modelling that as two separate
 * rows would make "stage" and "unstage" ambiguous, so both sides live here and
 * the UI renders whichever the user is acting on.
 */
data class GitFileStatus(
    val path: String,
    /** Change between HEAD and the index; `null` when the index matches HEAD. */
    val staged: GitChangeType?,
    /** Change between the index and the working tree; `null` when they match. */
    val unstaged: GitChangeType?,
    /** Previous path for a rename detected in the index. */
    val oldPath: String? = null
) {
    val isStaged: Boolean get() = staged != null
    val isDirty: Boolean get() = unstaged != null
    val isConflicted: Boolean get() =
        staged == GitChangeType.Conflicted || unstaged == GitChangeType.Conflicted
    val isUntracked: Boolean get() = unstaged == GitChangeType.Untracked

    /** The type worth showing on a single row. */
    val displayType: GitChangeType
        get() = when {
            isConflicted -> GitChangeType.Conflicted
            unstaged != null -> unstaged
            staged != null -> staged
            else -> GitChangeType.Modified
        }

    val name: String get() = path.substringAfterLast('/')
}

/** Where the working tree currently sits. */
data class GitBranch(
    val name: String,
    val isCurrent: Boolean,
    val lastCommitMessage: String? = null,
    val lastCommitAt: Long = 0L
)

data class GitCommit(
    val id: String,
    val shortId: String,
    val message: String,
    val authorName: String,
    val authorEmail: String,
    val timestamp: Long,
    val parentCount: Int
) {
    /** First line only; the body belongs on a detail screen, not in a list. */
    val summary: String get() = message.lineSequence().firstOrNull()?.trim().orEmpty()
    val isMerge: Boolean get() = parentCount > 1
}

/**
 * Everything the git screen needs in one read.
 *
 * Status, branch and history are gathered in a single pass because each one
 * opens the repository, and opening it three times on a phone is three times
 * the disk work for the same answer.
 */
data class GitStatus(
    val branch: String,
    val detachedHead: Boolean = false,
    val files: List<GitFileStatus> = emptyList(),
    val commits: List<GitCommit> = emptyList(),
    val branches: List<GitBranch> = emptyList(),
    /** True before the first commit exists, when HEAD points at nothing yet. */
    val unborn: Boolean = false
) {
    val stagedFiles: List<GitFileStatus> get() = files.filter { it.isStaged && !it.isConflicted }
    val unstagedFiles: List<GitFileStatus> get() = files.filter { it.isDirty && !it.isConflicted }
    val conflicted: List<GitFileStatus> get() = files.filter { it.isConflicted }
    val isClean: Boolean get() = files.isEmpty()
    val canCommit: Boolean get() = stagedFiles.isNotEmpty() && conflicted.isEmpty()
}

/**
 * Why the git screen cannot work, as a state rather than an exception.
 *
 * Each case has a different remedy, and the screen offers exactly one action
 * per case instead of a generic error.
 */
sealed interface GitUnavailable {
    /** The project has no folder attached yet. */
    data object NoWorkspace : GitUnavailable

    /** The folder is not on a volume that maps to a filesystem path. */
    data class NotOnFilesystem(val label: String) : GitUnavailable

    /** All-files access has not been granted. */
    data object NeedsPermission : GitUnavailable

    /** The folder resolves, but there is no repository in it. */
    data class NotARepository(val path: String) : GitUnavailable

    /** Anything JGit refused to open. */
    data class Broken(val reason: String) : GitUnavailable
}
