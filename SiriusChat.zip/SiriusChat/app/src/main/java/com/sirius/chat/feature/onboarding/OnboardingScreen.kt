package com.sirius.chat.feature.onboarding

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusOrb
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.siriusFadeThrough
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.ui.rememberWorkspacePicker
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.di.AppContainer
import kotlinx.coroutines.launch

class OnboardingViewModel(private val container: AppContainer) : ViewModel() {

    fun createWorkspaceProject(treeUri: String, onDone: () -> Unit) {
        viewModelScope.launch {
            val project = container.createProject(name = "", treeUri = treeUri)
            container.settingsRepository.update { it.copy(activeProjectId = project.id) }
            onDone()
        }
    }

    fun finish(onDone: () -> Unit) {
        viewModelScope.launch {
            container.settingsRepository.update { it.copy(onboardingDone = true) }
            onDone()
        }
    }
}

private const val StepCount = 3

/** First run: explain the product, offer a workspace, then get out of the way. */
@Composable
fun OnboardingScreen(
    onFinished: () -> Unit,
    onOpenProviders: () -> Unit
) {
    val viewModel: OnboardingViewModel = siriusViewModel { OnboardingViewModel(it) }
    val colors = SiriusTheme.colors
    var step by remember { mutableIntStateOf(0) }
    var workspaceReady by remember { mutableStateOf(false) }

    val picker = rememberWorkspacePicker { treeUri ->
        viewModel.createWorkspaceProject(treeUri) {
            workspaceReady = true
            step = 2
        }
    }

    // Back should walk the flow backwards before it leaves it; dropping out of
    // onboarding on the first press loses the step the user just completed.
    BackHandler(enabled = step > 0) { step-- }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(SiriusSpacing.lg),
        verticalArrangement = Arrangement.Center
    ) {
        // The orb is the app's mark; on the first screen it is also the only thing
        // moving, so it carries the "alive" impression by itself.
        SiriusOrb(size = 74.dp, active = step == 0)
        VSpace(SiriusSpacing.lg)

        // transitionSpec is a plain lambda, so the transition has to be read from
        // the theme out here where composition is still available.
        val (stepEnter, stepExit) = siriusFadeThrough()
        AnimatedContent(
            targetState = step,
            transitionSpec = { stepEnter togetherWith stepExit },
            label = "onboarding"
        ) { current ->
            Column {
                when (current) {
                    0 -> {
                        Text(
                            text = stringResource(R.string.onboarding_intro_title),
                            style = MaterialTheme.typography.displaySmall,
                            color = colors.textPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        VSpace(SiriusSpacing.xs)
                        Text(
                            text = stringResource(R.string.onboarding_intro),
                            style = MaterialTheme.typography.bodyLarge,
                            color = colors.textSecondary
                        )
                    }

                    1 -> {
                        StepBody(
                            title = stringResource(R.string.onboarding_workspace_title),
                            body = stringResource(R.string.onboarding_workspace_body)
                        ) {
                            ActionCard(
                                icon = Icons.Rounded.FolderOpen,
                                tint = colors.primary,
                                label = stringResource(
                                    if (workspaceReady) R.string.onboarding_workspace_change
                                    else R.string.onboarding_select_folder
                                ),
                                onClick = { picker.launch(null) }
                            )
                        }
                    }

                    else -> {
                        StepBody(
                            title = stringResource(R.string.onboarding_model_title),
                            body = stringResource(R.string.onboarding_model_body)
                        ) {
                            ActionCard(
                                icon = Icons.Rounded.Key,
                                tint = colors.accent,
                                label = stringResource(R.string.onboarding_open_providers),
                                onClick = onOpenProviders
                            )
                            VSpace(SiriusSpacing.xs)
                            Text(
                                text = stringResource(R.string.onboarding_later),
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textTertiary
                            )
                        }
                    }
                }
            }
        }

        VSpace(SiriusSpacing.xl)

        // A confirmation the user can miss is worth nothing: it stays put on the
        // step it belongs to and is announced when it appears.
        if (workspaceReady && step >= 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics { liveRegion = LiveRegionMode.Polite },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint = colors.success,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(Modifier.width(SiriusSpacing.xxs))
                Text(
                    text = stringResource(R.string.onboarding_workspace_connected),
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.success,
                    textAlign = TextAlign.Center
                )
            }
            VSpace(SiriusSpacing.sm)
        }

        StepIndicator(step = step)

        VSpace(SiriusSpacing.md)

        Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
            SiriusGhostButton(
                text = stringResource(
                    if (step > 0) R.string.action_back else R.string.action_skip
                ),
                onClick = {
                    if (step > 0) step-- else viewModel.finish(onFinished)
                },
                modifier = Modifier.weight(1f)
            )
            SiriusPrimaryButton(
                text = stringResource(
                    if (step >= StepCount - 1) R.string.action_start else R.string.action_next
                ),
                onClick = {
                    if (step >= StepCount - 1) viewModel.finish(onFinished) else step++
                },
                modifier = Modifier.weight(1f)
            )
        }

        // Skipping is always available, but it should not masquerade as "Back".
        if (step > 0) {
            VSpace(SiriusSpacing.xs)
            SiriusGhostButton(
                text = stringResource(R.string.action_skip),
                tint = colors.textTertiary,
                onClick = { viewModel.finish(onFinished) },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/** Title, supporting paragraph and whatever the step asks the user to do. */
@Composable
private fun StepBody(
    title: String,
    body: String,
    content: @Composable () -> Unit
) {
    val colors = SiriusTheme.colors
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            color = colors.textPrimary
        )
        VSpace(SiriusSpacing.xs)
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary
        )
        VSpace(SiriusSpacing.md)
        content()
    }
}

/** The one thing to tap on a step, as a full-width card. */
@Composable
private fun ActionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: androidx.compose.ui.graphics.Color,
    label: String,
    onClick: () -> Unit
) {
    val colors = SiriusTheme.colors
    GlassCard(onClick = onClick, onClickLabel = label, modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(SiriusSpacing.sm))
            Text(
                text = label,
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary
            )
        }
    }
}

/**
 * Three segments that fill as the flow advances.
 *
 * Sighted users read the position from the bars; everyone else gets it from the
 * one spoken label on the row, which is why the segments themselves are silent.
 */
@Composable
private fun StepIndicator(step: Int) {
    val colors = SiriusTheme.colors
    val label = stringResource(R.string.onboarding_step, step + 1, StepCount)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .semantics { contentDescription = label },
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
    ) {
        repeat(StepCount) { index ->
            val fill by animateColorAsState(
                targetValue = if (index <= step) colors.primary else colors.outline,
                animationSpec = siriusTween(SiriusMotion.Base),
                label = "stepFill"
            )
            Box(
                modifier = Modifier
                    .height(4.dp)
                    .weight(1f)
                    .clip(RoundedCornerShape(SiriusRadius.pill))
                    .background(fill)
                    .clearAndSetSemantics { }
            )
        }
    }
}
