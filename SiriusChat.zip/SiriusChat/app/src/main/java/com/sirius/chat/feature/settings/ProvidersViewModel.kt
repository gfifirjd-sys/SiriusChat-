package com.sirius.chat.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.ai.provider.ProbeResult
import com.sirius.chat.ai.provider.ProviderProbe
import com.sirius.chat.core.designsystem.components.deleteProviderIcon
import com.sirius.chat.core.locale.displayLabel
import com.sirius.chat.data.local.preferences.ProviderPreset
import com.sirius.chat.data.local.preferences.ProviderPresets
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class ProviderEditor(
    val id: String? = null,
    val label: String = "",
    /** Set for shipped templates whose name is a string resource. */
    val labelKey: String? = null,
    val baseUrl: String = "",
    val type: ProviderType = ProviderType.OpenAiCompatible,
    val models: String = "",
    val apiKey: String = "",
    val builtIn: Boolean = false,
    /** Key of a built-in mark; ignored while [iconImagePath] is set. */
    val iconKey: String? = null,
    /** Path to an image copied out of the gallery, or `null` for a built-in mark. */
    val iconImagePath: String? = null,
    /**
     * The image the provider already had when the sheet opened. Kept so a
     * cancelled edit never deletes a file the saved provider still points at.
     */
    val savedIconImagePath: String? = null
) {
    /**
     * The models field parsed into ids.
     *
     * The field stays free text so anyone can paste an id no endpoint advertises,
     * while the picker needs the same list as a set to mark what is already in.
     */
    fun modelIds(): List<String> = models
        .split(',', '\n')
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()
}

/**
 * Outcome of the last connection check, shown inside the editor sheet.
 *
 * Kept separate from [ProviderEditor] because it is not something the user typed
 * and must never be written back to the provider on save.
 */
sealed interface ProbeState {
    data object Idle : ProbeState
    data object Running : ProbeState

    /**
     * The endpoint answered. [models] is its own catalogue, which the user picks
     * from; an empty list still means the key and URL work.
     */
    data class Success(val models: List<AiModel>, val message: String) : ProbeState

    data class Failure(val message: String) : ProbeState
}

data class ProvidersUiState(
    /** Exactly what the user added; nothing is here that they did not choose. */
    val providers: List<ProviderConfig> = emptyList(),
    /** Presets not yet added, offered in the catalogue sheet. */
    val catalog: List<ProviderPreset> = emptyList(),
    /** `true` while the catalogue sheet is open. */
    val catalogOpen: Boolean = false,
    val settings: AppSettings = AppSettings(),
    val editor: ProviderEditor? = null,
    /** Result of the editor's connection check; resets whenever the sheet opens. */
    val probe: ProbeState = ProbeState.Idle,
    /** Free text filtering the discovered model list. */
    val modelQuery: String = "",
    val message: String? = null
)

class ProvidersViewModel(private val container: AppContainer) : ViewModel() {

    private val _editor = MutableStateFlow<ProviderEditor?>(null)
    private val _message = MutableStateFlow<String?>(null)
    private val _catalogOpen = MutableStateFlow(false)
    private val _probe = MutableStateFlow<ProbeState>(ProbeState.Idle)
    private val _modelQuery = MutableStateFlow("")
    private val probe = ProviderProbe()

    /** The in-flight check, kept so a second tap replaces it instead of racing it. */
    private var probeJob: Job? = null

    /** Everything the editor sheet owns, folded into one flow to stay inside combine's arity. */
    private val editorState = combine(
        _editor,
        _probe,
        _modelQuery
    ) { editor, probeState, query -> Triple(editor, probeState, query) }

    val state: StateFlow<ProvidersUiState> = combine(
        container.providerRepository.observeProviders(),
        container.settingsRepository.settings,
        editorState,
        _message,
        _catalogOpen
    ) { providers, settings, editorBundle, message, catalogOpen ->
        val kept = providers.filter { it.enabled }
        val (editor, probeState, modelQuery) = editorBundle
        ProvidersUiState(
            providers = kept,
            // A preset already in the list is not offered again; adding it twice
            // would just collide on its id.
            catalog = ProviderPresets.all.filter { preset ->
                kept.none { it.id == preset.config.id }
            },
            catalogOpen = catalogOpen,
            settings = settings,
            editor = editor,
            probe = probeState,
            modelQuery = modelQuery,
            message = message
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ProvidersUiState())

    fun startEdit(config: ProviderConfig) {
        // A result from the previous provider would be read as this one's.
        resetProbe()
        _editor.value = ProviderEditor(
            id = config.id,
            label = config.label,
            labelKey = config.labelKey,
            baseUrl = config.baseUrl,
            type = config.type,
            models = config.models.joinToString(", ") { it.id },
            builtIn = config.builtIn,
            iconKey = config.iconKey,
            iconImagePath = config.iconImagePath,
            savedIconImagePath = config.iconImagePath
        )
    }

    fun startCreate() {
        resetProbe()
        _editor.value = ProviderEditor(
            label = container.strings.get(R.string.providers_default_label),
            baseUrl = "https://",
            type = ProviderType.OpenAiCompatible,
            iconKey = "robot"
        )
    }

    /** Picking a built-in mark drops the custom image; the two cannot both win. */
    fun selectIcon(key: String) {
        _editor.value = _editor.value?.let { editor ->
            editor.discardDraftImage()
            editor.copy(iconKey = key, iconImagePath = null)
        }
    }

    /** [path] is a copy already inside app storage, produced by `saveProviderIcon`. */
    fun selectIconImage(path: String) {
        _editor.value = _editor.value?.let { editor ->
            if (editor.iconImagePath != path) editor.discardDraftImage()
            editor.copy(iconImagePath = path)
        }
    }

    fun clearIconImage() {
        _editor.value = _editor.value?.let { editor ->
            editor.discardDraftImage()
            editor.copy(iconImagePath = null)
        }
    }

    fun updateEditor(transform: (ProviderEditor) -> ProviderEditor) {
        val before = _editor.value ?: return
        val after = transform(before)
        _editor.value = after
        // A "Connected" badge next to a URL or key the user has since changed is a
        // lie, so the result dies with the thing it was about.
        if (after.baseUrl != before.baseUrl ||
            after.apiKey != before.apiKey ||
            after.type != before.type
        ) {
            resetProbe()
        }
    }

    /**
     * Asks the endpoint for its model list.
     *
     * This is both the connection check and the model finder: one free `GET` says
     * whether the URL resolves, whether the key is accepted, and what can be run.
     * Nothing is generated, so nothing is billed.
     */
    fun checkConnection() {
        val editor = _editor.value ?: return
        val url = editor.baseUrl.trim()
        if (!url.startsWith("http")) return

        probeJob?.cancel()
        _probe.value = ProbeState.Running
        probeJob = viewModelScope.launch {
            // An empty field means "keep the stored key", so the check has to use
            // the saved one or it would report a false 401.
            val key = editor.apiKey.trim().ifBlank {
                editor.id?.let { container.providerRepository.apiKey(it) }
            }
            val config = ProviderConfig(
                id = editor.id ?: "probe",
                label = editor.label,
                type = editor.type,
                baseUrl = url.trimEnd('/')
            )
            _probe.value = when (val result = probe.listModels(config, key)) {
                is ProbeResult.Ok -> ProbeState.Success(
                    models = result.models,
                    message = if (result.models.isEmpty()) {
                        container.strings.get(R.string.providers_probe_ok_empty)
                    } else {
                        container.strings.get(R.string.providers_probe_ok, result.models.size)
                    }
                )

                is ProbeResult.Failure -> ProbeState.Failure(result.error.message)
            }
        }
    }

    fun updateModelQuery(query: String) {
        _modelQuery.value = query
    }

    /** Adds or drops one discovered model id in the editor's list. */
    fun toggleModel(modelId: String) {
        val editor = _editor.value ?: return
        val current = editor.modelIds()
        val next = if (modelId in current) current - modelId else current + modelId
        _editor.value = editor.copy(models = next.joinToString(", "))
    }

    /**
     * Appends every model matching the current filter.
     *
     * Gateways like OpenRouter list hundreds, so this respects the search box: it
     * adds what the user is looking at, not the whole registry.
     */
    fun addAllModels(models: List<AiModel>) {
        val editor = _editor.value ?: return
        val current = editor.modelIds()
        val next = current + models.map { it.id }.filterNot { it in current }
        _editor.value = editor.copy(models = next.joinToString(", "))
    }

    private fun resetProbe() {
        probeJob?.cancel()
        probeJob = null
        _probe.value = ProbeState.Idle
        _modelQuery.value = ""
    }

    fun cancelEdit() {
        // Anything picked and then abandoned would otherwise sit in app storage
        // forever with nothing pointing at it.
        _editor.value?.discardDraftImage()
        _editor.value = null
        resetProbe()
    }

    /**
     * Deletes the editor's current image only when it is a copy this session
     * made. The provider's already-saved image is left alone: it is still the
     * one on disk if the edit is abandoned.
     */
    private fun ProviderEditor.discardDraftImage() {
        if (iconImagePath != null && iconImagePath != savedIconImagePath) {
            deleteProviderIcon(iconImagePath)
        }
    }

    fun saveEditor() {
        val editor = _editor.value ?: return
        viewModelScope.launch {
            // A discovered model keeps the name the endpoint gave it, so the chip
            // reads "Claude 3.5 Sonnet" rather than a raw slug.
            val discovered = (_probe.value as? ProbeState.Success)?.models.orEmpty()
                .associateBy { it.id }
            val models = editor.modelIds().map { id -> discovered[id] ?: AiModel(id) }

            val config = ProviderConfig(
                id = editor.id ?: "custom-${UUID.randomUUID().toString().take(8)}",
                label = editor.label.ifBlank {
                    container.strings.get(R.string.providers_custom_label)
                },
                labelKey = editor.labelKey,
                type = editor.type,
                baseUrl = editor.baseUrl.trim().trimEnd('/'),
                models = models,
                defaultModel = models.firstOrNull()?.id.orEmpty(),
                builtIn = editor.builtIn,
                iconKey = editor.iconKey,
                iconImagePath = editor.iconImagePath
            )
            // The replaced image is only safe to drop once the new one is stored.
            if (editor.savedIconImagePath != null &&
                editor.savedIconImagePath != editor.iconImagePath
            ) {
                deleteProviderIcon(editor.savedIconImagePath)
            }
            container.providerRepository.upsert(config)
            if (editor.apiKey.isNotBlank()) {
                container.providerRepository.setApiKey(config.id, editor.apiKey.trim())
            }
            // With an empty list on a fresh install, the first endpoint saved has
            // to become the active one or chat would have nothing to talk to.
            if (container.settingsRepository.settings.first().activeProviderId.isBlank()) {
                activateConfig(config)
            }
            _editor.value = null
            resetProbe()
            _message.value = container.strings.get(
                R.string.providers_saved,
                config.displayLabel(container.strings)
            )
        }
    }

    fun activate(config: ProviderConfig) {
        viewModelScope.launch { activateConfig(config) }
    }

    private suspend fun activateConfig(config: ProviderConfig) {
        container.settingsRepository.update {
            it.copy(
                activeProviderId = config.id,
                activeModel = config.defaultModel.ifBlank {
                    config.models.firstOrNull()?.id.orEmpty()
                }
            )
        }
    }

    fun selectModel(config: ProviderConfig, modelId: String) {
        viewModelScope.launch {
            container.settingsRepository.update {
                it.copy(activeProviderId = config.id, activeModel = modelId)
            }
        }
    }

    fun removeKey(config: ProviderConfig) {
        viewModelScope.launch {
            container.providerRepository.clearApiKey(config.id)
            _message.value = container.strings.get(
                R.string.providers_removed_key,
                config.displayLabel(container.strings)
            )
        }
    }

    fun delete(config: ProviderConfig) {
        viewModelScope.launch {
            val label = config.displayLabel(container.strings)
            // An editor still open on this provider would write it straight back
            // into the list on save, so it closes with the row.
            if (_editor.value?.id == config.id) _editor.value = null

            // The row is gone for good, so the file behind its picture goes too.
            deleteProviderIcon(config.iconImagePath)
            container.providerRepository.delete(config.id)

            // The deleted id must not stay selected: every screen resolves the
            // active provider by id and would silently find nothing.
            val settings = container.settingsRepository.settings.first()
            if (settings.activeProviderId == config.id) {
                val remaining = container.providerRepository.providers().filter { it.enabled }
                val next = remaining.firstOrNull { it.hasKey } ?: remaining.firstOrNull()
                container.settingsRepository.update {
                    it.copy(
                        activeProviderId = next?.id.orEmpty(),
                        activeModel = next?.defaultModel
                            ?.ifBlank { next.models.firstOrNull()?.id.orEmpty() }
                            .orEmpty()
                    )
                }
            }
            _message.value = container.strings.get(R.string.providers_deleted, label)
        }
    }

    fun openCatalog() {
        _catalogOpen.value = true
    }

    fun closeCatalog() {
        _catalogOpen.value = false
    }

    /**
     * Adds a preset as an ordinary provider and opens the editor on it, because a
     * keyed endpoint cannot answer anything until the user pastes their key. The
     * two local engines need none, so they are simply activated.
     */
    fun addPreset(preset: ProviderPreset) {
        viewModelScope.launch {
            _catalogOpen.value = false
            container.providerRepository.upsert(preset.config)
            if (preset.requiresKey) {
                startEdit(preset.config)
            } else {
                activateConfig(preset.config)
            }
            _message.value = container.strings.get(
                R.string.providers_added,
                preset.config.displayLabel(container.strings)
            )
        }
    }

    fun consumeMessage() {
        _message.value = null
    }
}
