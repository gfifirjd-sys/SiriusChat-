package com.sirius.chat.feature.editor.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.codeTextStyle
import com.sirius.chat.core.util.CodeLanguage
import com.sirius.chat.core.util.FoldRegion
import com.sirius.chat.core.util.SyntaxHighlighter

/**
 * Read-only viewer used for large files and whenever folding is active.
 *
 * Rendering line by line inside a LazyColumn means a 20k line file costs the
 * same as a 50 line one, which is what makes opening real project files on a
 * phone viable.
 */
@Composable
fun CodeViewer(
    content: String,
    language: CodeLanguage,
    fontSize: Int,
    showLineNumbers: Boolean,
    folds: List<FoldRegion>,
    collapsed: Set<Int>,
    onToggleFold: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors
    val textStyle = codeTextStyle(fontSize)
    val horizontal = rememberScrollState()

    val lines = remember(content) { content.lines() }
    val foldByStart = remember(folds) { folds.associateBy { it.startLine } }

    val hiddenLines = remember(collapsed, folds) {
        val hidden = HashSet<Int>()
        collapsed.forEach { start ->
            foldByStart[start]?.let { region ->
                for (line in (region.startLine + 1)..region.endLine) hidden += line
            }
        }
        hidden
    }

    val visibleIndices = remember(lines, hiddenLines) {
        lines.indices.filterNot { it in hiddenLines }
    }

    val gutterWidth = (10 + lines.size.toString().length * (fontSize * 0.62f)).dp

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.codeBackground)
            .horizontalScroll(horizontal)
    ) {
        items(visibleIndices.size, key = { visibleIndices[it] }) { position ->
            val index = visibleIndices[position]
            val region = foldByStart[index]
            val highlighted = remember(lines[index], language, colors.isDark) {
                SyntaxHighlighter.highlight(lines[index], language, colors)
            }

            Row(verticalAlignment = Alignment.Top) {
                if (showLineNumbers) {
                    Text(
                        text = "${index + 1}",
                        style = textStyle,
                        color = colors.codeComment,
                        textAlign = TextAlign.End,
                        modifier = Modifier
                            .width(gutterWidth)
                            .padding(end = 6.dp)
                    )
                }
                Box(modifier = Modifier.size(width = 18.dp, height = (fontSize * 1.45f).dp)) {
                    if (region != null) {
                        Icon(
                            imageVector = if (index in collapsed) {
                                Icons.Rounded.ChevronRight
                            } else {
                                Icons.Rounded.ExpandMore
                            },
                            contentDescription = stringResource(R.string.editor_fold),
                            tint = colors.codeComment,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { onToggleFold(index) }
                        )
                    }
                }
                Text(
                    text = highlighted,
                    style = textStyle,
                    color = colors.codePlain,
                    softWrap = false,
                    modifier = Modifier.padding(end = 16.dp)
                )
                if (region != null && index in collapsed) {
                    Text(
                        text = pluralStringResource(
                            R.plurals.editor_folded_lines,
                            region.lineCount,
                            region.lineCount
                        ),
                        style = textStyle,
                        color = colors.codeComment
                    )
                }
            }
        }
    }
}
