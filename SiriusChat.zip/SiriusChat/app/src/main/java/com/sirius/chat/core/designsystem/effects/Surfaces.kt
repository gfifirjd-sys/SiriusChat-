package com.sirius.chat.core.designsystem.effects

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusPalette
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.domain.model.GlassLevel

/**
 * Flat chrome.
 *
 * Surfaces used to be milled metal plates: a body gradient, a specular sweep and
 * a bevelled rim on every card, chip and toolbar. With a real liquid-metal
 * shader now carrying the accent (`LiquidMetal.kt`), all of that competed with
 * it, so every surface here is deliberately inert — one opaque fill from the
 * value ramp plus one hairline edge.
 *
 * That is the whole vocabulary. Depth comes from the fill being a step lighter
 * than what is behind it, not from shading, and the only surface allowed a
 * shadow is one that genuinely floats above the page (sheet, dialog, composer).
 */

/** Hairline width. One physical-ish line at any density; never scaled up. */
val SiriusHairline: Dp = 1.dp

/**
 * A page-level surface: cards, toolbars, the composer, sheets.
 *
 * [tint] overrides the fill for semantic surfaces (an error banner, a project
 * accent). [elevation] is a *shadow* hint only — the fill never changes with it,
 * so a raised card and a flush one are the same colour, as they should be in a
 * flat system. [highlight] keeps the top edge of the hairline a touch brighter,
 * which is the one concession to lighting that survived the flattening: it is
 * what stops a 16dp-radius panel from disappearing into a near-black page.
 */
@Composable
fun Modifier.glassSurface(
    shape: Shape = RoundedCornerShape(SiriusRadius.lg),
    elevation: Dp = 10.dp,
    tint: Color? = null,
    borderAlpha: Float = 1f,
    highlight: Boolean = true
): Modifier {
    val colors = SiriusTheme.colors
    val level = SiriusTheme.glass
    val fill = tint ?: colors.surface

    // Shadows are cheap but they are also the main way a flat dark UI turns
    // muddy, so they are capped hard and skipped entirely when effects are off.
    val lifted = if (level == GlassLevel.Off || elevation <= 0.dp) {
        Modifier
    } else {
        val depth = if (elevation > 12.dp) 12.dp else elevation
        Modifier.shadow(
            elevation = depth,
            shape = shape,
            clip = false,
            ambientColor = colors.metalShadow,
            spotColor = colors.metalShadow
        )
    }

    return this
        .then(lifted)
        .clip(shape)
        .background(fill, shape)
        .border(
            BorderStroke(
                width = SiriusHairline,
                brush = if (highlight) {
                    metalBevelBrush(colors, borderAlpha)
                } else {
                    SolidColor(colors.metalRim.copy(alpha = colors.metalRim.alpha * borderAlpha))
                }
            ),
            shape = shape
        )
}

/**
 * The dense variant: chips, pills, icon buttons, list rows. Same rules, one step
 * lighter than a [glassSurface] so a control inside a card is still visible, and
 * never any shadow — these sit *in* the page, not above it.
 */
@Composable
fun Modifier.softSurface(
    shape: Shape = RoundedCornerShape(SiriusRadius.pill),
    alpha: Float = 1f
): Modifier {
    val colors = SiriusTheme.colors
    val fill = colors.surfaceMuted.copy(alpha = colors.surfaceMuted.alpha * alpha)
    return clip(shape)
        .background(fill, shape)
        .border(SiriusHairline, metalBevelBrush(colors, alpha), shape)
}

/**
 * Flat fill for a surface. Kept as a `Brush` factory because callers pass it
 * straight to `background(...)`; [tint] is nudged one step darker so a tinted
 * plate still separates from the accent text on top of it.
 */
fun metalBodyBrush(colors: SiriusPalette, tint: Color? = null): Brush =
    SolidColor(tint?.let { lerpColor(it, Color.Black, 0.06f) } ?: colors.surface)

/**
 * The top-edge highlight, and the only thing left of the old specular sweep: a
 * short fade from a faint light at the top edge to nothing by a third of the
 * way down. On a fill this is invisible at a glance and just keeps the upper
 * border from reading as a hard line.
 */
fun metalSheenBrush(colors: SiriusPalette): Brush = Brush.verticalGradient(
    0.00f to colors.metalSpecular,
    0.34f to Color.Transparent,
    1.00f to Color.Transparent
)

/**
 * The hairline. Vertical rather than flat so the top edge is slightly lit and
 * the bottom slightly recessed — a one-value-step difference, enough for the eye
 * to place the surface without any gradient being perceptible.
 */
fun metalBevelBrush(colors: SiriusPalette, alpha: Float = 1f): Brush = Brush.verticalGradient(
    0.00f to colors.metalRimLight.copy(alpha = colors.metalRimLight.alpha * alpha),
    0.45f to colors.metalRim.copy(alpha = colors.metalRim.alpha * alpha),
    1.00f to colors.metalRim.copy(alpha = colors.metalRim.alpha * 0.55f * alpha)
)

/**
 * Filled accent plate (primary button, armed send). Flat: the shader ring is
 * what makes such a control feel metallic now, so the fill underneath it must
 * stay a single solid colour or the two effects fight.
 */
fun liquidMetalBrush(colors: SiriusPalette, base: Color, edge: Color): Brush = SolidColor(base)

internal fun lerpColor(a: Color, b: Color, t: Float): Color = Color(
    red = a.red + (b.red - a.red) * t,
    green = a.green + (b.green - a.green) * t,
    blue = a.blue + (b.blue - a.blue) * t,
    alpha = a.alpha + (b.alpha - a.alpha) * t
)
