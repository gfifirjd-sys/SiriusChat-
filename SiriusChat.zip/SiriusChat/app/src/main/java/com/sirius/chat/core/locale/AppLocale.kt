package com.sirius.chat.core.locale

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.sirius.chat.domain.model.AppLanguage
import java.util.Locale

/** The [Locale] this language maps to, or `null` when it follows the system. */
fun AppLanguage.locale(): Locale? =
    if (tag.isEmpty()) null else Locale.forLanguageTag(tag)

/**
 * Returns a context whose resources resolve against [language].
 *
 * Used instead of `AppCompatDelegate.setApplicationLocales` because the app
 * runs on plain `ComponentActivity` and has no AppCompat dependency; a
 * configuration-scoped context flips the language without recreating the
 * activity, so the in-app switch is instant and survives no state.
 */
fun Context.localizedFor(language: AppLanguage): Context {
    val locale = language.locale() ?: return this
    val config = Configuration(resources.configuration).apply {
        setLocale(locale)
        setLocales(LocaleList(locale))
    }
    return createConfigurationContext(config)
}

/**
 * Makes every `stringResource` call below it resolve in [language].
 *
 * `stringResource` reads `LocalContext.resources`, and `LocalConfiguration` is
 * overridden too so components that format dates or numbers see the same
 * locale.
 */
@Composable
fun ProvideAppLanguage(
    language: AppLanguage,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current

    val localizedContext = remember(context, language, configuration) {
        context.localizedFor(language)
    }
    val localizedConfiguration = remember(localizedContext) {
        localizedContext.resources.configuration
    }

    CompositionLocalProvider(
        LocalContext provides localizedContext,
        LocalConfiguration provides localizedConfiguration,
        content = content
    )
}
