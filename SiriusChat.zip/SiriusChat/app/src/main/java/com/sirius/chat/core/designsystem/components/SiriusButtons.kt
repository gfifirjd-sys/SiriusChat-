package com.sirius.chat.core.designsystem.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.disabled
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.siriusRise
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.designsystem.touchTarget
import com.sirius.chat.core.designsystem.effects.ambientGlow
import com.sirius.chat.core.designsystem.effects.beamBorder
import com.sirius.chat.core.designsystem.effects.SiriusHairline
import com.sirius.chat.core.designsystem.effects.metalBevelBrush
import com.sirius.chat.core.designsystem.effects.softSurface
import com.sirius.chat.core.util.rememberHaptics

/**
 * Which of the two meanings a filled plate can carry.
 *
 * There is no third tone on purpose: "primary" is the default path forward and
 * "danger" is the one that destroys something. Anything else belongs on a ghost.
 */
enum class SiriusButtonTone { Primary, Danger }

/**
 * Primary call to action: a solid plate, the highest-contrast fill in the app.
 *
 * In a flat, near-black interface contrast is the only weight available, so this
 * is the one control filled with `primary` (an off-white in dark mode, near-black
 * in light) — it needs no gradient, sheen or bevel to outrank everything around
 * it. A restrained [ambientGlow] separates it from the page, a spring press keeps
 * it tactile, and while [loading] a [beamBorder] travels the outline so a slow
 * request looks like work rather than a frozen button.
 *
 * [tone] recolours the plate for destructive confirmations, which need the same
 * weight as the primary action but must never be mistaken for it.
 */
@Composable
fun SiriusPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    loading: Boolean = false,
    tone: SiriusButtonTone = SiriusButtonTone.Primary
) {
    val colors = SiriusTheme.colors
    val fill = when (tone) {
        SiriusButtonTone.Primary -> colors.primary
        SiriusButtonTone.Danger -> colors.error
    }
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.965f else 1f,
        animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
        label = "btnPress"
    )
    // The bloom dims on press: the plate reads as pushed *into* the surface.
    val glow by animateFloatAsState(
        targetValue = when {
            !enabled -> 0f
            pressed -> 0.22f
            else -> 0.5f
        },
        animationSpec = siriusSpring(),
        label = "btnGlow"
    )
    val shape = RoundedCornerShape(SiriusRadius.md)
    // Disabled dims the plate itself rather than fading the whole node: node-wide
    // alpha also faded the border and the glow, which left a barely-there shape
    // that did not read as a button at all.
    val plate = if (enabled) fill else fill.copy(alpha = 0.38f)
    val ink = if (enabled) colors.onPrimary else colors.onPrimary.copy(alpha = 0.62f)

    Row(
        modifier = modifier
            .scale(scale)
            .ambientGlow(color = fill, shape = shape, radius = 16.dp, alpha = glow)
            .clip(shape)
            .background(plate, shape)
            .border(SiriusHairline, metalBevelBrush(colors), shape)
            .beamBorder(shape = shape, active = loading, rim = false, head = colors.onPrimary)
            .clickable(
                enabled = enabled && !loading,
                interactionSource = interaction,
                indication = null,
                role = Role.Button
            ) {
                haptics.light()
                onClick()
            }
            .semantics { if (!enabled) disabled() }
            .padding(horizontal = 20.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                strokeWidth = 2.dp,
                color = ink
            )
        } else if (icon != null) {
            Icon(icon, contentDescription = null, tint = ink, modifier = Modifier.size(18.dp))
        }
        // One line, always. Half-width buttons sit side by side all over the app
        // and a translated label ("Настроить фон") is wider than the plate it has
        // to fit in: without this the label wraps to one letter per line instead
        // of truncating, which is unreadable and stretches the button vertically.
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = ink,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Secondary action: the dense surface fill, no accent colour and no bloom. */
@Composable
fun SiriusGhostButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    tint: Color? = null,
    enabled: Boolean = true
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = siriusSpring(),
        label = "ghostPress"
    )
    val shape = RoundedCornerShape(SiriusRadius.md)
    // Disabled fades the *content*, never the plate. `alpha()` on the whole node
    // faded the surface too, and a 45% subtle plate on a near-black background is
    // invisible: the button read as a stray label with no button behind it.
    val contentColor = (tint ?: colors.textPrimary).let {
        if (enabled) it else it.copy(alpha = 0.42f)
    }

    Row(
        modifier = modifier
            .scale(scale)
            .softSurface(shape)
            .clickable(
                enabled = enabled,
                interactionSource = interaction,
                indication = null,
                role = Role.Button
            ) {
                haptics.light()
                onClick()
            }
            .semantics { if (!enabled) disabled() }
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = contentColor, modifier = Modifier.size(18.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = contentColor,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Round icon button used across every toolbar.
 *
 * [size] is the painted size; the touch box is always expanded to 48dp by
 * [touchTarget], so dense chrome never costs reachability. [highlighted] swaps
 * the plate for a tinted well so an active toggle is legible without a label.
 */
@Composable
fun GlassIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color? = null,
    size: Dp = 40.dp,
    iconSize: Dp = 20.dp,
    enabled: Boolean = true,
    highlighted: Boolean = false,
    busy: Boolean = false
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.88f else 1f,
        animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
        label = "iconPress"
    )

    Box(
        modifier = modifier
            .clickable(
                enabled = enabled,
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClickLabel = contentDescription
            ) {
                haptics.light()
                onClick()
            }
            .touchTarget()
            .size(size)
            .scale(scale)
            .then(
                if (highlighted) {
                    Modifier
                        .clip(CircleShape)
                        .background(colors.primarySoft, CircleShape)
                } else {
                    Modifier.softSurface(CircleShape)
                }
            )
            .beamBorder(shape = CircleShape, active = busy, rim = false)
            .semantics { if (!enabled) disabled() },
        contentAlignment = Alignment.Center
    ) {
        // Disabled dims the glyph, never the plate: an icon button whose plate
        // disappears reads as an empty gap in a toolbar, not as an unavailable
        // action, and the user cannot tell there was ever a button there.
        val glyph = tint ?: if (highlighted) colors.primary else colors.textSecondary
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (enabled) glyph else glyph.copy(alpha = 0.38f),
            modifier = Modifier.size(iconSize)
        )
    }
}

/**
 * A row of actions that arrives from below once its content is ready. Used at
 * the bottom of sheets and forms so the affirmative action never pops in.
 */
@Composable
fun SiriusActionRow(
    visible: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val (enter, exit) = siriusRise()
    AnimatedVisibility(visible = visible, enter = enter, exit = exit, modifier = modifier) {
        content()
    }
}
