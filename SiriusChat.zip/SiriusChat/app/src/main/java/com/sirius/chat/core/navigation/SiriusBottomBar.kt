package com.sirius.chat.core.navigation

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.designsystem.touchTarget
import com.sirius.chat.core.util.rememberHaptics

/**
 * Padding between the plate's edge and the tabs. Shared by the layout and by the
 * indicator that is drawn behind them, because the two must agree on where a
 * slot begins for the well to line up with the icon above it.
 */
private val TabPlateInset = 6.dp

/**
 * Floating metal tab bar. It hovers above the content instead of docking to the
 * edge, which keeps the app feeling light and leaves room for the keyboard.
 *
 * The selection is carried by a single indicator that *slides* between tabs
 * rather than one highlight per tab fading in and out. One moving object
 * is what makes the bar read as a physical switch, and it also tells you which
 * direction you just travelled. Icons only lift and warm; the label under the
 * active tab thickens rather than changing size, so nothing reflows.
 */
@Composable
fun SiriusBottomBar(
    current: TopLevelDestination?,
    onSelect: (TopLevelDestination) -> Unit,
    modifier: Modifier = Modifier,
    badge: Map<TopLevelDestination, Int> = emptyMap()
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val destinations = TopLevelDestination.entries
    val selectedIndex = destinations.indexOf(current).coerceAtLeast(0)

    // Animating the index (not four booleans) is what lets the indicator travel.
    val indicator by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = siriusSpring(),
        label = "tabIndicator"
    )
    val hasSelection = current != null

    Row(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            // highlight = false: the lit top edge of the plate showed up as a
            // visible bright line across the menu on OLED panels. The bar keeps a
            // single even hairline instead.
            .glassSurface(
                shape = RoundedCornerShape(SiriusRadius.xl),
                elevation = 18.dp,
                highlight = false
            )
            .drawBehind {
                if (!hasSelection || destinations.isEmpty()) return@drawBehind
                // The tabs are laid out inside this plate's own inner padding, so
                // the slots have to be measured from the same inset the children
                // get — otherwise the indicator drifts off their centres.
                val inset = TabPlateInset.toPx()
                val slot = (size.width - inset * 2f) / destinations.size
                // Five tabs leave the label almost as wide as its slot, so the
                // well hugs the slot instead of sitting inside two thirds of it.
                val padX = slot * 0.04f
                val left = inset + slot * indicator + padX
                val width = slot - padX * 2f
                // One flat well, no lit edge. The bright 1.4px line over the
                // selected tab is the second half of the "stripe in the menu"
                // report: at this radius it reads as a scratch, not as lighting.
                drawRoundRect(
                    color = colors.primary.copy(alpha = 0.12f),
                    topLeft = Offset(left, size.height * 0.06f),
                    size = Size(width, size.height * 0.88f),
                    cornerRadius = CornerRadius(size.height * 0.32f)
                )
            }
            .padding(horizontal = TabPlateInset, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        destinations.forEach { destination ->
            val selected = destination == current
            val label = stringResource(destination.labelRes)
            val count = badge[destination] ?: 0
            val badgeLabel = if (count > 0) {
                pluralStringResource(R.plurals.a11y_unread, count, count)
            } else {
                null
            }

            val lift by animateFloatAsState(
                targetValue = if (selected) -2f else 0f,
                animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
                label = "tabLift"
            )
            val iconScale by animateFloatAsState(
                targetValue = if (selected) 1.06f else 1f,
                animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
                label = "tabScale"
            )
            val tint by animateColorAsState(
                targetValue = if (selected) colors.primary else colors.textTertiary,
                animationSpec = siriusTween(SiriusMotion.Base),
                label = "tabTint"
            )
            val interaction = remember { MutableInteractionSource() }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(SiriusRadius.md))
                    .clickable(
                        interactionSource = interaction,
                        indication = null,
                        role = Role.Tab,
                        onClickLabel = label
                    ) {
                        haptics.light()
                        onSelect(destination)
                    }
                    .touchTarget()
                    .padding(vertical = 6.dp)
                    .semantics {
                        this.selected = selected
                        contentDescription = listOfNotNull(label, badgeLabel).joinToString(", ")
                    },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Box(
                    modifier = Modifier.offset(y = lift.dp),
                    contentAlignment = Alignment.TopEnd
                ) {
                    Icon(
                        imageVector = destination.icon,
                        contentDescription = null,
                        tint = tint,
                        modifier = Modifier
                            .size(20.dp)
                            .scale(iconScale)
                    )
                    if (count > 0) {
                        // Ringed so it stays visible on top of the icon's own
                        // strokes; the label above already announces the count.
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(colors.backgroundElevated, CircleShape)
                                .padding(1.5.dp)
                                .background(colors.error, CircleShape)
                                .clearAndSetSemantics { }
                        )
                    }
                }
                Text(
                    text = label,
                    // Five tabs on a 360dp screen leave ~64dp a piece, and
                    // "Настройки" does not fit that at label metrics. Dropping a
                    // point of size and the tracking buys the room back; the
                    // label is a name under an icon, not running text.
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp,
                        lineHeight = 12.sp,
                        letterSpacing = 0.sp,
                        textAlign = TextAlign.Center
                    ),
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                    color = tint,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    // Filling the slot is what keeps the bold selected label
                    // centred on its icon instead of growing off to one side.
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
