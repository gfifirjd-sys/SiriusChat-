package com.sirius.chat.core.util

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import com.sirius.chat.core.designsystem.SiriusPalette
import com.sirius.chat.core.designsystem.SiriusTheme

/**
 * Shell command colouring for the terminal log.
 *
 * [SyntaxHighlighter] already covers shell *scripts* with the same regex machine
 * it uses for Kotlin and JSON, but a command line is a different shape of text:
 * there are no declarations, the first word carries almost all the meaning, and
 * the interesting parts are flags and paths rather than keywords. Running the
 * script highlighter over `git commit -m "fix"` colours `commit` and leaves the
 * flag and the path grey, which is exactly backwards.
 *
 * So this is a single-pass, word-wise tokenizer built around one piece of state:
 * whether the next word sits in command position. That flag starts true, is
 * cleared by the first real word, and is *restored* by any pipe or redirect —
 * which is what makes the second half of `cat log | grep error` colour `grep` as
 * a command too. It is the model used by Aceternity's terminal component, ported
 * to Kotlin and repointed at the Sirius code tokens so the terminal and a chat
 * code block agree on what a string looks like.
 *
 * One deliberate divergence from the source: `#` there colours only the word it
 * starts, which is fine for a landing-page demo and wrong for a real log, where
 * `# rebuild everything` must not come back half grey and half green. Here a
 * comment runs to the end of the line, as a shell actually parses it.
 */
object BashHighlighter {

    /**
     * Past this, a line is machine output rather than a command — a base64 blob,
     * a minified stack trace — and colouring it costs more than it explains.
     */
    const val MAX_HIGHLIGHT_CHARS = 2_000

    enum class Token {
        /** First word of a line, or of a segment after `|`, `>`, `&`, `<`. */
        Command,

        /** `-v`, `--force`. */
        Flag,

        /** Fully quoted word. */
        StringLiteral,

        /** Bare integer. */
        Number,

        /** Pipe or redirect; also re-arms command position. */
        Operator,

        /** Contains `/`, or starts with `.` or `~`. */
        Path,

        /** `$HOME`, `$1`. */
        Variable,

        /** `#` to end of line. */
        Comment,

        /** Whitespace and everything unclaimed. */
        Plain
    }

    data class Span(val token: Token, val text: String)

    /**
     * Splits [text] into coloured spans.
     *
     * Whitespace is emitted as its own [Token.Plain] span rather than trimmed,
     * because terminal output is column-aligned and the highlighter must be able
     * to rebuild the line byte for byte.
     */
    fun tokenize(text: String): List<Span> {
        if (text.isEmpty()) return emptyList()

        val spans = ArrayList<Span>(8)
        var commandPosition = true
        var i = 0

        while (i < text.length) {
            val ch = text[i]

            // Whitespace run: carried through untouched, never resets command
            // position (that is what the operator branch is for).
            if (ch.isWhitespace()) {
                val start = i
                while (i < text.length && text[i].isWhitespace()) i++
                spans += Span(Token.Plain, text.substring(start, i))
                continue
            }

            // Comment swallows the remainder of the line.
            if (ch == '#') {
                spans += Span(Token.Comment, text.substring(i))
                break
            }

            // Quotes are scanned as one span rather than word by word. The
            // reference tokenizer splits on whitespace first, so `-m "fix bug"`
            // arrives as two unmatched fragments and neither one looks like a
            // string; here the closing quote is found first and the space inside
            // it stays part of the literal. An unterminated quote runs to the end
            // of the line, which is also how the shell would read it.
            if (ch == '"' || ch == '\'') {
                val close = text.indexOf(ch, startIndex = i + 1)
                val end = if (close == -1) text.length else close + 1
                spans += Span(Token.StringLiteral, text.substring(i, end))
                i = end
                commandPosition = false
                continue
            }

            val start = i
            while (i < text.length && !text[i].isWhitespace() &&
                text[i] != '"' && text[i] != '\''
            ) {
                i++
            }
            val word = text.substring(start, i)

            spans += Span(classify(word, commandPosition), word)
            // A pipe or redirect starts a new command; anything else consumes the
            // command slot.
            commandPosition = isOperator(word)
        }

        return spans
    }

    private fun classify(word: String, commandPosition: Boolean): Token = when {
        word.startsWith("$") -> Token.Variable
        // Checked before the flag test: a lone "-" is stdin, not a flag, and
        // "--" is the end-of-options marker. Both read better as plain.
        word == "-" || word == "--" -> Token.Plain
        word.startsWith("-") -> Token.Flag
        isQuoted(word) -> Token.StringLiteral
        isOperator(word) -> Token.Operator
        word.all { it.isDigit() } -> Token.Number
        word.contains('/') || word.startsWith(".") || word.startsWith("~") -> Token.Path
        commandPosition -> Token.Command
        else -> Token.Plain
    }

    private fun isQuoted(word: String): Boolean {
        if (word.length < 2) return false
        val first = word.first()
        return (first == '"' || first == '\'') && word.last() == first
    }

    private fun isOperator(word: String): Boolean =
        word.isNotEmpty() && word.all { it == '|' || it == '>' || it == '&' || it == '<' }

    /**
     * Token colours.
     *
     * Mapped onto the palette the chat code blocks already use instead of a new
     * set of literals, so the terminal inherits every theme and accent for free
     * and a path looks the same wherever it appears. The semantic pairing is kept
     * from the reference — command reads green, flag blue, operator red — because
     * that is the convention shells themselves ship with.
     */
    fun colorOf(token: Token, colors: SiriusPalette): Color = when (token) {
        Token.Command -> colors.success
        Token.Flag -> colors.codeFunction
        Token.StringLiteral -> colors.codeString
        Token.Number -> colors.codeNumber
        Token.Operator -> colors.error
        Token.Path -> colors.codeType
        Token.Variable -> colors.codeKeyword
        Token.Comment -> colors.codeComment
        Token.Plain -> colors.codePlain
    }

    fun annotate(text: String, colors: SiriusPalette): AnnotatedString {
        if (text.length > MAX_HIGHLIGHT_CHARS) return AnnotatedString(text)
        return buildAnnotatedString {
            tokenize(text).forEach { span ->
                if (span.token == Token.Plain) {
                    append(span.text)
                } else {
                    withStyle(SpanStyle(color = colorOf(span.token, colors))) {
                        append(span.text)
                    }
                }
            }
        }
    }
}

/**
 * Cached per-line highlight.
 *
 * Keyed on the text and the palette so a themed rebuild is picked up, and so
 * scrolling a thousand-line build log re-tokenizes nothing.
 */
@Composable
fun rememberBashHighlight(text: String): AnnotatedString {
    val colors = SiriusTheme.colors
    return remember(text, colors) { BashHighlighter.annotate(text, colors) }
}
