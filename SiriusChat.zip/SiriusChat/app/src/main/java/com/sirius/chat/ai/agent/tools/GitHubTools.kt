package com.sirius.chat.ai.agent.tools

import android.util.Log
import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.int
import com.sirius.chat.ai.agent.string
import com.sirius.chat.ai.agent.stringOrEmpty
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.data.github.GitHubException
import com.sirius.chat.data.github.GitHubService
import com.sirius.chat.domain.repository.SettingsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * GitHub for the agent.
 *
 * Two design decisions are worth stating, because they are the ones that make
 * these tools different from every other tool in the app.
 *
 * **They act immediately.** Workspace writes are queued as a [com.sirius.chat.domain.model.PendingChange]
 * and shown as a diff, because the workspace is a set of local files that the
 * user is going to build and can lose. GitHub is a server: a commit there is
 * already versioned, already attributed, and already revertible from the repo's
 * own history. Holding a commit in an approval queue would give the illusion of
 * safety while duplicating what Git does better. Every tool below therefore
 * reports the commit sha it produced, so the trail is in the transcript.
 *
 * **Nothing here can destroy a repository.** Files can be written and deleted —
 * both are recoverable from history — but repo deletion is not exposed at all.
 * A model that misreads "remove the test folder" as "remove the repo" would be
 * doing something no history can undo, and the app's own UI is the right place
 * for a decision like that.
 *
 * `repo` is optional on every tool: it falls back to the repository the user
 * selected on the GitHub screen, so "commit this and build it" works without the
 * model having to guess an owner.
 */
private abstract class GitHubTool(
    protected val github: GitHubService,
    protected val settings: SettingsRepository
) : AgentTool {

    /**
     * `owner/name`, from the arguments or from the user's selected repo.
     *
     * Accepts what models actually send instead of only the documented form. A
     * repository was rejected — or worse, requested with a URL glued into the
     * path and answered with a bare 404 — when the argument arrived as
     * `https://github.com/owner/name`, ``owner/name`` in backticks, `owner/name.git`,
     * or split across `owner` and `name`. All of those name one repository
     * unambiguously, so all of them are normalised rather than refused.
     */
    protected suspend fun repoOf(args: JsonObject): String {
        val explicit = args.string("repo")
            ?: args.string("repository")
            ?: args.string("full_name")
        val owner = args.string("owner")
        val name = args.string("name") ?: args.string("repo_name")
        val candidate = when {
            explicit != null -> explicit
            owner != null && name != null -> "$owner/$name"
            else -> settings.settings.first().githubRepo
        }
        return normalizeRepo(candidate)
    }

    /**
     * The repository, or an [IllegalArgumentException] that says what was wrong.
     *
     * The old check was `contains('/')`, which let `https://github.com/o/n` and
     * `owner/name/tree/main` through to the API and turned a wrong argument into
     * an unexplained 404. Validating the shape here means the model is told about
     * its own mistake instead of being sent to debug GitHub.
     */
    protected suspend fun requireRepo(args: JsonObject): String {
        val repo = repoOf(args)
        require(repo.isNotBlank()) {
            "No repository. Pass \"repo\": \"owner/name\", or ask the user to pick one on the " +
                "GitHub screen."
        }
        val parts = repo.split('/')
        require(parts.size == 2 && parts.all { it.isNotBlank() } && REPO_SHAPE.matches(repo)) {
            "Invalid \"repo\": received \"$repo\". Expected exactly \"owner/name\" — no URL, no " +
                "\".git\" suffix, no branch or path after the name. You can also pass \"owner\" " +
                "and \"name\" as two separate arguments."
        }
        return repo
    }

    /**
     * Turns every spelling of a repository into `owner/name`.
     *
     * Anything after the name (`/tree/main`, `/blob/...`) is dropped: it comes
     * from a pasted browser URL and never belongs in this argument.
     */
    private fun normalizeRepo(raw: String): String {
        var value = raw.trim().trim('`', '"', '\'', '<', '>').trim()
        listOf(
            "https://github.com/",
            "http://github.com/",
            "https://www.github.com/",
            "git@github.com:",
            "github.com/"
        ).forEach { prefix ->
            if (value.startsWith(prefix, ignoreCase = true)) {
                value = value.substring(prefix.length)
            }
        }
        value = value.removeSuffix(".git").trim('/')
        val segments = value.split('/').filter { it.isNotBlank() }
        return if (segments.size >= 2) "${segments[0]}/${segments[1]}" else segments.joinToString("/")
    }

    /**
     * One place to turn a failure into something a model and a user can act on.
     *
     * This used to return `error.message`, which for a failed listing was the
     * single line "GitHub 404: Not Found" — the transcript showed a red cross and
     * the model retried the identical call. Now every failure reports the request
     * that failed, the arguments it was made with, GitHub's own body, the most
     * likely cause for that status, and — when credentials could be involved —
     * the live state of the stored token. The same text goes to logcat.
     */
    protected suspend fun guard(args: JsonObject, block: suspend () -> String): AgentToolResult =
        try {
            AgentToolResult(block())
        } catch (cancellation: CancellationException) {
            // Stopping the agent is not a tool failure. `catch (Exception)` below
            // used to swallow this and report a fake error, which also let the
            // agent loop start another step after the user pressed Stop.
            throw cancellation
        } catch (error: IllegalArgumentException) {
            report(args, error.message ?: "Invalid arguments.", error)
        } catch (error: GitHubException) {
            report(args, error.detail, error, error.status)
        } catch (error: Exception) {
            report(args, error.message ?: "GitHub request failed.", error)
        }

    private suspend fun report(
        args: JsonObject,
        summary: String,
        error: Throwable,
        status: Int? = null
    ): AgentToolResult {
        Log.w(TAG, "$name failed with args $args: $summary", error)
        val text = buildString {
            appendLine("$name failed.")
            appendLine(summary)
            // Truncated: github_write_file carries an entire file in its
            // arguments, and echoing that back would bury the diagnosis in the
            // content the model just sent.
            appendLine("Arguments received: ${args.toString().take(ARGS_PREVIEW_CHARS)}")
            hintFor(status)?.let { appendLine("Most likely cause: $it") }
            // Only when credentials could plausibly be the cause: this costs one
            // extra request, and a 422 on a bad branch name is not about the token.
            val code = status
            if (code == null || CREDENTIAL_STATUSES.contains(code)) {
                appendLine(github.tokenStatus().summary)
            }
            append(
                "Tell the user what failed and what they need to do; do not silently retry the " +
                    "identical call."
            )
        }
        return AgentToolResult(text.trim(), success = false)
    }

    /** What each status usually means for *these* endpoints, specifically. */
    private fun hintFor(status: Int?): String? {
        val code = status ?: return null
        return when (code) {
            401 -> "the token is invalid, expired or revoked — it has to be reconnected in " +
                "Settings > GitHub."
            403 -> "either the rate limit is exhausted, or the token lacks permission for this " +
                "repository (a fine-grained token needs Contents: read and write; an " +
                "organisation repository may also require SSO authorisation)."
            404 -> "the repository, path or ref does not exist *for this token*. A private " +
                "repository returns 404 rather than 403 when the token cannot see it, so check " +
                "the owner spelling, that the token has the repo scope, and that the path " +
                "exists on that branch. A repository with no commits yet has no contents at all."
            409 -> "the repository is empty: it has no initial commit, so there is nothing to " +
                "read and nothing to update against."
            422 -> "GitHub rejected the values — usually a branch that does not exist, or a " +
                "stale file sha because the file changed after it was read."
            415 -> "the path is not a text file."
            in 500..599 -> "GitHub itself is failing; this is worth one retry later, not now."
            else -> null
        }
    }

    private companion object {
        const val TAG = "SiriusGitHubTools"

        /**
         * GitHub's own allowed characters for an owner and a repository name.
         *
         * The dash is last inside the class on purpose: `0-9-_.` would read as a
         * range from `9` to `_` and quietly accept `owner:name`.
         */
        val REPO_SHAPE = Regex("^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$")

        /** Statuses where checking the stored token is worth an extra request. */
        val CREDENTIAL_STATUSES = setOf(401, 403, 404, 409)

        const val ARGS_PREVIEW_CHARS = 400
    }
}

private class GitHubStatusTool(
    github: GitHubService,
    settings: SettingsRepository,
    private val accountLogin: suspend () -> String?
) : GitHubTool(github, settings) {
    override val name = "github_status"
    override val description =
        "Check whether a GitHub account is connected, and which repository is selected."
    override val usage = """{}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val login = accountLogin()
                ?: return@guard "No GitHub account is connected. The user connects one in " +
                    "Settings > GitHub by pasting a personal access token."
            val repo = settings.settings.first().githubRepo
            buildString {
                appendLine("Connected as $login.")
                // Checked against GitHub rather than read from storage: a saved
                // account whose token expired looks connected right up to the
                // moment a write fails, and this is the tool whose entire job is
                // to answer "will GitHub calls work".
                appendLine(github.tokenStatus().summary)
                if (repo.isBlank()) {
                    append("No repository selected; pass \"repo\": \"owner/name\" explicitly.")
                } else {
                    append("Selected repository: $repo")
                }
            }
        }
}

private class GitHubListReposTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_list_repos"
    override val description = "List the user's GitHub repositories, most recently updated first."
    override val usage = """{"limit": 30}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val repos = github.repos()
            if (repos.isEmpty()) return@guard "This account has no repositories."
            repos.joinToString("\n") { repo ->
                val visibility = if (repo.isPrivate) "private" else "public"
                "- ${repo.fullName} ($visibility, ${repo.defaultBranch})" +
                    repo.description.takeIf { it.isNotBlank() }?.let { ": $it" }.orEmpty()
            }
        }
}

private class GitHubCreateRepoTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_create_repo"
    override val description =
        "Create a new GitHub repository. It is private unless public is true, and it always " +
            "gets an initial commit so files can be written to it right away."
    override val usage =
        """{"name": "my-app", "description": "optional", "public": false}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val name = args.string("name") ?: throw IllegalArgumentException("Missing 'name'.")
            val public = args.bool("public", false)
            val repo = github.createRepo(
                name = name,
                description = args.stringOrEmpty("description"),
                isPrivate = !public,
                autoInit = true
            )
            "Created ${repo.fullName} (${if (repo.isPrivate) "private" else "public"}), " +
                "default branch ${repo.defaultBranch}: ${repo.htmlUrl}"
        }
}

private class GitHubVisibilityTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_set_visibility"
    override val description = "Make a repository public or private."
    override val usage = """{"repo": "owner/name", "public": true}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val repo = requireRepo(args)
            val public = args.bool("public", true)
            val updated = github.setVisibility(repo, isPrivate = !public)
            "${updated.fullName} is now ${if (updated.isPrivate) "private" else "public"}."
        }
}

private class GitHubListFilesTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_list_files"
    override val description = "List files and folders at a path inside a GitHub repository."
    override val usage =
        """{"repo": "owner/name", "path": "app/src", "ref": "main"} — repo is "owner/name" only"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val repo = requireRepo(args)
            val path = args.stringOrEmpty("path")
            val ref = args.stringOrEmpty("ref")
            val entries = try {
                github.list(repo, path, ref)
            } catch (error: GitHubException) {
                // A listing can 404 for three unrelated reasons and GitHub says
                // "Not Found" for all of them. One extra request tells them apart.
                throw if (error.status == 404) explain(repo, path, ref, error) else error
            }
            if (entries.isEmpty()) return@guard "Empty: $repo/${path.ifBlank { "(root)" }}"
            val sorted = entries.sortedWith(
                compareByDescending<com.sirius.chat.domain.model.GitHubEntry> { it.isDirectory }
                    .thenBy { it.name.lowercase() }
            )
            buildString {
                appendLine(
                    "$repo/${path.ifBlank { "(root)" }}" +
                        ref.takeIf { it.isNotBlank() }?.let { " @ $it" }.orEmpty() +
                        " — ${entries.size} entries"
                )
                append(
                    sorted.joinToString("\n") { entry ->
                        if (entry.isDirectory) {
                            "- ${entry.name}/"
                        } else {
                            "- ${entry.name} (${Formatters.fileSize(entry.sizeBytes)})"
                        }
                    }
                )
            }
        }

    /**
     * The repository the user probably meant.
     *
     * Names differing only in punctuation are the single most common cause of a
     * 404 here — a trailing hyphen or an underscore where the real name has a dot
     * is invisible when read out of a chat message, and the API answers the same
     * "Not Found" it gives for a repository that truly does not exist. Comparing
     * against what the token can actually see turns that into a name to retry.
     */
    private suspend fun nearMiss(repo: String): String? {
        val wanted = repo.substringAfter('/').simplified()
        if (wanted.isEmpty()) return null
        val match = runCatching { github.repos() }.getOrNull()
            ?.firstOrNull { it.fullName != repo && it.fullName.substringAfter('/').simplified() == wanted }
            ?: return null
        return " Did you mean \"${match.fullName}\"?"
    }

    /** Lowercase letters and digits only, so punctuation stops hiding a typo. */
    private fun String.simplified(): String =
        lowercase().filter { it.isLetterOrDigit() }

    /**
     * Says which of the three possible things was actually missing.
     *
     * Asking for the repository itself separates "this token cannot see the
     * repository" from "the repository is fine, that path or branch is not", and
     * the answer carries the real default branch — the single most common cause,
     * since a model that assumes `main` gets a 404 on every `master` repository.
     */
    private suspend fun explain(
        repo: String,
        path: String,
        ref: String,
        error: GitHubException
    ): GitHubException {
        val info = runCatching { github.repo(repo) }.getOrNull()
            ?: return GitHubException(
                status = 404,
                message = "GitHub 404: repository \"$repo\" does not exist or is not visible to " +
                    "this token. Check the owner and name, and remember that a private " +
                    "repository the token cannot read also answers 404. " +
                    "github_list_repos shows exactly what this token can see." +
                    nearMiss(repo).orEmpty(),
                method = error.method,
                url = error.url,
                body = error.body
            )
        val branch = ref.ifBlank { info.defaultBranch }
        return GitHubException(
            status = 404,
            message = "GitHub 404: $repo exists and is readable, but " +
                "\"${path.ifBlank { "(root)" }}\" was not found on \"$branch\". " +
                "Its default branch is \"${info.defaultBranch}\"" +
                if (ref.isNotBlank() && ref != info.defaultBranch) {
                    " — you asked for ref \"$ref\", which may not exist."
                } else {
                    ". List the root first, then descend one level at a time."
                },
            method = error.method,
            url = error.url,
            body = error.body
        )
    }
}

private class GitHubReadFileTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_read_file"
    override val description =
        "Read a text file from a GitHub repository. Long files come back in pages: when the " +
            "footer reports remaining lines, call this again with the offset it gives you until " +
            "the whole file has been read."
    override val usage =
        """{"repo": "owner/name", "path": "app/build.gradle.kts", "ref": "main", "offset": 1}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val repo = requireRepo(args)
            val path = args.string("path") ?: throw IllegalArgumentException("Missing 'path'.")
            val ref = args.stringOrEmpty("ref")
            val text = github.readFile(repo, path, ref)
            val lines = text.lines()
            val total = lines.size
            val offset = args.int("offset", 1).coerceIn(1, maxOf(total, 1))
            val limit = args.int("limit", PAGE_LINES).coerceIn(1, MAX_PAGE_LINES)

            // Same page contract as the workspace read_file: bounded by lines and
            // characters, always ending on a line boundary, and stating how to
            // continue. A remote read that stops mid-file without saying so is
            // what makes a model commit a truncated file back to the repository.
            val page = StringBuilder()
            var lastLine = offset - 1
            var budget = 0
            for (index in (offset - 1) until minOf(total, offset - 1 + limit)) {
                val rendered = "${index + 1}\t${lines[index]}"
                if (budget + rendered.length + 1 > PAGE_CHARS && lastLine >= offset) break
                page.append(rendered).append('\n')
                budget += rendered.length + 1
                lastLine = index + 1
            }
            val remaining = total - lastLine
            buildString {
                append("$repo/$path")
                if (ref.isNotBlank()) append(" @ $ref")
                appendLine(" ($total lines) — showing lines $offset-$lastLine")
                append(page)
                if (remaining > 0) {
                    appendLine("\u2026 $remaining more lines. This is NOT the end of the file. Continue with:")
                    append(
                        """{"tool": "github_read_file", "args": {"repo": "$repo", "path": "$path", "offset": ${lastLine + 1}}}"""
                    )
                } else {
                    append("(end of file)")
                }
            }
        }

    private companion object {
        const val PAGE_LINES = 800
        const val MAX_PAGE_LINES = 4_000
        const val PAGE_CHARS = 20_000
    }
}

private class GitHubWriteFileTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_write_file"
    override val description =
        "Create or replace a file in a GitHub repository. This commits immediately, so send the " +
            "COMPLETE new content and a real commit message."
    override val usage =
        """{"repo": "owner/name", "path": "README.md", "content": "...", "message": "Add readme", "branch": ""}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val repo = requireRepo(args)
            val path = args.string("path") ?: throw IllegalArgumentException("Missing 'path'.")
            val content = args.stringOrEmpty("content")
            val sha = github.putFile(
                fullName = repo,
                path = path,
                content = content,
                message = args.stringOrEmpty("message"),
                branch = args.stringOrEmpty("branch")
            )
            "Committed $repo/$path (${content.length} chars) as ${sha.take(7)}."
        }
}

private class GitHubCreateFolderTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_create_folder"
    override val description =
        "Create a folder in a GitHub repository. Git cannot store an empty directory, so this " +
            "commits a .gitkeep inside it."
    override val usage = """{"repo": "owner/name", "path": "app/src/main/assets"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val repo = requireRepo(args)
            val path = args.string("path") ?: throw IllegalArgumentException("Missing 'path'.")
            val sha = github.createFolder(repo, path, args.stringOrEmpty("branch"))
            "Created $repo/$path/ (via .gitkeep) as ${sha.take(7)}."
        }
}

private class GitHubDeleteFileTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_delete_file"
    override val description =
        "Delete one file from a GitHub repository. Recoverable from the repo's history."
    override val usage = """{"repo": "owner/name", "path": "old.txt", "message": "Drop old.txt"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val repo = requireRepo(args)
            val path = args.string("path") ?: throw IllegalArgumentException("Missing 'path'.")
            github.deleteFile(
                fullName = repo,
                path = path,
                message = args.stringOrEmpty("message"),
                branch = args.stringOrEmpty("branch")
            )
            "Deleted $repo/$path."
        }
}

private class GitHubBuildApkTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_build_apk"
    override val description =
        "Build an APK on GitHub Actions. Installs the build workflow if the repository does not " +
            "have it yet, then starts a run. Builds take minutes; report the run and let the user " +
            "watch it, or check back with github_build_status."
    override val usage = """{"repo": "owner/name", "variant": "debug", "branch": "main"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val repo = requireRepo(args)
            val variant = args.stringOrEmpty("variant").ifBlank { "debug" }
            require(variant == "debug" || variant == "release") {
                "variant must be \"debug\" or \"release\"."
            }
            val branch = args.stringOrEmpty("branch").ifBlank { github.repo(repo).defaultBranch }
            val installed = github.ensureBuildWorkflow(repo, branch)
            github.dispatchWorkflow(fullName = repo, ref = branch, variant = variant)
            buildString {
                if (installed) {
                    appendLine("Installed ${GitHubService.WORKFLOW_PATH} in $repo.")
                }
                append("Started a $variant build of $repo on $branch. ")
                append("Actions needs a moment to register the run.")
            }
        }
}

private class GitHubBuildStatusTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_build_status"
    override val description =
        "Show the latest GitHub Actions runs for a repository, and the artifacts of the newest one."
    override val usage = """{"repo": "owner/name", "limit": 5}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard(args) {
            val repo = requireRepo(args)
            val runs = github.runs(repo, limit = 5)
            if (runs.isEmpty()) return@guard "$repo has no Actions runs yet."
            val lines = runs.joinToString("\n") { run ->
                val state = if (run.finished) run.conclusion.ifBlank { "completed" } else run.status
                "- #${run.runNumber} ${run.name} [$state] ${run.branch} ${run.htmlUrl}"
            }
            val newest = runs.first()
            val artifacts = if (newest.finished && newest.succeeded) {
                runCatching { github.artifacts(repo, newest.id) }.getOrNull().orEmpty()
            } else {
                emptyList()
            }
            buildString {
                append(lines)
                if (artifacts.isNotEmpty()) {
                    appendLine()
                    appendLine("Artifacts of #${newest.runNumber}:")
                    append(
                        artifacts.joinToString("\n") {
                            "- ${it.name} (${Formatters.fileSize(it.sizeBytes)})" +
                                if (it.expired) " [expired]" else ""
                        }
                    )
                    appendLine()
                    append("The user downloads these from the GitHub screen in the app.")
                }
            }
        }
}

/** Booleans arrive as `true` or as `"true"` depending on the model. Accept both. */
private fun JsonObject.bool(key: String, fallback: Boolean): Boolean {
    val primitive = this[key] as? JsonPrimitive ?: return fallback
    return primitive.content.lowercase().toBooleanStrictOrNull() ?: fallback
}

/**
 * The GitHub tool set, or nothing at all.
 *
 * When no account is connected the tools are still registered: a model that is
 * told the capability exists and gets "connect an account in Settings > GitHub"
 * back can pass that on, whereas a model with no GitHub tools at all will
 * confidently explain that it cannot use GitHub, which is worse advice.
 */
fun gitHubTools(
    github: GitHubService,
    settings: SettingsRepository,
    accountLogin: suspend () -> String?
): List<AgentTool> = listOf(
    GitHubStatusTool(github, settings, accountLogin),
    GitHubListReposTool(github, settings),
    GitHubCreateRepoTool(github, settings),
    GitHubVisibilityTool(github, settings),
    GitHubListFilesTool(github, settings),
    GitHubReadFileTool(github, settings),
    GitHubWriteFileTool(github, settings),
    GitHubCreateFolderTool(github, settings),
    GitHubDeleteFileTool(github, settings),
    GitHubBuildApkTool(github, settings),
    GitHubBuildStatusTool(github, settings)
)
