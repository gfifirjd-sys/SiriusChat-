package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.string
import com.sirius.chat.ai.agent.stringOrEmpty
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.data.github.GitHubService
import com.sirius.chat.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.first
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * GitHub for the agent.
 *
 * Two design decisions are worth stating, because they are the ones that make
 * these tools different from every other tool in the app.
 *
 * **They act immediately.** Workspace writes are queued as a [com.sirius.chat.domain.model.PendingChange]
 * and shown as a diff, because the workspace is a set of local files that the
 * user is going to build and can lose. GitHub is a server: a commit there is
 * already versioned, already attributed, and already revertible from the repo's
 * own history. Holding a commit in an approval queue would give the illusion of
 * safety while duplicating what Git does better. Every tool below therefore
 * reports the commit sha it produced, so the trail is in the transcript.
 *
 * **Nothing here can destroy a repository.** Files can be written and deleted —
 * both are recoverable from history — but repo deletion is not exposed at all.
 * A model that misreads "remove the test folder" as "remove the repo" would be
 * doing something no history can undo, and the app's own UI is the right place
 * for a decision like that.
 *
 * `repo` is optional on every tool: it falls back to the repository the user
 * selected on the GitHub screen, so "commit this and build it" works without the
 * model having to guess an owner.
 */
private abstract class GitHubTool(
    protected val github: GitHubService,
    protected val settings: SettingsRepository
) : AgentTool {

    /** `owner/name`, from the arguments or from the user's selected repo. */
    protected suspend fun repoOf(args: JsonObject): String {
        val explicit = args.string("repo")
        if (explicit != null) return explicit.trim().trim('/')
        return settings.settings.first().githubRepo
    }

    protected suspend fun requireRepo(args: JsonObject): String {
        val repo = repoOf(args)
        require(repo.contains('/')) {
            "No repository. Pass \"repo\": \"owner/name\", or ask the user to pick one on the GitHub screen."
        }
        return repo
    }

    /**
     * One place to turn a failure into a sentence the model can act on. Without
     * this, a 401 surfaces as a stack trace and the model retries the same call
     * forever instead of telling the user their token expired.
     */
    protected suspend fun guard(block: suspend () -> String): AgentToolResult =
        try {
            AgentToolResult(block())
        } catch (error: IllegalArgumentException) {
            AgentToolResult(error.message ?: "Invalid arguments.", success = false)
        } catch (error: Exception) {
            AgentToolResult(error.message ?: "GitHub request failed.", success = false)
        }
}

private class GitHubStatusTool(
    github: GitHubService,
    settings: SettingsRepository,
    private val accountLogin: suspend () -> String?
) : GitHubTool(github, settings) {
    override val name = "github_status"
    override val description =
        "Check whether a GitHub account is connected, and which repository is selected."
    override val usage = """{}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val login = accountLogin()
                ?: return@guard "No GitHub account is connected. The user connects one in " +
                    "Settings > GitHub by pasting a personal access token."
            val repo = settings.settings.first().githubRepo
            buildString {
                appendLine("Connected as $login.")
                if (repo.isBlank()) {
                    append("No repository selected; pass \"repo\": \"owner/name\" explicitly.")
                } else {
                    append("Selected repository: $repo")
                }
            }
        }
}

private class GitHubListReposTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_list_repos"
    override val description = "List the user's GitHub repositories, most recently updated first."
    override val usage = """{"limit": 30}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val repos = github.repos()
            if (repos.isEmpty()) return@guard "This account has no repositories."
            repos.joinToString("\n") { repo ->
                val visibility = if (repo.isPrivate) "private" else "public"
                "- ${repo.fullName} ($visibility, ${repo.defaultBranch})" +
                    repo.description.takeIf { it.isNotBlank() }?.let { ": $it" }.orEmpty()
            }
        }
}

private class GitHubCreateRepoTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_create_repo"
    override val description =
        "Create a new GitHub repository. It is private unless public is true, and it always " +
            "gets an initial commit so files can be written to it right away."
    override val usage =
        """{"name": "my-app", "description": "optional", "public": false}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val name = args.string("name") ?: throw IllegalArgumentException("Missing 'name'.")
            val public = args.bool("public", false)
            val repo = github.createRepo(
                name = name,
                description = args.stringOrEmpty("description"),
                isPrivate = !public,
                autoInit = true
            )
            "Created ${repo.fullName} (${if (repo.isPrivate) "private" else "public"}), " +
                "default branch ${repo.defaultBranch}: ${repo.htmlUrl}"
        }
}

private class GitHubVisibilityTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_set_visibility"
    override val description = "Make a repository public or private."
    override val usage = """{"repo": "owner/name", "public": true}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val repo = requireRepo(args)
            val public = args.bool("public", true)
            val updated = github.setVisibility(repo, isPrivate = !public)
            "${updated.fullName} is now ${if (updated.isPrivate) "private" else "public"}."
        }
}

private class GitHubListFilesTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_list_files"
    override val description = "List files and folders at a path inside a GitHub repository."
    override val usage = """{"repo": "owner/name", "path": "app/src", "ref": "main"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val repo = requireRepo(args)
            val path = args.stringOrEmpty("path")
            val entries = github.list(repo, path, args.stringOrEmpty("ref"))
            if (entries.isEmpty()) return@guard "Empty: $repo/${path.ifBlank { "(root)" }}"
            entries.sortedWith(compareByDescending<com.sirius.chat.domain.model.GitHubEntry> { it.isDirectory }
                .thenBy { it.name.lowercase() })
                .joinToString("\n") { entry ->
                    if (entry.isDirectory) {
                        "- ${entry.name}/"
                    } else {
                        "- ${entry.name} (${Formatters.fileSize(entry.sizeBytes)})"
                    }
                }
        }
}

private class GitHubReadFileTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_read_file"
    override val description = "Read a text file from a GitHub repository."
    override val usage = """{"repo": "owner/name", "path": "app/build.gradle.kts", "ref": "main"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val repo = requireRepo(args)
            val path = args.string("path") ?: throw IllegalArgumentException("Missing 'path'.")
            val text = github.readFile(repo, path, args.stringOrEmpty("ref"))
            "$repo/$path\n$text"
        }
}

private class GitHubWriteFileTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_write_file"
    override val description =
        "Create or replace a file in a GitHub repository. This commits immediately, so send the " +
            "COMPLETE new content and a real commit message."
    override val usage =
        """{"repo": "owner/name", "path": "README.md", "content": "...", "message": "Add readme", "branch": ""}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val repo = requireRepo(args)
            val path = args.string("path") ?: throw IllegalArgumentException("Missing 'path'.")
            val content = args.stringOrEmpty("content")
            val sha = github.putFile(
                fullName = repo,
                path = path,
                content = content,
                message = args.stringOrEmpty("message"),
                branch = args.stringOrEmpty("branch")
            )
            "Committed $repo/$path (${content.length} chars) as ${sha.take(7)}."
        }
}

private class GitHubCreateFolderTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_create_folder"
    override val description =
        "Create a folder in a GitHub repository. Git cannot store an empty directory, so this " +
            "commits a .gitkeep inside it."
    override val usage = """{"repo": "owner/name", "path": "app/src/main/assets"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val repo = requireRepo(args)
            val path = args.string("path") ?: throw IllegalArgumentException("Missing 'path'.")
            val sha = github.createFolder(repo, path, args.stringOrEmpty("branch"))
            "Created $repo/$path/ (via .gitkeep) as ${sha.take(7)}."
        }
}

private class GitHubDeleteFileTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_delete_file"
    override val description =
        "Delete one file from a GitHub repository. Recoverable from the repo's history."
    override val usage = """{"repo": "owner/name", "path": "old.txt", "message": "Drop old.txt"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val repo = requireRepo(args)
            val path = args.string("path") ?: throw IllegalArgumentException("Missing 'path'.")
            github.deleteFile(
                fullName = repo,
                path = path,
                message = args.stringOrEmpty("message"),
                branch = args.stringOrEmpty("branch")
            )
            "Deleted $repo/$path."
        }
}

private class GitHubBuildApkTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_build_apk"
    override val description =
        "Build an APK on GitHub Actions. Installs the build workflow if the repository does not " +
            "have it yet, then starts a run. Builds take minutes; report the run and let the user " +
            "watch it, or check back with github_build_status."
    override val usage = """{"repo": "owner/name", "variant": "debug", "branch": "main"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val repo = requireRepo(args)
            val variant = args.stringOrEmpty("variant").ifBlank { "debug" }
            require(variant == "debug" || variant == "release") {
                "variant must be \"debug\" or \"release\"."
            }
            val branch = args.stringOrEmpty("branch").ifBlank { github.repo(repo).defaultBranch }
            val installed = github.ensureBuildWorkflow(repo, branch)
            github.dispatchWorkflow(fullName = repo, ref = branch, variant = variant)
            buildString {
                if (installed) {
                    appendLine("Installed ${GitHubService.WORKFLOW_PATH} in $repo.")
                }
                append("Started a $variant build of $repo on $branch. ")
                append("Actions needs a moment to register the run.")
            }
        }
}

private class GitHubBuildStatusTool(
    github: GitHubService,
    settings: SettingsRepository
) : GitHubTool(github, settings) {
    override val name = "github_build_status"
    override val description =
        "Show the latest GitHub Actions runs for a repository, and the artifacts of the newest one."
    override val usage = """{"repo": "owner/name", "limit": 5}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult =
        guard {
            val repo = requireRepo(args)
            val runs = github.runs(repo, limit = 5)
            if (runs.isEmpty()) return@guard "$repo has no Actions runs yet."
            val lines = runs.joinToString("\n") { run ->
                val state = if (run.finished) run.conclusion.ifBlank { "completed" } else run.status
                "- #${run.runNumber} ${run.name} [$state] ${run.branch} ${run.htmlUrl}"
            }
            val newest = runs.first()
            val artifacts = if (newest.finished && newest.succeeded) {
                runCatching { github.artifacts(repo, newest.id) }.getOrNull().orEmpty()
            } else {
                emptyList()
            }
            buildString {
                append(lines)
                if (artifacts.isNotEmpty()) {
                    appendLine()
                    appendLine("Artifacts of #${newest.runNumber}:")
                    append(
                        artifacts.joinToString("\n") {
                            "- ${it.name} (${Formatters.fileSize(it.sizeBytes)})" +
                                if (it.expired) " [expired]" else ""
                        }
                    )
                    appendLine()
                    append("The user downloads these from the GitHub screen in the app.")
                }
            }
        }
}

/** Booleans arrive as `true` or as `"true"` depending on the model. Accept both. */
private fun JsonObject.bool(key: String, fallback: Boolean): Boolean {
    val primitive = this[key] as? JsonPrimitive ?: return fallback
    return primitive.content.lowercase().toBooleanStrictOrNull() ?: fallback
}

/**
 * The GitHub tool set, or nothing at all.
 *
 * When no account is connected the tools are still registered: a model that is
 * told the capability exists and gets "connect an account in Settings > GitHub"
 * back can pass that on, whereas a model with no GitHub tools at all will
 * confidently explain that it cannot use GitHub, which is worse advice.
 */
fun gitHubTools(
    github: GitHubService,
    settings: SettingsRepository,
    accountLogin: suspend () -> String?
): List<AgentTool> = listOf(
    GitHubStatusTool(github, settings, accountLogin),
    GitHubListReposTool(github, settings),
    GitHubCreateRepoTool(github, settings),
    GitHubVisibilityTool(github, settings),
    GitHubListFilesTool(github, settings),
    GitHubReadFileTool(github, settings),
    GitHubWriteFileTool(github, settings),
    GitHubCreateFolderTool(github, settings),
    GitHubDeleteFileTool(github, settings),
    GitHubBuildApkTool(github, settings),
    GitHubBuildStatusTool(github, settings)
)
