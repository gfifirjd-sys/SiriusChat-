package com.sirius.chat.data.repository

import com.sirius.chat.data.local.preferences.SettingsDataStore
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow

class SettingsRepositoryImpl(
    private val store: SettingsDataStore
) : SettingsRepository {

    override val settings: Flow<AppSettings> = store.settings

    override suspend fun current(): AppSettings = store.current()

    override suspend fun update(transform: (AppSettings) -> AppSettings) = store.update(transform)
}
