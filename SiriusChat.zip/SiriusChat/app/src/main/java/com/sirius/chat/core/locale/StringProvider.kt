package com.sirius.chat.core.locale

import android.content.Context
import androidx.annotation.PluralsRes
import androidx.annotation.StringRes
import com.sirius.chat.domain.model.AppLanguage
import com.sirius.chat.domain.model.AppSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Resolves string resources outside composition, for the messages ViewModels
 * put into UI state (snackbars, inline errors, terminal banners).
 *
 * It mirrors the language chosen in settings so those strings never drift out
 * of sync with what `stringResource` renders on screen.
 */
class StringProvider(
    context: Context,
    settings: Flow<AppSettings>,
    scope: CoroutineScope
) {
    private val appContext: Context = context.applicationContext

    @Volatile
    private var localized: Context = appContext

    init {
        scope.launch {
            settings
                .map { it.language }
                .distinctUntilChanged()
                .collect { language -> localized = appContext.localizedFor(language) }
        }
    }

    fun get(@StringRes id: Int): String = localized.getString(id)

    fun get(@StringRes id: Int, vararg args: Any): String = localized.getString(id, *args)

    fun plural(@PluralsRes id: Int, count: Int): String =
        localized.resources.getQuantityString(id, count, count)

    /** Used by preview/test code that has no settings flow. */
    fun forLanguage(language: AppLanguage): Context = appContext.localizedFor(language)
}
