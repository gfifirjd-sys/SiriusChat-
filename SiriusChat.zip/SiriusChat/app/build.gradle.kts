import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
}

// Optional release signing. Create `keystore.properties` in the project root
// (it is git-ignored) with storeFile / storePassword / keyAlias / keyPassword.
// When absent, `assembleRelease` still works and falls back to the debug key,
// so the project never blocks a release build on a missing keystore.
val keystorePropertiesFile = rootProject.file("keystore.properties")
val keystoreProperties = Properties().apply {
    if (keystorePropertiesFile.exists()) {
        keystorePropertiesFile.inputStream().use { load(it) }
    }
}
val hasReleaseKeystore = keystoreProperties.getProperty("storeFile") != null

android {
    namespace = "com.sirius.chat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sirius.chat"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        // Background generation changed what a chat *is* in this app, and the GitHub
        // layer is new surface rather than a fix, so 2.0 was a major bump. "-beta"
        // stays in the name until a cloud build has been installed from the app end
        // to end on a real device.
        //
        // 2.0.1: the agent loop stopped ending a run on any step that produced no
        // tool call, gained a blocking `run_command` so it can build and read the
        // failure, and gained `ask_user`. Behaviour fixes on top of 2.0, hence patch.
        //
        // 2.0.2: "the model returned an empty response" is no longer a dead end.
        // The stream now reads reasoning fields and gateway errors sent inside a
        // 200, the engine reacts to finish_reason instead of discarding it, and a
        // project folder with a non-ASCII name is no longer shown percent-encoded.
        versionName = "2.0.2-beta"
        resourceConfigurations += setOf("en", "ru")
        vectorDrawables { useSupportLibrary = true }
    }

    signingConfigs {
        create("release") {
            if (hasReleaseKeystore) {
                storeFile = rootProject.file(keystoreProperties.getProperty("storeFile"))
                storePassword = keystoreProperties.getProperty("storePassword")
                keyAlias = keystoreProperties.getProperty("keyAlias")
                keyPassword = keystoreProperties.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = if (hasReleaseKeystore) {
                signingConfigs.getByName("release")
            } else {
                signingConfigs.getByName("debug")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // Sources are UTF-8. On-device toolchains (AndroidIDE) and CI runners
        // frequently default to an ASCII platform charset, which is how a dash or
        // a Cyrillic letter in a string literal ends up on screen as "?".
        encoding = "UTF-8"
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs = freeCompilerArgs + listOf(
            "-opt-in=kotlin.RequiresOptIn"
        )
    }

    androidResources {
        // Same reason as compileOptions.encoding: aapt2 must not guess.
        noCompress += listOf("apk")
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/DEPENDENCIES",
                "/META-INF/LICENSE*",
                "/META-INF/*.version",
                "DebugProbesKt.bin",
                "kotlin-tooling-metadata.json"
            )
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

// javac reads -encoding from the task, not from compileOptions alone, and the
// Kotlin compile tasks get the same treatment through the daemon args in
// gradle.properties.
tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.core.splashscreen)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)

    val composeBom = platform(libs.androidx.compose.bom)
    implementation(composeBom)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    debugImplementation(libs.androidx.compose.ui.tooling)

    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.documentfile)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.okhttp)

    // Local git plumbing. The HTTP/SSH transports and the Apache client are not
    // used — this build has no network git — so they are excluded to keep the
    // dex small and to avoid dragging desktop-only crypto into the app.
    implementation(libs.jgit) {
        exclude(group = "org.eclipse.jgit", module = "org.eclipse.jgit.ssh.apache")
        exclude(group = "org.apache.httpcomponents")
    }
    // JGit logs through SLF4J; without a binding every call prints a warning.
    implementation(libs.slf4j.nop)
}
