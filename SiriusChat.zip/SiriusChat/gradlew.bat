@rem Gradle start-up script for Windows (Sirius Chat).
@if "%DEBUG%"=="" @echo off
setlocal

set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_HOME=%DIRNAME%
set APP_BASE_NAME=%~n0
set WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar

if defined JAVA_HOME goto findJavaFromJavaHome

set JAVA_EXE=java.exe
"%JAVA_EXE%" -version >NUL 2>&1
if %ERRORLEVEL% equ 0 goto checkJar
echo ERROR: no Java runtime found. Set JAVA_HOME to a JDK 17 installation. 1>&2
exit /b 1

:findJavaFromJavaHome
set JAVA_EXE=%JAVA_HOME%/bin/java.exe
if exist "%JAVA_EXE%" goto checkJar
echo ERROR: JAVA_HOME points to an invalid directory: %JAVA_HOME% 1>&2
exit /b 1

:checkJar
if exist "%WRAPPER_JAR%" goto execute
echo ERROR: %WRAPPER_JAR% is missing. 1>&2
echo Restore it from the Sirius Chat archive, or run 'gradle wrapper --gradle-version 8.9'. 1>&2
exit /b 1

:execute
"%JAVA_EXE%" %JAVA_OPTS% %GRADLE_OPTS% "-Dorg.gradle.appname=%APP_BASE_NAME%" -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
