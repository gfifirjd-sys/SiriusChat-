# Подключение GitHub к Sirius Chat

Экран: **Настройки → GitHub**.

Sirius не использует OAuth-приложение. Вы создаёте **personal access token** сами,
сами выбираете права и в любой момент можете его отозвать — приложение хранит
только этот токен, локально и в зашифрованном виде (AES-256/GCM, ключ в Android
Keystore). Ни один запрос не проходит через сторонний сервер: телефон обращается
напрямую к `api.github.com`.

---

## 1. Создайте токен

Откройте одну из ссылок (первая уже выставляет нужные права):

- **Classic token с нужными скоупами (рекомендуется):**
  https://github.com/settings/tokens/new?scopes=repo,workflow&description=Sirius%20Chat
- Список всех токенов: https://github.com/settings/tokens
- Fine-grained tokens: https://github.com/settings/personal-access-tokens/new

Что выбрать:

| Тип токена | Что включить |
|---|---|
| **Classic** | `repo` (полный доступ к репозиториям) и `workflow` (запуск сборок) |
| **Fine-grained** | Repository permissions: **Contents — Read and write**, **Actions — Read and write**, **Administration — Read and write** (нужно только для смены public/private), **Metadata — Read** |

Срок действия — на ваше усмотрение. Когда токен истечёт, приложение скажет
«токен недействителен», и его достаточно будет заменить на новый.

Нажмите **Generate token** и скопируйте значение. **GitHub показывает токен
ровно один раз** — если потеряли, создайте новый.

## 2. Вставьте токен в приложение

Настройки → GitHub → поле **Токен доступа** → **Подключить**.

Приложение сразу делает проверочный запрос и показывает:

- логин и имя аккаунта — значит токен рабочий;
- предупреждение «у токена нет права `repo`/`workflow`» — значит скоупы не те, и
  запись или сборка не сработают. Лучше сразу создать токен заново, чем
  выяснить это в середине операции.

## 3. Выберите репозиторий

Список подтягивается автоматически (сначала те, где вы можете писать). Выбранный
репозиторий — это тот, с которым работают **и кнопка сборки, и агент**. Он
запоминается в настройках (`githubRepo`).

Из карточки репозитория доступно: открыть на GitHub, сменить видимость
(**Сделать публичным / приватным**), запустить сборку.

## 4. Сборка APK

Сборка идёт **на GitHub Actions**, а не на телефоне.

1. **Собрать debug** (или **Release**).
2. При первом запуске приложение само коммитит workflow
   `.github/workflows/sirius-apk.yml` в репозиторий и запускает его.
3. Статус запусков обновляется на экране; **Открыть Actions** — полный лог в браузере.
4. Готовый APK появляется в разделе **Артефакты** → **Скачать**.
5. **Установить** — Android спросит разрешение «устанавливать неизвестные
   приложения» для Sirius Chat. Файл отдаётся установщику через FileProvider,
   наружу ничего не публикуется.

> Workflow триггерится только вручную (`workflow_dispatch`). Триггера на `push`
> нет намеренно: иначе каждый коммит агента жёг бы минуты Actions.

Сборка требует, чтобы в репозитории лежал сам Android-проект (`gradlew`,
`settings.gradle.kts`, модуль `app`). Если репозиторий пустой, сначала попросите
агента залить проект.

## 5. Что умеет агент

Инструменты зарегистрированы всегда; без подключённого аккаунта они отвечают
«подключите аккаунт в Настройках → GitHub».

| Инструмент | Действие |
|---|---|
| `github_status` | кто подключён, какой репозиторий выбран, какие есть права |
| `github_list_repos` | список репозиториев |
| `github_create_repo` | создать репозиторий (public/private) |
| `github_set_visibility` | сделать публичным или приватным |
| `github_list_files` | содержимое папки в репозитории |
| `github_read_file` | прочитать файл |
| `github_write_file` | создать/изменить файл и закоммитить |
| `github_delete_file` | удалить файл |
| `github_create_folder` | создать папку (через `.gitkeep`) |
| `github_build_apk` | запустить сборку APK |
| `github_build_status` | статус последних запусков и артефакты |

Примеры запросов: «создай приватный репозиторий sirius-notes и залей туда
README», «сделай Sirius-Chat- публичным», «собери debug APK и скажи, когда
будет готов».

## Отзыв доступа

- В приложении: **Отключить** — токен и профиль стираются с устройства.
- На GitHub: https://github.com/settings/tokens → **Delete**. После этого токен
  не работает нигде, даже если копия где-то осталась.

## Если что-то не работает

| Симптом | Причина |
|---|---|
| «Токен недействителен» | истёк, удалён или скопирован с пробелом/переносом |
| Нет права `repo` | classic-токен без скоупа `repo` (или fine-grained без Contents: write) |
| Нет права `workflow` | нет скоупа `workflow` — сборку запустить нельзя |
| Пустой список репозиториев | fine-grained токен выдан не на те репозитории |
| Смена видимости отклонена | нужен `repo`/Administration: write, и вы должны быть владельцем |
| Сборка падает сразу | в репозитории нет Android-проекта или нет `gradle/wrapper/gradle-wrapper.properties` |
| APK не устанавливается | не выдано «устанавливать неизвестные приложения» для Sirius Chat |

## Полезные ссылки

- Personal access tokens: https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens
- Скоупы OAuth/PAT: https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/scopes-for-oauth-apps
- REST API репозиториев: https://docs.github.com/en/rest/repos/repos
- REST API содержимого файлов: https://docs.github.com/en/rest/repos/contents
- REST API Actions (запуски, артефакты): https://docs.github.com/en/rest/actions
- `workflow_dispatch`: https://docs.github.com/en/actions/using-workflows/events-that-trigger-workflows#workflow_dispatch
- Лимиты API (5000 запросов/час на токен): https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api
