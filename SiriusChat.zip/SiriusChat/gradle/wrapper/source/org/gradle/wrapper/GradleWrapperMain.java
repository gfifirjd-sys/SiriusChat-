package org.gradle.wrapper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLConnection;
import java.nio.channels.FileLock;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Drop-in replacement for the stock Gradle wrapper bootstrap.
 *
 * Reads gradle/wrapper/gradle-wrapper.properties, makes sure the requested
 * Gradle distribution is present in the local cache (downloading and unpacking
 * it if needed), then hands control over to org.gradle.launcher.GradleMain.
 *
 * Cache layout and the URL hashing scheme match the official wrapper, so the
 * distribution downloaded here is reused by any other Gradle wrapper on the
 * machine and vice versa.
 */
public final class GradleWrapperMain {

    private static final String DEFAULT_DISTRIBUTION_PATH = "wrapper/dists";

    public static void main(String[] args) throws Exception {
        File jar = locateJar();
        File wrapperDir = jar.getParentFile();                 // gradle/wrapper
        File gradleDir = wrapperDir.getParentFile();           // gradle
        File projectDir = gradleDir.getParentFile();           // <project>

        File propertiesFile = new File(wrapperDir, "gradle-wrapper.properties");
        if (!propertiesFile.isFile()) {
            fail("gradle-wrapper.properties not found at " + propertiesFile);
        }

        Properties props = new Properties();
        InputStream in = new FileInputStream(propertiesFile);
        try {
            props.load(in);
        } finally {
            in.close();
        }

        String distributionUrl = required(props, "distributionUrl", propertiesFile);
        String distributionBase = props.getProperty("distributionBase", "GRADLE_USER_HOME").trim();
        String distributionPath = props.getProperty("distributionPath", DEFAULT_DISTRIBUTION_PATH).trim();
        String zipStoreBase = props.getProperty("zipStoreBase", distributionBase).trim();
        String zipStorePath = props.getProperty("zipStorePath", distributionPath).trim();

        URI uri = new URI(distributionUrl.replace(" ", "%20"));
        if (!uri.isAbsolute()) {
            uri = new File(projectDir, distributionUrl).toURI();
        }

        File gradleUserHome = resolveGradleUserHome(args);
        File distDir = resolveDir(distributionBase, distributionPath, gradleUserHome, projectDir);
        File zipDir = resolveDir(zipStoreBase, zipStorePath, gradleUserHome, projectDir);

        String fileName = fileNameOf(uri);                     // gradle-8.9-bin.zip
        String distName = stripExtension(fileName);            // gradle-8.9-bin
        String hash = hash(uri.toString());

        File distHome = new File(new File(distDir, distName), hash);
        File zipHome = new File(new File(zipDir, distName), hash);
        File localZip = new File(zipHome, fileName);
        File marker = new File(zipHome, fileName + ".ok");

        File gradleHome = alreadyInstalled(distHome, marker);
        if (gradleHome == null) {
            gradleHome = install(uri, localZip, marker, distHome);
        }

        String appName = System.getProperty("org.gradle.appname");
        if (appName == null || appName.length() == 0) {
            System.setProperty("org.gradle.appname", "gradlew");
        }
        launch(gradleHome, args);
    }

    // ---------------------------------------------------------------- install

    private static File alreadyInstalled(File distHome, File marker) {
        if (!marker.isFile() || !distHome.isDirectory()) {
            return null;
        }
        return findGradleHome(distHome);
    }

    private static File install(URI uri, File localZip, File marker, File distHome) throws Exception {
        mkdirs(localZip.getParentFile());
        mkdirs(distHome);

        File lockFile = new File(localZip.getParentFile(), localZip.getName() + ".lck");
        RandomAccessFile lockRaf = new RandomAccessFile(lockFile, "rw");
        FileLock lock = null;
        try {
            try {
                lock = lockRaf.getChannel().lock();
            } catch (Exception ignored) {
                // Locking is best effort; some filesystems on Android do not support it.
            }

            // Another process may have finished while we waited for the lock.
            File existing = alreadyInstalled(distHome, marker);
            if (existing != null) {
                return existing;
            }

            if (!marker.isFile() || !localZip.isFile()) {
                System.err.println("Downloading " + uri);
                download(uri, localZip);
            } else {
                System.err.println("Using cached " + localZip.getName());
            }

            deleteUnpackedDirs(distHome);
            System.err.println("Unpacking " + localZip.getName() + " to " + distHome);
            unzip(localZip, distHome);

            File gradleHome = findGradleHome(distHome);
            if (gradleHome == null) {
                throw new IOException("Gradle distribution '" + localZip.getName()
                        + "' does not contain a bin/gradle launcher. The download may be corrupt; "
                        + "delete " + localZip + " and retry.");
            }
            makeExecutable(new File(gradleHome, "bin"));

            if (!marker.isFile() && !marker.createNewFile()) {
                System.err.println("Warning: could not create marker file " + marker);
            }
            return gradleHome;
        } finally {
            if (lock != null) {
                try { lock.release(); } catch (Exception ignored) { }
            }
            try { lockRaf.close(); } catch (Exception ignored) { }
        }
    }

    private static void download(URI uri, File target) throws IOException {
        File partial = new File(target.getParentFile(), target.getName() + ".part");
        if (partial.exists() && !partial.delete()) {
            throw new IOException("Cannot remove stale download " + partial);
        }

        URL url = uri.toURL();
        URLConnection connection = null;
        for (int redirect = 0; redirect < 6; redirect++) {
            connection = url.openConnection();
            connection.setConnectTimeout(30000);
            connection.setReadTimeout(120000);
            connection.setRequestProperty("User-Agent", "gradlew/sirius");
            if (!(connection instanceof HttpURLConnection)) {
                break;
            }
            HttpURLConnection http = (HttpURLConnection) connection;
            http.setInstanceFollowRedirects(true);
            int status = http.getResponseCode();
            if (status == HttpURLConnection.HTTP_MOVED_PERM
                    || status == HttpURLConnection.HTTP_MOVED_TEMP
                    || status == HttpURLConnection.HTTP_SEE_OTHER
                    || status == 307 || status == 308) {
                String location = http.getHeaderField("Location");
                http.disconnect();
                if (location == null) {
                    throw new IOException("Redirect without Location header from " + url);
                }
                // Cross-protocol redirects (http -> https) are not followed automatically.
                url = new URL(url, location);
                continue;
            }
            if (status / 100 != 2) {
                http.disconnect();
                throw new IOException("Download failed: HTTP " + status + " for " + url);
            }
            break;
        }

        long total = connection.getContentLengthLong();
        InputStream input = connection.getInputStream();
        OutputStream output = new FileOutputStream(partial);
        long done = 0;
        int lastPercent = -1;
        try {
            byte[] buffer = new byte[65536];
            int read;
            while ((read = input.read(buffer)) >= 0) {
                output.write(buffer, 0, read);
                done += read;
                if (total > 0) {
                    int percent = (int) (done * 100 / total);
                    if (percent >= lastPercent + 5) {
                        lastPercent = percent;
                        System.err.println("  " + percent + "%  (" + (done / 1048576) + " MB)");
                    }
                } else if (done / 8388608 > lastPercent) {
                    lastPercent = (int) (done / 8388608);
                    System.err.println("  " + (done / 1048576) + " MB");
                }
            }
        } finally {
            try { output.close(); } catch (IOException ignored) { }
            try { input.close(); } catch (IOException ignored) { }
            if (connection instanceof HttpURLConnection) {
                ((HttpURLConnection) connection).disconnect();
            }
        }

        if (total > 0 && done != total) {
            partial.delete();
            throw new IOException("Truncated download: got " + done + " of " + total + " bytes");
        }
        if (target.exists() && !target.delete()) {
            throw new IOException("Cannot replace " + target);
        }
        if (!partial.renameTo(target)) {
            throw new IOException("Cannot move " + partial + " to " + target);
        }
    }

    private static void unzip(File zip, File destination) throws IOException {
        String root = destination.getCanonicalPath() + File.separator;
        ZipFile archive = new ZipFile(zip);
        try {
            Enumeration<? extends ZipEntry> entries = archive.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                File target = new File(destination, entry.getName());
                if (!target.getCanonicalPath().startsWith(root)) {
                    throw new IOException("Refusing to extract outside the target directory: " + entry.getName());
                }
                if (entry.isDirectory()) {
                    mkdirs(target);
                    continue;
                }
                mkdirs(target.getParentFile());
                InputStream input = archive.getInputStream(entry);
                OutputStream output = new FileOutputStream(target);
                try {
                    byte[] buffer = new byte[65536];
                    int read;
                    while ((read = input.read(buffer)) >= 0) {
                        output.write(buffer, 0, read);
                    }
                } finally {
                    try { output.close(); } catch (IOException ignored) { }
                    try { input.close(); } catch (IOException ignored) { }
                }
            }
        } finally {
            archive.close();
        }
    }

    // ----------------------------------------------------------------- launch

    private static void launch(File gradleHome, String[] args) throws Exception {
        File libDir = new File(gradleHome, "lib");
        File[] candidates = libDir.listFiles();
        File launcher = null;
        if (candidates != null) {
            Arrays.sort(candidates);
            for (int i = 0; i < candidates.length; i++) {
                String name = candidates[i].getName();
                if (name.startsWith("gradle-launcher-") && name.endsWith(".jar")) {
                    launcher = candidates[i];
                    break;
                }
            }
        }
        if (launcher == null) {
            fail("Could not locate gradle-launcher-*.jar in " + libDir);
        }

        URLClassLoader loader = new URLClassLoader(
                new URL[]{ launcher.toURI().toURL() },
                ClassLoader.getSystemClassLoader().getParent());
        Thread.currentThread().setContextClassLoader(loader);
        Class<?> mainClass = loader.loadClass("org.gradle.launcher.GradleMain");
        Method main = mainClass.getMethod("main", String[].class);
        main.invoke(null, new Object[]{ args });
    }

    // ------------------------------------------------------------------ paths

    private static File locateJar() throws Exception {
        URI location = GradleWrapperMain.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI();
        return new File(location).getAbsoluteFile();
    }

    private static File resolveGradleUserHome(String[] args) {
        for (int i = 0; i < args.length - 1; i++) {
            if ("-g".equals(args[i]) || "--gradle-user-home".equals(args[i])) {
                return new File(args[i + 1]).getAbsoluteFile();
            }
        }
        String property = System.getProperty("gradle.user.home");
        if (property != null && property.length() > 0) {
            return new File(property).getAbsoluteFile();
        }
        String env = System.getenv("GRADLE_USER_HOME");
        if (env != null && env.length() > 0) {
            return new File(env).getAbsoluteFile();
        }
        return new File(System.getProperty("user.home"), ".gradle").getAbsoluteFile();
    }

    private static File resolveDir(String base, String path, File gradleUserHome, File projectDir) {
        File root;
        if ("GRADLE_USER_HOME".equals(base)) {
            root = gradleUserHome;
        } else if ("PROJECT".equals(base)) {
            root = projectDir;
        } else {
            root = new File(base);
        }
        return new File(root, path);
    }

    /** Same scheme as the official wrapper: base36 of the MD5 of the distribution URL. */
    private static String hash(String distributionUrl) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("MD5");
        digest.update(distributionUrl.getBytes("UTF-8"));
        return new BigInteger(1, digest.digest()).toString(36);
    }

    private static String fileNameOf(URI uri) {
        String path = uri.getPath();
        if (path == null || path.length() == 0) {
            return "gradle-dist.zip";
        }
        int slash = path.lastIndexOf('/');
        return slash < 0 ? path : path.substring(slash + 1);
    }

    private static String stripExtension(String fileName) {
        int dot = fileName.lastIndexOf('.');
        return dot <= 0 ? fileName : fileName.substring(0, dot);
    }

    private static File findGradleHome(File distHome) {
        File[] children = distHome.listFiles();
        if (children == null) {
            return null;
        }
        List<File> dirs = new ArrayList<File>();
        for (int i = 0; i < children.length; i++) {
            if (children[i].isDirectory()) {
                dirs.add(children[i]);
            }
        }
        for (int i = 0; i < dirs.size(); i++) {
            if (new File(dirs.get(i), "bin/gradle").isFile()) {
                return dirs.get(i);
            }
        }
        return null;
    }

    private static void makeExecutable(File binDir) {
        File[] files = binDir.listFiles();
        if (files == null) {
            return;
        }
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].setExecutable(true, false);
            }
        }
    }

    private static void mkdirs(File dir) throws IOException {
        if (dir != null && !dir.isDirectory() && !dir.mkdirs() && !dir.isDirectory()) {
            throw new IOException("Cannot create directory " + dir);
        }
    }

    /**
     * Removes previously unpacked distributions. Only directories are touched:
     * when zipStorePath and distributionPath are identical the cached zip, its
     * marker and the lock file live in this same folder and must survive.
     */
    private static void deleteUnpackedDirs(File dir) {
        File[] children = dir.listFiles();
        if (children == null) {
            return;
        }
        for (int i = 0; i < children.length; i++) {
            if (children[i].isDirectory()) {
                deleteRecursively(children[i]);
            }
        }
    }

    private static void deleteRecursively(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (int i = 0; i < children.length; i++) {
                    deleteRecursively(children[i]);
                }
            }
        }
        file.delete();
    }

    private static String required(Properties props, String key, File file) {
        String value = props.getProperty(key);
        if (value == null || value.trim().length() == 0) {
            fail("'" + key + "' is not set in " + file);
        }
        return value.trim();
    }

    private static void fail(String message) {
        System.err.println("ERROR: " + message);
        System.exit(1);
    }

    private GradleWrapperMain() {
    }
}
