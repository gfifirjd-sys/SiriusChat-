Source of gradle/wrapper/gradle-wrapper.jar.

The jar is a self-contained bootstrap: it reads gradle-wrapper.properties,
downloads and unpacks the Gradle distribution into the standard wrapper cache
(~/.gradle/wrapper/dists/<name>/<md5-base36-of-url>/), then hands off to
org.gradle.launcher.GradleMain. Cache layout and URL hashing match the official
wrapper byte for byte, so the download is shared with any other Gradle project.

Nothing here is compiled by the Android build; this folder is documentation.

Rebuild:
  javac -source 8 -target 8 -d out org/gradle/wrapper/GradleWrapperMain.java
  jar cfe ../gradle-wrapper.jar org.gradle.wrapper.GradleWrapperMain -C out .

Or replace it with the official one at any time:
  gradle wrapper --gradle-version 8.9
