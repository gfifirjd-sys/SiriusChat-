package com.sirius.chat.data.web

import android.util.Log
import com.sirius.chat.core.common.AppDispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** One hit, already trimmed to what is worth spending prompt tokens on. */
data class WebResult(
    val title: String,
    val url: String,
    val snippet: String
)

/** A page, reduced to readable text. */
data class WebPage(
    val url: String,
    val title: String,
    val text: String,
    val truncated: Boolean
)

/**
 * Keyless web access.
 *
 * ### Why scrape instead of using an API
 * Every search API worth using (Tavily, Brave, Serper, Bing) needs a key the
 * user does not have and would have to buy before the switch in the settings
 * panel did anything. A feature that is off until you sign up for a third
 * service is not a feature, it is an advertisement. DuckDuckGo's HTML endpoints
 * answer without one, so "Интернет" works the first time it is switched on, on
 * a fresh install, on a local Ollama model with no keys stored at all.
 *
 * The cost is that this is parsing a page rather than reading a contract, and
 * pages change. That shapes everything below: two independent endpoints are
 * tried, the extraction is deliberately loose, and a total failure returns an
 * empty list rather than throwing — the agent is told "no results" and can
 * answer from what it knows, which is far better than a run dying on a markup
 * change.
 *
 * ### Why Wikipedia is in here
 * The lite endpoint is rate limited and occasionally serves a challenge page. For
 * the factual questions that dominate this switch's use ("what is X", "when did
 * Y") Wikipedia's REST API is keyless, stable, has a real contract, and gives a
 * better paragraph than a search snippet. It runs alongside rather than instead:
 * one summary is prepended, the search hits follow.
 */
class WebSearchService(private val dispatchers: AppDispatchers) {

    private val client = OkHttpClient.Builder()
        // Short by the standards of the rest of the app. This sits inside an
        // agent step the user is watching a spinner for, and a search that takes
        // 30s is worse than a search that admits defeat at 12 and lets the model
        // answer from memory.
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /**
     * Search, best effort.
     *
     * @return up to [limit] results, newest-relevance first, or an empty list if
     *   every endpoint failed. Never throws for a network reason.
     */
    suspend fun search(query: String, limit: Int = 6): List<WebResult> =
        withContext(dispatchers.io) {
            val clean = query.trim()
            if (clean.isEmpty()) return@withContext emptyList()

            val results = LinkedHashMap<String, WebResult>()

            // Wikipedia first so its paragraph leads, but only for queries that
            // look like a lookup rather than a navigation ("site:x", a bare URL,
            // a long natural question) — otherwise it mostly returns noise.
            if (clean.length in 3..80 && !clean.contains("://") && !clean.contains("site:")) {
                wikipedia(clean)?.let { results[it.url] = it }
            }

            for (endpoint in listOf(::duckDuckGoLite, ::duckDuckGoHtml)) {
                runCatching { endpoint(clean) }
                    .onFailure { Log.w(TAG, "search endpoint failed", it) }
                    .getOrDefault(emptyList())
                    .forEach { hit -> results.putIfAbsent(hit.url, hit) }
                // One working endpoint is enough; the second exists for the day
                // the first changes its markup, not to double every query.
                if (results.size >= limit) break
            }

            results.values.take(limit)
        }

    /**
     * Fetch one page as text.
     *
     * The cap is a prompt-budget decision, not a memory one. A 400 KB article
     * pasted into the context window evicts the conversation that asked for it,
     * so the model ends up reading the page and forgetting the question.
     */
    suspend fun fetch(url: String, maxChars: Int = 12_000): WebPage =
        withContext(dispatchers.io) {
            val normalized = normalizeUrl(url)
            val request = Request.Builder()
                .url(normalized)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "text/html,application/xhtml+xml,text/plain;q=0.9")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("HTTP ${response.code} for $normalized")
                }
                val body = response.body?.string().orEmpty()
                val title = Regex("<title[^>]*>(.*?)</title>", REGEX_OPTS)
                    .find(body)?.groupValues?.get(1)?.let(::decodeEntities)?.trim().orEmpty()
                val text = htmlToText(body)
                WebPage(
                    url = normalized,
                    title = title,
                    text = text.take(maxChars),
                    truncated = text.length > maxChars
                )
            }
        }

    // ------------------------------------------------------------- endpoints

    /**
     * `lite.duckduckgo.com` — a table of links with no CSS and no JavaScript.
     *
     * Preferred over the `html.` variant because the markup is an order of
     * magnitude smaller (less to download on a phone connection) and has stayed
     * unchanged far longer.
     */
    private fun duckDuckGoLite(query: String): List<WebResult> {
        val body = get("https://lite.duckduckgo.com/lite/?q=${encode(query)}")
        val links = Regex(
            """<a[^>]+class="result-link"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""",
            REGEX_OPTS
        ).findAll(body).toList()
        val snippets = Regex(
            """<td[^>]+class="result-snippet"[^>]*>(.*?)</td>""",
            REGEX_OPTS
        ).findAll(body).map { decodeEntities(stripTags(it.groupValues[1])).trim() }.toList()

        return links.mapIndexedNotNull { index, match ->
            val url = unwrapRedirect(decodeEntities(match.groupValues[1]))
            val title = decodeEntities(stripTags(match.groupValues[2])).trim()
            if (url.isBlank() || title.isBlank()) return@mapIndexedNotNull null
            WebResult(title, url, snippets.getOrElse(index) { "" })
        }
    }

    /** The classic no-JS results page, kept as the second opinion. */
    private fun duckDuckGoHtml(query: String): List<WebResult> {
        val body = get("https://html.duckduckgo.com/html/?q=${encode(query)}")
        val blocks = body.split("result__body").drop(1)
        return blocks.mapNotNull { block ->
            val href = Regex("""href="([^"]+)"""", REGEX_OPTS).find(block)
                ?.groupValues?.get(1)?.let(::decodeEntities)?.let(::unwrapRedirect)
            val title = Regex("""result__a[^>]*>(.*?)</a>""", REGEX_OPTS).find(block)
                ?.groupValues?.get(1)?.let { decodeEntities(stripTags(it)).trim() }
            val snippet = Regex("""result__snippet[^>]*>(.*?)</a>""", REGEX_OPTS).find(block)
                ?.groupValues?.get(1)?.let { decodeEntities(stripTags(it)).trim() }.orEmpty()
            if (href.isNullOrBlank() || title.isNullOrBlank()) null
            else WebResult(title, href, snippet)
        }
    }

    /**
     * Wikipedia's search + summary pair.
     *
     * Two calls rather than one because the summary endpoint needs an exact
     * title, and users do not type exact titles. A miss is silent: this is a
     * bonus result, not the answer.
     */
    private fun wikipedia(query: String): WebResult? = runCatching {
        val searchBody = get(
            "https://en.wikipedia.org/w/api.php?action=opensearch&limit=1&format=json" +
                "&search=${encode(query)}"
        )
        // opensearch returns [query, [titles], [descriptions], [urls]] — plain
        // enough to read with one regex rather than pulling in a model class.
        val title = Regex("""\[\s*"[^"]*"\s*,\s*\[\s*"((?:[^"\\]|\\.)*)"""", REGEX_OPTS)
            .find(searchBody)?.groupValues?.get(1)?.replace("\\\"", "\"")
            ?: return@runCatching null
        if (title.isBlank()) return@runCatching null

        val summaryBody = get(
            "https://en.wikipedia.org/api/rest_v1/page/summary/${encode(title.replace(' ', '_'))}"
        )
        val extract = Regex(""""extract"\s*:\s*"((?:[^"\\]|\\.)*)"""", REGEX_OPTS)
            .find(summaryBody)?.groupValues?.get(1)
            ?.replace("\\\"", "\"")?.replace("\\n", " ")?.trim()
            ?: return@runCatching null
        if (extract.length < 40) return@runCatching null

        WebResult(
            title = "$title — Wikipedia",
            url = "https://en.wikipedia.org/wiki/${title.replace(' ', '_')}",
            snippet = extract.take(700)
        )
    }.getOrNull()

    // ----------------------------------------------------------------- plumbing

    private fun get(url: String): String {
        val request = Request.Builder()
            .url(url)
            // A bare OkHttp user agent gets a challenge page from both search
            // endpoints. This is not evasion — the request is a normal, single,
            // rate-respecting page load — it is the minimum needed to be served
            // the same HTML a browser would get.
            .header("User-Agent", USER_AGENT)
            .header("Accept-Language", "en-US,en;q=0.9")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code} for $url")
            return response.body?.string().orEmpty()
        }
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")

    /**
     * DuckDuckGo wraps outbound links in `/l/?uddg=<encoded target>`.
     *
     * Unwrapped because the raw redirect is useless to the model and to
     * [fetch]: it cannot be judged for relevance, cannot be cited, and every
     * result would look like it came from the same domain.
     */
    private fun unwrapRedirect(href: String): String {
        val marker = "uddg="
        val index = href.indexOf(marker)
        val raw = if (index >= 0) {
            val end = href.indexOf('&', index).let { if (it < 0) href.length else it }
            runCatching {
                java.net.URLDecoder.decode(href.substring(index + marker.length, end), "UTF-8")
            }.getOrDefault(href)
        } else {
            href
        }
        return when {
            raw.startsWith("//") -> "https:$raw"
            raw.startsWith("http") -> raw
            else -> raw
        }
    }

    private fun normalizeUrl(url: String): String {
        val trimmed = url.trim().trim('`', '<', '>', '"', '\'')
        return if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            trimmed
        } else {
            "https://$trimmed"
        }
    }

    private fun stripTags(html: String): String = html.replace(TAG_REGEX, "")

    /**
     * HTML to something a model can read.
     *
     * Script and style bodies are removed *before* tags, or their contents would
     * survive as a wall of JavaScript — which is most of the byte weight of a
     * modern page and none of its meaning. Block-level tags become newlines so
     * paragraphs and list items stay separated; without that the whole article
     * arrives as one line and the model loses every structural cue.
     */
    private fun htmlToText(html: String): String {
        var text = html
        for (regex in NOISE_REGEXES) text = text.replace(regex, " ")
        text = text.replace(BREAK_REGEX, "\n")
        text = text.replace(TAG_REGEX, " ")
        text = decodeEntities(text)
        return text
            .lineSequence()
            .map { it.replace(WHITESPACE_REGEX, " ").trim() }
            .filter { it.isNotEmpty() }
            .joinToString("\n")
    }

    /**
     * The handful of entities that actually appear in extracted prose.
     *
     * Numeric forms are decoded generically because typographic punctuation
     * (`&#8217;`, `&#8212;`) is everywhere in articles and leaving it raw makes
     * every quoted sentence look corrupted.
     */
    private fun decodeEntities(raw: String): String {
        var text = raw
            .replace("&nbsp;", " ")
            .replace("&#160;", " ")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
            .replace("&#39;", "'")
            .replace("&hellip;", "…")
            .replace("&mdash;", "—")
            .replace("&ndash;", "–")
        text = NUMERIC_ENTITY.replace(text) { match ->
            val code = match.groupValues[1].toIntOrNull() ?: return@replace match.value
            if (code in 1..0x10FFFF) String(Character.toChars(code)) else match.value
        }
        // Ampersand last, so `&amp;lt;` does not become `<`.
        return text.replace("&amp;", "&")
    }

    private companion object {
        const val TAG = "WebSearch"

        /**
         * A real, current browser string. Search endpoints serve a JavaScript
         * challenge to anything that looks automated, and the challenge page
         * parses to zero results — which is indistinguishable from "the internet
         * has nothing about this" from the agent's side.
         */
        const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

        val REGEX_OPTS = setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)

        val TAG_REGEX = Regex("<[^>]*>")
        val WHITESPACE_REGEX = Regex("[ \\t\\u00A0]+")
        val NUMERIC_ENTITY = Regex("&#(\\d{2,7});")

        val NOISE_REGEXES = listOf(
            Regex("<script[^>]*>.*?</script>", REGEX_OPTS),
            Regex("<style[^>]*>.*?</style>", REGEX_OPTS),
            Regex("<noscript[^>]*>.*?</noscript>", REGEX_OPTS),
            Regex("<svg[^>]*>.*?</svg>", REGEX_OPTS),
            Regex("<!--.*?-->", REGEX_OPTS),
            Regex("<head[^>]*>.*?</head>", REGEX_OPTS)
        )

        val BREAK_REGEX = Regex(
            "</?(?:p|div|br|li|tr|h[1-6]|section|article|header|footer|ul|ol|table|blockquote|pre)[^>]*>",
            REGEX_OPTS
        )
    }
}
