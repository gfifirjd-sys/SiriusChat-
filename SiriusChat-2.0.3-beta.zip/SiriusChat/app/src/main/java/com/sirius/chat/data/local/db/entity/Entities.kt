package com.sirius.chat.data.local.db.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val treeUri: String?,
    val workspaceLabel: String,
    val providerId: String?,
    val model: String?,
    val accentIndex: Int,
    val favorite: Boolean,
    val createdAt: Long,
    val lastOpenedAt: Long
)

@Entity(
    tableName = "recent_files",
    primaryKeys = ["documentId", "projectId"],
    indices = [Index("projectId"), Index("openedAt")]
)
data class RecentFileEntity(
    val documentId: String,
    val projectId: String,
    val name: String,
    val path: String,
    val openedAt: Long,
    val caretOffset: Int,
    val scrollLine: Int
)

@Entity(
    tableName = "chat_sessions",
    indices = [Index("projectId"), Index("updatedAt")]
)
data class ChatSessionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val projectId: String?,
    val providerId: String,
    val model: String,
    val agentMode: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean,
    val draft: String = "",
    /**
     * The chat's feature switches, packed into one integer.
     *
     * ### Why a bitmask and not five columns
     * Five booleans would be more readable in a `SELECT`, and that is genuinely
     * the only thing they would be better at. Against it: five `ALTER TABLE`
     * statements in the migration instead of one, five more parameters threaded
     * through `toEntity`/`toDomain`, and — the deciding factor — a schema change
     * every single time a switch is added to the settings panel. A sixth feature
     * is a new bit here and nothing else; as a column it is another migration and
     * another version bump for every user.
     *
     * The packing is confined to [com.sirius.chat.data.repository.ChatFeatureFlags],
     * so nothing outside that object ever sees an integer.
     *
     * ### Why the default is declared twice
     * `@ColumnInfo(defaultValue = "-1")` is not redundant with the Kotlin default.
     * Room ignores Kotlin defaults when it builds the schema it expects to find,
     * and it *does* compare column defaults during validation. The migration adds
     * this column with `DEFAULT -1`, so without the annotation a fresh install
     * (no default in `CREATE TABLE`) and an upgraded install (default present)
     * would have different schemas -- and only the upgraded one would crash, on
     * the user's device, well after this code was reviewed. Declaring it here
     * makes both paths produce the same table.
     *
     * ### Why the default is negative
     * `-1` is not a set of flags, it is the absence of one: this session has never
     * had its switches touched, so it should follow the user's defaults from
     * [com.sirius.chat.domain.model.AppSettings]. A `0` default would be
     * indistinguishable from "the user deliberately turned everything off", which
     * would silently disable streaming for every conversation that existed before
     * this column did.
     */
    @ColumnInfo(defaultValue = "-1")
    val featureFlags: Int = INHERIT_FEATURES
) {
    companion object {
        /** Sentinel for "no explicit choice stored". */
        const val INHERIT_FEATURES = -1
    }
}

@Entity(
    tableName = "chat_messages",
    indices = [Index("sessionId"), Index("createdAt")],
    foreignKeys = [
        ForeignKey(
            entity = ChatSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val role: String,
    val content: String,
    val createdAt: Long,
    val model: String?,
    val providerId: String?,
    val status: String,
    val error: String?,
    /** JSON encoded attachments; small and read together with the message. */
    val attachmentsJson: String = "[]",
    val toolRunsJson: String = "[]"
)

/** Denormalised counters used by the sessions list. */
data class SessionWithStats(
    val id: String,
    val title: String,
    val projectId: String?,
    val providerId: String,
    val model: String,
    val agentMode: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val pinned: Boolean,
    val messageCount: Int,
    val lastMessagePreview: String?
)
