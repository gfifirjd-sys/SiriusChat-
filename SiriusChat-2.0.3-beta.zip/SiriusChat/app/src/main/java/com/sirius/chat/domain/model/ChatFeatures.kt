package com.sirius.chat.domain.model

/**
 * The switchable abilities of one conversation.
 *
 * ### Why this is per-session and not global
 * A toggle like "internet" is not a preference, it is part of what a
 * conversation *is*. A thread where the model researched three libraries online
 * reads differently on reopening than one where it answered from memory, and the
 * user needs to be able to tell those apart weeks later. Storing the switches
 * next to the messages means reopening a chat restores the world that produced
 * it; storing them in [AppSettings] would silently rewrite the past every time
 * the user flipped a switch in some other chat.
 *
 * [AppSettings] still holds the *defaults* a brand-new session starts from, so
 * the user configures this once rather than on every chat.
 *
 * ### Why the flags are not simply booleans on ChatSession
 * They travel together — the settings panel reads all of them, the agent asks
 * for all of them, and the entity round-trips all of them. Every one of those
 * places would otherwise grow another parameter each time a feature is added,
 * which is exactly how the `agentMode` legacy column ended up stranded.
 */
data class ChatFeatures(
    /** Live web search and page fetching. */
    val webSearch: Boolean = false,
    /** Text-to-image generation. */
    val imageGeneration: Boolean = false,
    /**
     * Whether attached images are sent as real image blocks.
     *
     * Off (or unsupported) means an attached screenshot is described by name and
     * size instead of being seen. That is a worse answer, but it is an *answer*:
     * sending an image block to a text-only model is a hard 400 that loses the
     * whole turn.
     */
    val vision: Boolean = true,
    /** Whether the agent may call tools at all. */
    val tools: Boolean = true,
    /** Token-by-token rendering. */
    val streaming: Boolean = true
) {
    operator fun get(feature: ChatFeature): Boolean = when (feature) {
        ChatFeature.WebSearch -> webSearch
        ChatFeature.ImageGeneration -> imageGeneration
        ChatFeature.Vision -> vision
        ChatFeature.Tools -> tools
        ChatFeature.Streaming -> streaming
    }

    fun with(feature: ChatFeature, enabled: Boolean): ChatFeatures = when (feature) {
        ChatFeature.WebSearch -> copy(webSearch = enabled)
        ChatFeature.ImageGeneration -> copy(imageGeneration = enabled)
        ChatFeature.Vision -> copy(vision = enabled)
        ChatFeature.Tools -> copy(tools = enabled)
        ChatFeature.Streaming -> copy(streaming = enabled)
    }

    /**
     * Clamps every flag to what the model can actually do.
     *
     * Applied on the way *out* to the network rather than on the way in to
     * storage, so switching a session from GPT-4o to a text-only local model
     * does not erase the user's choice — it suspends it, and switching back
     * restores it. A stored `true` the current model cannot honour is a
     * preference, not a lie.
     */
    fun clampTo(support: FeatureSupport): ChatFeatures = ChatFeatures(
        webSearch = webSearch && support.webSearch.usable,
        imageGeneration = imageGeneration && support.imageGeneration.usable,
        vision = vision && support.vision.usable,
        tools = tools && support.tools.usable,
        streaming = streaming && support.streaming.usable
    )
}

/** Stable identity for a switch, so the UI can loop instead of hard-coding rows. */
enum class ChatFeature { WebSearch, ImageGeneration, Vision, Tools, Streaming }

/**
 * How a feature is delivered for the current provider and model.
 *
 * The distinction matters to the user, not just to the code: "Интернет" backed
 * by Perplexity Sonar is the model searching natively, while the same switch on
 * a local Ollama model is Sirius searching and pasting results into the prompt.
 * Both work; they cost different things and fail differently, so the panel names
 * which one is in play instead of showing an identical switch for both.
 */
enum class FeatureTier {
    /** The provider does it itself, with the user's own key. */
    Native,

    /** Sirius does it, keyless, and feeds the result to the model. */
    Builtin,

    /** Nothing can deliver it here. The switch is disabled. */
    Unsupported
}

/**
 * One feature's availability, plus the short human name of whatever will run it.
 *
 * [engine] is shown verbatim under the switch ("gpt-image-1", "Pollinations",
 * "DuckDuckGo"). Unsupported carries a [reason] resource id instead, because a
 * greyed-out switch with no explanation is the single most common way a settings
 * screen makes a working app look broken.
 */
data class FeatureState(
    val tier: FeatureTier,
    val engine: String = "",
    val reasonKey: String = ""
) {
    val usable: Boolean get() = tier != FeatureTier.Unsupported

    companion object {
        fun native(engine: String) = FeatureState(FeatureTier.Native, engine)
        fun builtin(engine: String) = FeatureState(FeatureTier.Builtin, engine)
        fun unsupported(reasonKey: String) =
            FeatureState(FeatureTier.Unsupported, reasonKey = reasonKey)
    }
}

/** The full capability answer for one provider + model pair. */
data class FeatureSupport(
    val webSearch: FeatureState,
    val imageGeneration: FeatureState,
    val vision: FeatureState,
    val tools: FeatureState,
    val streaming: FeatureState
) {
    operator fun get(feature: ChatFeature): FeatureState = when (feature) {
        ChatFeature.WebSearch -> webSearch
        ChatFeature.ImageGeneration -> imageGeneration
        ChatFeature.Vision -> vision
        ChatFeature.Tools -> tools
        ChatFeature.Streaming -> streaming
    }

    companion object {
        /**
         * What to assume before the provider list has loaded.
         *
         * Everything unsupported rather than everything available: a switch that
         * is briefly enabled and then disables itself is worse than one that
         * arrives correct a frame later, because the user may have already
         * tapped it.
         */
        val Unknown = FeatureSupport(
            webSearch = FeatureState.unsupported("provider"),
            imageGeneration = FeatureState.unsupported("provider"),
            vision = FeatureState.unsupported("provider"),
            tools = FeatureState.unsupported("provider"),
            streaming = FeatureState.unsupported("provider")
        )
    }
}

/**
 * The switches a brand-new chat starts with.
 *
 * Lives beside [ChatFeatures] rather than on [AppSettings] because it is a
 * translation between two types that both belong here, and putting it on the
 * settings class would make that file depend on the feature model for one
 * function.
 *
 * Vision and tools are not user-configurable defaults: they are on unless the
 * model cannot do them, and `clampTo` already handles that. Adding global
 * switches for them would give the user two places to turn off the same thing.
 */
fun AppSettings.defaultChatFeatures(): ChatFeatures = ChatFeatures(
    webSearch = defaultWebSearch,
    imageGeneration = defaultImageGeneration,
    vision = true,
    tools = true,
    streaming = streamingEnabled
)
