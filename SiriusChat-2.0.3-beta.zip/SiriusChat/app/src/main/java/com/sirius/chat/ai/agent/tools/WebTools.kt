package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.int
import com.sirius.chat.ai.agent.string
import com.sirius.chat.data.web.WebSearchService
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.JsonObject

/**
 * The two tools behind the "Интернет" switch.
 *
 * ### Why two and not one
 * A search result is a title and two sentences. That is enough to answer "which
 * library does X" and nowhere near enough to answer "what changed in version
 * 3.2" — for that the model has to read the page. Collapsing both into a single
 * `web` tool would mean either fetching every hit (six page loads and 70 KB of
 * prompt for a question a snippet answered) or never fetching any (confident
 * answers built on two sentences of marketing copy).
 *
 * Splitting them lets the model spend a cheap call first and an expensive one
 * only when the snippets were not enough, which is the same way a person uses a
 * search engine.
 *
 * ### Why they are read-only
 * Neither proposes a [com.sirius.chat.domain.model.PendingChange], so neither
 * goes through the approval queue. Reading a public page changes nothing the user
 * could lose, and putting a diff dialog in front of every search would make the
 * feature unusable for the case it exists for: the agent quietly checking a fact
 * mid-run.
 */
private class WebSearchTool(private val service: WebSearchService) : AgentTool {
    override val name = "web_search"
    override val description =
        "Search the live web and get titles, URLs and snippets. Use for anything " +
            "that changed after your training cutoff, for exact version numbers, " +
            "current API signatures, prices, news, or when the user asks you to " +
            "look something up. Follow with open_url when a snippet is not enough."
    override val usage = """{"query": "kotlin 2.1 release notes", "limit": 5}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val query = args.string("query") ?: args.string("q") ?: args.string("search")
            ?: return AgentToolResult("Missing 'query'.", success = false)

        val limit = args.int("limit", DEFAULT_LIMIT).coerceIn(1, MAX_LIMIT)

        val results = try {
            service.search(query, limit)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (error: Throwable) {
            return AgentToolResult(
                "Search failed: ${error.message ?: error::class.simpleName}. " +
                    "Answer from what you already know and say the search did not run.",
                success = false
            )
        }

        // An empty result set is a successful search, not a failed one. Reported
        // as success = true on purpose: a red cross in the transcript would tell
        // the user the feature is broken when in fact the query simply matched
        // nothing, and it pushes the model into retrying the same query.
        if (results.isEmpty()) {
            return AgentToolResult(
                "No results for \"$query\". Try a shorter or more specific query, " +
                    "or answer from what you know and say the search returned nothing."
            )
        }

        val output = buildString {
            append("Search results for \"").append(query).append("\":\n")
            results.forEachIndexed { index, result ->
                append('\n').append(index + 1).append(". ").append(result.title).append('\n')
                append("   ").append(result.url).append('\n')
                if (result.snippet.isNotBlank()) {
                    append("   ").append(result.snippet.take(SNIPPET_CHARS)).append('\n')
                }
            }
            append(
                "\nCite the URLs you actually used as markdown links in your answer. " +
                    "Call open_url for any page you need the full text of."
            )
        }
        return AgentToolResult(output)
    }

    private companion object {
        const val DEFAULT_LIMIT = 6
        const val MAX_LIMIT = 10
        const val SNIPPET_CHARS = 400
    }
}

/**
 * Reads one page as text.
 *
 * The character cap is the whole design of this tool. An agent that can fetch
 * unbounded pages will, on its third call, have filled the context window with
 * navigation menus and cookie banners and pushed the user's actual question out
 * of it. So the budget is fixed, the model is told when it was hit, and it is
 * told what to do about it — request a narrower page rather than assume it saw
 * everything.
 */
private class OpenUrlTool(private val service: WebSearchService) : AgentTool {
    override val name = "open_url"
    override val description =
        "Fetch one web page and read it as plain text. Use after web_search when " +
            "a snippet is not enough, or when the user gives you a URL directly. " +
            "Scripts, styles and navigation are stripped."
    override val usage = """{"url": "https://kotlinlang.org/docs/whatsnew21.html", "max_chars": 12000}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val url = args.string("url") ?: args.string("link") ?: args.string("href")
            ?: return AgentToolResult("Missing 'url'.", success = false)

        val maxChars = args.int("max_chars", DEFAULT_CHARS).coerceIn(500, MAX_CHARS)

        val page = try {
            service.fetch(url, maxChars)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (error: Throwable) {
            return AgentToolResult(
                "Could not fetch $url: ${error.message ?: error::class.simpleName}. " +
                    "The page may be blocked, require a login, or render only with " +
                    "JavaScript. Try another result from web_search.",
                success = false
            )
        }

        if (page.text.isBlank()) {
            return AgentToolResult(
                "$url returned no readable text. It is most likely rendered by " +
                    "JavaScript. Try a different source.",
                success = false
            )
        }

        val output = buildString {
            append(page.url)
            if (page.title.isNotBlank()) append(" — ").append(page.title)
            append('\n')
            if (page.truncated) {
                append("(truncated to ").append(maxChars).append(" characters)\n")
            }
            append('\n').append(page.text)
        }
        return AgentToolResult(output)
    }

    private companion object {
        const val DEFAULT_CHARS = 12_000
        const val MAX_CHARS = 40_000
    }
}

/**
 * Registers the web tools.
 *
 * A factory, matching `gitHubTools`, because these need a service instance and
 * [com.sirius.chat.ai.agent.AgentEngine.defaultTools] is deliberately a
 * dependency-free static list.
 */
fun webTools(service: WebSearchService): List<AgentTool> = listOf(
    WebSearchTool(service),
    OpenUrlTool(service)
)

/** Names of the tools this switch controls, for the per-session tool filter. */
val WEB_TOOL_NAMES: Set<String> = setOf("web_search", "open_url")
