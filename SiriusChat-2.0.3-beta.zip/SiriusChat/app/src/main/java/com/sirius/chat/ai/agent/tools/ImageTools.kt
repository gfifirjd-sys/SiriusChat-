package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.int
import com.sirius.chat.ai.agent.string
import com.sirius.chat.ai.agent.stringOrEmpty
import com.sirius.chat.data.image.ImageGenerationService
import com.sirius.chat.data.image.ImageModerationException
import com.sirius.chat.data.image.ImageRequest
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.JsonObject

/**
 * The tool behind the "Генерация изображений" switch.
 *
 * ### Why the result is markdown and not a structured field
 * The tool returns the image as a markdown link in its output, and the model is
 * told to repeat that link in its answer. The alternative — a dedicated
 * `imageUrl` field on the message that the bubble renders specially — was
 * rejected because it makes the picture invisible to everything that treats a
 * message as text: the transcript export, the clipboard, the prompt history sent
 * back on the next turn, and the model's own view of what it just did.
 *
 * With markdown, the model *knows* there is an image in the conversation, can
 * refer to it ("the second one, with the blue background"), and can place it
 * mid-sentence where it belongs rather than always at the end of the bubble.
 *
 * ### Why the tool does not silently retry
 * One call, one picture. A model asked for "some icons" will otherwise call this
 * four times in one step, and each call is a real generation the user may be
 * paying for. The per-run cap in the engine bounds the total, and the
 * instructions below tell the model to ask before producing a batch.
 */
private class GenerateImageTool(
    private val service: ImageGenerationService
) : AgentTool {

    override val name = "generate_image"
    override val description =
        "Generate one image from a text description and place it in the chat. Use " +
            "when the user asks for a picture, illustration, icon, logo, mockup or " +
            "diagram-as-art. Write the prompt in English and describe subject, " +
            "composition, lighting and style — the image model does not see the " +
            "conversation, only your prompt. Ask first before generating more than one."
    override val usage =
        """{"prompt": "a red fox sleeping on a mossy rock, soft morning light", """ +
            """"aspect": "square", "style": "photorealistic"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val prompt = args.string("prompt") ?: args.string("description")
            ?: args.string("text") ?: args.string("query")
            ?: return AgentToolResult(
                "Missing 'prompt'. Describe the picture in English.",
                success = false
            )

        val (width, height) = dimensions(args)

        val result = try {
            service.generate(
                providerId = context.providerId,
                request = ImageRequest(
                    prompt = prompt,
                    width = width,
                    height = height,
                    style = args.stringOrEmpty("style")
                )
            )
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (refusal: ImageModerationException) {
            // Reported as a failure but with no suggestion to rephrase and retry:
            // the engine refused the content, and coaching the model into finding
            // a wording that slips past is not this app's job.
            return AgentToolResult(
                "The image engine refused this prompt: ${refusal.message}. " +
                    "Tell the user it was declined and do not retry it.",
                success = false
            )
        } catch (error: Throwable) {
            return AgentToolResult(
                "Image generation failed: ${error.message ?: error::class.simpleName}. " +
                    "Tell the user, and suggest checking the provider key in Settings " +
                    "if the endpoint rejected the request.",
                success = false
            )
        }

        val alt = prompt.replace(']', ' ').replace('[', ' ').trim().take(ALT_CHARS)
        val markdown = "![$alt](${result.image.markdownUri})"

        return AgentToolResult(
            buildString {
                append("Image generated with ").append(result.engine)
                append(" at ").append(result.image.resolution).append(".\n\n")
                if (result.fellBack) {
                    append("Note: the provider's own image endpoint refused (")
                    append(result.fallbackReason.take(200))
                    append("), so the built-in engine drew it instead. ")
                    append("Mention this to the user.\n\n")
                }
                append("Include exactly this line in your answer so the picture is shown:\n")
                append(markdown)
                append("\n\nDo not describe the image in detail afterwards — the user can see it.")
            }
        )
    }

    /**
     * Pixel size from whatever the model expressed the shape as.
     *
     * Named aspects are accepted because that is what models emit — `"aspect":
     * "landscape"` far more often than `"width": 1344`. Explicit pixels win when
     * given, and everything is snapped to a multiple of 64: diffusion endpoints
     * reject or silently re-round odd sizes, and a silent re-round means the
     * resolution badge in the chat lies about what was produced.
     */
    private fun dimensions(args: JsonObject): Pair<Int, Int> {
        val explicitWidth = args.int("width", 0)
        val explicitHeight = args.int("height", 0)
        if (explicitWidth > 0 && explicitHeight > 0) {
            return snap(explicitWidth) to snap(explicitHeight)
        }

        val aspect = (args.string("aspect") ?: args.string("aspect_ratio") ?: args.string("size"))
            ?.lowercase()
            .orEmpty()

        return when {
            aspect.contains("land") || aspect.contains("wide") || aspect == "16:9" ->
                1344 to 768
            aspect.contains("port") || aspect.contains("tall") || aspect == "9:16" ->
                768 to 1344
            aspect == "4:3" -> 1152 to 896
            aspect == "3:4" -> 896 to 1152
            else -> 1024 to 1024
        }
    }

    private fun snap(value: Int): Int =
        (value.coerceIn(256, 1536) / 64) * 64

    private companion object {
        const val ALT_CHARS = 120
    }
}

/** Registers the image tool. */
fun imageTools(service: ImageGenerationService): List<AgentTool> = listOf(
    GenerateImageTool(service)
)

/** Names of the tools this switch controls, for the per-session tool filter. */
val IMAGE_TOOL_NAMES: Set<String> = setOf("generate_image")
