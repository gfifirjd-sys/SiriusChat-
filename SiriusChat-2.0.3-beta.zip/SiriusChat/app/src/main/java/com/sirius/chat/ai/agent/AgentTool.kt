package com.sirius.chat.ai.agent

import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.repository.WorkspaceRepository
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * A question the agent wants answered before it continues.
 *
 * [options] are suggestions, never a closed set — the sheet always offers a free
 * text field as well. A model that can only offer a fixed menu ends up guessing
 * at the one case the user actually has, and guessing is the thing this tool
 * exists to stop.
 */
data class AgentQuestion(
    val id: String,
    val question: String,
    val options: List<String>,
    /**
     * Whether several options can be picked at once.
     *
     * Single select answers on tap, which is the right cost for "which module?".
     * Multi select cannot: it needs a confirm step, because there is no way to
     * tell a finished selection from a half-made one. That extra tap is why this
     * is opt-in per question rather than always on.
     */
    val multiSelect: Boolean = false
)

/**
 * Result of a finished shell command.
 *
 * `stdout` and `stderr` stay separate all the way to the model. Interleaving them
 * the way a terminal does is right for a human reading a screen and wrong here:
 * the error is the signal, and burying three lines of it inside four hundred
 * lines of Gradle progress is how a model concludes a failed build succeeded.
 */
data class CommandOutcome(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val durationMs: Long,
    val timedOut: Boolean = false,
    /**
     * Where it actually ran. Reported to the model because it is frequently not
     * the project folder — see `shellPathForTree` — and a relative path that
     * failed is only diagnosable if you know the directory it was relative to.
     */
    val workingDirectory: String = ""
)

/** Everything a tool needs to touch the workspace. */
data class AgentContext(
    val sessionId: String,
    val projectId: String?,
    val treeUri: String?,
    val workspace: WorkspaceRepository,
    /**
     * Provider the conversation is talking to.
     *
     * Only `generate_image` reads it, and it reads it for a specific reason: the
     * picture should come from the endpoint the user is already paying for and
     * has already chosen to trust, not from whatever the app happens to prefer.
     * Passing the id through the context rather than binding it into the tool at
     * construction time is what makes that possible -- the engine is one shared
     * instance, so a tool that captured a provider would hand every session the
     * provider of whichever one started first.
     */
    val providerId: String = "",
    /**
     * Suspends the run until the user answers, and returns what they said.
     *
     * Null when nothing can present a question — a background run, or a unit
     * test. `ask_user` then fails fast instead of hanging forever, which matters:
     * an agent blocked on a question no one will ever see looks identical to a
     * frozen app.
     */
    val askUser: (suspend (AgentQuestion) -> String)? = null,
    /**
     * Runs a shell command and suspends until it exits.
     *
     * Null when no terminal engine is usable — no Termux, or a device where the
     * local shell cannot start. [RunCommandTool] then refuses explicitly rather
     * than pretending, because an agent that silently skips the build step still
     * reports the build as done.
     */
    val runCommand: (suspend (String, Long) -> CommandOutcome)? = null
)

data class AgentToolResult(
    val output: String,
    val success: Boolean = true,
    /** Set by mutating tools: the change waits for user approval. */
    val proposal: PendingChange? = null
)

/**
 * A capability the model can invoke.
 *
 * Tools are split into read-only and mutating. Read-only tools run
 * immediately; mutating tools never touch storage themselves, they only
 * produce a [PendingChange] that the user reviews in the diff viewer.
 */
interface AgentTool {
    val name: String
    val description: String
    /** Human readable argument list injected into the system prompt. */
    val usage: String
    val mutating: Boolean get() = false

    suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult
}

internal fun JsonObject.string(key: String): String? =
    this[key]?.let { runCatching { it.jsonPrimitive.content }.getOrNull() }?.takeIf { it.isNotBlank() }

internal fun JsonObject.stringOrEmpty(key: String): String =
    this[key]?.let { runCatching { it.jsonPrimitive.content }.getOrNull() }.orEmpty()

internal fun JsonObject.int(key: String, fallback: Int): Int =
    this[key]?.let { runCatching { it.jsonPrimitive.content.toInt() }.getOrNull() } ?: fallback
