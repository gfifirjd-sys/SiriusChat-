package com.sirius.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.locale.ProvideAppLanguage
import com.sirius.chat.core.ui.LocalAppContainer
import com.sirius.chat.feature.chat.components.LocalGeneratedImageStore
import com.sirius.chat.domain.model.AppSettings

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val container = (application as SiriusApplication).container

        // Keep the splash up only until the first settings emission is ready,
        // which avoids a theme flash without adding a fixed artificial delay.
        var settingsLoaded = false
        splash.setKeepOnScreenCondition { !settingsLoaded }

        setContent {
            val settings: AppSettings? by container.settingsRepository.settings
                .collectAsStateWithLifecycle(initialValue = null)
            val loaded = settings

            if (loaded != null) {
                SideEffect { settingsLoaded = true }
                CompositionLocalProvider(
                    LocalAppContainer provides container,
                    // Needed by the markdown renderer deep inside the transcript.
                    // See LocalGeneratedImageStore for why it is ambient rather
                    // than threaded through four layers of composable.
                    LocalGeneratedImageStore provides container.generatedImages
                ) {
                    // Language wraps the theme so every screen below, including
                    // dialogs and sheets, reads strings in the chosen locale.
                    ProvideAppLanguage(language = loaded.language) {
                        SiriusTheme(
                            themeMode = loaded.themeMode,
                            accentColor = loaded.accentColor,
                            glassLevel = loaded.glassLevel,
                            reduceMotion = loaded.reduceMotion
                        ) {
                            SiriusApp(startWithOnboarding = !loaded.onboardingDone)
                        }
                    }
                }
            }
        }
    }
}
