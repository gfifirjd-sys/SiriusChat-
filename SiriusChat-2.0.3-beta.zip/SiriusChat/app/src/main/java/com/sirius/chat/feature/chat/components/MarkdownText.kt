package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.effects.LiquidMetalPreset
import com.sirius.chat.core.designsystem.effects.SiriusHairline
import com.sirius.chat.core.designsystem.effects.liquidMetalFill
import com.sirius.chat.core.designsystem.effects.metalBevelBrush
import com.sirius.chat.core.util.ColumnAlign
import com.sirius.chat.core.util.MarkdownBlock
import com.sirius.chat.core.util.MarkdownParser
import com.sirius.chat.core.util.ProgressRow
import com.sirius.chat.core.util.TreeLine

/**
 * Renders assistant markdown. Parsing is memoised on the raw text, so a
 * streaming answer only re-parses when new tokens actually arrive.
 *
 * The block vocabulary is wider than a chat app normally needs because Sirius is
 * used to build software: tables carry design tokens and comparisons, `$$…$$`
 * carries the maths behind a contrast ratio, ```tree shows a project layout and
 * ```progress shows how far something got. Anything not recognised degrades to a
 * paragraph rather than disappearing.
 */
@Composable
fun MarkdownText(
    markdown: String,
    modifier: Modifier = Modifier,
    baseStyle: TextStyle = MaterialTheme.typography.bodyMedium,
    codeFontSize: Int = 13
) {
    val colors = SiriusTheme.colors
    val blocks = remember(markdown) { MarkdownParser.parse(markdown) }

    Column(modifier = modifier.fillMaxWidth()) {
        blocks.forEachIndexed { index, block ->
            if (index > 0) Spacer(Modifier.height(SiriusSpacing.xs))
            when (block) {
                is MarkdownBlock.Paragraph -> ParagraphWithMath(
                    text = block.text,
                    baseStyle = baseStyle
                )

                is MarkdownBlock.Heading -> Text(
                    text = block.text,
                    style = baseStyle.copy(
                        fontSize = when (block.level) {
                            1 -> 20.sp
                            2 -> 18.sp
                            else -> 16.sp
                        },
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = colors.textPrimary
                )

                is MarkdownBlock.Code -> CodeBlockView(
                    code = block.code,
                    language = block.language,
                    tag = block.tag,
                    fontSize = codeFontSize
                )

                is MarkdownBlock.ListBlock -> Column {
                    block.items.forEachIndexed { itemIndex, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    start = (item.depth * 16).dp,
                                    top = 2.dp,
                                    bottom = 2.dp
                                )
                        ) {
                            when {
                                item.checked != null -> TaskMark(checked = item.checked)
                                // Per item, not per block: markdown nests ordered
                                // lists inside unordered ones and vice versa.
                                item.ordinal != null || block.ordered -> Text(
                                    text = "${item.ordinal ?: (itemIndex + 1)}.",
                                    style = baseStyle,
                                    color = colors.textTertiary
                                )
                                // Bullet shape tracks depth, the way a printed
                                // outline does, so nesting survives a screenshot.
                                else -> Text(
                                    text = when (item.depth) {
                                        0 -> "\u2022"
                                        1 -> "\u25E6"
                                        else -> "\u25AA"
                                    },
                                    style = baseStyle,
                                    color = colors.textTertiary
                                )
                            }
                            Spacer(Modifier.width(SiriusSpacing.xs))
                            RichText(
                                text = item.text,
                                style = baseStyle,
                                color = if (item.checked == true) colors.textTertiary else colors.textPrimary,
                                strikethrough = item.checked == true
                            )
                        }
                    }
                }

                is MarkdownBlock.Quote -> Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        // Min intrinsic height is what lets the accent bar match
                        // the text beside it instead of collapsing to nothing.
                        .height(IntrinsicSize.Min)
                        .clip(RoundedCornerShape(SiriusRadius.sm))
                        .background(colors.surfaceMuted)
                ) {
                    // The bar does the work a background tint cannot: it marks
                    // the quote without dimming the text inside it.
                    Spacer(
                        Modifier
                            .width(3.dp)
                            .fillMaxHeight()
                            .background(colors.accent)
                    )
                    RichText(
                        text = block.text,
                        style = baseStyle,
                        color = colors.textSecondary,
                        modifier = Modifier.padding(SiriusSpacing.sm)
                    )
                }

                is MarkdownBlock.Table -> MarkdownTable(
                    header = block.header,
                    rows = block.rows,
                    aligns = block.aligns,
                    baseStyle = baseStyle
                )

                is MarkdownBlock.Math -> MathView(
                    latex = block.latex,
                    modifier = Modifier.fillMaxWidth(),
                    baseStyle = baseStyle
                )

                is MarkdownBlock.Progress -> Column(
                    verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
                ) {
                    block.rows.forEach { row -> ProgressBar(row = row, baseStyle = baseStyle) }
                }

                is MarkdownBlock.Tree -> TreeBlock(lines = block.lines, fontSize = codeFontSize)

                is MarkdownBlock.Image -> GeneratedImageView(
                    alt = block.alt,
                    uri = block.uri,
                    store = LocalGeneratedImageStore.current
                )

                MarkdownBlock.Divider -> Spacer(
                    Modifier
                        .fillMaxWidth()
                        .height(SiriusHairline)
                        .background(colors.outline)
                )
            }
        }
    }
}

/**
 * A paragraph that may contain `$$…$$` maths mid-sentence.
 *
 * The formula is laid out, not written into the text run, so it cannot flow
 * around the words beside it — each one takes its own line. That is a deliberate
 * trade: a correctly stacked fraction on its own line beats a squashed one
 * inline, and prose-with-formula is rare enough that the extra line costs little.
 */
@Composable
private fun ParagraphWithMath(text: String, baseStyle: TextStyle) {
    val colors = SiriusTheme.colors
    val segments = remember(text) { splitMath(text) }
    if (segments.size == 1 && !segments.first().math) {
        RichText(text = text, style = baseStyle, color = colors.textPrimary)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        segments.forEach { segment ->
            if (segment.math) {
                MathInline(latex = segment.text, baseStyle = baseStyle)
            } else {
                RichText(text = segment.text, style = baseStyle, color = colors.textPrimary)
            }
        }
    }
}

private data class MathSegment(val text: String, val math: Boolean)

private val inlineMathPattern = Regex("\\$\\$(.+?)\\$\\$", RegexOption.DOT_MATCHES_ALL)

private fun splitMath(text: String): List<MathSegment> {
    val matches = inlineMathPattern.findAll(text).toList()
    if (matches.isEmpty()) return listOf(MathSegment(text, false))
    val out = ArrayList<MathSegment>()
    var cursor = 0
    for (match in matches) {
        if (match.range.first > cursor) {
            val before = text.substring(cursor, match.range.first).trim()
            if (before.isNotEmpty()) out += MathSegment(before, false)
        }
        out += MathSegment(match.groupValues[1].trim(), true)
        cursor = match.range.last + 1
    }
    if (cursor < text.length) {
        val tail = text.substring(cursor).trim()
        if (tail.isNotEmpty()) out += MathSegment(tail, false)
    }
    return out
}

/**
 * Inline-markdown text with colour swatches resolved into real chips.
 *
 * Every text-bearing block routes through here so that a colour literal renders
 * identically in a paragraph, a list item and a table cell.
 */
@Composable
private fun RichText(
    text: String,
    style: TextStyle,
    color: Color,
    modifier: Modifier = Modifier,
    textAlign: TextAlign? = null,
    strikethrough: Boolean = false
) {
    val colors = SiriusTheme.colors
    val inline = remember(text, colors.isDark) {
        InlineMarkdown.render(
            text = text,
            codeColor = colors.accent,
            codeBackground = colors.primarySoft,
            linkColor = colors.info
        )
    }
    val swatchShape = RoundedCornerShape(4.dp)
    val inlineContent = remember(inline.swatches, colors.isDark) {
        inline.swatches.associate { (id, swatchColor) ->
            id to InlineTextContent(
                placeholder = Placeholder(
                    width = 16.sp,
                    height = 13.sp,
                    placeholderVerticalAlign = PlaceholderVerticalAlign.TextCenter
                )
            ) {
                Box(
                    modifier = Modifier
                        .size(13.dp)
                        .clip(swatchShape)
                        .background(swatchColor, swatchShape)
                        // Hairline, or a swatch of the page colour would vanish.
                        .border(SiriusHairline, colors.metalRimLight, swatchShape)
                )
            }
        }
    }

    Text(
        text = inline.text,
        style = if (strikethrough) {
            style.copy(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
        } else {
            style
        },
        color = color,
        textAlign = textAlign,
        inlineContent = inlineContent,
        modifier = modifier
    )
}

/** Checkbox for `- [x]` items: a filled mark, not an interactive control. */
@Composable
private fun TaskMark(checked: Boolean) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(4.dp)
    Box(
        modifier = Modifier
            .padding(top = 2.dp)
            .size(15.dp)
            .clip(shape)
            .background(if (checked) colors.accent else Color.Transparent, shape)
            .border(SiriusHairline, metalBevelBrush(colors), shape),
        contentAlignment = Alignment.Center
    ) {
        if (checked) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = null,
                tint = colors.background,
                modifier = Modifier.size(11.dp)
            )
        }
    }
}

/**
 * Markdown table.
 *
 * Columns share the width by weight and cells wrap, rather than scrolling
 * horizontally: on a phone a table you have to drag sideways is a table you do
 * not read. Alignment from the delimiter row is honoured, which matters because
 * numeric columns are usually right-aligned on purpose.
 */
@Composable
private fun MarkdownTable(
    header: List<String>,
    rows: List<List<String>>,
    aligns: List<ColumnAlign>,
    baseStyle: TextStyle
) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.sm)
    val columns = maxOf(header.size, rows.maxOfOrNull { it.size } ?: 0)
    if (columns == 0) return

    fun alignOf(index: Int): TextAlign = when (aligns.getOrNull(index)) {
        ColumnAlign.Center -> TextAlign.Center
        ColumnAlign.End -> TextAlign.End
        else -> TextAlign.Start
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(SiriusHairline, metalBevelBrush(colors), shape)
    ) {
        Row(modifier = Modifier.background(colors.surfaceMuted)) {
            for (column in 0 until columns) {
                RichText(
                    text = header.getOrElse(column) { "" },
                    style = baseStyle.copy(fontWeight = FontWeight.SemiBold, fontSize = 13.sp),
                    color = colors.textSecondary,
                    textAlign = alignOf(column),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xs)
                )
            }
        }
        rows.forEach { row ->
            Spacer(
                Modifier
                    .fillMaxWidth()
                    .height(SiriusHairline)
                    .background(colors.outline)
            )
            Row {
                for (column in 0 until columns) {
                    RichText(
                        text = row.getOrElse(column) { "" },
                        style = baseStyle.copy(fontSize = 13.sp),
                        color = colors.textPrimary,
                        textAlign = alignOf(column),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xs)
                    )
                }
            }
        }
    }
}

/** A ```progress row: label, metal-filled bar, percentage. */
@Composable
private fun ProgressBar(row: ProgressRow, baseStyle: TextStyle) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.pill)
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = row.label,
                style = baseStyle.copy(fontSize = 13.sp),
                color = colors.textSecondary,
                modifier = Modifier.weight(1f)
            )
            if (row.caption.isNotEmpty()) {
                Text(
                    text = row.caption,
                    style = baseStyle.copy(fontSize = 13.sp, fontFamily = FontFamily.Monospace),
                    color = colors.textTertiary
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(shape)
                .background(colors.surfaceMuted, shape)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(row.fraction)
                    .height(6.dp)
                    // The one place a bar of live metal is honest: it is a
                    // quantity, and the shader already means "in progress".
                    .liquidMetalFill(shape = shape, preset = LiquidMetalPreset.Silver)
            )
        }
    }
}

/** A ```tree listing rendered with box-drawing guides. */
@Composable
private fun TreeBlock(lines: List<TreeLine>, fontSize: Int) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.sm)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(colors.codeBackground, shape)
            .border(SiriusHairline, metalBevelBrush(colors), shape)
            .padding(SiriusSpacing.sm)
    ) {
        lines.forEach { line ->
            val prefix = buildString {
                line.ancestorsLast.forEach { last -> append(if (last) "    " else "\u2502   ") }
                if (line.depth > 0) append(if (line.last) "\u2514\u2500\u2500 " else "\u251C\u2500\u2500 ")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = prefix,
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = fontSize.sp
                    ),
                    color = colors.textTertiary
                )
                if (line.directory) {
                    Icon(
                        imageVector = Icons.Rounded.Folder,
                        contentDescription = null,
                        tint = colors.accent,
                        modifier = Modifier.size((fontSize + 1).dp)
                    )
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    text = line.name,
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = fontSize.sp,
                        fontWeight = if (line.directory) FontWeight.Medium else FontWeight.Normal
                    ),
                    color = if (line.directory) colors.textPrimary else colors.textSecondary,
                    // A deep path leaves little room after the indent guides; a
                    // truncated name is readable, a vertically stacked one is not.
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
