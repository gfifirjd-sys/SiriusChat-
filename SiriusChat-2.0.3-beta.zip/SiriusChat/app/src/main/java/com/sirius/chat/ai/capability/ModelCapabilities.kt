package com.sirius.chat.ai.capability

import com.sirius.chat.domain.model.AiModel
import com.sirius.chat.domain.model.FeatureState
import com.sirius.chat.domain.model.FeatureSupport
import com.sirius.chat.domain.model.ProviderConfig
import com.sirius.chat.domain.model.ProviderType
import java.util.Locale

/**
 * Answers "can this provider and model do X" for the chat settings panel.
 *
 * ### Why this is heuristic and not a table
 * The model list is not ours. A user can point a provider at any OpenAI-shaped
 * endpoint, rename it, and paste in model ids we have never seen — the whole
 * point of the provider catalogue is that it is a starting point, not a fixture.
 * A hard-coded allow-list would therefore mark every model added after this
 * build shipped as incapable, which is the worst possible failure mode: the user
 * sees a greyed-out switch and concludes the app is broken rather than out of
 * date.
 *
 * So capabilities are inferred from the model id, which is the one thing that
 * *is* stable — vendors put `vision`, `image`, `-vl`, `omni` in their names
 * precisely so people can tell. Guessing wrong is cheap in one direction and
 * expensive in the other, and that asymmetry decides every default below.
 *
 * ### The asymmetry
 * Guessing a model *has* vision when it does not costs the user a whole turn: a
 * hard 400 from the endpoint, no answer, and tokens already paid for. Guessing a
 * model *lacks* vision when it has it costs a filename instead of a picture —
 * annoying, recoverable, and visible (the panel says so).
 *
 * Vision is therefore opt-in by pattern: unknown means no. Search and image
 * generation are the opposite, because Sirius has a keyless path for both that
 * works regardless of the model, so "unknown" there still has a real answer.
 */
object ModelCapabilities {

    /**
     * Fragments that appear in the id of a model that can read images.
     *
     * Matched as substrings on the lowercased id, so `openai/gpt-4o-mini` from
     * OpenRouter and bare `gpt-4o-mini` both resolve — routed ids are prefixed
     * with a vendor and would miss an equality check.
     */
    private val VISION_MARKERS = listOf(
        // OpenAI: every 4o/4.1/5 and the o-series reasoning models see images.
        "gpt-4o", "gpt-4.1", "gpt-4.5", "gpt-5", "gpt-4-turbo", "gpt-4-vision",
        "o1", "o3", "o4",
        // Anthropic: the whole Claude 3 line onward.
        "claude-3", "claude-4", "claude-sonnet", "claude-opus", "claude-haiku",
        // Google.
        "gemini",
        // xAI.
        "grok-2-vision", "grok-2v", "grok-3", "grok-4",
        // Open weights.
        "llama-3.2", "llama-4", "llava", "pixtral", "qwen-vl", "qwen2-vl",
        "qwen2.5-vl", "qwen3-vl", "internvl", "molmo", "phi-3-vision",
        "phi-3.5-vision", "phi-4-multimodal", "glm-4v", "glm-4.1v", "minicpm-v",
        "idefics", "moondream", "aya-vision", "mistral-medium-3", "mistral-small-3",
        // Generic vendor suffixes.
        "vision", "-vl-", "multimodal", "omni"
    )

    /**
     * Ids that contain a vision marker but are text-only.
     *
     * `o1-mini` and `o3-mini` are the reason this list exists: they match `o1`
     * and `o3` above and genuinely cannot see, so without an exception the app
     * would send them an image block and lose the turn. Checked before the
     * markers, so an exception always wins.
     */
    private val VISION_EXCEPTIONS = listOf(
        "o1-mini", "o1-preview", "o3-mini", "o4-mini-text",
        "gpt-4o-mini-tts", "gpt-4o-mini-audio", "gpt-4o-audio", "gpt-4o-realtime",
        "gemini-embedding", "gemini-1.0-pro", "text-embedding"
    )

    /**
     * Providers that serve `POST /images/generations` on the same base URL and
     * the same key as their chat endpoint.
     *
     * Restricted to endpoints that are known to answer, because the fallback is
     * good: guessing that an arbitrary OpenAI-compatible gateway also does
     * images would trade a working keyless generation for a 404.
     */
    private val OPENAI_IMAGE_PROVIDERS = mapOf(
        "openai" to "gpt-image-1",
        "xai" to "grok-2-image",
        "together" to "black-forest-labs/FLUX.1-schnell-Free",
        "fireworks" to "accounts/fireworks/models/flux-1-schnell-fp8",
        "deepinfra" to "black-forest-labs/FLUX-1-schnell",
        "novita" to "flux-1-schnell",
        "nebius" to "black-forest-labs/flux-schnell",
        "openrouter" to "openai/gpt-image-1"
    )

    /** Host fragments that identify those same endpoints for a renamed provider. */
    private val OPENAI_IMAGE_HOSTS = mapOf(
        "api.openai.com" to "gpt-image-1",
        "api.x.ai" to "grok-2-image",
        "api.together.xyz" to "black-forest-labs/FLUX.1-schnell-Free",
        "api.fireworks.ai" to "accounts/fireworks/models/flux-1-schnell-fp8",
        "api.deepinfra.com" to "black-forest-labs/FLUX-1-schnell",
        "api.novita.ai" to "flux-1-schnell",
        "api.studio.nebius.com" to "black-forest-labs/flux-schnell",
        "openrouter.ai" to "openai/gpt-image-1"
    )

    /** Keyless engine names, shown in the panel so the user knows what ran. */
    const val BUILTIN_SEARCH = "DuckDuckGo"
    const val BUILTIN_IMAGE = "Pollinations"

    /**
     * Resolve everything the settings panel needs.
     *
     * @param provider the endpoint the session is pointed at, or `null` while the
     *   provider list is still loading.
     * @param modelId the session's model, which may not be in [ProviderConfig.models]
     *   at all — the user can type one the catalogue never listed.
     */
    fun of(provider: ProviderConfig?, modelId: String): FeatureSupport {
        if (provider == null) return FeatureSupport.Unknown
        val model = provider.models.firstOrNull { it.id == modelId }
        val id = modelId.lowercase(Locale.ROOT)

        return FeatureSupport(
            webSearch = webSearch(provider, id),
            imageGeneration = imageGeneration(provider, id),
            vision = vision(id),
            tools = tools(model),
            streaming = streaming(model)
        )
    }

    /**
     * Search.
     *
     * Native for the two endpoints where searching is part of the chat call
     * itself: Perplexity's Sonar models *are* a search engine with a language
     * model attached, and xAI takes a `search_parameters` block on the same
     * request. In both cases the model reasons over live results directly, which
     * beats anything Sirius can paste into a prompt.
     *
     * Everything else gets the keyless path, which is always available — so this
     * switch is never disabled. That is correct: the phone has internet whether
     * or not the model's vendor sells search.
     */
    private fun webSearch(provider: ProviderConfig, id: String): FeatureState {
        val host = provider.baseUrl.lowercase(Locale.ROOT)
        val perplexity = provider.id == "perplexity" || host.contains("api.perplexity.ai")
        if (perplexity && provider.hasKey && id.startsWith("sonar")) {
            return FeatureState.native("Perplexity Sonar")
        }
        val xai = provider.id == "xai" || host.contains("api.x.ai")
        if (xai && provider.hasKey && id.startsWith("grok")) {
            return FeatureState.native("Grok Live Search")
        }
        return FeatureState.builtin(BUILTIN_SEARCH)
    }

    /**
     * Image generation.
     *
     * Native when the session's own endpoint sells images and a key is stored —
     * the user gets the quality they are already paying for, and no third party
     * sees their prompt. Falling back to keyless whenever that is not true is
     * what keeps the switch enabled on a DeepSeek or Ollama session, where the
     * chat model will never draw anything but the *feature* still works.
     */
    private fun imageGeneration(provider: ProviderConfig, id: String): FeatureState {
        // Gemini draws through its own generateContent surface rather than an
        // OpenAI-shaped images route, so it is matched on the model id.
        val gemini = provider.id == "google-gemini" ||
            provider.baseUrl.contains("generativelanguage.googleapis.com")
        if (gemini && provider.hasKey) {
            return FeatureState.native(if (id.contains("image")) id else "Imagen 4")
        }
        if (provider.type == ProviderType.OpenAiCompatible && provider.hasKey) {
            nativeImageModel(provider)?.let { return FeatureState.native(it) }
        }
        return FeatureState.builtin(BUILTIN_IMAGE)
    }

    /**
     * The image model to ask this provider for, or `null` if it serves none.
     *
     * Public because the generation service needs the same answer and must not
     * re-derive it: two copies of this mapping would drift, and the drift would
     * show up as the panel promising `gpt-image-1` while the request asked for
     * something else.
     */
    fun nativeImageModel(provider: ProviderConfig): String? {
        OPENAI_IMAGE_PROVIDERS[provider.id]?.let { return it }
        val host = provider.baseUrl.lowercase(Locale.ROOT)
        return OPENAI_IMAGE_HOSTS.entries.firstOrNull { host.contains(it.key) }?.value
    }

    /** True when this provider draws through Gemini's `generateContent`. */
    fun isGeminiImageProvider(provider: ProviderConfig): Boolean =
        provider.id == "google-gemini" ||
            provider.baseUrl.contains("generativelanguage.googleapis.com")

    /**
     * Vision, the one genuinely model-bound switch.
     *
     * Unknown means unsupported here, for the reason in the class doc: the cost
     * of a false positive is a failed turn, and the cost of a false negative is
     * a filename instead of a picture.
     */
    private fun vision(id: String): FeatureState = when {
        VISION_EXCEPTIONS.any { id.contains(it) } ->
            FeatureState.unsupported("vision")
        VISION_MARKERS.any { id.contains(it) } ->
            FeatureState.native("")
        else -> FeatureState.unsupported("vision")
    }

    /**
     * Tools.
     *
     * Sirius drives its agent with a fenced text block rather than vendor
     * function calling, so this is about instruction-following, not about an API
     * field. That is why the default is yes for anything not explicitly marked
     * otherwise — even a small local model can emit the block, and the ones that
     * cannot simply produce no calls, which the engine already handles.
     */
    private fun tools(model: AiModel?): FeatureState =
        if (model == null || model.supportsTools) {
            FeatureState.native("")
        } else {
            FeatureState.unsupported("tools")
        }

    private fun streaming(model: AiModel?): FeatureState =
        if (model == null || model.supportsStreaming) {
            FeatureState.native("")
        } else {
            FeatureState.unsupported("streaming")
        }
}
