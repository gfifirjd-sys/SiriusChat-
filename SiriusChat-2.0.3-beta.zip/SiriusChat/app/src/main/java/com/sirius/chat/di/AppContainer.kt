package com.sirius.chat.di

import android.content.Context
import com.sirius.chat.ai.agent.AgentEngine
import com.sirius.chat.ai.agent.GenerationManager
import com.sirius.chat.ai.agent.tools.gitHubTools
import com.sirius.chat.ai.agent.tools.imageTools
import com.sirius.chat.ai.agent.tools.webTools
import com.sirius.chat.data.image.GeneratedImageStore
import com.sirius.chat.data.image.ImageGenerationService
import com.sirius.chat.data.web.WebSearchService
import com.sirius.chat.ai.context.ProjectContextBuilder
import com.sirius.chat.ai.context.AttachmentPromptBuilder
import com.sirius.chat.data.attachment.AttachmentReader
import com.sirius.chat.ai.provider.ProviderFactory
import com.sirius.chat.core.common.AppDispatchers
import com.sirius.chat.core.locale.StringProvider
import com.sirius.chat.data.local.db.SiriusDatabase
import com.sirius.chat.data.local.preferences.ProviderDataStore
import com.sirius.chat.data.local.preferences.SettingsDataStore
import com.sirius.chat.data.git.JGitRepository
import com.sirius.chat.data.github.GitHubAccountStore
import com.sirius.chat.data.github.GitHubService
import com.sirius.chat.data.git.WorkspacePathResolver
import com.sirius.chat.data.local.security.SecureCredentialStore
import com.sirius.chat.data.repository.ChangeStore
import com.sirius.chat.data.repository.ChatRepositoryImpl
import com.sirius.chat.data.repository.EditorSessionStore
import com.sirius.chat.data.repository.ProjectRepositoryImpl
import com.sirius.chat.data.repository.ProviderRepositoryImpl
import com.sirius.chat.data.repository.SettingsRepositoryImpl
import com.sirius.chat.data.repository.TerminalSessionStore
import com.sirius.chat.data.repository.WorkspaceRepositoryImpl
import com.sirius.chat.data.terminal.LocalShellBackend
import com.sirius.chat.data.terminal.TerminalBackend
import com.sirius.chat.data.terminal.TermuxShellBackend
import com.sirius.chat.domain.model.TerminalEngine
import com.sirius.chat.domain.repository.ChatRepository
import com.sirius.chat.domain.repository.GitRepository
import com.sirius.chat.domain.repository.ProjectRepository
import com.sirius.chat.domain.repository.ProviderRepository
import com.sirius.chat.domain.repository.SettingsRepository
import com.sirius.chat.domain.repository.WorkspaceRepository
import com.sirius.chat.domain.usecase.ApplyChangesUseCase
import com.sirius.chat.domain.usecase.AttachWorkspaceUseCase
import com.sirius.chat.domain.usecase.BuildPromptUseCase
import com.sirius.chat.domain.usecase.CreateProjectUseCase
import com.sirius.chat.domain.usecase.CreateSessionUseCase
import com.sirius.chat.domain.usecase.DeleteProjectUseCase
import com.sirius.chat.domain.usecase.DeriveSessionTitleUseCase
import com.sirius.chat.domain.usecase.RewindConversationUseCase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first

/**
 * Manual dependency container.
 *
 * A DI framework would add annotation processing to every build; on-device
 * builds in AndroidIDE are slow enough already, and the graph here is small
 * and explicit. Everything is lazy, so app startup only pays for what the
 * first screen touches.
 */
class AppContainer(context: Context) {

    /** Public so a Service can reach the container without a DI framework. */
    val appContext: Context = context.applicationContext

    val dispatchers = AppDispatchers()

    /** Lives as long as the process; only used for app-wide observers. */
    /**
     * Lives as long as the process, not as long as a screen.
     *
     * Work that must survive a ViewModel being cleared — persisting a finished
     * answer, above all — belongs here. A `viewModelScope` write is cancelled the
     * moment the user presses Back, and a cancelled write loses the message.
     */
    val appScope = CoroutineScope(SupervisorJob() + dispatchers.default)

    private val database: SiriusDatabase by lazy { SiriusDatabase.build(appContext) }

    val settingsRepository: SettingsRepository by lazy {
        SettingsRepositoryImpl(SettingsDataStore(appContext))
    }

    /** Locale-aware resource lookup for strings produced outside composition. */
    val strings: StringProvider by lazy {
        StringProvider(appContext, settingsRepository.settings, appScope)
    }

    val providerRepository: ProviderRepository by lazy {
        ProviderRepositoryImpl(ProviderDataStore(appContext), SecureCredentialStore(appContext))
    }

    val projectRepository: ProjectRepository by lazy {
        ProjectRepositoryImpl(database.projectDao(), dispatchers)
    }

    val chatRepository: ChatRepository by lazy {
        ChatRepositoryImpl(database.chatDao(), dispatchers)
    }

    val workspaceRepository: WorkspaceRepository by lazy {
        WorkspaceRepositoryImpl(appContext, dispatchers)
    }

    /**
     * Git is the one feature that needs a real filesystem path instead of SAF,
     * so it gets its own resolver rather than going through the workspace.
     */
    val workspacePathResolver: WorkspacePathResolver by lazy { WorkspacePathResolver(appContext) }

    val gitRepository: GitRepository by lazy {
        JGitRepository(workspacePathResolver, dispatchers)
    }

    // ---------------------------------------------------------------- GitHub

    /** Token + profile of the connected account, in its own encrypted store. */
    val githubAccounts: GitHubAccountStore by lazy { GitHubAccountStore(appContext) }

    val github: GitHubService by lazy { GitHubService(githubAccounts, dispatchers) }

    val webSearch: WebSearchService by lazy { WebSearchService(dispatchers) }

    val generatedImages: GeneratedImageStore by lazy {
        GeneratedImageStore(appContext, dispatchers)
    }

    val imageGeneration: ImageGenerationService by lazy {
        ImageGenerationService(providerRepository, dispatchers, generatedImages)
    }

    val providerFactory: ProviderFactory by lazy { ProviderFactory(providerRepository) }

    /**
     * Every running generation in the app, owned here rather than by a screen.
     *
     * It takes `this` back: the manager needs repositories, the agent engine and
     * the prompt builder, and all of them are lazy, so there is no cycle at
     * construction time -- only when the first generation starts, by which point
     * the container is fully usable.
     */
    val generations: GenerationManager by lazy { GenerationManager(this, appScope) }

    /**
     * Workspace tools plus the GitHub set.
     *
     * The GitHub tools are registered even with no account connected: they answer
     * "connect an account in Settings > GitHub", which the model can relay. A model
     * with no GitHub tools at all instead insists the feature does not exist.
     */
    val agentEngine: AgentEngine by lazy {
        AgentEngine(
            // The registry is the union of everything the app can do. Which of
            // these a given run may actually call is decided per session by the
            // chat's feature switches -- see AgentEngine.activeTools -- so the
            // web and image tools are registered unconditionally here even
            // though most conversations will never be offered them.
            AgentEngine.defaultTools() + webTools(webSearch) + imageTools(imageGeneration) + gitHubTools(
                github = github,
                settings = settingsRepository,
                accountLogin = { githubAccounts.account.first()?.login }
            )
        )
    }
    val projectContextBuilder: ProjectContextBuilder by lazy { ProjectContextBuilder(workspaceRepository) }

    val attachmentReader: AttachmentReader by lazy { AttachmentReader(appContext) }

    val attachmentPromptBuilder: AttachmentPromptBuilder by lazy {
        AttachmentPromptBuilder(attachmentReader, workspaceRepository)
    }

    val changeStore = ChangeStore()
    val editorSessionStore = EditorSessionStore()
    val terminalSessionStore = TerminalSessionStore()

    /**
     * Both engines are kept alive so switching back and forth does not lose the
     * process a backend is holding, and so availability checks (package lookup,
     * permission state) stay on one instance.
     */
    val localShellBackend: LocalShellBackend by lazy { LocalShellBackend() }
    val termuxBackend: TermuxShellBackend by lazy { TermuxShellBackend(appContext) }

    fun terminalBackend(engine: TerminalEngine): TerminalBackend = when (engine) {
        TerminalEngine.DeviceShell -> localShellBackend
        TerminalEngine.Termux -> termuxBackend
    }

    // ------------------------------------------------------------ use cases

    val createSession by lazy { CreateSessionUseCase(chatRepository) }
    val deriveSessionTitle = DeriveSessionTitleUseCase()
    val rewindConversation by lazy { RewindConversationUseCase(chatRepository) }
    val buildPrompt = BuildPromptUseCase()
    val createProject by lazy { CreateProjectUseCase(projectRepository, workspaceRepository) }
    val attachWorkspace by lazy { AttachWorkspaceUseCase(projectRepository, workspaceRepository) }
    val deleteProject by lazy { DeleteProjectUseCase(projectRepository, workspaceRepository) }
    val applyChanges by lazy { ApplyChangesUseCase(workspaceRepository) }

    /** Scratch directory used as the terminal home. */
    val terminalHome: java.io.File by lazy {
        java.io.File(appContext.filesDir, "terminal").apply { mkdirs() }
    }
}
