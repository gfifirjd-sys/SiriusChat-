package com.sirius.chat.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.sirius.chat.data.local.db.dao.ChatDao
import com.sirius.chat.data.local.db.dao.ProjectDao
import com.sirius.chat.data.local.db.entity.ChatMessageEntity
import com.sirius.chat.data.local.db.entity.ChatSessionEntity
import com.sirius.chat.data.local.db.entity.ProjectEntity
import com.sirius.chat.data.local.db.entity.RecentFileEntity

@Database(
    entities = [
        ProjectEntity::class,
        RecentFileEntity::class,
        ChatSessionEntity::class,
        ChatMessageEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class SiriusDatabase : RoomDatabase() {

    abstract fun projectDao(): ProjectDao
    abstract fun chatDao(): ChatDao

    companion object {

        /**
         * Adds the per-chat feature switches.
         *
         * ### Why this is a real migration
         * The builder below still falls back to destroying the database, and for
         * v1 that was defensible: the schema was new and nobody had months of
         * conversations in it. It is not defensible now. Bumping to 2 without
         * this migration would silently delete every chat on the device the first
         * time the user opened the updated app -- to add a settings panel. That
         * is the single worst possible trade in this codebase.
         *
         * One `ALTER TABLE` is all it takes, which is precisely why the flags are
         * packed into one column rather than five.
         *
         * `DEFAULT -1` matches [ChatSessionEntity.INHERIT_FEATURES], so every
         * pre-existing conversation reads as "follow the user's defaults" instead
         * of "the user switched everything off".
         */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE chat_sessions ADD COLUMN featureFlags INTEGER NOT NULL DEFAULT -1"
                )
            }
        }

        fun build(context: Context): SiriusDatabase = Room
            .databaseBuilder(context.applicationContext, SiriusDatabase::class.java, "sirius.db")
            .addMigrations(MIGRATION_1_2)
            // Kept as the last resort for a database from a build that never
            // shipped, but it is now unreachable for any released version --
            // every step from 1 has a migration above.
            .fallbackToDestructiveMigration()
            .build()
    }
}
