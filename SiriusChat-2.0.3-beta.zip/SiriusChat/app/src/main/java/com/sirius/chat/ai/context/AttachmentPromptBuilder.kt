package com.sirius.chat.ai.context

import com.sirius.chat.ai.model.AiContentPart
import com.sirius.chat.core.util.Formatters
import com.sirius.chat.data.attachment.AttachmentPayload
import com.sirius.chat.data.attachment.AttachmentReader
import com.sirius.chat.domain.model.AttachmentKind
import com.sirius.chat.domain.model.ChatMessage
import com.sirius.chat.domain.model.MessageAttachment
import com.sirius.chat.domain.model.MessageRole
import com.sirius.chat.domain.repository.WorkspaceRepository

/**
 * Turns messages with attachments into ordered content blocks.
 *
 * Two problems are solved here, and they pull in opposite directions.
 *
 * **Order.** Files are emitted at the caret position they were attached at, so
 * "compare this screenshot with this log" produces text, image, text, document —
 * the sequence the user typed. Dumping attachments at the end of the message, as
 * the previous implementation did, leaves the model guessing which file each
 * sentence refers to as soon as there is more than one.
 *
 * **Budget.** A conversation with fifteen screenshots and three logs cannot be
 * sent whole. Messages are therefore walked newest first and charged against
 * shared budgets; once a budget is gone, older attachments degrade to a one-line
 * description instead of being dropped silently. The model is told what was left
 * out, because "here is the file" followed by nothing is worse than "this file
 * was omitted": one produces a confident answer about content it never saw, the
 * other produces a request for it.
 */
class AttachmentPromptBuilder(
    private val reader: AttachmentReader,
    private val workspace: WorkspaceRepository
) {

    /**
     * Content blocks per message id, for every message that needs them.
     *
     * Messages without attachments are absent from the result: their provider
     * representation is still the plain string, so nothing else has to change.
     */
    suspend fun build(
        treeUri: String?,
        messages: List<ChatMessage>,
        /**
         * Whether the model can actually look at pixels.
         *
         * When false, images are described instead of sent. This is the one place
         * the vision switch has any effect, and it has to be here rather than in
         * the provider: by the time a request reaches the wire an image block is
         * already committed, and an endpoint that cannot read one answers with a
         * 400 that loses the entire turn -- the user's message, the attachment and
         * the tokens already spent on the prompt.
         *
         * Describing the file is a genuinely worse answer. It is also an answer.
         */
        vision: Boolean = true
    ): Map<String, List<AiContentPart>> {
        val budget = Budget()
        val built = LinkedHashMap<String, List<AiContentPart>>()
        // Newest first: the attachment the user just sent is the one the next
        // answer is about, so it gets the budget before a screenshot from twenty
        // turns ago.
        messages.asReversed().forEach { message ->
            if (message.role != MessageRole.User) return@forEach
            if (message.attachments.isEmpty()) return@forEach
            built[message.id] = parts(treeUri, message, budget, vision)
        }
        return built
    }

    private suspend fun parts(
        treeUri: String?,
        message: ChatMessage,
        budget: Budget,
        vision: Boolean
    ): List<AiContentPart> {
        val text = message.content
        val blocks = mutableListOf<AiContentPart>()
        var cursor = 0

        // Sorted by anchor, and ties keep their insertion order.
        message.attachments.sortedBy { it.anchor }.forEach { attachment ->
            val anchor = attachment.anchor.coerceIn(0, text.length)
            if (anchor > cursor) {
                blocks.addText(text.substring(cursor, anchor))
                cursor = anchor
            }
            blocks += render(treeUri, attachment, budget, vision)
        }
        if (cursor < text.length) blocks.addText(text.substring(cursor))
        return blocks
    }

    private suspend fun render(
        treeUri: String?,
        attachment: MessageAttachment,
        budget: Budget,
        vision: Boolean
    ): List<AiContentPart> {
        val label = "${attachment.name}" +
            attachment.sizeBytes.takeIf { it > 0 }?.let { ", ${Formatters.fileSize(it)}" }.orEmpty()

        return when (attachment.kind) {
            AttachmentKind.WorkspaceFile -> listOf(
                AiContentPart.Text(workspaceBlock(treeUri, attachment, budget))
            )

            AttachmentKind.Image -> {
                if (!vision) {
                    // Named and sized, not silently dropped. The model needs to
                    // know an image exists so it can say "I cannot see images on
                    // this model" instead of answering as if the user sent
                    // nothing -- which is how a vision-off session produces
                    // confidently wrong answers about a screenshot.
                    listOf(
                        note(
                            "Attached image ($label) — this model cannot read images, " +
                                "so it was not sent. Tell the user to switch on Vision in " +
                                "the chat settings, or to pick a model that supports it."
                        )
                    )
                } else if (!budget.takeImage()) {
                    listOf(note("Attached image ($label) — omitted: too many images in this conversation to send them all. Ask the user to resend it if you need to look at it."))
                } else {
                    when (val payload = reader.payload(attachment, budget.textChars)) {
                        is AttachmentPayload.Binary -> listOf(
                            // The label goes before the image, not after: the model
                            // reads blocks in order, and a name that arrives after
                            // the pixels cannot be used to refer back to them.
                            note("Attached image ($label):"),
                            AiContentPart.Image(payload.base64, payload.mediaType)
                        )
                        is AttachmentPayload.Unavailable -> listOf(
                            note("Attached image ($label) — not available: ${payload.reason}.")
                        )
                        is AttachmentPayload.Text -> listOf(note("Attached image ($label)."))
                    }
                }
            }

            AttachmentKind.Document -> {
                when (val payload = reader.payload(attachment, budget.textChars)) {
                    is AttachmentPayload.Binary -> {
                        if (!budget.takeDocument()) {
                            listOf(note("Attached document ($label) — omitted to stay inside the context budget."))
                        } else {
                            listOf(
                                note("Attached document ($label):"),
                                AiContentPart.Document(payload.base64, payload.mediaType, attachment.name)
                            )
                        }
                    }
                    is AttachmentPayload.Unavailable -> listOf(
                        note("Attached document ($label) — not available: ${payload.reason}.")
                    )
                    is AttachmentPayload.Text -> listOf(note(payload.text))
                }
            }

            AttachmentKind.TextFile -> {
                if (budget.textChars <= 0) {
                    listOf(note("Attached file ($label) — content omitted: the conversation is already at its file-content budget."))
                } else {
                    when (val payload = reader.payload(attachment, budget.textChars)) {
                        is AttachmentPayload.Text -> {
                            budget.spendText(payload.text.length)
                            listOf(note(fenced(attachment, label, payload.text, payload.omittedChars)))
                        }
                        is AttachmentPayload.Unavailable -> listOf(
                            note("Attached file ($label) — not available: ${payload.reason}.")
                        )
                        is AttachmentPayload.Binary -> listOf(
                            note("Attached file ($label) — binary, content not available to the model.")
                        )
                    }
                }
            }

            AttachmentKind.Opaque -> listOf(
                note(
                    "Attached file ($label, ${attachment.mimeType ?: "unknown type"}) — the file " +
                        "is attached but its content cannot be shown to you. Answer from its name " +
                        "and type, or ask the user for the part you need as text."
                )
            )
        }
    }

    /** Project files keep going through the workspace tree, as before. */
    private suspend fun workspaceBlock(
        treeUri: String?,
        attachment: MessageAttachment,
        budget: Budget
    ): String {
        if (treeUri == null) {
            return "Attached project file (${attachment.name}) — no project is open, content unavailable."
        }
        val text = runCatching {
            workspace.readText(treeUri, attachment.uri, maxBytes = WORKSPACE_MAX_BYTES)
        }.getOrElse {
            return "Attached project file (${attachment.name}) — could not be read: ${it.message}."
        }
        val allowed = budget.textChars
        val clipped = if (text.length > allowed) text.take(allowed) else text
        budget.spendText(clipped.length)
        return fenced(attachment, attachment.name, clipped, text.length - clipped.length)
    }

    private fun fenced(
        attachment: MessageAttachment,
        label: String,
        content: String,
        omitted: Int
    ): String = buildString {
        appendLine("Attached file ($label):")
        appendLine("```${attachment.language ?: attachment.name.substringAfterLast('.', "")}")
        append(content)
        if (!content.endsWith("\n")) appendLine()
        appendLine("```")
        if (omitted > 0) {
            append(
                "[Only the first ${content.length} characters of ${attachment.name} are shown; " +
                    "$omitted characters were omitted. Say so if you need the rest.]"
            )
        }
    }.trimEnd()

    private fun note(text: String) = AiContentPart.Text(text)

    /**
     * Adds text, merging with the previous block when it is also text.
     *
     * Two adjacent text blocks are legal but pointless, and they make the request
     * harder to read when debugging what the model was actually sent.
     */
    private fun MutableList<AiContentPart>.addText(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        val last = lastOrNull()
        if (last is AiContentPart.Text) {
            this[lastIndex] = AiContentPart.Text(last.text + "\n\n" + text)
        } else {
            add(AiContentPart.Text(text))
        }
    }

    /** Shared allowance for one request. */
    private class Budget(
        var images: Int = MAX_IMAGES,
        var documents: Int = MAX_DOCUMENTS,
        var textChars: Int = MAX_TEXT_CHARS
    ) {
        fun takeImage(): Boolean = if (images > 0) { images--; true } else false

        fun takeDocument(): Boolean = if (documents > 0) { documents--; true } else false

        fun spendText(chars: Int) {
            textChars = (textChars - chars).coerceAtLeast(0)
        }
    }

    private companion object {
        /** Images per request, newest first. Each one costs well over a thousand tokens. */
        const val MAX_IMAGES = 6

        const val MAX_DOCUMENTS = 3

        /** Total characters of inlined file content per request. */
        const val MAX_TEXT_CHARS = 200_000

        const val WORKSPACE_MAX_BYTES = 1L * 1024 * 1024
    }
}
