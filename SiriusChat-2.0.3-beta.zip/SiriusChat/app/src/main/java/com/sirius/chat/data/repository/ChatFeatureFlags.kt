package com.sirius.chat.data.repository

import com.sirius.chat.data.local.db.entity.ChatSessionEntity
import com.sirius.chat.domain.model.ChatFeature
import com.sirius.chat.domain.model.ChatFeatures

/**
 * Packs [ChatFeatures] into the single integer column on `chat_sessions`.
 *
 * The whole reason this is its own object is that a bitmask is exactly the kind
 * of thing that rots when it is inlined: someone reorders [ChatFeature], every
 * stored session silently changes meaning, and a user's chat quietly loses its
 * internet switch. Keeping the encoding in one place means the ordering contract
 * can be stated once, here, and tested here.
 *
 * ### The ordering contract
 * A feature's bit is its **declaration index** in [ChatFeature]. That is a real
 * constraint on that enum: new features must be appended, never inserted, and
 * an obsolete one must be left in place (or its ordinal deliberately retired)
 * rather than deleted. `ordinal` is used instead of a hand-written map because
 * the alternative is a second list to keep in sync with the first, and a
 * forgotten entry there fails silently rather than loudly.
 *
 * ### Unknown bits
 * Bits beyond what this build knows about are ignored on read and dropped on
 * write. That is the correct behaviour for a downgrade: an older build that
 * cannot honour a newer switch should not pretend to, and it should not preserve
 * a flag it might mis-set either.
 */
object ChatFeatureFlags {

    /**
     * The stored integer for [features], or [ChatSessionEntity.INHERIT_FEATURES]
     * when there is nothing to store.
     */
    fun encode(features: ChatFeatures?): Int {
        if (features == null) return ChatSessionEntity.INHERIT_FEATURES
        var flags = 0
        for (feature in ChatFeature.entries) {
            if (features[feature]) flags = flags or (1 shl feature.ordinal)
        }
        // A session with every switch off encodes to 0, which is a perfectly
        // valid stored value and must stay distinguishable from the -1 sentinel.
        return flags
    }

    /**
     * The switches for a stored value, or `null` when the session should follow
     * the user's defaults.
     *
     * Any negative value counts as "inherit", not just `-1`: a corrupted or
     * hand-edited row should degrade to the defaults rather than decode into a
     * nonsense combination via two's-complement bits.
     */
    fun decode(flags: Int): ChatFeatures? {
        if (flags < 0) return null
        var features = ChatFeatures()
        for (feature in ChatFeature.entries) {
            features = features.with(feature, flags and (1 shl feature.ordinal) != 0)
        }
        return features
    }
}
