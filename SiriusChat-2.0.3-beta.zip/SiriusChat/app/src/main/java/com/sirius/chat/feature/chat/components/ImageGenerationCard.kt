package com.sirius.chat.feature.chat.components

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import kotlin.math.cos
import kotlin.math.sin

/**
 * The "drawing your picture" placeholder, after `aicss.dev/components/image-generation`.
 *
 * ### What is actually being reproduced
 * The reference is not a spinner in a box. It is a dotted canvas — a fine grid
 * of 0.7px dots at 22% opacity — with a second, brighter copy of the same grid
 * on top, revealed only through two soft moving blobs. The dots never move; the
 * *light over them* does. That is the entire trick, and it is why it reads as a
 * surface being developed rather than as a loading animation: the texture is
 * static and stable, so the eye tracks the light instead.
 *
 * Two consequences shape the implementation:
 *
 *  - the grid must be drawn, not tiled from an image, because it has to stay
 *    pixel-exact at any card size;
 *  - the highlight must be a *mask over a brighter grid*, not a glow drawn on
 *    top. A glow lightens the gaps between dots as much as the dots themselves
 *    and immediately looks like a flashlight on paper.
 *
 * ### Why a real 1:1 box and not a thin bar
 * The card occupies the same shape the finished image will, so when the picture
 * arrives it replaces the placeholder without the transcript jumping. A slim
 * progress row would reflow every message below it the moment a 1024×1024 PNG
 * landed — on a phone, mid-scroll, that loses the user's place.
 */
@Composable
fun ImageGenerationCard(
    prompt: String,
    modifier: Modifier = Modifier,
    /** Shown in the badge. Blank until the engine has committed to a size. */
    resolution: String = "",
    /** Engine name, so the user knows whether this cost them money. */
    engine: String = "",
    /**
     * The status line, already localised by the caller.
     *
     * Passed in rather than resolved here so this file stays free of `R` and can
     * be previewed and unit-tested without a Context -- and so the same card can
     * say "Generating image" during a run and "Upscaling" later without growing a
     * mode flag.
     */
    label: String,
    maxWidth: Dp = CanvasMaxWidth
) {
    val colors = SiriusTheme.colors
    val reduceMotion = SiriusTheme.reduceMotion

    // `ig-morph` at 4.2s and `ig-breathe` at 1.9s. The periods are deliberately
    // not multiples of each other: the highlight's travel and its brightness
    // drift in and out of phase, so the loop never visibly repeats. Locking them
    // to a shared period is the single fastest way to make this look cheap.
    val transition = rememberInfiniteTransition(label = "imageGen")
    val morph = if (reduceMotion) 0f else transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(MorphMs, easing = MorphEase),
            repeatMode = RepeatMode.Reverse
        ),
        label = "morph"
    ).value
    val breathe = if (reduceMotion) 1f else transition.animateFloat(
        initialValue = BreatheMin,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(BreatheMs, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathe"
    ).value
    val shine = if (reduceMotion) 0f else transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(ShineMs, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shine"
    ).value

    Column(
        modifier = modifier.widthIn(max = maxWidth),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = maxWidth)
                .aspectRatio(1f)
                .clip(RoundedCornerShape(SiriusRadius.md))
                .background(colors.surfaceMuted)
                .drawWithCache {
                    // The lattice is built once per size, not per frame.
                    //
                    // Drawn as individual circles this was ~360 `drawCircle` calls
                    // for a 208dp card, every frame, for the whole time a card was
                    // on screen. That is invisible on a flagship and is real,
                    // measurable jank on a Mali-G52 -- and the grid never changes,
                    // so paying for it once and replaying one path is strictly
                    // better. Only the two highlight blobs are per-frame now.
                    val lattice = buildDotLattice(
                        width = size.width,
                        height = size.height,
                        pitch = DotPitch.toPx(),
                        radius = DotRadius.toPx()
                    )
                    onDrawBehind {
                        drawPath(lattice, colors.textTertiary.copy(alpha = DotAlphaBase))
                        highlight(colors.textPrimary, morph, breathe)
                    }
                }
        ) {
            if (resolution.isNotBlank()) {
                Text(
                    text = resolution,
                    style = TextStyle(
                        // Monospace because the badge's width must not twitch as
                        // the digits change; proportional figures make a
                        // 1024x1024 badge visibly narrower than 896x1152.
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    ),
                    color = colors.textSecondary,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(SiriusSpacing.xs)
                        .clip(RoundedCornerShape(SiriusRadius.pill))
                        .background(colors.surface.copy(alpha = BadgeAlpha))
                        .padding(horizontal = SiriusSpacing.xs, vertical = 2.dp)
                )
            }
        }

        // `ig-shine`: a light band travelling through the label. Implemented as a
        // gradient *brush on the text* rather than an overlay, so it lights the
        // glyphs and not the space between them -- the same reason the canvas
        // masks a brighter grid instead of drawing a glow.
        val statusLine = if (engine.isBlank()) label else "$label · $engine"
        val labelStyle = MaterialTheme.typography.labelMedium.let { base ->
            // `merge` rather than `copy(brush = ...)`: the brush-bearing `copy`
            // overload is easy to bind ambiguously, and merging an otherwise empty
            // TextStyle is the documented way to layer a brush onto a typography
            // token without restating the rest of it.
            if (reduceMotion) base
            else base.merge(
                TextStyle(brush = shineBrush(colors.textTertiary, colors.textPrimary, shine))
            )
        }
        Text(
            text = statusLine,
            style = labelStyle,
            color = colors.textTertiary
        )

        if (prompt.isNotBlank()) {
            Text(
                text = prompt,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary,
                maxLines = 3
            )
        }
    }
}

/**
 * The static dot lattice, as a single reusable path.
 *
 * One path rather than N `drawCircle` calls, because this is replayed every frame
 * for as long as a card is visible and the geometry never moves. A
 * `Brush.radialGradient` tiled by the framework would be cheaper still and is
 * wrong: tiling quantises the pitch to whole pixels, so the grid develops visible
 * seams at most card widths.
 */
private fun buildDotLattice(
    width: Float,
    height: Float,
    pitch: Float,
    radius: Float
): Path {
    val path = Path()
    if (pitch <= 0f || width <= 0f || height <= 0f) return path
    var y = pitch / 2f
    while (y < height) {
        var x = pitch / 2f
        while (x < width) {
            path.addOval(
                Rect(
                    left = x - radius,
                    top = y - radius,
                    right = x + radius,
                    bottom = y + radius
                )
            )
            x += pitch
        }
        y += pitch
    }
    return path
}

/**
 * The two moving blobs of brighter dots.
 *
 * The same lattice is drawn again at a higher opacity, clipped to two soft
 * radial gradients that orbit on different, non-commensurate paths. Compose has
 * no mask primitive here, so the effect is built the other way round: the bright
 * dots are drawn *inside* a radial-gradient-filled layer, which multiplies the
 * two automatically.
 */
private fun DrawScope.highlight(color: Color, morph: Float, breathe: Float) {
    val blobs = listOf(
        Offset(
            x = size.width * (0.30f + 0.34f * morph),
            y = size.height * (0.34f + 0.22f * sin(morph * TwoPi).toFloat())
        ) to size.minDimension * (0.42f + 0.08f * morph),
        Offset(
            x = size.width * (0.70f - 0.28f * morph),
            y = size.height * (0.66f - 0.24f * cos(morph * TwoPi).toFloat())
        ) to size.minDimension * (0.34f + 0.10f * (1f - morph))
    )

    for ((centre, radius) in blobs) {
        drawCircle(
            brush = Brush.radialGradient(
                // A hard stop at 1f would draw a visible disc edge. The middle
                // stop is what gives the blob its soft shoulder.
                colorStops = arrayOf(
                    0f to color.copy(alpha = DotAlphaGlow * breathe),
                    0.55f to color.copy(alpha = DotAlphaGlow * breathe * 0.45f),
                    1f to Color.Transparent
                ),
                center = centre,
                radius = radius,
                tileMode = TileMode.Clamp
            ),
            radius = radius,
            center = centre
        )
    }
}

/** The travelling light band for the label. */
private fun shineBrush(base: Color, highlight: Color, progress: Float): Brush {
    // Swept across three widths so the band spends most of the cycle offscreen,
    // which is what makes it a periodic glint rather than a constant shimmer.
    val span = 3f
    val head = (progress * span) - 1f
    return Brush.linearGradient(
        colorStops = arrayOf(
            0f to base,
            (head - 0.18f).coerceIn(0f, 1f) to base,
            head.coerceIn(0f, 1f) to highlight,
            (head + 0.18f).coerceIn(0f, 1f) to base,
            1f to base
        ),
        start = Offset.Zero,
        end = Offset(600f, 0f)
    )
}

/** `--ig-canvas-max`: 208px in the reference. */
private val CanvasMaxWidth = 208.dp
private val DotPitch = 11.dp
private val DotRadius = 0.7.dp

/** `opacity: 0.22` on the base grid; the glow copy is brighter. */
private const val DotAlphaBase = 0.22f
private const val DotAlphaGlow = 0.16f

private const val BadgeAlpha = 0.72f

/** `ig-morph`, `ig-breathe`, `ig-shine`. */
private const val MorphMs = 4_200
private const val BreatheMs = 1_900
private const val ShineMs = 2_250
private const val BreatheMin = 0.55f

private val MorphEase = CubicBezierEasing(0.35f, 1.55f, 0.65f, 1f)

private const val TwoPi = 6.2831855f
