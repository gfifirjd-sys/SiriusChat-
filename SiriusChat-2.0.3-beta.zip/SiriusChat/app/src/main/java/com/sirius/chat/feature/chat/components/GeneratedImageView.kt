package com.sirius.chat.feature.chat.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.data.image.GeneratedImageStore

/**
 * Renders a `![alt](uri)` block from the transcript.
 *
 * ### Why decoding happens here and not in the repository
 * The obvious alternative is to decode every image when the message list loads
 * and hand the bubble a ready `ImageBitmap`. That puts a 4 MB bitmap per picture
 * into a `Flow` that re-emits on every streamed token, and holds all of them for
 * the lifetime of the screen regardless of scroll position. Decoding in the
 * composable ties the bitmap's life to the item being on screen, which is what
 * `LazyColumn` already manages well.
 *
 * ### Why there is no image loading library
 * The project has no Coil or Glide, and adding one for this would be a large
 * dependency for a narrow job: these files are local, already-sized PNGs that we
 * wrote ourselves. `BitmapFactory` with `inSampleSize` covers it in the store,
 * and the failure surface is smaller than a cache library's.
 *
 * Remote `http(s)` images are deliberately *not* fetched. A model can emit any
 * URL, and silently loading one would let a prompt-injected link phone home with
 * the user's IP the moment a message renders. Those degrade to a labelled link
 * the user can choose to open.
 */
@Composable
fun GeneratedImageView(
    alt: String,
    uri: String,
    store: GeneratedImageStore,
    modifier: Modifier = Modifier
) {
    val colors = SiriusTheme.colors

    if (!uri.startsWith(GeneratedImageStore.SCHEME)) {
        // Not one of ours: show it as text, not as a request.
        Text(
            text = if (alt.isBlank()) uri else "$alt — $uri",
            style = MaterialTheme.typography.bodySmall,
            color = colors.textTertiary,
            modifier = modifier
        )
        return
    }

    val context = LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<ImageBitmap?>(null) }
    var missing by remember(uri) { mutableStateOf(false) }

    LaunchedEffect(uri) {
        val file = store.resolve(uri)
        if (file == null) {
            // The file was pruned, or the model invented a name. Both end here,
            // and both must say so rather than leave an empty gap: a picture the
            // user remembers seeing and now cannot find is a bug report.
            missing = true
            return@LaunchedEffect
        }
        bitmap = store.decode(file)?.asImageBitmap()
        missing = bitmap == null
    }

    val loaded = bitmap
    // The reveal is a fade with a slight upward drift rather than a scale-in: a
    // photograph that grows into place draws attention to the animation, and the
    // picture is the content here, not the transition.
    val appear by animateFloatAsState(
        targetValue = if (loaded != null) 1f else 0f,
        animationSpec = siriusTween(SiriusMotion.Slow, SiriusMotion.Emphasized),
        label = "imageAppear"
    )

    Column(
        modifier = modifier.widthIn(max = MaxImageWidth),
        verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
    ) {
        when {
            loaded != null -> Image(
                bitmap = loaded,
                contentDescription = alt.ifBlank { stringResource(R.string.chat_image_generated) },
                contentScale = ContentScale.FillWidth,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(SiriusRadius.md))
                    .alpha(appear)
                    .graphicsLayer {
                        translationY = (1f - appear) * RevealDriftPx * density
                    }
            )

            missing -> Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(SiriusRadius.md))
                    .background(colors.surfaceMuted)
            ) {
                Text(
                    text = stringResource(R.string.chat_image_missing),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary,
                    modifier = Modifier.padding(SiriusSpacing.sm)
                )
            }

            // Still decoding. The generation card is reused so the transcript
            // shows the same shape it will settle into, and the layout does not
            // jump when the bitmap arrives a frame or two later.
            else -> ImageGenerationCard(
                prompt = alt,
                label = stringResource(R.string.chat_image_loading)
            )
        }

        if (alt.isNotBlank() && loaded != null) {
            Text(
                text = alt,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary,
                maxLines = 2
            )
        }
    }
}

private val MaxImageWidth = 320.dp
private const val RevealDriftPx = 10f

/**
 * The store, made ambient for the markdown renderer.
 *
 * ### Why a CompositionLocal rather than a parameter
 * Images are discovered deep inside [MarkdownText], which is called by
 * `MessageBubble`, which is called by the transcript, which is called by the
 * screen. Threading a store through all four means every one of them gains a
 * parameter it does not use, and every other caller of `MarkdownText` in the app
 * (the review sheet, the terminal output view) has to supply one too.
 *
 * This is the case CompositionLocal exists for: a process-wide singleton that a
 * leaf needs and no intermediate cares about. It is `staticCompositionLocalOf`
 * because the value never changes after startup, so no recomposition tracking is
 * warranted.
 *
 * The default throws rather than returning a no-op store. A silently missing
 * provider would show every generated image as "file not found" — a bug that
 * looks like a data problem and would be hunted in the wrong layer.
 */
val LocalGeneratedImageStore = staticCompositionLocalOf<GeneratedImageStore> {
    error("LocalGeneratedImageStore was not provided. Wire it in SiriusApp from AppContainer.")
}
