package com.sirius.chat.domain.model

enum class ThemeMode { System, Light, Dark }

/** How aggressive the liquid-glass layer is; lowest tier is the fastest. */
enum class GlassLevel { Off, Subtle, Full }

/**
 * UI language. [System] follows the device locale, the rest force one language
 * regardless of system settings. [tag] is a BCP-47 tag matching a `values-*`
 * resource folder; it is empty for [System].
 */
enum class AppLanguage(val tag: String) {
    System(""),
    English("en"),
    Russian("ru");

    companion object {
        fun ofTag(tag: String): AppLanguage =
            entries.firstOrNull { it.tag == tag } ?: System
    }
}

/**
 * Which engine the terminal runs commands with.
 *
 * [DeviceShell] always works but is confined to the app sandbox; [Termux] gives
 * up streaming output and process control in exchange for a real toolchain.
 */
enum class TerminalEngine { DeviceShell, Termux }

data class AppSettings(
    val language: AppLanguage = AppLanguage.System,
    val themeMode: ThemeMode = ThemeMode.System,
    /**
     * Interface accent as an ARGB int, or 0 for the monochrome default.
     *
     * This replaced the Material You switch. A wallpaper scheme could only ever
     * reach four palette slots, and which four was unpredictable; an explicit
     * colour lands on the same four, visibly and reproducibly.
     */
    val accentColor: Int = 0,
    val glassLevel: GlassLevel = GlassLevel.Full,
    val reduceMotion: Boolean = false,
    val hapticsEnabled: Boolean = true,
    val streamingEnabled: Boolean = true,
    val activeProviderId: String = "",
    val activeModel: String = "",
    val temperature: Float = 0.3f,
    val maxTokens: Int = 4096,
    val agentAutoApproveReads: Boolean = true,
    /**
     * Write agent proposals straight to disk instead of queueing them for review.
     *
     * Defaults to off, and stays off after an update, because it removes the only
     * checkpoint between a model's mistake and the user's files. Deletion is the
     * part that has no undo: SAF has no trash, so an auto-applied `delete_file`
     * is gone unless the folder happens to be a Git repository.
     */
    val agentAutoApplyChanges: Boolean = false,
    val agentMaxSteps: Int = 6,
    /**
     * What a *new* chat's internet switch starts as.
     *
     * Off by default, and that is a deliberate choice against convenience. A
     * search runs before the model answers, so it adds latency to every reply,
     * and it sends a query derived from the user's message to a third party. Both
     * are fine when asked for and both are surprising when they arrive by
     * default -- particularly on the local-model setups where users pick Ollama
     * precisely so nothing leaves the device.
     *
     * The switch is one tap away in the chat's own panel, which is the right cost
     * for something with those two properties.
     */
    val defaultWebSearch: Boolean = false,
    /**
     * What a new chat's image switch starts as.
     *
     * Off, because when the provider sells images this spends real money per
     * call, and a model that sees the tool available will reach for it on a
     * borderline request ("show me how this looks") that the user meant
     * rhetorically.
     */
    val defaultImageGeneration: Boolean = false,
    val editorFontSize: Int = 14,
    val editorTabSize: Int = 4,
    val editorWordWrap: Boolean = false,
    val editorLineNumbers: Boolean = true,
    val editorAutoSave: Boolean = false,
    val terminalFontSize: Int = 13,
    val terminalEngine: TerminalEngine = TerminalEngine.DeviceShell,
    /**
     * Whether the one-off Termux background-mode explanation has been read.
     *
     * Termux is a separate app: once Android stops it, RUN_COMMAND silently
     * stops producing results and the terminal looks broken rather than
     * throttled. The explanation is therefore shown once, the first time the
     * user picks the Termux engine, and never again.
     */
    val termuxBackgroundNoticeShown: Boolean = false,
    val activeProjectId: String = "",
    /** `owner/name` of the repository the GitHub screen is pointed at. */
    val githubRepo: String = "",
    val onboardingDone: Boolean = false
)
