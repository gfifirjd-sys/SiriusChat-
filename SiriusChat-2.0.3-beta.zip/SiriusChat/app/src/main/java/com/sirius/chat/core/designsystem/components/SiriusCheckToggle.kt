package com.sirius.chat.core.designsystem.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusTheme
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

/**
 * The check mark from `transitions.dev/detail.html?t=checkbox-check`.
 *
 * ### Why this is a hand-drawn Canvas and not a Material Switch
 * The transition being reproduced is not "a control changes state", it is a
 * three-second-long *sentence*: a ring spins while something is being decided, a
 * green disc swells in under it, the whole badge overshoots and bobs, and only
 * then does a stroke draw itself through the middle. Material's `Switch` and
 * `Checkbox` animate a thumb and a tick with fixed, unreachable internals — there
 * is no parameter that gets you a spinner phase, and no way to sequence the disc
 * against the stroke.
 *
 * So the geometry is drawn directly. That also makes the spinner phase honest:
 * these switches trigger real work (a capability re-check, a settings write), and
 * a control that shows a spinner while that happens is telling the truth in the
 * same gesture that confirms the tap.
 *
 * ### The timings are copied, not invented
 * Every constant below is lifted from the reference. They are unusual on purpose
 * and the unusual parts are what make it read as expensive:
 *
 *  - the disc's ease and the scale's ease **differ** (`1.35` vs `1.96` overshoot),
 *    so the badge grows past its size slightly after the colour lands rather than
 *    with it;
 *  - the stroke starts at 230ms — *before* the bob finishes — so the check is
 *    already being drawn while the badge is still settling. Sequencing them
 *    strictly would add 250ms of dead air and lose the whole effect;
 *  - the return half of the bob uses a violent `2.56` overshoot over 300ms,
 *    which is what produces the small physical "tock" at the end.
 *
 * ### Reduce motion
 * Collapses to the final frame: filled disc, complete check, no spinner, no bob.
 * The state is still legible — that is the point of the setting — but nothing
 * moves. This is checked at every animation site rather than once at the top,
 * because the composable is also used in a static (already-on) state where there
 * is nothing to animate in the first place.
 */
@Composable
fun SiriusCheckToggle(
    checked: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 22.dp,
    /**
     * True while the tap's side effect is still running.
     *
     * The reference plays a spinner unconditionally before the check. Here it is
     * driven by real work: if the caller has nothing to wait for, the spinner
     * phase is skipped entirely rather than faked for 900ms. A fake spinner is a
     * lie about latency, and it makes a fast app feel slow.
     */
    busy: Boolean = false,
    accent: Color? = null
) {
    val colors = SiriusTheme.colors
    val reduceMotion = SiriusTheme.reduceMotion
    val discColor = accent ?: CheckGreen

    // One driver for the whole sequence. Three separate `animateFloatAsState`
    // calls cannot express "the stroke starts before the bob ends" without
    // hand-held delays that drift apart after the first interruption; an
    // Animatable per phase launched from one effect keeps them on the same clock
    // and, crucially, makes an interrupted toggle animate back from wherever it
    // actually was.
    val disc = remember { Animatable(if (checked) 1f else 0f) }
    val stroke = remember { Animatable(if (checked) 1f else 0f) }
    val bob = remember { Animatable(0f) }
    val pop = remember { Animatable(if (checked) 1f else 0f) }

    LaunchedEffect(checked, reduceMotion) {
        if (reduceMotion) {
            // Snap, do not animate. `snapTo` rather than a zero-duration tween so
            // no frame is scheduled at all.
            disc.snapTo(if (checked) 1f else 0f)
            stroke.snapTo(if (checked) 1f else 0f)
            pop.snapTo(if (checked) 1f else 0f)
            bob.snapTo(0f)
            return@LaunchedEffect
        }

        if (!checked) {
            // Switching off is not the sequence in reverse. Reversing it would
            // un-draw the stroke over 600ms and bob the badge again, which reads
            // as a second confirmation of the opposite thing. Off is a plain,
            // quick fade -- the state is gone, there is nothing to celebrate.
            coroutineScope {
                launch { disc.animateTo(0f, tween(OffMs, easing = EaseOut)) }
                launch { stroke.animateTo(0f, tween(OffMs, easing = EaseOut)) }
                launch { pop.animateTo(0f, tween(OffMs, easing = EaseOut)) }
                launch { bob.animateTo(0f, tween(OffMs, easing = EaseOut)) }
            }
            return@LaunchedEffect
        }

        coroutineScope {
            // Disc: colour arrives first and alone.
            launch { disc.animateTo(1f, tween(DiscMs, easing = SpringishSoft)) }

            // Scale: same start, harder overshoot, so the swell trails the colour.
            launch { pop.animateTo(1f, tween(PopMs, easing = SpringishHard)) }

            // Bob: up, then a sharp settle back down.
            launch {
                bob.animateTo(1f, tween(BobUpMs, easing = SpringishSoft))
                bob.animateTo(0f, tween(BobDownMs, easing = SpringishSnap))
            }

            // Stroke: deliberately overlapping the bob's tail.
            launch {
                kotlinx.coroutines.delay(StrokeDelayMs.toLong())
                stroke.animateTo(1f, tween(StrokeMs, easing = EaseOutQuint))
            }
        }
    }

    // The spinner is an independent loop rather than part of the sequence above:
    // it has no end state to animate towards and must not be restarted every time
    // `checked` changes.
    val spin = if (busy && !reduceMotion) {
        val transition = rememberInfiniteTransition(label = "checkSpin")
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(SpinMs, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "checkSpinAngle"
        ).value
    } else {
        0f
    }
    val spinnerAlpha = if (busy) 1f else 0f

    Box(modifier = modifier.size(size)) {
        Canvas(
            modifier = Modifier
                .size(size)
                // Read in the draw phase, so the bob and the swell cost no
                // recomposition and no relayout -- the entire animation is one
                // extra draw per frame.
                .graphicsLayer {
                    val scale = 1f + (PopOvershoot - 1f) * pop.value
                    scaleX = scale
                    scaleY = scale
                    translationY = -BobDistancePx * density * bob.value
                }
        ) {
            val diameter = this.size.minDimension
            val centre = Offset(diameter / 2f, diameter / 2f)
            val ringWidth = diameter * RingWidthRatio
            val radius = (diameter - ringWidth) / 2f

            // The empty ring, faded out as the disc takes over. It is drawn even
            // at zero disc so an unchecked switch is still a visible affordance
            // rather than blank space.
            if (disc.value < 1f) {
                drawCircle(
                    color = colors.outline.copy(alpha = (1f - disc.value) * RingAlpha),
                    radius = radius,
                    center = centre,
                    style = Stroke(width = ringWidth)
                )
            }

            // The spinner arc: one quarter of the ring, rotating.
            if (spinnerAlpha > 0f) {
                rotate(degrees = spin, pivot = centre) {
                    drawArc(
                        color = colors.textTertiary.copy(
                            alpha = spinnerAlpha * (1f - disc.value)
                        ),
                        startAngle = -90f,
                        sweepAngle = 90f,
                        useCenter = false,
                        topLeft = Offset(ringWidth / 2f, ringWidth / 2f),
                        size = Size(radius * 2f, radius * 2f),
                        style = Stroke(width = ringWidth, cap = StrokeCap.Round)
                    )
                }
            }

            // The filled disc.
            if (disc.value > 0f) {
                drawCircle(
                    color = discColor.copy(alpha = disc.value),
                    // Grown from the ring's inner edge to the full badge, so the
                    // fill visibly swallows the outline instead of appearing
                    // behind it.
                    radius = radius + ringWidth / 2f * disc.value,
                    center = centre
                )
            }

            // The check itself, drawn as a partial path.
            if (stroke.value > 0f) {
                val path = checkPath(diameter)
                // `PathMeasure` is what turns a CSS stroke-dashoffset animation
                // into a Compose one: taking a prefix of the path is exactly what
                // the browser does with a dash array the length of the stroke.
                val measure = PathMeasure().apply { setPath(path, false) }
                val visible = Path()
                measure.getSegment(0f, measure.length * stroke.value, visible, true)
                drawPath(
                    path = visible,
                    color = CheckInk,
                    style = Stroke(
                        width = diameter * CheckWidthRatio,
                        cap = StrokeCap.Round,
                        join = androidx.compose.ui.graphics.StrokeJoin.Round
                    )
                )
            }
        }
    }
}

/**
 * The reference's tick, scaled and centred inside the badge.
 *
 * The source path is `M1 5.52L3.92 9.17L9.17 1` on a 10-unit box. Kept as those
 * exact numbers rather than re-derived from thirds, because this particular
 * asymmetry -- a short stub down-left, a long sweep up-right, neither arm at 45
 * degrees -- is most of why the mark looks drawn rather than geometric.
 *
 * ### Two things this has to get right, and both were wrong before
 * **The origin.** The glyph's own coordinates start at 1, not 0, so mapping
 * `v -> v * unit` places it a whole unit down and to the right. At a 22dp badge
 * that is a 2.2dp shift, which pushed the long arm's tip past the right edge of
 * the disc entirely.
 *
 * **The scale.** The 10-unit box is not the badge. Scaling the box to the full
 * diameter gives a tick spanning 82% of it -- but the disc is a *circle*, and a
 * glyph that wide has its corners outside the inscribed area, so the arms
 * visibly break the edge. The reference draws roughly a 10px tick in a 22px
 * circle, so the span is set from the diameter directly at [CheckSpanFraction].
 *
 * Both are centred on the glyph's real extent (1..9.17), not on its nominal box,
 * so the optical centre lands on the disc's centre.
 */
private fun checkPath(diameter: Float): Path {
    val unit = diameter * CheckSpanFraction / CheckGlyphSpan
    val span = CheckGlyphSpan * unit
    val origin = (diameter - span) / 2f - CheckGlyphMin * unit
    fun p(v: Float) = origin + v * unit
    return Path().apply {
        moveTo(p(1f), p(5.52f))
        lineTo(p(3.92f), p(9.17f))
        lineTo(p(9.17f), p(1f))
    }
}

// --------------------------------------------------------------- reference tokens

/** `--pv4u-done-bg`: the reference green. Not the theme's success colour, which
 *  is tuned for text on a dark surface and reads muddy as a large fill. */
private val CheckGreen = Color(0xFF35BA00)

/** The tick is always white: it sits on the green disc in both themes. */
private val CheckInk = Color(0xFFFFFFFF)

/** The glyph's own extent: x and y both run 1..9.17 in the source path. */
private const val CheckGlyphMin = 1f
private const val CheckGlyphSpan = 8.17f

/**
 * How much of the badge's diameter the tick spans.
 *
 * The reference draws about a 10px mark in a 22px circle. Anything much above
 * this puts the arms outside the inscribed circle and the tick breaks the disc's
 * edge; much below and it reads as a dot.
 */
private const val CheckSpanFraction = 0.46f

/** `--pv4u-ring-w`: 2.5 on a 22px badge. */
private const val RingWidthRatio = 2.5f / 22f
private const val RingAlpha = 0.55f

/**
 * `stroke-width: 2` on the same badge.
 *
 * Held against the diameter rather than the glyph, so shrinking the tick to fit
 * the circle makes it proportionally bolder -- which is what the reference looks
 * like, and what keeps it legible at 22dp.
 */
private const val CheckWidthRatio = 2.1f / 22f

/** `--pv4u-disc-in`. */
private const val DiscMs = 350

/** `--pv4u-pop`. */
private const val PopMs = 350
private const val PopOvershoot = 1.09f

/** `--pv4u-bob-up` / `--pv4u-bob-down`, and the 3px travel. */
private const val BobUpMs = 250
private const val BobDownMs = 300
private const val BobDistancePx = 3f

/** `--pv4u-draw`, and its start relative to the disc. */
private const val StrokeMs = 600
private const val StrokeDelayMs = 230

/** `--pv4u-spin`. */
private const val SpinMs = 900

/** Switching off is not the sequence reversed; see the effect above. */
private const val OffMs = 180

/** `cubic-bezier(0.34, 1.35, 0.64, 1)` — the soft overshoot. */
private val SpringishSoft: Easing = CubicBezierEasing(0.34f, 1.35f, 0.64f, 1f)

/** `cubic-bezier(0.34, 1.96, 0.94, 1)` — the swell. */
private val SpringishHard: Easing = CubicBezierEasing(0.34f, 1.96f, 0.94f, 1f)

/** `cubic-bezier(0.14, 2.56, 0.94, 1)` — the settle back down. */
private val SpringishSnap: Easing = CubicBezierEasing(0.14f, 2.56f, 0.94f, 1f)

/** `cubic-bezier(0.22, 1, 0.36, 1)` — the stroke draw. */
private val EaseOutQuint: Easing = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)

private val EaseOut: Easing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)
